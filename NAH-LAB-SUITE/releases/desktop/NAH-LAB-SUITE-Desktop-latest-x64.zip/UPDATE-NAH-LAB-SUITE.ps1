param([Parameter(Mandatory=$true)][string]$Payload)
$ErrorActionPreference='Stop'
function Fail([string]$m){ try { Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue; [System.Windows.MessageBox]::Show($m,'NAH LAB SUITE') | Out-Null } catch {} ; exit 1 }
try {
  if(-not $Payload.StartsWith('nahlab-update:')){ Fail 'Gói lệnh cập nhật không hợp lệ.' }
  $raw=[uri]::UnescapeDataString($Payload.Substring('nahlab-update:'.Length))
  $m=$raw | ConvertFrom-Json
  $u=[uri]$m.url
  if($u.Scheme -ne 'https' -or @('sachyhoc.com','www.sachyhoc.com') -notcontains $u.Host.ToLower()){ Fail 'Nguồn cập nhật không hợp lệ.' }
  if(([string]$m.sha256) -notmatch '^[A-Fa-f0-9]{64}$'){ Fail 'Thiếu mã kiểm tra SHA-256.' }
  $root=Split-Path -Parent $MyInvocation.MyCommand.Path
  $work=Join-Path $env:LOCALAPPDATA 'NAH LAB SUITE\Updates'
  New-Item -ItemType Directory -Force -Path $work | Out-Null
  $zip=Join-Path $work ('NAH-LAB-SUITE-'+[string]$m.version+'.zip')
  $stage=Join-Path $work ('stage-'+[string]$m.version)
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Invoke-WebRequest -UseBasicParsing -Uri $u.AbsoluteUri -OutFile $zip
  $got=(Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLowerInvariant()
  if($got -ne ([string]$m.sha256).ToLowerInvariant()){ Remove-Item $zip -Force -ErrorAction SilentlyContinue; Fail 'Gói cập nhật không vượt qua kiểm tra SHA-256.' }
  Expand-Archive -Path $zip -DestinationPath $stage -Force
  $newExe=Get-ChildItem -Path $stage -Filter 'NAH-LAB-SUITE.exe' -Recurse | Select-Object -First 1
  if(-not $newExe){ Fail 'Gói cập nhật không có tệp ứng dụng hợp lệ.' }
  $packageRoot=Split-Path -Parent $newExe.FullName
  Start-Sleep -Seconds 3
  $ok=$false
  for($i=0;$i -lt 25 -and -not $ok;$i++){
    try {
      Copy-Item -Path (Join-Path $packageRoot 'NAH-LAB-SUITE.exe') -Destination (Join-Path $root 'NAH-LAB-SUITE.exe') -Force
      if(Test-Path (Join-Path $packageRoot 'offline')){
        Remove-Item (Join-Path $root 'offline') -Recurse -Force -ErrorAction SilentlyContinue
        Copy-Item (Join-Path $packageRoot 'offline') (Join-Path $root 'offline') -Recurse -Force
      }
      if(Test-Path (Join-Path $packageRoot 'UPDATE-NAH-LAB-SUITE.ps1')){
        Copy-Item (Join-Path $packageRoot 'UPDATE-NAH-LAB-SUITE.ps1') (Join-Path $root 'UPDATE-NAH-LAB-SUITE.ps1') -Force
      }
      $ok=$true
    } catch { Start-Sleep -Seconds 1 }
  }
  if(-not $ok){ Fail 'Không thể thay thế tệp ứng dụng. Kiểm tra quyền ghi của thư mục NAH LAB SUITE.' }
  Start-Process -FilePath (Join-Path $root 'NAH-LAB-SUITE.exe')
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
} catch { Fail ('Cập nhật không thành công: '+$_.Exception.Message) }

(()=>{'use strict';
const API='https://sachyhoc.com/wp-json/nah-iso15189/v1/';
const nativeFetch=window.fetch.bind(window);
let content=window.NAH_OFFLINE_CONTENT||{};
const DB_NAME='nah-lab-desktop-cache-v2', STORE='kv';
const DATASET_MANIFEST='desktop/dataset/manifest', UPDATE_MANIFEST='app/update-manifest';
const SESSION_TOKEN='nahLabDesktopToken', SESSION_USER='nahLabDesktopUser';
const REMEMBERED_SESSION='nahLabDesktopRememberedLocalSession';
const RUN_VALIDATED='nahLabDesktopValidatedThisLaunch';
const MAX_REMEMBER_MS=30*24*60*60*1000;
const CACHE_PREFIX='api:';
const CORE_REFRESH_MS=5*60*1000;
const DEEP_REFRESH_MS=12*60*60*1000;
const CONTENT_REFRESH_MS=24*60*60*1000;
const INITIAL_CORE_DELAY_MS=350;
const INITIAL_DEEP_DELAY_MS=30000;
const DESKTOP_VERSION='1.3.1';
let dbPromise=null;
let volatileCredentials=null;
let rememberRequestedThisRun=false;
let syncInFlight=false;
let syncQueued=false;
let syncDebounceTimer=null;
let deepSyncInFlight=false;
let deepSyncTimer=null;
const PREFETCH=[
 'dashboard/snapshot','dashboard','quality-core/compliance','quality-core/summary','quality-core/management-review',
 'evidence-control/summary','evidence-control/retention-rules','evidence-control/external-documents','evidence-control/document-master',
 'cert-progress/overview','document-plan/summary','document-plan/overview','records?module=isoforms','records?module=qd2429',
 'records?module=documents','records?module=forms','records?module=tasks','records?module=projects','records?module=indicators',
 'records?module=incidents','records?module=risks','records?module=nc','records?module=capa','records?module=audits','records?module=meetings',
 'records?module=training','records?module=equipment','records?module=suppliers','team','competency/overview','competency/items','competency/assignments',
 'resources/overview','resources/equipment','resources/reagents','method-quality/overview','method-quality/methods','process-assurance/overview',
 'discussions','notifications','activity?limit=300','knowledge/implementation','knowledge/qd2429/assessment'
];
function db(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>{dbPromise=null;reject(r.error)}});return dbPromise}
async function get(k,d=null){try{const x=await db();return await new Promise((res,rej)=>{const t=x.transaction(STORE,'readonly').objectStore(STORE).get(k);t.onsuccess=()=>res(t.result===undefined?d:t.result);t.onerror=()=>rej(t.error)})}catch(_e){return d}}
async function set(k,v){try{const x=await db();return await new Promise((res,rej)=>{const tx=x.transaction(STORE,'readwrite'),st=tx.objectStore(STORE);st.put(v,k);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error)})}catch(_e){return false}}
async function setMany(entries){if(!entries?.length)return true;try{const x=await db();return await new Promise((res,rej)=>{const tx=x.transaction(STORE,'readwrite'),st=tx.objectStore(STORE);for(const [k,v] of entries)st.put(v,k);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error)})}catch(_e){return false}}
async function deleteByPrefixes(prefixes=[]){try{const x=await db();return await new Promise((res,rej)=>{const tx=x.transaction(STORE,'readwrite'),st=tx.objectStore(STORE),rq=st.openCursor();rq.onsuccess=()=>{const c=rq.result;if(!c)return;const k=String(c.key||'');if(prefixes.some(p=>k.startsWith(p)))c.delete();c.continue()};rq.onerror=()=>rej(rq.error);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error)})}catch(_e){return false}}
async function activateVault(user){const ref=String(user?.ref||'');if(!ref)return false;const old=String(await get('vault:userRef','')||'');if(old&&old!==ref){await deleteByPrefixes(['api:','sync:','queue:','dataset:']);try{localStorage.removeItem('nahLabLearning')}catch(_e){}}await set('vault:userRef',ref);return true}
function sget(k,d=''){try{return sessionStorage.getItem(k)||d}catch(_e){return d}}function sset(k,v){try{if(v===null)sessionStorage.removeItem(k);else sessionStorage.setItem(k,v)}catch(_e){}}
function lget(k,d=null){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(_e){return d}}function lset(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(_e){}}
function token(){return sget(SESSION_TOKEN,'')}function currentUser(){try{return JSON.parse(sget(SESSION_USER,'null'))}catch(_e){return null}}
function normUserName(v){return String(v||'').trim().toLowerCase()}
function clearRememberedSession(){try{localStorage.removeItem(REMEMBERED_SESSION)}catch(_e){}}
function validatedThisRun(){return sget(RUN_VALIDATED,'')==='1'}
function markValidated(){sset(RUN_VALIDATED,'1')}
function clearRuntimeAuth({clearRemembered=false}={}){sset(SESSION_TOKEN,null);sset(SESSION_USER,null);sset(RUN_VALIDATED,null);volatileCredentials=null;rememberRequestedThisRun=false;if(clearRemembered)clearRememberedSession()}
function rememberedSession(){const rec=lget(REMEMBERED_SESSION,null);if(!rec)return null;const exp=Number(rec.expiresAt||0),saved=Number(rec.savedAt||0),tok=String(rec.token||''),u=rec.user||null;if(!/^[a-f0-9]{64}$/i.test(tok)||!u?.ref||u?.isWpAdmin||!String(u.ref).startsWith('app:')||exp<=Date.now()||!saved||exp-saved>MAX_REMEMBER_MS+60000){clearRememberedSession();return null}return rec}
function restoreRememberedSession(){const rec=rememberedSession();if(!rec)return false;sset(SESSION_TOKEN,rec.token);sset(SESSION_USER,JSON.stringify(rec.user));return true}
function saveRememberedSession(username,j){if(!j?.token||!j?.user||j.user?.isWpAdmin||!String(j.user.ref||'').startsWith('app:')){clearRememberedSession();return false}const serverExp=Date.parse(j.expiresAt||'');const now=Date.now();const expiresAt=Math.min(Number.isFinite(serverExp)?serverExp:now+MAX_REMEMBER_MS,now+MAX_REMEMBER_MS);lset(REMEMBERED_SESSION,{schema:'nah-lab-desktop-remember/v1',username:normUserName(username),token:String(j.token).toLowerCase(),user:j.user,savedAt:now,expiresAt});return true}
function json(obj,status=200,headers={}){return new Response(JSON.stringify(obj),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}})}
function methodOf(init){return String(init?.method||'GET').toUpperCase()}
function normalizeRel(url){try{const u=new URL(typeof url==='string'?url:url.url,location.href);if(u.href.startsWith(API))return u.href.slice(API.length);return null}catch(_e){return null}}
function bootstrap(){const u=currentUser();if(!u)return null;return {version:content.version||'1.47',user:{...u,csrf:u.csrf||''},users:[u],assignableUsers:[],roles:[],departments:[],permissionCatalog:{},modules:[],canManageModules:[],drive:{connected:false,folderId:''},notifications:{unread:0},app:{name:'NAH LAB SUITE',hospital:'Bệnh viện Hữu nghị Đa khoa Nghệ An - Giai đoạn 2',department:'Khoa Xét nghiệm'},desktop:{localCache:true,version:DESKTOP_VERSION}}}
function progressMap(snapshot){const m={};for(const x of (snapshot?.learningProgress||[]))m[x.lesson_slug]=x;try{const local=JSON.parse(localStorage.getItem('nahLabLearning')||'{}');for(const [slug,yes] of Object.entries(local))if(yes)m[slug]={status:'completed',score:null,attempts:1}}catch(_e){}return m}
function qdDefault(){const q=content.qd2429||{},criteria={};for(const c of (q.criteria||[]))criteria[c.code]={...c,result:'unassessed',score:null,note:'',evidence_url:''};return {period:String(new Date().getFullYear()),status:'draft',criteria,chapters:[],totals:{criteria:Object.keys(criteria).length,assessed:0,achieved_points:0,applicable_max_points:268,normative_max_points:268,not_applicable:0,percent:0,complete:false,mandatory_one_star_ok:false,mandatory_three_star_ok:false}}}
function pseudoIsoRecords(){return (content.requirements||[]).map((x,i)=>({id:900000+i,module:'iso',code:x.clause,title:x.title||x.requirement_summary||('Điều '+x.clause),description:x.requirement_summary||'',status:'new',priority:'normal',progress:0,due_date:null,owner_ref:null,owner_name:'',data:{clause:x.clause,guidance:x}}))}
function snapshotRecords(snapshot){return Array.isArray(snapshot?.records)?snapshot.records:[]}
function recordBundle(r,snapshot){if(!r)return null;const id=+r.id;return {...r,assignments:(snapshot?.assignments||[]).filter(x=>+x.record_id===id),comments:(snapshot?.comments||[]).filter(x=>+x.record_id===id),evidence:(snapshot?.evidence||[]).filter(x=>+x.record_id===id)}}
function staticCompliance(snapshot){const cached=snapshot?.compliance?.items;if(Array.isArray(cached))return snapshot.compliance;const recs=snapshotRecords(snapshot);const isoBy=new Map(recs.filter(x=>x.module==='iso').map(x=>[String(x.code||x.data?.clause||''),x]));const items=(content.requirements||[]).map(x=>{const r=isoBy.get(String(x.clause));const st=r?.data?.compliance_states||{};const states={understand:st.understand||'pending',procedure:st.procedure||'pending',assignment:st.assignment||'pending',evidence:st.evidence||'pending',effectiveness:st.effectiveness||'pending'};const done=Object.values(states).filter(v=>['ready','verified','not_applicable'].includes(v)).length;return {clause:x.clause,title:x.title||x.requirement_summary,states,readiness:Math.round(done*20),owner_ref:r?.owner_ref||'',due_date:r?.due_date||null,note:r?.description||'',has_evidence:false,related_counts:{documents:0,forms:0,tasks:0,risks:0,nc:0,capa:0}}});return {items,total:items.length,ready:items.filter(x=>x.readiness===100).length}}
function dashboardSnapshot(snapshot){const records=snapshotRecords(snapshot), tasks=records.filter(x=>['tasks','iso'].includes(x.module));const iso=records.filter(x=>x.module==='iso');const learning=progressMap(snapshot), totalL=(content.learning||[]).length, doneL=Object.values(learning).filter(x=>x?.status==='completed').length;const qsum={risk:{open:records.filter(x=>x.module==='risks'&&!['done','closed'].includes(x.status)).length,high_critical:0},audit:{open:records.filter(x=>x.module==='audits'&&!['done','closed'].includes(x.status)).length,open_findings:records.filter(x=>x.module==='nc'&&!['done','closed'].includes(x.status)).length},capa:{open:records.filter(x=>x.module==='capa'&&!['done','closed'].includes(x.status)).length,overdue:0,awaiting_effectiveness:0,ineffective:0},management_review:{readiness_pct:0,total:10}};return {dashboard:{readiness:{isoAssigned:iso.filter(x=>x.owner_ref).length,isoTotal:144,isoComplete:iso.filter(x=>['done','approved','closed'].includes(x.status)).length,documentsApproved:records.filter(x=>['documents','forms'].includes(x.module)&&['approved','issued'].includes(x.status)).length,learningCompleted:doneL,learningTotal:totalL,internalReadiness:0,assignedPct:0,evidencePct:0,completePct:0,learningPct:totalL?Math.round(doneL*100/totalL):0},competency:{competencyPct:0},methodQuality:{iqcOut:0,openDeviations:0},processAssurance:{rejected:0,criticalOpen:0},byModule:Object.fromEntries([...new Set(records.map(x=>x.module))].map(m=>[m,records.filter(x=>x.module===m).length])),focus:tasks.slice(0,8),resources:{calDue:0}},team:{members:[],totals:{}},quality:qsum,evidence:{counts:{evidence_total:(snapshot?.evidence||[]).length,retention_due:0}},roadmap:{steps:[],canManage:false},cert:{counts:{done:0,total:0}},docplan:{counts:{issued:0,total:0}}}}
async function localResponse(rel){const snapshot=await get('sync:snapshot',{});const key=CACHE_PREFIX+rel;const cached=await get(key,null);if(cached!==null)return cached;
 const path=rel.split('?')[0], params=new URLSearchParams(rel.includes('?')?rel.slice(rel.indexOf('?')+1):'');
 if(path==='bootstrap')return bootstrap();
 if(path==='dashboard/snapshot')return dashboardSnapshot(snapshot);
 if(path==='dashboard')return dashboardSnapshot(snapshot).dashboard;
 if(path==='knowledge/handbook')return {chapters:content.handbook||[],procedures:content.procedures||[],recordsCatalog:content.recordsCatalog||[],formTemplates:content.isoForms||[],snapshot:content.sourceSnapshot||{}};
 if(path==='knowledge/learning'){const pm=progressMap(snapshot),lessons=(content.learning||[]).map(l=>({...l,progress:pm[l.slug]||{status:'not_started',score:null,attempts:0}}));return {lessons,completed:lessons.filter(x=>x.progress?.status==='completed').length,total:lessons.length}}
 if(path==='knowledge/qd2429')return {...(content.qd2429||{}),form_hub:content.qdForms||{},shared_iso_forms:content.isoForms||[]};
 if(path==='knowledge/qd2429/assessment')return snapshot?.qd2429Assessment||qdDefault();
 if(path==='knowledge/sources')return {connected:false,items:[],archives:content.archiveCatalog||[],procedures:content.procedures||[],recordsCatalog:content.recordsCatalog||[],formTemplates:content.isoForms||[],snapshot:content.sourceSnapshot||{}};
 if(path==='knowledge/implementation')return {plan:content.implementation||{},project:null,tasks:snapshotRecords(snapshot).filter(x=>x.module==='tasks'&&String(x.code||'').startsWith('ISO-PLAN-')),canSeed:false};
 if(path==='knowledge/context'){const clause=params.get('clause')||'';const req=(content.requirements||[]).find(x=>x.clause===clause)||{};const hand=(content.handbook||[]).filter(x=>(x.clauses||[]).some(c=>String(clause).startsWith(String(c))||String(c).startsWith(clause)));const forms=(content.isoForms||[]).filter(x=>(x.clauses||[]).some(c=>String(clause).startsWith(String(c))||String(c).startsWith(clause)));return {clause,requirement:req,references:req.source_links||[],handbook:hand,procedures:[],records:[],sources:[],archives:[],formHub:{templates:forms},liveSourcesDeferred:true}}
 if(path==='quality-core/compliance')return staticCompliance(snapshot);
 if(path==='quality-core/summary')return {risk:{open:0,high_critical:0},audit:{open:0,open_findings:0},capa:{open:0,overdue:0,awaiting_effectiveness:0,ineffective:0},management_review:{readiness_pct:0,total:10},compliance:{ready:0,total:144}};
 if(path==='quality-core/management-review')return {readiness_pct:0,inputs:[]};
 if(path==='evidence-control/summary')return {counts:{evidence_total:(snapshot?.evidence||[]).length,retention_due:0,external_documents:0,document_master:0}};
 if(path==='evidence-control/retention-rules')return {items:[]};
 if(path==='evidence-control/external-documents')return {items:[]};
 if(path==='evidence-control/document-master')return {items:[]};
 if(path==='cert-progress/overview')return content.certificationProgress||{counts:{done:0,total:0},items:[]};
 if(path==='document-plan/summary'||path==='document-plan/overview')return content.documentPlan||{counts:{issued:0,total:0},groups:[],items:[]};
 if(path==='team')return {members:[],totals:{staff:0,activeTasks:0,overdue:0,due7:0,supportRequests:0},canManage:false,safeCaps:[]};
 if(path==='competency/overview')return {summary:{},items:[],assignments:[]};
 if(path==='competency/items'||path==='competency/assignments')return [];
 if(path==='resources/overview')return {summary:{},equipment:[],reagents:[],lots:[]};
 if(path==='resources/equipment'||path==='resources/reagents')return [];
 if(path==='method-quality/overview')return {summary:{},methods:[],iqc:{},eqa:{},deviations:[]};
 if(path==='method-quality/methods')return [];
 if(path==='process-assurance/overview')return {summary:{},samples:[],tat:[],critical_results:[],amendments:[],referrals:[],complaints:[],downtime:[],timeline:[],canRecord:false,canManage:false};
 if(path==='drive/files')return {connected:false,files:[]};
 if(path==='discussions'||path==='notifications'||path==='activity')return [];
 if(path==='search'){const q=(params.get('q')||'').toLowerCase();const results=[];for(const x of content.requirements||[])if(`${x.clause} ${x.title} ${x.requirement_summary}`.toLowerCase().includes(q))results.push({type:'iso',id:x.clause,title:`${x.clause} · ${x.title}`,subtitle:x.requirement_summary||''});for(const x of content.learning||[])if(`${x.title} ${x.overview}`.toLowerCase().includes(q))results.push({type:'learning',id:x.slug,title:x.title,subtitle:x.module_title||''});return {results:results.slice(0,30)}}
 if(path==='records'){let rows=snapshotRecords(snapshot);const module=params.get('module');if(module)rows=rows.filter(x=>x.module===module);if(module==='iso'&&!rows.length)rows=pseudoIsoRecords();const q=(params.get('q')||'').toLowerCase();if(q)rows=rows.filter(x=>`${x.code||''} ${x.title||''} ${x.description||''}`.toLowerCase().includes(q));const st=params.get('status');if(st)rows=rows.filter(x=>x.status===st);return rows}
 if(/^records\/\d+$/.test(path)){const id=+path.split('/')[1];const r=snapshotRecords(snapshot).find(x=>+x.id===id)||pseudoIsoRecords().find(x=>+x.id===id);return recordBundle(r,snapshot)||{}}
 if(path==='document-control/summary')return {counts:{},items:[]};
 if(path==='admin/directory')return {users:[],roles:[],departments:[]};
 if(path==='admin/users'||path==='admin/roles'||path==='admin/departments')return [];
 if(path==='admin/drive')return {connected:false};
 return null
}
async function cacheResponse(rel,res){try{const clone=res.clone();const ct=clone.headers.get('content-type')||'';if(!ct.includes('application/json'))return;const data=await clone.json();await set(CACHE_PREFIX+rel,data)}catch(_e){}}
function simpleUrl(rel){return API+rel+(rel.includes('?')?'&':'?')+'_desktop_ts='+Date.now()}
function isFormDataBody(body){return typeof FormData!=='undefined'&&body instanceof FormData}
function bodyAsJson(body){if(body===undefined||body===null||body==='')return null;if(typeof body==='string'){try{return JSON.parse(body)}catch(_e){return {__nah_raw:String(body)}}}if(typeof URLSearchParams!=='undefined'&&body instanceof URLSearchParams)return Object.fromEntries(body.entries());return null}
async function remote(rel,init={}){
 const method=methodOf(init),t=token(),u=currentUser();
 if(!t)return json({message:'Bạn chưa đăng nhập ứng dụng.'},401);
 // File/FormData uploads remain direct, but authentication is carried in the
 // multipart body so the browser still sends a CORS-simple request without a
 // custom header or preflight.
 if(isFormDataBody(init.body)){
   const fd=new FormData();for(const [k,v] of init.body.entries())fd.append(k,v);fd.append('_nah_device_token',t);fd.append('_nah_csrf',u?.csrf||'');
   const h=new Headers(init.headers||{});h.delete('Content-Type');h.delete('X-NAH-Device-Token');h.delete('X-NAH-CSRF');h.delete('Cache-Control');h.delete('Pragma');h.set('Accept','application/json');
   return nativeFetch(simpleUrl(rel),{...init,method,body:fd,headers:h,credentials:'omit',cache:'default'});
 }
 // Normal Desktop API traffic is tunneled through one simple text/plain POST.
 // The server internally dispatches the original GET/POST/PATCH/PUT/DELETE and
 // still applies the original permission + CSRF checks. This removes WebView2
 // preflight/WAF dependence from Hạn hoàn thành, Phân công and other writes.
 const payload={path:rel,method,token:t,csrf:u?.csrf||'',json:bodyAsJson(init.body)};
 return nativeFetch(simpleUrl('desktop/transport'),{method:'POST',headers:{'Accept':'application/json','Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify(payload),credentials:'omit',cache:'default',signal:init.signal});
}
async function serverLogin(credentials){const r=await nativeFetch(simpleUrl('desktop/auth/login'),{method:'POST',headers:{'Accept':'application/json','Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify(credentials),credentials:'omit',cache:'default'});let j={};try{j=await r.json()}catch(_e){}return {r,j}}
async function reauthenticateSilently(){if(!navigator.onLine||token()||!volatileCredentials)return false;try{const {r,j}=await serverLogin(volatileCredentials);if(!r.ok||!j?.token||!j?.user)return false;sset(SESSION_TOKEN,j.token);sset(SESSION_USER,JSON.stringify(j.user));markValidated();if(rememberRequestedThisRun&&!j.user?.isWpAdmin)saveRememberedSession(volatileCredentials.username,j);return true}catch(_e){return false}}
async function updateContent(force=false){if(!navigator.onLine)return false;const last=Number(await get('content:lastCheck',0)||0);if(!force&&last&&Date.now()-last<CONTENT_REFRESH_MS)return false;try{const m=await nativeFetch(simpleUrl('desktop/content/manifest'),{headers:{'Accept':'application/json'},credentials:'omit',cache:'default'});await set('content:lastCheck',Date.now());if(!m.ok)return false;const meta=await m.json();const current=await get('content:version',content.version||'');if(meta.version&&meta.version!==current){const r=await nativeFetch(simpleUrl('desktop/content/bundle'),{headers:{'Accept':'application/json'},credentials:'omit',cache:'default'});if(r.ok){const b=await r.json();if(b&&b.version){content={...content,...b};window.NAH_OFFLINE_CONTENT=content;await setMany([['content:bundle',content],['content:version',b.version]]);return true}}}return false}catch(_e){return false}}
async function pullSnapshot(force=false){if(!navigator.onLine)return false;const last=Number(await get('sync:lastDeepSuccess',0)||0);if(!force&&last&&Date.now()-last<DEEP_REFRESH_MS)return true;if(!token()&&!(await reauthenticateSilently()))return false;try{let r=await remote('desktop/sync/pull');if(r.status===401&&await reauthenticateSilently())r=await remote('desktop/sync/pull');if(!r.ok)return false;const j=await r.json();await setMany([['sync:snapshot',j],['sync:lastSuccess',Date.now()],['sync:lastDeepSuccess',Date.now()]]);return true}catch(_e){return false}}
async function datasetManifest(){if(!navigator.onLine||!token())return null;try{const r=await remote(DATASET_MANIFEST);if(!r.ok)return null;return await r.json()}catch(_e){return null}}
async function hydrateCore(force=false){if(!navigator.onLine)return false;const last=Number(await get('sync:lastCoreSuccess',0)||0);if(!force&&last&&Date.now()-last<CORE_REFRESH_MS)return true;if(!token()&&!(await reauthenticateSilently()))return false;try{const meta=await datasetManifest();if(meta?.userRef){const old=String(await get('vault:userRef','')||'');if(old&&old!==String(meta.userRef)){await deleteByPrefixes(['api:','sync:','queue:','dataset:']);try{localStorage.removeItem('nahLabLearning')}catch(_e){}}await set('vault:userRef',String(meta.userRef))}const known=String(await get('dataset:version','')||'');if(!force&&meta?.datasetVersion&&known===String(meta.datasetVersion)&&await get(CACHE_PREFIX+'bootstrap',null)!==null){await setMany([['sync:lastCoreSuccess',Date.now()],['sync:lastSuccess',Date.now()],['dataset:lastValidated',Date.now()]]);return true}let r=await remote('desktop/mirror/full?scope=core');if(r.status===401&&await reauthenticateSilently())r=await remote('desktop/mirror/full?scope=core');if(!r.ok)return false;const j=await r.json(),cache=j?.endpointCache||{};const entries=[];for(const [rel,val] of Object.entries(cache))entries.push([CACHE_PREFIX+rel,val]);entries.push(['sync:lastCoreSuccess',Date.now()]);entries.push(['sync:lastSuccess',Date.now()]);if(meta?.datasetVersion)entries.push(['dataset:version',String(meta.datasetVersion)]);if(meta?.updatedAt)entries.push(['dataset:updatedAt',String(meta.updatedAt)]);if(j?.contentManifest)entries.push(['content:manifest',j.contentManifest]);await setMany(entries);return true}catch(_e){return false}}
async function prefetch(){return hydrateCore(false)}
async function flushLearningQueue(){if(!navigator.onLine)return;const q=await get('queue:learning',[]);if(!Array.isArray(q)||!q.length)return;if(!token()&&!(await reauthenticateSilently()))return;const keep=[];for(const item of q){try{const r=await remote(`knowledge/learning/${encodeURIComponent(item.slug)}/progress`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(item.payload||{status:'completed'})});if(!r.ok)keep.push(item)}catch(_e){keep.push(item)}}await set('queue:learning',keep)}
async function syncAll({forceCore=false,allowDeep=false}={}){if(syncInFlight){syncQueued=true;return}syncInFlight=true;try{if(currentUser()&&validatedThisRun()){await reauthenticateSilently();await flushLearningQueue();await hydrateCore(forceCore);if(allowDeep)await pullSnapshot(false)}await updateContent(false)}finally{syncInFlight=false;if(syncQueued){syncQueued=false;setTimeout(()=>syncAll(),900)}}}
async function syncDeep(force=false){if(deepSyncInFlight||!navigator.onLine||!currentUser()||!validatedThisRun())return;deepSyncInFlight=true;try{if(!token())await reauthenticateSilently();if(token())await pullSnapshot(force)}finally{deepSyncInFlight=false}}
function scheduleDeep(delay=INITIAL_DEEP_DELAY_MS){clearTimeout(deepSyncTimer);deepSyncTimer=setTimeout(()=>syncDeep(false),delay)}
function scheduleSync(delay=700,forceCore=false){clearTimeout(syncDebounceTimer);syncDebounceTimer=setTimeout(()=>{if(navigator.onLine&&currentUser()&&validatedThisRun())syncAll({forceCore})},delay)}
window.fetch=async function(input,init={}){const rel=normalizeRel(input);if(rel===null)return nativeFetch(input,init);const method=methodOf(init);const path=rel.split('?')[0];
 if(path==='auth/client-start'){
   if(!navigator.onLine)return json({ok:false,message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);
   try{
     let r=await nativeFetch(simpleUrl('auth/client-start?nah_client_start=1'),{method:'POST',headers:{'Accept':'application/json','Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify({token:token()||''}),credentials:'omit',cache:'default'}),j={};
     try{j=await r.json()}catch(_e){}
     if(!r.ok)return json(j,r.status);
     if(token()&&j?.resumedSession===false)clearRuntimeAuth({clearRemembered:true});
     if(j?.resumedSession===true&&currentUser())markValidated();
     return json({...j,ok:true,clientKind:'desktop',freshLoginRequired:false,onlineValidationRequired:true,sessionPolicy:'online-validated-device'});
   }catch(_e){return json({ok:false,message:'Không thể kết nối máy chủ để xác thực đăng nhập. Vui lòng kiểm tra kết nối mạng.'},503)}
 }
 if(path==='auth/login'&&method==='POST'){
   let body={};try{body=typeof init.body==='string'?JSON.parse(init.body):{}}catch(_e){}
   const username=normUserName(body.username),password=String(body.password||''),rememberLocal=body.remember_local===true||body.remember_local===1||body.remember_local==='1';
   if(!username||!password)return json({ok:false,message:'Cần nhập tên người dùng và mật khẩu.'},400);
   if(!navigator.onLine)return json({ok:false,message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);
   volatileCredentials={username,password,remember_local:rememberLocal};rememberRequestedThisRun=rememberLocal;
   try{
     const {r,j}=await serverLogin({username,password,remember_local:rememberLocal});
     if(r.ok&&j?.user&&j?.token){
       sset(SESSION_TOKEN,j.token);sset(SESSION_USER,JSON.stringify(j.user));markValidated();await activateVault(j.user);
       if(rememberLocal&&!j.user?.isWpAdmin)saveRememberedSession(username,j);else clearRememberedSession();
       scheduleSync(INITIAL_CORE_DELAY_MS,true);scheduleDeep(INITIAL_DEEP_DELAY_MS);return json({ok:true,user:j.user,handoff:'desktop-device-session'});
     }
     if(r.status===400||r.status===401||r.status===403||r.status===429)return json(j,r.status);
     return json(j||{ok:false,message:'Không thể xác thực tài khoản.'},r.status||500);
   }catch(_e){return json({ok:false,message:'Không thể kết nối máy chủ để xác thực đăng nhập. Vui lòng kiểm tra kết nối mạng.'},503)}
 }
 if(path==='auth/confirm'&&method==='POST'){const u=currentUser();return u?json({ok:true,user:u}):json({ok:false,message:'Phiên đăng nhập không còn hiệu lực.'},401)}
 if(path==='auth/logout'&&method==='POST'){try{if(navigator.onLine&&token())await remote('desktop/auth/logout',{method:'POST'})}catch(_e){}clearRuntimeAuth({clearRemembered:true});return json({ok:true,redirect:'./index.html'})}
 if(path==='bootstrap'&&method==='GET'){
   if(validatedThisRun()){const fast=await get(CACHE_PREFIX+rel,null);if(fast){fast.desktop={...(fast.desktop||{}),localCache:true,version:DESKTOP_VERSION};if(navigator.onLine&&token())scheduleSync(150,true);return json(fast)}}
   if(navigator.onLine){try{if(!token())await reauthenticateSilently();if(token()){let r=await remote(rel,init);if(r.status===401&&await reauthenticateSilently())r=await remote(rel,init);if(r.ok){let j=null;try{j=await r.clone().json()}catch(_e){}if(j){const bu=j.user||currentUser();sset(SESSION_USER,JSON.stringify(bu));markValidated();await activateVault(bu);j.desktop={...(j.desktop||{}),localCache:true,version:DESKTOP_VERSION};await set(CACHE_PREFIX+rel,j);return json(j)} }else if(r.status===401||r.status===403){clearRuntimeAuth({clearRemembered:true});return r}}}catch(_e){}
     if(!token()&&!currentUser())return json({message:'Bạn chưa đăng nhập ứng dụng.'},401);
   }
   if(!validatedThisRun())return json({message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);
   const cached=await get(CACHE_PREFIX+rel,null);if(cached){cached.desktop={...(cached.desktop||{}),localCache:true,version:DESKTOP_VERSION};return json(cached)}
   const b=bootstrap();return b?json(b):json({message:'Bạn chưa đăng nhập ứng dụng.'},401)
 }
 if(method==='GET'){
   if(!validatedThisRun())return json({message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);
   const local=await localResponse(rel);
   if(local!==null){if(navigator.onLine&&token())scheduleSync(900);return json(local)}
   if(navigator.onLine&&token())try{const r=await remote(rel,init);if(r.ok){cacheResponse(rel,r);return r}}catch(_e){}
   return json({message:'Dữ liệu này chưa được tải về trên thiết bị. Vui lòng kết nối máy chủ để cập nhật.'},503)
 }
 if(path.startsWith('knowledge/learning/')&&path.endsWith('/progress')&&method==='POST'){if(!validatedThisRun())return json({message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);const slug=decodeURIComponent(path.split('/')[2]||'');let payload={status:'completed'};try{payload=JSON.parse(init.body||'{}');const local=lget('nahLabLearning',{});if(payload.status==='completed')local[slug]=true;lset('nahLabLearning',local)}catch(_e){}if(navigator.onLine){try{if(!token())await reauthenticateSilently();if(token()){const r=await remote(rel,init);if(r.ok){scheduleSync();return r}}}catch(_e){}}const q=await get('queue:learning',[]);q.push({slug,payload,queuedAt:Date.now()});await set('queue:learning',q.slice(-500));return json({ok:true,lesson:slug,status:payload.status||'completed'})}
 if(!validatedThisRun())return json({message:'Cần kết nối mạng để đăng nhập NAH LAB SUITE.'},503);
 if(navigator.onLine){try{if(!token())await reauthenticateSilently();if(token()){const r=await remote(rel,init);if(r.ok)scheduleSync();return r}}catch(_e){}}
 return json({message:'Không thể kết nối máy chủ để lưu thay đổi. Vui lòng thử lại khi kết nối được khôi phục.'},503)
};
function versionParts(v){return String(v||'').split('.').map(x=>parseInt(x,10)||0)}
function versionNewer(a,b){const x=versionParts(a),y=versionParts(b);for(let i=0;i<Math.max(x.length,y.length);i++){const p=x[i]||0,q=y[i]||0;if(p>q)return true;if(p<q)return false}return false}
async function checkDesktopUpdate(userInitiated=false){if(!navigator.onLine){if(userInitiated)alert('Cần kết nối mạng để kiểm tra cập nhật.');return false}try{let r;if(token())r=await remote(UPDATE_MANIFEST);else r=await nativeFetch(simpleUrl(UPDATE_MANIFEST),{headers:{'Accept':'application/json'},cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json(),d=j?.platforms?.desktop;if(!d?.available||!d.version||!versionNewer(d.version,DESKTOP_VERSION)){if(userInitiated)alert('NAH LAB SUITE Desktop đang ở phiên bản mới nhất.');return false}const ok=confirm(`Có NAH LAB SUITE Desktop v${d.version}.\n\n${d.releaseNotes||''}\n\nTải và cài đặt ngay?`);if(!ok)return true;if(!/^https:\/\/([^.]+\.)?sachyhoc\.com\//i.test(String(d.downloadUrl||''))||!/^[a-f0-9]{64}$/i.test(String(d.sha256||'')))throw new Error('Metadata cập nhật không hợp lệ');const payload={url:d.downloadUrl,sha256:d.sha256,version:d.version,file:d.file||''};window.open('nahlab-update:'+encodeURIComponent(JSON.stringify(payload)),'_blank');return true}catch(_e){if(userInitiated)alert('Chưa thể kiểm tra cập nhật. Vui lòng thử lại khi kết nối ổn định.');return false}}
function injectDesktopUpdateButton(){const v=document.getElementById('desktopVersionLabel');if(!v||document.getElementById('desktopUpdateBtn'))return;const b=document.createElement('button');b.id='desktopUpdateBtn';b.type='button';b.textContent='Kiểm tra cập nhật';b.style.cssText='margin:10px auto 0;display:block;border:0;background:transparent;color:#087a43;font:600 13px system-ui;cursor:pointer';b.onclick=()=>checkDesktopUpdate(true);v.parentNode.insertBefore(b,v.nextSibling)}
restoreRememberedSession();
async function restoreContent(){const b=await get('content:bundle',null);if(b&&b.version){content={...content,...b};window.NAH_OFFLINE_CONTENT=content}}
function primeLoginName(){const rec=rememberedSession();const input=document.querySelector('#loginForm input[name=username]'),box=document.querySelector('#loginForm input[name=remember_local]');if(rec?.username&&input&&!input.value)input.value=rec.username;if(rec&&box)box.checked=true}
window.addEventListener('DOMContentLoaded',async()=>{await restoreContent();primeLoginName();const versionLabel=document.getElementById('desktopVersionLabel');if(versionLabel)versionLabel.textContent=`NAH LAB SUITE Desktop v${DESKTOP_VERSION}`;injectDesktopUpdateButton();if(navigator.onLine){setTimeout(()=>updateContent(false),15000);setTimeout(()=>checkDesktopUpdate(false),18000)}});
window.addEventListener('online',()=>{scheduleSync(250,true);scheduleDeep(5000)});
window.addEventListener('focus',()=>{scheduleSync(500);scheduleDeep(15000)});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){scheduleSync(500);scheduleDeep(15000)}});
setInterval(()=>{if(navigator.onLine&&currentUser()&&validatedThisRun())syncAll()},CORE_REFRESH_MS);setInterval(()=>{if(navigator.onLine&&currentUser()&&validatedThisRun())syncDeep(false)},30*60*1000);
window.NAHLAB_DESKTOP={version:DESKTOP_VERSION,sync:syncAll,checkUpdate:()=>checkDesktopUpdate(true),isAuthenticated:()=>!!currentUser(),getSnapshot:()=>get('sync:snapshot',{})};
})();

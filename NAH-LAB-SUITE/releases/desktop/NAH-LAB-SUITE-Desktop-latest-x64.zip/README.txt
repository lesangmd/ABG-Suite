NAH LAB SUITE Desktop v1.3.1 x64

Persistent Offline Vault + Native Auto-Updater

- Dữ liệu/biểu mẫu đã hydrate được giữ lại qua Logout; Logout chỉ xóa phiên xác thực.
- Sau đăng nhập trực tuyến lại cùng tài khoản, local vault được dùng ngay rồi đồng bộ nền.
- Nếu đăng nhập tài khoản khác, cache account-sensitive cũ được xóa trước khi nạp tài khoản mới.
- Dataset manifest v1.47 giúp bỏ qua core mirror khi dữ liệu server chưa thay đổi.
- Tự kiểm tra phiên bản mới và hỗ trợ tải/kiểm SHA-256/cài runtime Desktop trực tiếp bằng UPDATE-NAH-LAB-SUITE.ps1.
- Web baseline: v1.47.

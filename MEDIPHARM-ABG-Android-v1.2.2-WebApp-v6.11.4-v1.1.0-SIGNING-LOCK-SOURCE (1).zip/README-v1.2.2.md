# MEDIPHARM ABG Android v1.2.2 — WebApp v6.11.4

**Source overlay for** https://github.com/lesangmd/ABG-Suite (parent Android v1.2.1).

- Application ID: `com.medipharm.abgsuite` (unchanged)
- Version: `1.2.2` / code `6` (increments 1.2.1/code 5)
- Runtime UI & clinical content: locally generated from the supplied WebApp v6.11.4 ZIP, **not** the stale web target v6.2.8 or v6.2.9.
- Offline: embeds SQLite `abg_offline.db` containing HTML, CSS, core JS, UI JS, canonical learning JS, learning data, icons, and visual backgrounds.
- WebUI: 4-entry dock, consolidated review Q&A, inline dictionary, responsive reading dialogs, consistent Menu with Update/About.
- Native Android authentication, native update behavior, offline entitlement, applicationId, and update certificate MUST remain unchanged.

## Application to GitHub source

1. Copy this overlay to the root of `lesangmd/ABG-Suite` checkout, preserving existing Android Java source, resources and manifests.
2. Inspect the diff before committing; these files replace `app/build.gradle` and `.github/workflows/build-apk.yml`.
3. Push the new `offline/abg_offline_v122.db.xz.b64`, `offline/abg_offline_v122.db.sha256`, and workflow together.
4. In GitHub Actions, ensure secrets `ANDROID_KEYSTORE_B64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD` reference the SAME release key that signed the uploaded *device-installed* Android v1.1.0 APK. The workflow pins the fingerprint, independently of GitHub secrets. Never commit the keystore/private key.
5. Dispatch the workflow: it MUST fail if the keystore certificate differs from the v1.1.0 fingerprint pinned in the workflow. Only after verification, install over v1.1.0 (no uninstall) and test on mobile/tablet/foldable, then publish **signed** APK.

**Signing warning:** Uploaded `MEDIPHARM-ABG-v1.1.0.apk` has SHA-256 certificate fingerprint
`47826c56a86d6253f2b7419630c0f19ddc334392eebeec1da543cd3de97686ac`, whereas GitHub's `MEDIPHARM-ABG-v1.1.1-QA.txt` reports a DIFFERENT fingerprint
`2beb71a576fd79dced9d475ce0e63f002707eb5912988ebeceac3533ca9b3f4a`. The user confirmed that the installed production release is **v1.1.0**, so `47826c56...` is the ONLY allowed signer for Android v1.2.2. The GitHub v1.1.1 certificate MUST NOT be used for this update.

## Offline payload details

- SQLite source SHA-256: `2914baa6b34bf05bb8c0da6e8e894b9ac429944c3295d9ca5da8a0876682a3d8`
- Metadata web source: v6.11.4
- Compressed payload: `offline/abg_offline_v122.db.xz.b64`
- A raw SQLite database copy is supplied inside `diagnostics/` for independent inspection. To regenerate, run `php tools/render_webapp.php` followed by `python3 tools/build_offline_db_from_plugin.py` at repository root.

## Canonical signing decision — 2026-10-08

Production installed app: Android v1.1.0, as confirmed by the user. Required fingerprint (SHA-256): `47826c56a86d6253f2b7419630c0f19ddc334392eebeec1da543cd3de97686ac`. Do not use any other signing key, do not rotate signing lineage, and do not uninstall the production build during installation testing. This ZIP contains no keystore/private key and does not itself produce a signed APK.

## QA status

STATIC only: PHP rendering, JS syntax, SQLite integrity, asset hashes, and navigation markers. No signed APK was built, no emulator/device runtime test completed, and GitHub has not been updated by this package.

# MEDIPHARM ABG Suite v6.0.5 — Menu Layering & Trial Footer Cleanup Hotfix

**Parent:** v6.0.4 — Trial Footer Copy Deduplication Hotfix  
**Parent SHA-256:** `7163d9e42fe5c34c6160e7a8a72c45e48f410289bb5a0edb38aa59d178dc5445`

## Scope

1. Sửa menu ABG bị thanh điều hướng sticky của chính WebApp che phần đầu khi menu mở.
2. Giữ menu ABG ở thang z-index nội bộ thấp để NAH Search Dock Right Rail vẫn có thể hiển thị phía trên WebApp.
3. Footer khách chỉ còn một câu quota với hai liên kết nội tuyến: **Đăng nhập** và **Đăng ký tài khoản**; không có CTA Đăng ký/Đăng nhập lặp ở cuối.
4. Bump phiên bản để bust cache CSS/markup cũ đang hiển thị v6.0.3/v6.0.4.

## Runtime invariants

- Calculation core unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- Trial access remains action-level; opening the route does not consume a trial use.
- Route remains `/phan-tich-khi-mau-app/`.
- Assessment/content/localStorage/remediation/analytics unchanged.
- Membership/Clinical Access and NAH Search Dock code are not modified.

## QA

- PHP lint: 2/2 PASS.
- JavaScript syntax: 76/76 PASS.
- Node regression/static: 70 PASS / 1 UI smoke SKIP / 0 FAIL.
- CSS brace integrity: main 2276/2276; launcher 46/46.
- ZIP CRC: PASS.
- Clean extraction: 70 PASS / 1 UI smoke SKIP / 0 FAIL.

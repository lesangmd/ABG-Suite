# MEDIPHARM ABG Suite v6.0.2 — Access Gate & Search Dock Layering Hotfix

**Parent:** v6.0.1 — Landing Page Visual Refresh & Trial Footer Hotfix  
**Parent SHA-256:** `c3eefce8038034a87858e032184a690256943c5f850f995fd46b50a10e00bead`

## Fixed

### 1. Membership / Clinical Access form proportion
The ABG access gate no longer forces the host-owned login form into a narrow ~460px column at medium desktop widths.

- Wide desktop: access gate expands to 1280px and reserves a minimum 640px for the login surface.
- `<=1180px`: the gate becomes one full-width column, so the existing Membership / Clinical Access form keeps its intended proportions.
- Both `.syh-modern-login-wrap` and `.yhls-modern-login-wrap` are allowed to use the full available width.
- No login markup, authentication rule, Membership policy, payment logic or member database logic is copied into ABG.

### 2. NAH Search Dock Right Rail layering
The overlap was caused by legacy ABG sticky-header rules using near-maximum integer z-index values.

v6.0.2 restores a local WebApp layer scale:

- workspace tabs: 116
- header: 120
- open-menu header: 140
- ABG menu: 150
- ABG search results / picker: 180

This keeps ABG internal overlays ordered correctly while allowing host-owned overlays such as NAH Search Dock Pro Right Rail to render above the WebApp.

## Preserved

- 220 assessment items
- 50 handbook lessons
- 50 clinical cases
- 8 mock-test packs
- 6 assessment item formats
- trial limit 10
- route `/phan-tich-khi-mau-app/`
- localStorage key `medipharm_abg_learning_v30`
- v6.0.1 landing page and trial-footer wording
- remediation, longitudinal analytics, Blueprint Generator and Integrated Session
- calculation core SHA-256 `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`

## Source QA

- PHP lint: 2/2 PASS
- JavaScript syntax: 73/73 PASS
- Node regression/static tests: 67 PASS / 1 UI smoke SKIP / 0 FAIL
- CSS braces: main 2249/2249; launcher 46/46
- Dedicated v6.0.2 access/layering gate: PASS

A live WordPress smoke test remains required before baseline lock.

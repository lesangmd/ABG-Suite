# MEDIPHARM ABG Suite v6.3.7 — Mockup-Aligned WebApp

## Phạm vi
- Đóng gói WebApp; không thay đổi Android trong release này.
- Trang chủ Desktop bám sát mockup: hero chuyên môn, 5 module chính, cụm Nhập nhanh thông số khí máu và Hoạt động gần đây.
- Trang chủ Mobile bỏ dropdown điều hướng lớn; giữ header Logo + Tài khoản + Menu, hộp tìm kiếm một lớp, hero cô đọng, danh sách module và Kiến thức nổi bật.
- Menu hamburger bổ sung điều hướng trực tiếp Trang chủ / Phân tích khí máu / Học tập / Ca lâm sàng / Ôn luyện / Tiến độ.
- Màn hình đăng nhập trong WebApp dùng nhận diện O₂/CO₂ – ABG, bố cục card trung tâm và nền wave đỏ/xanh theo mockup; logic xác thực vẫn do Membership hiện hữu xử lý.
- Nhập nhanh trên Trang chủ có thể chuyển pH, PaCO₂, PaO₂, HCO₃⁻, SaO₂, FiO₂ sang biểu mẫu Phân tích mà không tạo một calculation engine thứ hai.

## Không thay đổi
- Thuật toán khí máu và clinical rules.
- Ngân hàng 50 bài học, 50 ca lâm sàng, 220 câu hỏi và nội dung đánh giá.
- Chính sách trial/thành viên, route, localStorage, PWA manifest và liên kết Android.
- Hệ nhận diện logo O₂/CO₂ đã duyệt.

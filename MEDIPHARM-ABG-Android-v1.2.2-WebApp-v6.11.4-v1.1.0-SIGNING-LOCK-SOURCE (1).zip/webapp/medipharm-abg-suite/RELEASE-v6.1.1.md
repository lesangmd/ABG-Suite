# MEDIPHARM ABG Suite v6.1.1

## Tablet Dark Shell, Typography & Learning Profile Simplification Hotfix

Technical parent: v6.1 (`MEDIPHARM-ABG-Suite-v6.1.zip`)
Parent SHA-256: `8bd0e62ccfcb9d9e0ef3cd2f38986ae0763409c9ffa445484417e5430583be01`

### Scope
- Extend the tablet responsive contract through 1280 CSS px to cover tablet browsers using desktop-width layouts.
- Darken the host content container that directly carries the ABG WebApp so no light gutter remains around the dark application canvas.
- Increase tablet/mobile body, secondary copy and CTA readability.
- Simplify the Home learning profile to four primary metrics plus one clear link to the detailed Progress area.
- Preserve calculation core, assessment corpus, trial policy, shared dark-mode ownership, Search Dock layering, route and local storage.

### Home learning profile
Visible summary on tablet/mobile:
- Bài đã mở
- Câu đã làm
- Điểm tốt nhất
- Nội dung cần ôn
- CTA: `Xem hồ sơ học tập →`

Detailed milestones, seven-day analytics, mastery, flashcards and daily plan remain available in the Learning/Progress area rather than being spread across the Home surface.

### QA
- PHP lint: 2/2 PASS
- JavaScript syntax: 3/3 PASS
- Node regression/static tests: 76 PASS / 1 UI smoke SKIP / 0 FAIL
- Main CSS braces: 2388/2388 PASS
- Launcher CSS braces: 46/46 PASS
- Calculation core unchanged.

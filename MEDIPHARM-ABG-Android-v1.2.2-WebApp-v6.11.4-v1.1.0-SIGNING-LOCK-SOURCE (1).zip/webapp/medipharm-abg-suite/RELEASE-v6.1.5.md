# MEDIPHARM ABG Suite v6.1.5 — Assessment Layout & Responsive Navigation Hotfix

## Parent
- Exact technical parent: v6.1.4.
- No calculation-core change.

## Changes
- Desktop (>=1180 CSS px): moves the three primary workspaces into a compact vertical navigation rail beside the active workspace.
- Tablet/mobile (<1180 CSS px): keeps the three workspaces horizontal but reduces tab height/padding and hides secondary descriptions.
- Assessment setup is now a single content flow: exam controls first, generator full-width, then blueprint summary.
- Generator controls remain responsive: 4 columns on desktop, 2 on tablet, 1 on mobile.
- The question review marker is a compact native 18×18 px checkbox with an inline label; it no longer inherits oversized form-control geometry.
- Sticky-scroll calculations ignore vertical-navigation height on desktop so deep links and accordion targets are not over-offset.

## Regression locks
- 220 canonical assessment items.
- 50 handbook lessons.
- 50 clinical cases.
- 8 mock-test packs.
- Trial gate, shared dark mode, Search Dock layering, route and localStorage unchanged.
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

## QA
- PHP lint: 2/2 PASS.
- JavaScript syntax: PASS.
- Node regression/static: 80 PASS / 1 UI smoke SKIP / 0 FAIL.
- CSS brace balance: main 2477/2477; launcher 46/46.
- ZIP integrity: required before baseline lock.

=== MEDIPHARM ABG Suite ===
Contributors: MEDIPHARM
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 6.11.4

MEDIPHARM ABG Suite v6.10.0 – Clinical Context & Host Canvas Alignment.

== v6.11.4 ==
* Bỏ tab “Thêm” khỏi Dock trên mobile/tablet/foldable; Dock còn 4 mục cốt lõi: Trang chủ, Phân tích, Ca lâm sàng, Học tập.
* Đưa “Kiểm tra cập nhật” vào Menu header trên Web/WebApp; Android tiếp tục dùng kênh cập nhật native hiện có.
* Giữ “Giới thiệu” trực tiếp trong Menu header và loại bỏ More sheet trùng lặp.
* Không thay đổi calculation core, dữ liệu chuyên môn, đăng nhập/phân quyền hay Android download channel.

== v6.11.3 ==
* Gộp Hỏi đáp vào Ôn luyện: bỏ tab Hỏi đáp riêng; 38 câu hỏi được tổ chức theo 6 chuyên đề và mở đáp án/giải thích/ý nghĩa lâm sàng ngay trong danh sách.
* Từ điển hiển thị toàn bộ định nghĩa trực tiếp dưới từng mục từ, bỏ popup chi tiết; liên kết tra cứu từ chuyên đề và tìm kiếm toàn cục đưa thẳng tới mục từ tương ứng.
* Sửa popup đọc chuyên đề/ca lâm sàng cho tablet, mobile và thiết bị gập bằng giới hạn 100dvh, full-width an toàn, header 3 vùng co giãn, safe-area và khóa overflow ngang.
* Giữ nguyên calculation core, dữ liệu chuyên môn, dữ liệu câu hỏi, dữ liệu ca lâm sàng, phân quyền, đăng nhập và Android download channel.

== v6.11.2 ==
* Căn lại đồ họa nền Hero theo mockup: nền xanh y khoa sáng, phổi mờ, dải sóng đỏ–xanh và logo ABG ở vùng hình ảnh bên phải.
* Căn lại đồ họa màn hình đăng nhập theo mockup: nền toàn màn hình với dải sóng đỏ–xanh, điểm nhấn xanh góc trên và card đăng nhập trắng nổi.
* Giữ nguyên nội dung chuyên môn, luồng phân tích, dữ liệu học tập, phân quyền và cơ chế đăng nhập hiện hành.


== v6.6.0 ==
* Rebuild Trang chủ theo hierarchy mockup: Hero lâm sàng → 5 module → nhập nhanh + hoạt động gần đây.
* Desktop dùng 5 module cards gọn; điện thoại dùng 2 cột + Tiến độ toàn chiều rộng; foldable/tablet dùng 2–3 cột theo bề rộng thực.
* Header chuẩn hóa Logo/ABG + Search + Tài khoản + Menu; mobile bổ sung bottom navigation.
* Mặc định giao diện sáng độc lập với dark mode của website/OS; người dùng vẫn có thể bật dark mode trong app.
* Form đăng nhập render trực tiếp trong WebApp, chỉ còn tài khoản/email, mật khẩu, Đăng nhập, Quên mật khẩu và Đăng ký.
* Giữ nguyên calculation core, dữ liệu học tập và logic quyền truy cập.









== v6.3.3 ==
* Result Summary & Component Contrast Fix: sửa lỗi chữ trắng trên gradient sáng ở Kết quả phân tích tổng hợp.
* Thiết kế lại summary panel với hierarchy kết luận → lập luận → bối cảnh → thông số cốt lõi, tương phản rõ ở Light/Dark.
* Nâng contrast và trạng thái hover/focus cho primary/secondary CTA; Sao chép kết luận trở thành hành động chính trong vùng kết quả.
* Result cards, status badges, cảnh báo và khoảng tham chiếu có border/elevation và màu trạng thái rõ hơn.
* Mobile giữ summary 2 cột thông số, action buttons một cột và không thay đổi calculation core hay dữ liệu chuyên môn.

== v6.3.2 ==
* Visual Refinement & Accent System: teal–aqua primary, indigo secondary và amber có kiểm soát.
* CTA chính dùng gradient nhẹ; active tabs, stepper và segmented control có depth tinh tế nhưng vẫn ưu tiên khả năng đọc.
* Featured cards ở Phân tích, Học tập, Ca lâm sàng và Ôn luyện dùng tint gradient nhẹ; content cards thông thường giữ nền phẳng.
* Light/Dark mode dùng cùng hierarchy màu, border và elevation; dark mode không dùng surface trắng hoặc contrast gắt.
* Không thay calculation core, clinical rules, ngân hàng câu hỏi, case bank hay assessment schema.

== v6.2.4 ==
* Mở rộng Hỏi & Đáp ra toàn chiều rộng workspace; bỏ max-width 920px làm nội dung co giữa.
* Nâng thư viện giải đáp nhanh từ 12 lên 36 câu, chia 4 nhóm: Nền tảng & toan–kiềm, Oxy hóa & thông khí, Chất lượng mẫu, Tình huống lâm sàng.
* Hợp nhất các câu tự kiểm tra mang tính giải thích từ Lý thuyết vào thư viện Hỏi & Đáp; các câu luyện có chấm điểm vẫn giữ ở Ôn tập.
* Desktop dùng bố cục 2 nhóm/ hàng để tận dụng chiều ngang; tablet/mobile tự chuyển 1 cột và giữ font dễ đọc.

== v6.2.3 ==
* Làm dịu hệ màu phần Lý thuyết bằng gradient nhẹ, ưu tiên nền trắng và màu nhấn có kiểm soát.
* Thu gọn các phần mở đầu Lý thuyết thành accordion để nội dung bài chính xuất hiện sớm hơn.
* Sửa sơ đồ oxy hóa–thông khí: desktop theo luồng ngang, tablet hai hàng, mobile theo chuỗi dọc rõ ràng.
* Chuẩn hóa visual color contract cho các workspace: màu module dùng ở accent/CTA, card chỉ dùng tint phai nhanh về nền chính.

== v6.2.2 ==
* Chuẩn hóa một content-width contract cho tất cả workspace và module chính.
* Loại các max-width/căn giữa cũ khiến một số module hẹp hơn Trang chủ, Phân tích hoặc Thi thử.
* Mobile bỏ outer wrapper, border, radius, shadow và padding ngang lặp; chỉ giữ một gutter an toàn 8px.
* Không thay calculation core, corpus, trial policy, dark mode, Search Dock, route hoặc localStorage.

== v6.2.1 ==
* Sửa triệt để Tạo đề luyện tập bị treo ở trạng thái “Đang tạo đề…”.
* Generator là tác vụ local: thành viên không còn chờ admin-ajax trước khi dựng đề; khách còn lượt được dựng đề ngay rồi mới đối soát quota ở nền.
* Bổ sung snapshot quyền thành viên trực tiếp trên root WebApp để tránh lệch trạng thái giữa footer server-side và JavaScript.
* Nếu render đề phát sinh lỗi, giao diện tự hoàn nguyên và hiển thị thông báo thay vì treo nút.
* Giữ nguyên ngân hàng 220 câu, calculation core, trial policy, 8 workspace, dark mode, Search Dock, route và localStorage.

== v6.2 ==
* Desktop: 3 tab Trang chủ / Phân tích / Học tập chuyển sang thanh điều hướng dọc để giải phóng chiều cao nội dung.
* Tablet/mobile: thanh tab ngang được thu gọn, chỉ giữ nhãn chính.
* Tạo đề luyện tập: cấu hình đề dùng toàn chiều ngang; panel generator không còn bị ép sang cột bên phải.
* Đánh dấu câu: checkbox chuẩn 18×18 px và nhãn cùng hàng, không còn control quá lớn hoặc lệch vị trí.
* Giữ nguyên calculation core, corpus, trial gate, dark mode, Search Dock, route và localStorage.

== v6.1.4 ==
* Sửa Tạo đề luyện tập không còn mắc kẹt ở trạng thái “Đang tạo đề…”.
* Trên thiết bị cảm ứng, tạo đề được khởi tạo ngay sau cấu hình hợp lệ; lượt dùng thử được đối soát nền và chặn lại nếu máy chủ từ chối.
* Loại nhãn phiên bản kỹ thuật khỏi giao diện người dùng: v5.5 → ĐỀ; v6.0 → 5 bước.
* Căn các CTA của card Trang chủ về phía phải trên tablet/mobile.
* Không thay calculation core, corpus, route, localStorage, dark mode hay Search Dock.

== v6.1.3 ==
* Tablet learning-card layout: chuyển các card điều hướng sang cấu trúc badge + tiêu đề, mô tả và CTA riêng, loại cột CTA hẹp gây gãy chữ.
* CTA trên tablet/mobile luôn có vùng riêng ở cuối card, không bẻ chữ theo cột dọc.
* Giữ nguyên nội dung, hành vi click, dark mode, trial gate, Search Dock và calculation core.

== v6.1.1 ==
* Tablet dark shell: unify host content gutter and ABG outer canvas through 1280px without changing dark-mode ownership.
* Tablet/mobile typography: increase body, secondary copy and CTA readability.
* Home learning profile: compact summary on tablet/mobile with four key metrics and one clear link to the detailed Progress area.

== v6.1 ==
* Responsive Home Information Architecture Redesign: tinh giản Trang chủ trên tablet/mobile thành Hero, Tiếp tục hôm nay, Chọn cách học và Hồ sơ học tập tóm tắt.
* User-facing Clinical Copy Gate: loại ngôn ngữ kỹ thuật nội bộ khỏi Trang chủ; chuẩn hóa tiêu đề/mô tả ngắn, rõ, phù hợp chuyên môn.
* Mobile/tablet giảm số card ngang cấp, ẩn các cụm nội dung lặp và ưu tiên điều hướng theo nhiệm vụ.

== v6.0.9 ==
* Trên tablet/mobile ≤1024px chỉ hiển thị logo ABG; ẩn tên ứng dụng để dành chiều ngang cho hộp tìm kiếm và nút Menu.
* Desktop >1024px giữ nguyên logo + tên ứng dụng.
* Giữ nguyên menu layering v6.0.5, trial footer, trial action gate, calculation core, corpus, route và localStorage.

== v6.0.5 ==
* Sửa stacking context khi mở trình đơn: menu ABG luôn hiển thị trên thanh điều hướng sticky của chính WebApp.
* Giữ toàn bộ lớp ABG dưới NAH Search Dock Right Rail theo hợp đồng host ownership.
* Footer khách chỉ còn một câu quota với liên kết Đăng nhập và Đăng ký tài khoản nội tuyến; không còn CTA lặp.
* Không thay đổi calculation core, trial policy, nội dung học tập, assessment, route hoặc localStorage.

== v6.0.4 ==
* Trial footer copy deduplication hotfix trên nền v6.0.3.
* Bỏ CTA lặp “Đăng ký/Đăng nhập” ở cuối thông báo dùng thử.
* Footer khách chỉ còn một câu: “Còn x/10 lượt dùng thử. Vui lòng Đăng nhập hoặc Đăng ký tài khoản để truy cập đầy đủ mọi nội dung.”
* “Đăng nhập” tiếp tục mở form thành viên hiện có; “Đăng ký tài khoản” dẫn trực tiếp tới /dangky.
* Không thay trial logic, calculation core, corpus, route, localStorage, Search Dock layering hoặc Membership/Clinical Access ownership.


== v5.6 ==
* Branch trực tiếp từ v5.5 SHA-256 15639118a2443744d73803eea31e6717c9e36a791ef9c7b843c0a44f5c6893c5.
* Sổ tay: 39 → 50 bài; thêm thở máy, ABG nối tiếp sau chỉnh máy, ARDS, NIV, HFNC, shock–lactate, đồng oxy kế/dyshemoglobin, cồn độc, thận–chuyển hóa, thai kỳ và độ cao.
* Thư viện ca: 30 → 50 ca; thêm 20 tình huống nâng cao và serial-ready.
* Nguồn hiện hành bổ sung: AARC 2024, ERS HFNC, Surviving Sepsis Campaign 2026, KDIGO 2024, CDC CO 2024, WMS 2024 và tổng quan sinh lý thai kỳ/độ cao.
* Không thay calculation core, ngân hàng 220 câu, mixed-format engine, mock packs, blueprint generator, trial gate, localStorage key, route, Super App/Theme/Search Dock.

== v5.5 ==
* Blueprint-Driven Exam Generator: 20/30/40 câu, preset miền kiến thức và độ khó, 3 chế độ định dạng, seed tái lập và chống lặp câu gần đây.
* Thiết kế lại Trang chủ ABG theo mosaic card khác biệt về màu sắc/kích thước và làm nổi bật Phân tích, Học tập, Kiểm tra, Sinh đề.
* Launcher homepage tương tác nhẹ: thử khí máu nhanh + tạo seed đề; không tải full ABG engine trên homepage.
* Guest trial gate: tối đa 10 lượt mở đầy đủ ứng dụng trên trình duyệt, sau đó dùng form đăng nhập do SachYHoc Membership [syh_login] hoặc YHocLamSang Clinical Access [yhls_login] sở hữu.
* Không đổi calculation core, 220 câu canonical, localStorage key, route, scoring của các chế độ cũ hoặc PWA ownership.





== v5.4 ==
* Thêm 6 bộ thi thử cố định, mỗi bộ 30 câu: Nền tảng, Toan–kiềm, Oxy hóa/Thông khí, Ca lâm sàng, Suy luận nâng cao và Tổng hợp.
* Mỗi bộ có seed riêng để thành phần đề ổn định trong release v5.4; không thay đổi ngân hàng canonical 220 câu.
* Bổ sung chế độ bấm giờ/không bấm giờ; hết giờ tự nộp và bảo toàn câu đã trả lời.
* Nâng điều hướng thi thử với đồng hồ, đánh dấu câu, nộp bài từ mọi câu và phân tích sau thi theo miền, độ khó, dạng câu hỏi.
* Lịch sử assessment lưu thêm metadata thời gian/pack trong cùng localStorage hiện có; không tạo storage key hoặc network request mới.
* Calculation core, route, Super App, Theme và Search Dock không thay đổi.

== v5.3 ==

* Mixed-Format Assessment Engine, branch trực tiếp từ baseline production v5.2 SHA-256 329f713a677f85f61c2ce10a89a65ca94a78d8e7971cd8717e8d5c9879a48de4.
* Giữ nguyên 180 câu SBA v5.2 và bổ sung 40 mục đa định dạng, nâng ngân hàng canonical lên 220 mục.
* Hỗ trợ 6 item_format: single_best_answer, multiple_response, ordering, matching, numeric_calculation và structured_case_interpretation.
* Corpus v5.3 cân bằng 10 mục mới/miền; mỗi trong 5 dạng mới có 8 mục, tương ứng 2 mục/miền.
* Thêm blueprint “Hỗn hợp · 20 câu”: mỗi miền có một câu của từng dạng mới; các blueprint Nhanh/Cân bằng/Nâng cao/Theo ca cũ tiếp tục chỉ dùng SBA.
* Quy tắc chấm điểm xác định rõ: exact-set cho nhiều đáp án, exact-order cho sắp xếp, exact-pair cho ghép cặp, tolerance cho câu số và all-fields-correct cho diễn giải cấu trúc; chưa dùng partial credit.
* Renderer hỗ trợ keyboard/native controls, mobile/tablet, Light/Dark; review sau nộp hiển thị đáp án người học và đáp án chuẩn cho từng dạng.
* Không migration localStorage, không thay calculation core, route, Super App, Theme, Search Dock và không thêm network request.

== v5.2 ==

* Branch trực tiếp từ baseline production v5.1 đã nghiệm thu; giữ nguyên calculation core và localStorage schema.
* Bổ sung 60 câu hỏi theo ca (20 ca × 3 câu), nâng ngân hàng chuẩn từ 120 lên 180 câu.
* Duy trì cân bằng 4 miền: 45 câu/miền; riêng lô v5.2 có 15 câu/miền và 5 câu ở mỗi mức Cơ bản/Trung bình/Nâng cao.
* Thêm metadata case_id, case_title, case_vignette, case_sequence, case_stage, case_linked, serial_abg, serial_group; schema_version=2 chỉ áp dụng cho câu v5.2.
* Có 8 ca khí máu nối tiếp, phục vụ nền dữ liệu cho progressive disclosure và exam generator ở các phiên bản sau.
* Thêm lựa chọn “Theo ca · 20 câu” nhưng không thay scoring semantics; các blueprint Nhanh/Cân bằng/Nâng cao cũ vẫn giữ nguyên.
* Giao diện assessment hiển thị thẻ bối cảnh ca bệnh responsive, tương thích Light/Dark.
* Không thêm network request, không thay route, Super App, Theme hay Search Dock.

== v5.1 ==
* Assessment Bank Expansion I, branch trực tiếp từ canonical v5.0.1 SHA-256 749a48152627dbe9dc02e186204c3239a32afb8db538ac53f5f1847475e923bb.
* Mở rộng ngân hàng đánh giá từ 48 lên 120 câu hỏi một đáp án tốt nhất; bảo toàn nguyên văn 48 câu legacy.
* Cân bằng 30 câu cho mỗi miền Nền tảng | Toan–kiềm | Oxy hóa & thông khí | Tình huống lâm sàng; mỗi miền 10 Cơ bản + 10 Trung bình + 10 Nâng cao.
* Chuẩn hóa taxonomy bắt buộc cho toàn bộ 120 câu: domain, lesson_id, concept, difficulty, cognitive_level, error_pattern, source_scope, distractor_rationale, remediation_link, item_format và schema_version.
* Bao phủ toàn bộ 39 bài Sổ tay trong ngân hàng mới; thêm gate trùng/gần trùng, lệch vị trí đáp án và referential integrity.
* Giữ nguyên calculation core, scoring semantics, localStorage schema, route, Super App, Theme, Search Dock và hotfix layout v5.0.1.


== v5.0.1 ==
* Lesson Summary Card Layout Hotfix, branch trực tiếp từ v5.0.
* Sửa lỗi chữ trong Mục tiêu bài học của các bài tóm tắt 17 và 27 bị dồn thành một cột trên mobile/tablet.
* Đưa Mục tiêu bài học, Ví dụ minh họa và Tự kiểm tra ra ngoài lưới các bước đọc đánh số của bài tóm tắt.
* Giới hạn CSS của danh sách bước đọc vào các li trực tiếp, ngăn danh sách lồng bên trong kế thừa grid 34px.
* Không thay đổi calculation core, learning engine, localStorage schema, route, Super App, Theme hoặc Search Dock.

== v5.0 ==
* Integrated Learning Portfolio & Mastery Milestones, branch trực tiếp từ baseline v4.9 đã nghiệm thu.
* Bổ sung Hồ sơ học tập tích hợp trên Dashboard, tổng hợp các dấu mốc từ bài học, câu hỏi, thẻ ghi nhớ, tự đánh giá, phân tích ca và nhịp học 7 ngày.
* Bổ sung 5 mốc tự học: Xây nền → Củng cố → Tự đánh giá → Vận dụng → Duy trì; đây là dấu mốc học tập, không phải chứng nhận năng lực chuyên môn.
* Hiển thị mốc tiếp theo và hành động gợi ý ngay trên Trang chủ và trong không gian Học tập.
* Chỉ sử dụng learning state cục bộ hiện có; không đổi localStorage schema, không thêm API/AJAX/cron/request nền.
* Giữ nguyên calculation core, route /phan-tich-khi-mau-app/, Super App, Theme và Search Dock.


== v4.5.1 ==
* Darkens the two remaining bright learning surfaces in Dark mode: the personalized next-step card and the Theory handbook hero.
* Fixes tablet Theory handbook TOC geometry by stacking category accordions vertically, preventing empty grid rows beside open groups.
* Preserves the v4.5 host-theme contract and all clinical/calculation logic.

== v4.5 ==
* Comprehensive Dark Mode Audit & Host Theme Contract.
* WebApp ưu tiên kế thừa trạng thái sáng/tối của Theme/Super App khi chạy nhúng; standalone/PWA dùng thiết lập ABG hoặc chế độ hệ thống làm dự phòng.
* Chuẩn hóa token nền, surface, card, control, border và text trên Dashboard, Phân tích, Phòng Học, Lý thuyết, thẻ ghi nhớ, câu hỏi, assessment, sampling safety và clinical integration.
* Không sửa Theme/Super App/Search Dock; không thêm API/AJAX/cron; calculation core giữ nguyên byte-for-byte.


== v4.4 ==
* Vietnamese Clinical Language & Editorial Consistency.
* Chuẩn hóa lớp nội dung hiển thị: tóm tắt, mô tả, diễn giải, câu hỏi, phản hồi và nội dung học tập sang tiếng Việt y khoa nhất quán.
* Giữ nguyên các ký hiệu/viết tắt chuyên môn chuẩn khi cần thiết; không thay đổi calculation core, learning engine, scoring hoặc localStorage schema.

== v4.3.2 ==
- Unified sticky ABG app header: logo, internal search, menu and workspace navigation.
- Dark-mode custom picker for classroom controls.
- Editorial UX copy polish across Home, Classroom and Theory.

== v4.3 ==
* Visual Learning Dashboard & Progress Intelligence, branch trực tiếp từ v4.2.5.
* Thiết kế lại Dashboard với Learning Snapshot, vòng tiến độ tổng hợp, ưu tiên học tiếp, bản đồ 6 miền kiến thức và insight học tập cục bộ.
* Giảm các KPI card đồng dạng; ưu tiên visual hierarchy, progress bar và trạng thái Mới / Đang học / Cần ôn / Đã vững.
* Responsive và dark mode được thiết kế đồng thời; không thêm API, AJAX, cron hoặc đồng bộ máy chủ.
* Không thay đổi learning engine, calculation core, localStorage schema, route, Super App, Theme hoặc Search Dock.

== v4.2.4 ==
* Dark Mode Component & Vietnamese UI Polish, branch trực tiếp từ v4.2.1.
* Chuẩn hóa select/option, input, button và các learning card theo token sáng/tối của WebApp; ưu tiên khả năng đọc trên menu chọn native của trình duyệt.
* Việt hóa nhãn Trang chủ: ĐIỂM NHẤN LÂM SÀNG, ĐIỀU CẦN NHỚ, CÂU HỎI NHANH, CA 60 GIÂY; loại bỏ nhãn Clinical Pearl / Fact / Quiz trùng nghĩa.
* Giữ nguyên learning engine, calculation core, route, localStorage, Super App và Theme.

== Kiến trúc v3.1 ==
- Branch trực tiếp từ v3.0.1.
- Ba tab cấp cao: Phân tích | Ôn tập | Lý thuyết.
- Phân tích: giữ nguyên công cụ nhập số liệu, diễn giải khí máu, oxy hóa, tóm tắt lâm sàng, ca thực hành và chuỗi theo dõi.
- Ôn tập: câu hỏi theo chủ đề, Hỏi & đáp, thẻ ghi nhớ, kiểm tra tổng hợp và tiến độ học tập tại thiết bị.
- Lý thuyết: chỉ chứa 39 bài lý thuyết/tình huống minh họa của Sổ tay khí máu; không còn hệ thống câu hỏi trong cùng cửa sổ.
- Liên kết chéo: Lý thuyết → Phân tích; Phân tích → đúng bài Lý thuyết; Lý thuyết → Ôn tập.

== Ngôn ngữ giao diện ==
- Ưu tiên tiếng Việt trong tiêu đề, giải thích, tóm tắt và hướng dẫn.
- Giữ các ký hiệu/công thức chuẩn như pH, PaCO₂, PaO₂, HCO₃⁻, FiO₂ và các viết tắt đã quen dùng như COPD, SGLT2.
- Các cụm tiếng Anh hoặc thuật ngữ triển khai nội bộ không được dùng làm tiêu đề giao diện người dùng cuối.
- Các nội dung phát sinh từ calculation core được chuẩn hóa cách hiển thị ở lớp giao diện mà không sửa calculation core.

== Dữ liệu và riêng tư ==
- Calculation core không thay đổi so với v3.0.1.
- Tiến độ ôn tập tiếp tục lưu bằng localStorage trên thiết bị.
- Chuỗi khí máu trong phiên tiếp tục dùng sessionStorage.
- Không thêm API, AJAX, cron hoặc request nền để lưu tiến độ học tập.

== Route ==
/phan-tich-khi-mau-app/


== v3.3 ==
* Bổ sung Thử thách ca lâm sàng trong tab Ôn tập.
* 9 ca phân tầng Cơ bản, Trung bình và Nâng cao.
* Mỗi ca yêu cầu người học tự trả lời từng bước trước khi mở giải thích.
* Liên kết từ thử thách sang phần Lý thuyết tương ứng.
* Tiến độ thử thách lưu cục bộ trên thiết bị; không phát sinh request nền.
* Giữ nguyên calculation core và kiến trúc Phân tích | Ôn tập | Lý thuyết.

== v3.2 ==
* Giữ nguyên kiến trúc ba tab Phân tích | Ôn tập | Lý thuyết.
* Bổ sung khu vực Nhìn nhanh với ba sơ đồ trực quan: phổi–thận–pH, ma trận bốn rối loạn nguyên phát và đường đi của oxy.
* Bổ sung Bảng tra nhanh có thể mở/đóng trong tab Lý thuyết: khoảng tham chiếu, công thức Winter, khoảng trống anion, phương trình khí phế nang, tỷ số oxy hóa và thứ tự đọc gợi ý.
* Không thay calculation core, dữ liệu học tập hoặc route ứng dụng.


== Mở rộng v3.4 ==
- Branch trực tiếp từ v3.3; giữ nguyên ba tab Phân tích | Ôn tập | Lý thuyết.
- Bổ sung chuyên đề trực quan về nhận diện rối loạn toan–kiềm phối hợp trong tab Lý thuyết.
- Bổ sung 8 tình huống luyện tập rối loạn phối hợp trong tab Ôn tập, trình bày từng bước trước khi mở giải thích.
- Nhấn mạnh ba lớp kiểm tra: rối loạn nguyên phát → đáp ứng dự kiến → so sánh khoảng trống anion với mức giảm HCO₃⁻ khi phù hợp.
- Tiến độ chuyên đề lưu cục bộ bằng localStorage; không thêm request nền lên máy chủ.
- Không thay đổi calculation core, ngưỡng hoặc logic phân tích của tab Phân tích.
- Giao diện người dùng ưu tiên tiếng Việt; không đưa thuật ngữ triển khai nội bộ lên giao diện.


== Mở rộng v3.5 ==
- Branch trực tiếp từ v3.4; giữ nguyên ba tab Phân tích | Ôn tập | Lý thuyết.
- Bổ sung chuyên đề Oxy hóa máu và thông khí chuyên sâu trong tab Lý thuyết.
- Phân tách hai trục PaO₂/oxy hóa máu và PaCO₂/thông khí phế nang; bổ sung cách dùng FiO₂, phương trình khí phế nang, chênh áp A–a và tỷ số PaO₂/FiO₂ theo bối cảnh.
- Trình bày năm cơ chế giảm oxy máu: giảm oxy hít vào, giảm thông khí, mất tương hợp thông khí–tưới máu, luồng thông trong phổi và hạn chế khuếch tán.
- Bổ sung 8 tình huống luyện tập chuyên sâu, mỗi tình huống yêu cầu tự nhận định trước khi mở giải thích.
- Nhắc rõ PaO₂ bình thường không loại trừ rối loạn vận chuyển oxy do hemoglobin bất thường.
- Tiến độ chuyên đề lưu cục bộ bằng localStorage; không thêm API, AJAX, cron hoặc request nền.
- Calculation core, route và logic phân tích của tab Phân tích không thay đổi.

== Mở rộng v3.6 ==

- Bổ sung chuyên đề Chất lượng mẫu khí máu trong tab Lý thuyết: định danh, nguồn mẫu, điều kiện oxy/thông khí, heparin, bọt khí, cục máu, nhiễm dịch đường truyền, vận chuyển và đối chiếu với lâm sàng.
- Bổ sung bảng kiểm bảy điểm trước khi diễn giải một kết quả không phù hợp lâm sàng.
- Bổ sung 8 tình huống luyện tập về bọt khí, heparin lỏng dư, chậm phân tích, lấy nhầm máu tĩnh mạch, nhiễm dịch đường động mạch, thay đổi oxy quanh thời điểm lấy mẫu, cục máu và giảm oxy giả khi tăng bạch cầu rất cao.
- Tiến độ các tình huống v3.6 chỉ lưu tại trình duyệt bằng localStorage; không có API, AJAX, cron hoặc request nền mới.
- Calculation core không thay đổi so với v3.5.


== Mở rộng v3.7 ==
- Branch trực tiếp từ v3.6; giữ nguyên ba tab Phân tích | Ôn tập | Lý thuyết.
- Bổ sung lộ trình ôn tập thích ứng trong tab Ôn tập, ưu tiên câu đến hạn, câu từng trả lời sai và chủ đề còn yếu.
- Ghi nhận hiệu suất theo bốn nhóm kiến thức: Nền tảng, Rối loạn toan–kiềm, Oxy hóa máu và suy hô hấp, Tình huống lâm sàng.
- Áp dụng lịch ôn lại có khoảng cách theo mức độ ghi nhớ; câu trả lời sai được đưa lại vào hàng đợi sớm hơn, câu trả lời đúng liên tiếp được giãn khoảng ôn.
- Bổ sung gợi ý chủ đề ưu tiên và phiên ôn thích ứng tối đa 8 câu/lượt.
- Kết quả bài kiểm tra tổng hợp cũng được đưa vào lịch sử học để cập nhật gợi ý ôn tập.
- Dữ liệu v3.0 trước đây được kế thừa; v3.7 chỉ mở rộng cấu trúc dữ liệu localStorage, không xóa tiến độ cũ.
- Toàn bộ tiến độ và lộ trình cá nhân hóa tiếp tục lưu cục bộ trên thiết bị; không thêm API, AJAX, cron hoặc request nền.
- Calculation core, route và logic phân tích lâm sàng không thay đổi.


== Mở rộng v3.8 ==
- Branch trực tiếp từ v3.7; giữ nguyên ba tab Phân tích | Ôn tập | Lý thuyết và toàn bộ lớp ôn tập thích ứng.
- Nâng cấp Kiểm tra tổng hợp thành khu vực Thi và đánh giá có cấu trúc, không hiển thị đáp án hoặc giải thích trong khi đang làm bài.
- Ngân hàng đánh giá hiện gồm 180 câu, trong đó 60 câu gắn với 20 ca lâm sàng; taxonomy vẫn theo bốn miền kiến thức, bài học, khái niệm, độ khó, mức nhận thức và kiểu lỗi.
- Có ba cấu trúc đề: Nhanh 12 câu, Cân bằng 16 câu và Nâng cao 20 câu; mỗi cấu trúc quy định số câu theo miền kiến thức và độ khó.
- Cho phép di chuyển giữa câu hỏi, đánh dấu câu cần xem lại và chỉ chấm điểm khi nộp bài.
- Báo cáo sau khi nộp gồm điểm tổng, kết quả theo miền kiến thức, kết quả theo độ khó và phân tích từng câu trả lời sai.
- Kết quả đánh giá được lưu cục bộ trong medipharm_abg_learning_v30 và kế thừa tiến độ v3.7; không thêm API, AJAX, cron hoặc request nền.
- Calculation core, route và logic phân tích lâm sàng không thay đổi.


== Mở rộng v3.9 ==
- Branch trực tiếp từ v3.8; giữ nguyên ba tab Phân tích | Ôn tập | Lý thuyết, Adaptive Learning và Thi & đánh giá.
- Bổ sung lựa chọn Bối cảnh chăm sóc và Câu hỏi lâm sàng cần làm rõ ngay tại bước nhập ca bệnh.
- Bổ sung thẻ Tích hợp với bối cảnh lâm sàng trong kết quả: tổng hợp mẫu hình khí máu, dữ kiện lâm sàng đã chọn, khoảng trống dữ liệu và các điểm cần đối chiếu.
- Bổ sung cảnh báo mâu thuẫn quan trọng như dùng mẫu tĩnh mạch để đánh giá oxy hóa, thiếu FiO₂/PaO₂, thiếu Na⁺/Cl⁻ khi cần khoảng trống anion, thiếu albumin khi cần hiệu chỉnh, hoặc thiếu xét nghiệm đồng oxy kế trong bệnh cảnh phù hợp.
- Bổ sung chuyên đề Tích hợp kết quả khí máu với bối cảnh lâm sàng trong tab Lý thuyết và liên kết từ kết quả sang đúng nhóm lý thuyết/ôn tập.
- Không tự xác lập chẩn đoán hoặc đưa phác đồ điều trị; lớp tích hợp chỉ cấu trúc hóa câu hỏi, dữ kiện và điểm cần kiểm chứng.
- Không thêm API, AJAX, cron hoặc request nền; dữ liệu học tập tiếp tục local-first.
- Calculation core, route và thuật toán phân tích nền không thay đổi.


== v4.0 – Nền tảng học tập khí máu ==
- Branch trực tiếp từ v3.9 và hợp nhất toàn bộ chuỗi Phân tích | Lý thuyết | Ôn tập thích ứng | Thi & đánh giá | Tích hợp lâm sàng thành một hành trình học tập thống nhất.
- Bổ sung Bảng điều khiển học tập trong tab Ôn tập, hiển thị số bài lý thuyết đã mở, câu hỏi đã nắm, điểm đánh giá tốt nhất và số lượt phân tích đã thực hiện trên thiết bị.
- Bổ sung gợi ý “Học tiếp” dựa trên tiến độ hiện có; gợi ý chỉ phục vụ tổ chức tự học và không phải đánh giá năng lực chuyên môn.
- Ghi nhận cục bộ bài lý thuyết đã mở và lượt phân tích để tạo tính liên tục giữa ba tab; không lưu thông tin nhận dạng người bệnh.
- Giữ nguyên khóa localStorage medipharm_abg_learning_v30 và mở rộng schema tại chỗ để không làm mất tiến độ từ v3.0–v3.9.
- Giữ nguyên route /phan-tich-khi-mau-app/, PWA, cấu trúc ba tab và calculation core.
- Không thêm API, AJAX, cron hoặc request nền.


= 4.2 =
* Nâng Trang chủ WebApp thành giao diện học tập tương tác, không còn chỉ là launcher chức năng.
* Thêm Learning Feed cục bộ: Điểm nhấn lâm sàng, Điều cần nhớ, Câu hỏi nhanh và Ca 60 giây; tổ hợp nội dung thay đổi mỗi lần mở hoặc khi bấm “Đổi nội dung”.
* Quiz và Ca 60 giây phản hồi ngay trên Trang chủ, có liên kết sang chủ đề lý thuyết hoặc đưa ca mẫu sang phần Phân tích.
* Bổ sung dashboard tiến độ và gợi ý học tiếp dựa trên trạng thái local-first hiện có.
* Ngân hàng v4.2 gồm 24 Điểm nhấn lâm sàng, 24 Điều cần nhớ, 24 Câu hỏi nhanh và 16 Ca 60 giây.
* Không thêm AJAX/API/cron/background request; nội dung random hoàn toàn ở trình duyệt.
* Không sửa Super App, Theme hoặc Search Dock trong release này.
* Calculation core giữ nguyên byte-for-byte.

= 4.1.1 =
* Sửa dứt điểm lỗi bố cục card đáp án ở Phòng Học và Đánh giá: chữ không còn bị co dồn thành cột dọc ở mép phải.
* Tăng độ ưu tiên CSS cho các phương án trả lời trong Câu hỏi theo chủ đề, Thử thách ca lâm sàng, Rối loạn phối hợp, An toàn tiền phân tích và các đề đánh giá.
* Bổ sung lớp riêng cho nội dung phương án để chống xung đột CSS từ theme/WordPress.
* Không thay đổi calculation core, dữ liệu học tập hay route hiện có.

= 4.1 =
* Chuyển trải nghiệm standalone thành webapp học tập với Trang chủ, Phân tích, Phòng Học và Lý thuyết.
* Chuyển Phòng học Ca lâm sàng khỏi form Phân tích sang Phòng Học.
* Bổ sung Dashboard Phòng Học, Knowledge Map, flashcard trực quan và shortcode launcher [medipharm_abg_launcher].
* Giữ nguyên calculation core và lưu tiến độ local-first.



= 4.9 =
* Bổ sung Learning Analytics & Review Readiness: nhịp học 7 ngày, trạng thái sẵn sàng tự kiểm tra và gợi ý củng cố từ dữ liệu học tập cục bộ hiện có.
* Không tạo hồ sơ máy chủ hoặc request nền; phân tích tiến độ được suy ra trực tiếp từ lịch sử câu hỏi, thẻ ghi nhớ, bài đã mở và các lượt tự đánh giá đã lưu trên thiết bị.
* Sửa điều hướng Bản đồ kiến thức trên mobile/tablet: khi chọn một miền, bài đích được mở và đưa chính xác vào vùng nhìn thấy bên dưới App Bar sticky.
* Chuẩn hóa cuộn đến bài học từ mục lục/cross-link theo cùng sticky-aware viewport contract.
* Calculation core, route, Super App, Theme và Search Dock không thay đổi.

= 4.8 =
* Khóa v4.7.1 làm baseline và bổ sung Kế hoạch học hôm nay gồm ba bước Hiểu → Nhớ → Áp dụng/Đánh giá dựa trên tiến độ cục bộ.
* Bổ sung phiên học gợi ý khoảng 15 phút trong không gian Học tập, dùng cùng engine ưu tiên chủ đề/câu đến hạn hiện có.
* Thêm chỉ báo mức dữ liệu gợi ý để tránh tạo cảm giác cá nhân hóa quá mức khi người dùng mới bắt đầu.
* Kế hoạch tự cập nhật sau khi mở bài, trả lời câu hỏi, ôn thẻ, làm đánh giá hoặc hoàn thành phân tích; không thêm localStorage schema mới.
* Không thêm API, AJAX, cron hoặc request nền; calculation core, route, Theme, Super App và Search Dock không thay đổi.

= 4.7.1 =
* Sửa rò rỉ nội dung Trang chủ sang tab Phân tích bằng workspace visibility contract rõ ràng.
* Tinh gọn microcopy Trang chủ, loại bỏ mô tả mang tính kỹ thuật nội bộ.
* Chuẩn hóa nội dung feed Trang chủ qua lớp Việt hóa công khai để tránh lẫn thuật ngữ Anh không cần thiết.

= 4.7 =
* Hợp nhất Phòng Học và Lý thuyết thành một không gian Học tập với hai chế độ Luyện tập / Bài học.
* Bổ sung nhận diện màu nhấn riêng cho Trang chủ, Phân tích và Học tập.
* Sửa bố cục lược đồ oxy hóa–thông khí trên tablet/mobile.
* Chuẩn hóa thêm dark-mode surface cho bài học, câu hỏi, ví dụ và card chuyên đề.

= 4.6 =
* Nâng Sổ tay thành hệ bài học tương tác với mục tiêu, ví dụ minh họa và tự kiểm tra cho 39 bài.

== v5.9 – Content Governance & Production Audit ==
* Khóa corpus v6.0 ở 220 câu, 50 bài, 50 ca và 6 dạng câu hỏi sau audit nội dung, đáp án, trùng lặp, Việt hóa, responsive và Dark mode.
* Mở rộng bộ thi thử cố định từ 6 lên 8 bộ mà không thêm câu hỏi mới.
* Thêm Đề Tổng hợp B và Đề Đa định dạng; cả hai dùng seed cố định và không lặp câu trong cùng đề.
* Calculation core, route, trial gate và local-first storage giữ nguyên.


== v5.8 – Longitudinal Assessment Intelligence ==
* Xu hướng tối đa 10 lượt đánh giá gần nhất: điểm, thay đổi gần đây, độ ổn định và gánh nặng ôn đến hạn.
* So sánh theo 4 miền kiến thức từ metadata đã lưu trong assessment.history.
* Chỉ số chỉ phục vụ tự học; không suy diễn hoặc chứng nhận năng lực lâm sàng.
* Không tạo storage key mới, không analytics mạng, không đổi calculation core.


== v5.7 – Error Pattern & Targeted Remediation ==
* Phân loại 7 kiểu lỗi suy luận từ các câu trả lời sai trong luyện tập và đánh giá.
* Tạo Lộ trình cải thiện cá nhân liên kết trực tiếp bài Sổ tay, thẻ ghi nhớ và ca thực hành.
* Kết quả thi lưu snapshot errorPatterns để làm nền cho phân tích dọc v5.8.
* Giữ nguyên khóa localStorage hiện có; không tạo request nền hoặc thay scoring.
* Launcher Trang chủ được thu gọn thành một card duy nhất, responsive trên tablet/mobile.


== v5.7.1 – Homepage Learning Hierarchy & Compact Profile Hotfix ==
* Đưa “Chọn cách bạn muốn học” lên ngay sau “Tiến độ của bạn”.
* Mỗi module Trang chủ dùng một tiêu đề chính; loại bỏ cặp tiêu đề/tiêu đề phụ trùng nghĩa.
* Tách Hồ sơ học tập khỏi Tiến độ và tái bố cục thành dashboard cô đọng, trực quan hơn trên desktop/tablet/mobile.
* Giữ nguyên calculation core, assessment/remediation engine, 220 câu, 50 bài, 50 ca, trial gate, route và localStorage.

== v6.0 – Integrated ABG Learning & Assessment Platform ==
- Hợp nhất Sổ tay, thẻ ghi nhớ, ôn thích ứng, ca lâm sàng, thi thử và trình sinh đề trong một Phiên học tích hợp.
- Corpus production giữ 220 câu, 50 bài, 50 ca, 8 bộ thi thử và 6 dạng câu hỏi.
- Giữ nguyên calculation core, localStorage hiện hữu, trial gate và mô hình local-first; không thêm analytics mạng.
- v5.9 governance freeze được giữ nguyên, v6.0 chỉ hợp nhất trải nghiệm và điều hướng học tập.

== v6.0.2 – Landing Page Visual Refresh & Trial Footer Hotfix ==
* Hero Trang chủ chỉ còn một tiêu đề chính: “Khám phá khí máu lâm sàng”; bỏ eyebrow trùng nghĩa.
* Microcopy chuyển sang giọng mời gọi, trực quan và sát lâm sàng; CTA phụ đổi thành “Khám phá bài học”.
* Đồ họa hero mới dùng pulse ABG, thẻ chỉ số PaCO₂/HCO₃⁻/PaO₂, wave line và strip 220 câu / 50 bài / 50 ca / 8 bộ thi.
* Trạng thái dùng thử được chuyển khỏi phần trên ứng dụng xuống footer bên trái với wording: “Còn x/10 lượt dùng thử. Vui lòng đăng nhập hoặc đăng ký để truy cập đầy đủ. Đăng ký/Đăng nhập”.
* Link Đăng ký/Đăng nhập mở trực tiếp form do Membership/Clinical Access hiện có sở hữu và không tiêu hao thêm lượt dùng thử.
* Không thay calculation core, corpus, scoring, localStorage, remediation, longitudinal analytics, integrated session, route hoặc access policy.

== v6.0.2 – Access Gate & Search Dock Layering Hotfix ==
- Mở rộng vùng hiển thị form đăng nhập thành viên; ở viewport hẹp hơn 1180px form chuyển sang hàng riêng thay vì bị ép vào cột nhỏ.
- Giữ nguyên form do Membership / Clinical Access sở hữu, không sao chép markup hay logic xác thực.
- Hạ z-index nội bộ của sticky header, workspace tabs, menu, search result và picker về thang ứng dụng cục bộ để NAH Search Dock Right Rail luôn nổi phía trên WebApp.
- Không thay calculation core, trial policy, route, storage, assessment corpus, Sổ tay hoặc ca lâm sàng.


== v6.0.9 ==
* Tablet dark wrapper: ABG shell becomes edge-to-edge at 701–1024 px to remove light outer gutters.
* Mobile density: flattens redundant outer wrappers, reduces nested padding, and increases key body-text sizes.
* No calculation, corpus, access, route, storage or shared-theme logic changes.




= 6.3.9 =
* Sửa triệt để bố cục mobile: 5 bước Phân tích co vừa chiều rộng, không còn thanh cuộn ngang; các nút điều hướng tôn trọng thuộc tính hidden.
* Card module Trang chủ dùng grid placement tường minh để không còn icon đè chữ trên điện thoại và thiết bị gập.
* Form Đăng nhập được rút gọn còn Tên đăng nhập/email + Mật khẩu + Đăng nhập + Quên mật khẩu + Đăng ký; bỏ toàn bộ khối provider lặp, checkbox lưu đăng nhập, chú thích trình duyệt và CTA đăng ký trùng.
* Giữ nguyên membership entitlement check, calculation core, corpus, trial policy, route, localStorage và Android package.

= 6.3.8 =
* Sửa logo ABG: bấm logo quay về Trang chủ WebApp `/phan-tich-khi-mau-app/`, không redirect về Trang chủ website.
* Bổ sung responsive riêng cho mobile, tablet cảm ứng và thiết bị gập: dùng pointer/coarse + breakpoint đến 1366px và container queries.
* Foldable/tablet chuyển sang header 2 hàng, điều hướng qua Menu, module grid 3→2→1 cột theo chiều rộng thực tế.
* Mobile tối ưu hero, logo, tìm kiếm, menu/account popover và dynamic viewport height.
* Không thay calculation core, corpus, trial policy, route dữ liệu hoặc Android package.

= 6.3.7 =
* Mockup-Aligned WebApp: đồng bộ Trang chủ Desktop/Mobile và màn hình đăng nhập theo hệ nhận diện O₂/CO₂ – ABG.
* Desktop: hero chuyên môn, 5 module chính, Nhập nhanh thông số khí máu và Hoạt động gần đây.
* Mobile: bỏ dropdown điều hướng lớn; điều hướng chuyển vào Menu, giữ header Logo + Tài khoản + Menu + Tìm kiếm, hero cô đọng và card Kiến thức nổi bật.
* Form đăng nhập trong WebApp được bọc trong ABG branded shell nhưng giữ nguyên provider xác thực Membership hiện hữu.
* Không thay calculation core, corpus, trial policy, route, localStorage hoặc Android package.


= 6.3.6 =
* Focused Clinical Home: xây lại Trang chủ theo bố cục mockup, giảm mật độ thông tin và ưu tiên hành trình Phân tích → Học tập → Ca lâm sàng → Ôn luyện → Tiến độ.
* Header chuẩn hóa Logo + tìm kiếm một lớp + Tài khoản + Menu; sửa lỗi ô tìm kiếm chồng viền/icon trên tablet/mobile.
* Điều hướng chính có icon chuyên môn, nhãn ngắn gọn và responsive.
* Hero chuyển sang tiêu đề chuyên môn “Khí máu lâm sàng”, loại microcopy mang tính audit/kỹ thuật nội bộ.
* Các module chính hiển thị thành 5 card đồng cấp; Tiếp tục học và Tiến độ học tập được gom thành một hàng tóm tắt.
* Giữ nguyên thuật toán ABG, dữ liệu học tập và hệ nhận diện O₂/CO₂.

= 6.3.5 =
* Trang chủ trở thành màn hình mặc định; header chuẩn hóa Logo + Tìm kiếm + Tài khoản + Menu.
* Điều hướng responsive 6 module và homepage IA được tổ chức lại, không thay đổi logic ABG.

# MEDIPHARM ABG Suite v6.2.1 — Generator Deadlock Hotfix

## Parent
- Exact parent: MEDIPHARM-ABG-Suite-v6.2.zip
- Parent SHA-256: `5ad986d53bd4e9c11b7c1807d77412132b79e39b7f8b14dca67200c16cf043a9`

## Fixed
- Tạo đề luyện tập no longer waits for an access AJAX response before building the local exam.
- Member access is now also stamped on the rendered ABG root, preventing a mismatch between the server-rendered member footer and the JavaScript access snapshot.
- Generator start is synchronous for members and for guests with a valid page-load trial snapshot; guest quota is reconciled afterward.
- Failure recovery now clears the exam shell, stops the timer, restores the setup screen and resets the Start button instead of leaving a busy state.

## Preserved
- 220 canonical assessment items.
- 50 handbook lessons.
- 50 clinical cases.
- 8 mock-test packs.
- 8-workspace navigation from v6.2.
- Trial policy, shared dark-mode ownership, Search Dock layering, route and localStorage.
- Calculation core unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

# MEDIPHARM ABG Suite v6.11.0 — Expanded Clinical Cases

- Bổ sung 12 ca mới, tổng số 25 ca lâm sàng contextual.
- Giữ nguyên viewport-adaptive content modal, calculation core và công cụ Phân tích.
- Cập nhật liên kết chéo Chuyên đề → Ca lâm sàng.

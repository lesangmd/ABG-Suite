<?php
/**
 * MEDIPHARM ABG Suite arterial blood gas application module.
 *
 * @package NAH_Search_Dock_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MEDIPHARM_ABG_Suite_Module {

	/**
	 * Singleton instance.
	 *
	 * @var MEDIPHARM_ABG_Suite_Module|null
	 */
	private static $instance = null;

	/**
	 * Whether assets have already been registered.
	 *
	 * @var bool
	 */
	private $assets_registered = false;

	/** Whether this request has already consumed one guest protected action. */
	private $trial_consumed_this_request = false;

	/**
	 * Get plugin instance.
	 *
	 * @return MEDIPHARM_ABG_Suite_Module
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * The parent plugin owns all hooks to avoid collisions with the standalone
	 * NAH Phân tích Khí máu plugin.
	 */
	private function __construct() {
	}

	/**
	 * Kept for API compatibility inside this bundled module. The parent plugin
	 * intentionally does not call it because the standalone plugin may already
	 * own the public shortcode.
	 */
	public function register_shortcode() {
		add_shortcode( 'nah_abg_analyzer', array( $this, 'render_analyzer' ) );
	}

	/**
	 * Register assets without loading them on unrelated pages.
	 */
	private function register_assets() {
		if ( $this->assets_registered ) {
			return;
		}

		wp_register_style(
				'medipharm-abg-suite-style',
				MEDIPHARM_ABG_SUITE_URL . 'assets/css/nah-abg.css',
				array(),
				MEDIPHARM_ABG_SUITE_VERSION
		);

		wp_register_script(
				'medipharm-abg-suite-core',
				MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-core.js',
				array(),
				MEDIPHARM_ABG_SUITE_VERSION,
			true
		);

		wp_register_script(
				'medipharm-abg-suite-ui',
				MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-ui.js',
				array( 'medipharm-abg-suite-core' ),
				MEDIPHARM_ABG_SUITE_VERSION,
			true
		);

		wp_register_script(
				'medipharm-abg-suite-canonical-learning',
				MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-canonical-learning.js',
				array( 'medipharm-abg-suite-ui' ),
				MEDIPHARM_ABG_SUITE_VERSION,
			true
		);

		wp_localize_script(
				'medipharm-abg-suite-ui',
				'NAHABGConfig',
				array(
					'version'     => MEDIPHARM_ABG_SUITE_VERSION,
					'manifestUrl' => add_query_arg( 'nah_sdp_abg_manifest', '1', home_url( '/' ) ),
					'swUrl'       => add_query_arg( 'nah_sdp_abg_sw', '1', home_url( '/' ) ),
					'appUrl'      => home_url( '/phan-tich-khi-mau-app/' ),
					'isHttps'     => is_ssl(),
					'learningBaseUrl' => MEDIPHARM_ABG_SUITE_URL . 'assets/data/learning/',
					'learningVersion' => '1.0.1',
				)
		);

		$this->assets_registered = true;
	}

	/**
	 * Register and enqueue the embedded analyzer assets early enough for footer
	 * rendering by the Dock.
	 */
	public function enqueue_assets() {
		$this->register_assets();
		wp_enqueue_style( 'medipharm-abg-suite-style' );
		wp_enqueue_script( 'medipharm-abg-suite-core' );
		wp_enqueue_script( 'medipharm-abg-suite-ui' );
		wp_enqueue_script( 'medipharm-abg-suite-canonical-learning' );
	}

	/**
	 * Determine whether the current singular post contains the analyzer.
	 *
	 * @return bool
	 */
	private function current_page_has_analyzer() {
		global $post;

		return is_singular()
			&& $post instanceof WP_Post
			&& has_shortcode( (string) $post->post_content, 'nah_abg_analyzer' );
	}

	/**
	 * Get a safe same-origin start path for the PWA.
	 *
	 * @param string $candidate Requested path.
	 * @return string
	 */
	private function sanitize_start_path( $candidate ) {
		$candidate = is_string( $candidate ) ? trim( rawurldecode( $candidate ) ) : '/';

		if ( '' === $candidate || '/' !== substr( $candidate, 0, 1 ) || false !== strpos( $candidate, '://' ) ) {
			return '/';
		}

		$parts = wp_parse_url( $candidate );
		if ( ! is_array( $parts ) || empty( $parts['path'] ) ) {
			return '/';
		}

		$path = '/' . ltrim( sanitize_text_field( $parts['path'] ), '/' );
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query_args );
			unset( $query_args['nah_sdp_abg_manifest'], $query_args['nah_sdp_abg_sw'], $query_args['start'] );
			if ( ! empty( $query_args ) ) {
				$path = add_query_arg( map_deep( $query_args, 'sanitize_text_field' ), $path );
			}
		}

		return $path;
	}

	/**
	 * Return the current request path without host information.
	 *
	 * @return string
	 */
	private function current_start_path() {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		return $this->sanitize_start_path( $request_uri );
	}

	/**
	 * Output manifest and mobile-app metadata on shortcode pages.
	 */
	public function output_pwa_meta() {
		if ( ! $this->current_page_has_analyzer() ) {
			return;
		}

		$start        = $this->current_start_path();
		$manifest_url = add_query_arg(
			array(
					'nah_sdp_abg_manifest' => '1',
				'start'            => $start,
			),
			home_url( '/' )
		);
		?>
		<link rel="manifest" href="<?php echo esc_url( $manifest_url ); ?>">
		<meta name="theme-color" content="#0b6674">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="default">
		<meta name="apple-mobile-web-app-title" content="NAH Khí máu">
		<link rel="apple-touch-icon" href="<?php echo esc_url( MEDIPHARM_ABG_SUITE_URL . 'assets/icons/icon-192.png' ); ?>">
		<?php
	}

	/**
	 * Serve dynamic manifest and root-scoped service worker.
	 */
	public function serve_pwa_endpoint() {
		$is_manifest = isset( $_GET['nah_sdp_abg_manifest'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_worker   = isset( $_GET['nah_sdp_abg_sw'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! $is_manifest && ! $is_worker ) {
			return;
		}

		$requested_start = isset( $_GET['start'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? wp_unslash( $_GET['start'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '/';
		$start           = $this->sanitize_start_path( $requested_start );

		nocache_headers();
		header( 'X-Content-Type-Options: nosniff' );

		if ( $is_manifest ) {
			$path  = wp_parse_url( $start, PHP_URL_PATH );
			$scope = is_string( $path ) && '' !== $path ? $path : '/';
			$data  = array(
				'id'          => $start,
				'name'        => 'MEDIPHARM ABG – Khí máu Động mạch',
				'short_name'  => 'Khí máu',
				'description' => 'Nền tảng học tập khí máu động mạch tích hợp phân tích, lý thuyết, ôn tập thích ứng và tự đánh giá.',
				'lang'        => 'vi',
				'start_url'   => $start,
				'scope'       => $scope,
				'display'     => 'fullscreen',
				'display_override' => array( 'fullscreen', 'standalone' ),
				'orientation' => 'any',
				'background_color' => '#ffffff',
				'theme_color'      => '#0b6674',
				'icons'            => array(
					array(
						'src'     => MEDIPHARM_ABG_SUITE_URL . 'assets/icons/icon-192.png',
						'sizes'   => '192x192',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
					array(
						'src'     => MEDIPHARM_ABG_SUITE_URL . 'assets/icons/icon-512.png',
						'sizes'   => '512x512',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
				),
			);

			header( 'Content-Type: application/manifest+json; charset=utf-8' );
			echo wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			exit;
		}

		$precache = array(
			MEDIPHARM_ABG_SUITE_URL . 'assets/css/nah-abg.css?ver=' . rawurlencode( MEDIPHARM_ABG_SUITE_VERSION ),
			MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-core.js?ver=' . rawurlencode( MEDIPHARM_ABG_SUITE_VERSION ),
			MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-ui.js?ver=' . rawurlencode( MEDIPHARM_ABG_SUITE_VERSION ),
			MEDIPHARM_ABG_SUITE_URL . 'assets/icons/icon-192.png',
			MEDIPHARM_ABG_SUITE_URL . 'assets/icons/icon-512.png',
		);
		$cache_name = 'medipharm-abg-suite-v' . preg_replace( '/[^0-9a-z.-]/i', '-', MEDIPHARM_ABG_SUITE_VERSION );

		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /phan-tich-khi-mau-app/' );
		?>
'use strict';
const CACHE_NAME = <?php echo wp_json_encode( $cache_name ); ?>;
const START_URL = <?php echo wp_json_encode( $start ); ?>;
const PRECACHE = <?php echo wp_json_encode( $precache, JSON_UNESCAPED_SLASHES ); ?>;

self.addEventListener('install', (event) => {
	event.waitUntil(
		caches.open(CACHE_NAME)
			.then((cache) => cache.addAll(PRECACHE.concat([START_URL])))
			.then(() => self.skipWaiting())
	);
});

self.addEventListener('activate', (event) => {
	event.waitUntil(
		caches.keys()
			.then((keys) => Promise.all(keys.filter((key) => key.startsWith('medipharm-abg-suite-v') && key !== CACHE_NAME).map((key) => caches.delete(key))))
			.then(() => self.clients.claim())
	);
});

self.addEventListener('fetch', (event) => {
	const request = event.request;
	if (request.method !== 'GET') return;
	const url = new URL(request.url);
	if (url.origin !== self.location.origin) return;

	if (request.mode === 'navigate') {
		event.respondWith(
			fetch(request)
				.then((response) => {
					const copy = response.clone();
					caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
					return response;
				})
				.catch(() => caches.match(request).then((cached) => cached || caches.match(START_URL)))
		);
		return;
	}

	if (url.pathname.includes('/modules/abg/assets/')) {
		event.respondWith(
			caches.match(request).then((cached) => cached || fetch(request).then((response) => {
				const copy = response.clone();
				caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
				return response;
			}))
		);
	}
});
		<?php
		exit;
	}

	/**
	 * Render a compact interactive launcher for a WordPress homepage.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_launcher( $atts = array() ) {
		wp_enqueue_style( 'medipharm-abg-suite-launcher', MEDIPHARM_ABG_SUITE_URL . 'assets/css/nah-abg-launcher.css', array(), MEDIPHARM_ABG_SUITE_VERSION );
		wp_enqueue_script( 'medipharm-abg-suite-launcher', MEDIPHARM_ABG_SUITE_URL . 'assets/js/nah-abg-launcher.js', array(), MEDIPHARM_ABG_SUITE_VERSION, true );
		$atts = shortcode_atts( array( 'title' => 'Khí máu động mạch' ), $atts, 'medipharm_abg_launcher' );
		$app = home_url( '/phan-tich-khi-mau-app/' );
		$trial = $this->trial_access_status( false );
		ob_start(); ?>
		<section class="nah-abg-launcher nah-abg-launcher--compact" aria-label="<?php echo esc_attr( $atts['title'] ); ?>" data-abg-launcher data-app-url="<?php echo esc_url( $app ); ?>">
			<div class="nah-abg-launcher__compact-card">
				<div class="nah-abg-launcher__compact-copy"><span>MEDIPHARM ABG · v6.11.3</span><h2><?php echo esc_html( $atts['title'] ); ?></h2><p>Phân tích khí máu, 6 chuyên đề chuyên sâu, từ điển, ôn luyện và ca lâm sàng trong một ứng dụng thống nhất.</p><div class="nah-abg-launcher__compact-meta"><b>6 chuyên đề</b><b>Từ điển</b><b>Ca lâm sàng</b></div></div>
				<article class="nah-abg-launcher__compact-challenge" data-abg-launcher-challenge><div><span>THỬ NHANH</span><strong data-abg-launcher-values>pH 7,28 · PaCO₂ 30 · HCO₃⁻ 14</strong></div><div class="nah-abg-launcher__challenge-options" data-abg-launcher-options></div><small data-abg-launcher-feedback>Chọn diễn giải phù hợp nhất.</small></article>
				<div class="nah-abg-launcher__compact-actions"><a class="nah-abg-launcher__primary" href="<?php echo esc_url( $app ); ?>">Mở ABG Suite <span>→</span></a><a class="nah-abg-launcher__secondary" href="<?php echo esc_url( add_query_arg( 'view', 'classroom', $app ) ); ?>">Học &amp; luyện tập</a><?php if ( ! $trial['member'] ) : ?><span class="nah-abg-launcher__trial">Còn <?php echo esc_html( (string) $trial['remaining'] ); ?>/<?php echo esc_html( (string) $trial['limit'] ); ?> lượt dùng thử</span><?php else : ?><span class="nah-abg-launcher__trial is-member">Thành viên · toàn quyền</span><?php endif; ?></div>
			</div>
		</section>
		<?php return ob_get_clean();
	}

	/**
	 * Resolve member/trial access without adding database writes or polling.
	 * Guest trials are tracked in a signed first-party browser cookie and count
	 * protected ABG actions, not WebApp visits or homepage launcher impressions.
	 *
	 * @param bool $consume Whether this protected action should consume one trial use.
	 * @return array
	 */
	private function trial_access_status( $consume = false ) {
		$limit  = max( 1, (int) apply_filters( 'medipharm_abg_trial_limit', 10 ) );
		$user_id = get_current_user_id();
		$member  = is_user_logged_in();
		// Reuse the host Super App's established membership policy when available.
		// This preserves Membership/Clinical Access expiry and legacy-account rules
		// instead of treating every generic WordPress login as an active member.
		if ( $member && class_exists( 'SYH_Super_App' ) && is_callable( array( 'SYH_Super_App', 'instance' ) ) ) {
			$host = SYH_Super_App::instance();
			if ( is_object( $host ) && is_callable( array( $host, 'is_active_member' ) ) ) {
				$member = (bool) $host->is_active_member( $user_id );
			}
		} elseif ( $member && class_exists( 'YHLS_Super_App' ) && is_callable( array( 'YHLS_Super_App', 'instance' ) ) ) {
			$host = YHLS_Super_App::instance();
			if ( is_object( $host ) && is_callable( array( $host, 'is_active_member' ) ) ) {
				$member = (bool) $host->is_active_member( $user_id );
			}
		}
		$member = (bool) apply_filters( 'medipharm_abg_member_has_access', $member, $user_id );
		if ( $member ) {
			return array( 'member' => true, 'limit' => $limit, 'used' => 0, 'remaining' => $limit, 'exhausted' => false, 'allowed' => true, 'cookie' => '', 'cookie_script' => '' );
		}

		$cookie_name = 'medipharm_abg_trial_v55';
		$used = 0;
		if ( ! empty( $_COOKIE[ $cookie_name ] ) ) {
			$raw = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
			$parts = explode( '.', $raw );
			if ( 3 === count( $parts ) ) {
				$count = max( 0, (int) $parts[0] );
				$expiry = (int) $parts[1];
				$sig = preg_replace( '/[^a-f0-9]/i', '', (string) $parts[2] );
				$expected = hash_hmac( 'sha256', $count . '|' . $expiry . '|' . home_url( '/' ), wp_salt( 'auth' ) );
				if ( $expiry >= time() && hash_equals( $expected, $sig ) ) {
					$used = $count;
				}
			}
		}

		$exhausted_before = $used >= $limit;
		$allowed = ! $exhausted_before;
		$cookie = '';
		$cookie_script = '';
		if ( $consume && $allowed && ! $this->trial_consumed_this_request ) {
			$this->trial_consumed_this_request = true;
			$used++;
			$expiry = time() + ( 180 * DAY_IN_SECONDS );
			$sig = hash_hmac( 'sha256', $used . '|' . $expiry . '|' . home_url( '/' ), wp_salt( 'auth' ) );
			$value = $used . '.' . $expiry . '.' . $sig;
			$cookie = $cookie_name . '=' . rawurlencode( $value ) . '; Path=/; Max-Age=' . ( 180 * DAY_IN_SECONDS ) . '; SameSite=Lax' . ( is_ssl() ? '; Secure' : '' );
			$cookie_script = '<script>(function(){try{document.cookie=' . wp_json_encode( $cookie ) . ';}catch(e){}})();</script>';
		}

		return array(
			'member'        => false,
			'limit'         => $limit,
			'used'          => $used,
			'remaining'     => max( 0, $limit - $used ),
			'exhausted'     => $used >= $limit,
			'allowed'       => $allowed,
			'cookie'        => $cookie,
			'cookie_script' => $cookie_script,
		);
	}

	/** Render a compact ABG login form while preserving the existing membership entitlement check. */
	private function render_login_form() {
		ob_start();
		?>
		<div class="nah-abg-login-shell nah-abg-login-shell--v639">
			<div class="nah-abg-login-shell__brand">
				<img src="<?php echo esc_url( MEDIPHARM_ABG_SUITE_URL . 'assets/icons/brand-abg.png' ); ?>" alt="ABG" width="180" height="180" decoding="async">
				<strong>ABG</strong>
			</div>
			<div class="nah-abg-login-shell__heading">
				<h2>Đăng nhập</h2>
				<p>Truy cập MEDIPHARM ABG</p>
			</div>
			<form class="nah-abg-login-form nah-abg-login-form--v639" data-abg-web-login novalidate>
				<label class="nah-abg-login-form__field">
					<span>Tên đăng nhập hoặc email</span>
					<input type="text" name="login" autocomplete="username" inputmode="email" placeholder="Nhập tên đăng nhập hoặc email" required>
				</label>
				<label class="nah-abg-login-form__field">
					<span>Mật khẩu</span>
					<span class="nah-abg-login-form__password">
						<input type="password" name="password" autocomplete="current-password" placeholder="Nhập mật khẩu" required>
						<button type="button" data-abg-password-toggle aria-label="Hiện mật khẩu">Hiện</button>
					</span>
				</label>
				<div class="nah-abg-login-form__status" data-abg-web-login-status role="status" aria-live="polite" hidden></div>
				<button type="submit" class="nah-abg-login-form__submit">Đăng nhập <span aria-hidden="true">→</span></button>
				<a class="nah-abg-login-form__forgot" href="<?php echo esc_url( wp_lostpassword_url( $this->current_start_path() ) ); ?>">Quên mật khẩu?</a>
			</form>
			<div class="nah-abg-login-shell__register">Chưa có tài khoản? <a href="<?php echo esc_url( home_url( '/dangky' ) ); ?>">Đăng ký tài khoản</a></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Lazily return the compact ABG login form only after an explicit login click. */
	public function handle_login_form() {
		check_ajax_referer( 'medipharm_abg_trial_action', 'nonce' );
		wp_send_json_success( array( 'html' => $this->render_login_form() ) );
	}

	/** Return the current Android offline entitlement without modifying trial counters. */
	public function handle_android_entitlement() {
		$status  = $this->trial_access_status( false );
		$user_id = get_current_user_id();
		$user    = $user_id ? wp_get_current_user() : null;
		$now     = time();
		$until   = ! empty( $status['member'] ) ? $now + ( 90 * DAY_IN_SECONDS ) : $now;
		$until   = (int) apply_filters( 'medipharm_abg_android_entitlement_until', $until, $user_id, $status );
		wp_send_json_success(
			array(
				'member'      => (bool) $status['member'],
				'userId'      => (int) $user_id,
				'displayName' => ( $user && ! empty( $user->display_name ) ) ? sanitize_text_field( $user->display_name ) : '',
				'verifiedAt'  => $now,
				'validUntil'  => max( $now, $until ),
				'dataVersion' => 'ABG-2026.09.29',
			)
		);
	}


	/** Authenticate a MEDIPHARM account for the native Android offline app. */
	public function handle_android_login() {
		if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
			wp_send_json_error( array( 'message' => 'Yêu cầu không hợp lệ.' ) );
		}

		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$rate_key = 'medipharm_abg_android_login_' . substr( hash( 'sha256', $remote ), 0, 24 );
		$attempts = (int) get_transient( $rate_key );
		if ( $attempts >= 12 ) {
			wp_send_json_error( array( 'message' => 'Có quá nhiều lần đăng nhập chưa thành công. Vui lòng thử lại sau ít phút.' ) );
		}

		$login = isset( $_POST['login'] ) ? trim( (string) wp_unslash( $_POST['login'] ) ) : '';
		$password = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
		if ( '' === $login || '' === $password ) {
			wp_send_json_error( array( 'message' => 'Vui lòng nhập tài khoản và mật khẩu.' ) );
		}

		if ( is_email( $login ) ) {
			$by_email = get_user_by( 'email', $login );
			if ( $by_email instanceof WP_User ) {
				$login = $by_email->user_login;
			}
		}

		$credentials = array(
			'user_login'    => $login,
			'user_password' => $password,
			'remember'      => true,
		);
		$user = wp_signon( $credentials, is_ssl() );
		if ( is_wp_error( $user ) ) {
			set_transient( $rate_key, $attempts + 1, 10 * MINUTE_IN_SECONDS );
			wp_send_json_error( array( 'message' => 'Tài khoản hoặc mật khẩu chưa đúng.' ) );
		}

		delete_transient( $rate_key );
		wp_set_current_user( $user->ID );
		$status = $this->trial_access_status( false );
		if ( empty( $status['member'] ) ) {
			wp_logout();
			wp_send_json_error( array( 'message' => 'Tài khoản hiện chưa có quyền truy cập Khí Máu.' ) );
		}

		$now = time();
		$until = $now + ( 90 * DAY_IN_SECONDS );
		$until = (int) apply_filters( 'medipharm_abg_android_entitlement_until', $until, $user->ID, $status );
		wp_send_json_success(
			array(
				'member'      => true,
				'userId'      => (int) $user->ID,
				'displayName' => ! empty( $user->display_name ) ? sanitize_text_field( $user->display_name ) : $user->user_login,
				'verifiedAt'  => $now,
				'validUntil'  => max( $now, $until ),
				'dataVersion' => 'ABG-2026.09.29',
			)
		);
	}

	/** Render the provider-owned login form in a minimal Android authentication surface. */
	public function serve_android_auth_page() {
		$status = $this->trial_access_status( false );
		status_header( 200 );
		nocache_headers();
		?>
		<!doctype html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
			<title>Đăng nhập MEDIPHARM</title>
			<meta name="theme-color" content="#0b6674">
			<?php wp_head(); ?>
			<style>
				body{margin:0;background:#f4f8f9;color:#17363d;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.abg-auth{max-width:560px;margin:0 auto;padding:28px 20px 48px}.abg-auth__brand{font-size:13px;font-weight:800;letter-spacing:.08em;color:#0b6674;text-transform:uppercase}.abg-auth h1{font-size:26px;margin:8px 0}.abg-auth>p{line-height:1.55;color:#526970}.abg-auth__card{background:#fff;border:1px solid #dce7e9;border-radius:18px;padding:20px;box-shadow:0 10px 28px rgba(22,70,79,.08)}.abg-auth__ok{padding:16px;border-radius:14px;background:#e8f7f3;color:#145c52;font-weight:700}.abg-auth__register{display:inline-block;margin-top:18px;color:#0b6674;font-weight:700;text-decoration:none}
			</style>
		</head>
		<body>
			<main class="abg-auth">
				<div class="abg-auth__brand">Khí Máu · MEDIPHARM</div>
				<h1>Đăng nhập tài khoản</h1>
				<p>Kết nối Internet chỉ được sử dụng để xác thực quyền truy cập. Sau khi xác thực thành công, Khí Máu có thể tiếp tục hoạt động ngoại tuyến trên thiết bị.</p>
				<div class="abg-auth__card">
				<?php if ( ! empty( $status['member'] ) ) : ?>
					<div class="abg-auth__ok">Tài khoản đã được xác thực. Có thể quay lại ứng dụng Khí Máu.</div>
				<?php else : ?>
					<?php echo $this->render_login_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php endif; ?>
				</div>
				<a class="abg-auth__register" href="<?php echo esc_url( home_url( '/dangky' ) ); ?>">Chưa có tài khoản? Đăng ký tài khoản</a>
			</main>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
		exit;
	}

	/** Consume one protected trial action. WebApp visits themselves never consume quota. */
	public function handle_trial_action() {
		check_ajax_referer( 'medipharm_abg_trial_action', 'nonce' );
		$action_name = isset( $_POST['trial_action_name'] ) ? sanitize_key( wp_unslash( $_POST['trial_action_name'] ) ) : 'tool';
		$allowed_actions = array( 'analysis', 'assessment', 'adaptive' );
		if ( ! in_array( $action_name, $allowed_actions, true ) ) {
			wp_send_json_error( array( 'message' => 'Hành động không hợp lệ.' ), 400 );
		}
		$status = $this->trial_access_status( true );
		wp_send_json_success(
			array(
				'allowed'   => (bool) $status['allowed'],
				'member'    => (bool) $status['member'],
				'limit'     => (int) $status['limit'],
				'used'      => (int) $status['used'],
				'remaining' => (int) $status['remaining'],
				'exhausted' => (bool) $status['exhausted'],
				'cookie'    => (string) $status['cookie'],
			)
		);
	}

	/**
	 * Render the analyzer UI.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_analyzer( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'   => 'Phân tích Khí máu Động mạch',
				'context' => 'dock',
				'app_url' => home_url( '/phan-tich-khi-mau-app/' ),
				'enqueue' => '1',
			),
			$atts,
			'nah_abg_analyzer'
		);

		if ( '0' !== (string) $atts['enqueue'] ) {
			$this->enqueue_assets();
		}

		$show_access_gate = isset( $_GET['access'] ) && 'member' === sanitize_key( wp_unslash( $_GET['access'] ) );
		$trial = $this->trial_access_status( false );
		wp_localize_script(
			'medipharm-abg-suite-ui',
			'NAHABGAccess',
			array(
				'member'      => (bool) $trial['member'],
				'limit'       => (int) $trial['limit'],
				'remaining'   => (int) $trial['remaining'],
				'exhausted'   => (bool) $trial['exhausted'],
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'medipharm_abg_trial_action' ),
				'registerUrl' => home_url( '/dangky' ),
				'openLogin'   => (bool) $show_access_gate,
			)
		);

		$instance_id = wp_unique_id( 'nah-abg-' );
		$title       = sanitize_text_field( $atts['title'] );
		$standalone  = 'standalone' === $atts['context'];
		$app_url         = esc_url( $atts['app_url'] );
		$android_apk_url = function_exists( 'medipharm_abg_suite_android_apk_url' ) ? esc_url( medipharm_abg_suite_android_apk_url() ) : '';
		$android_shell   = function_exists( 'medipharm_abg_suite_is_android_shell' ) && medipharm_abg_suite_is_android_shell();
		$wp_logged_in    = is_user_logged_in();
		$current_user    = $wp_logged_in ? wp_get_current_user() : null;
		$account_name    = $current_user && $current_user->exists() ? ( $current_user->display_name ?: $current_user->user_login ) : '';
		$logout_url      = $wp_logged_in ? wp_logout_url( home_url( '/phan-tich-khi-mau-app/' ) ) : '';

		ob_start();
		?>
		<div class="nah-abg nah-abg--light <?php echo $standalone ? 'nah-abg--standalone' : 'nah-abg--dock'; ?>" data-theme="light" id="<?php echo esc_attr( $instance_id ); ?>" data-nah-abg-root data-abg-standalone="<?php echo $standalone ? '1' : '0'; ?>" data-abg-member-access="<?php echo ! empty( $trial['member'] ) ? '1' : '0'; ?>" data-abg-trial-remaining="<?php echo esc_attr( (string) (int) $trial['remaining'] ); ?>">
			<header class="nah-abg__hero">
				<a class="nah-abg__brand" href="<?php echo $app_url; ?>" data-abg-brand-home aria-label="Khí máu động mạch – <?php echo esc_attr( $title ); ?>">
					<span class="nah-abg__logo" aria-hidden="true">
						<img src="<?php echo esc_url( MEDIPHARM_ABG_SUITE_URL . 'assets/icons/brand-abg.png' ); ?>" alt="" width="256" height="256" decoding="async">
					</span>
					<span class="nah-abg__brand-copy">
						<span class="nah-abg__brand-title">MEDIPHARM ABG</span>
						<small class="nah-abg__brand-subtitle">Khí máu động mạch</small>
					</span>
				</a>
				<div class="nah-abg__app-search" data-abg-search>
					<label class="nah-abg__app-search-box">
						<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4 4"/></svg>
						<input type="search" placeholder="Tìm thuật ngữ, ca lâm sàng, hướng dẫn…" aria-label="Tìm trong ứng dụng Khí máu" data-abg-search-input autocomplete="off">
					</label>
					<div class="nah-abg__search-results" data-abg-search-results hidden></div>
				</div>
				<div class="nah-abg__hero-actions" aria-label="Điều khiển ứng dụng">
					<?php if ( $android_shell ) : ?>
						<a class="nah-abg__account-toggle" href="medipharmabg://account" aria-label="Tài khoản" title="Tài khoản">
							<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4.2 3.5-6 8-6s7.2 1.8 8 6"/></svg>
						</a>
					<?php else : ?>
						<div class="nah-abg__account-control">
							<button type="button" class="nah-abg__account-toggle" data-abg-account-toggle aria-label="Tài khoản" title="Tài khoản" aria-expanded="false" aria-controls="<?php echo esc_attr( $instance_id ); ?>-account">
								<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4.2 3.5-6 8-6s7.2 1.8 8 6"/></svg>
							</button>
							<div class="nah-abg__account-popover" id="<?php echo esc_attr( $instance_id ); ?>-account" data-abg-account-popover hidden>
								<?php if ( $wp_logged_in ) : ?>
									<div class="nah-abg__account-summary"><small>Tài khoản MEDIPHARM</small><strong><?php echo esc_html( $account_name ); ?></strong></div>
									<a class="nah-abg__account-action" href="<?php echo esc_url( $logout_url ); ?>">Đăng xuất</a>
								<?php else : ?>
									<div class="nah-abg__account-summary"><small>Tài khoản MEDIPHARM</small><strong>Chưa đăng nhập</strong></div>
									<button type="button" class="nah-abg__account-action nah-abg__account-action--primary" data-abg-login-open>Đăng nhập</button>
									<a class="nah-abg__account-action" href="<?php echo esc_url( home_url( '/dangky' ) ); ?>">Đăng ký tài khoản</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>
					<button type="button" class="nah-abg__menu-toggle" data-abg-menu-toggle aria-label="Trình đơn" title="Trình đơn" aria-expanded="false" aria-controls="<?php echo esc_attr( $instance_id ); ?>-menu">
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
					</button>
					<div class="nah-abg__menu" id="<?php echo esc_attr( $instance_id ); ?>-menu" data-abg-menu hidden>
						<button type="button" class="nah-abg__menu-item" data-theme-toggle aria-pressed="false" aria-label="Bật chế độ tối"><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a9 9 0 1 0 11 11z"/></svg></span><span data-theme-label>Chế độ tối</span></button>
						<?php if ( $android_shell ) : ?>
							<?php if ( ! $wp_logged_in ) : ?>
								<a class="nah-abg__menu-item" href="medipharmabg://login" data-android-login><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4.2 3.5-6 8-6s7.2 1.8 8 6"/></svg></span><span>Đăng nhập</span></a>
								<a class="nah-abg__menu-item" href="medipharmabg://register" data-android-register><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="4"/><path d="M2 21c.7-4 3-6 7-6 2 0 3.7.5 5 1.4M18 8v8M14 12h8"/></svg></span><span>Đăng ký tài khoản</span></a>
							<?php endif; ?>
							<a class="nah-abg__menu-item" href="medipharmabg://check-update" data-android-update-check><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M18.5 9A7 7 0 0 0 6 6.5L4 9M5.5 15A7 7 0 0 0 18 17.5L20 15"/></svg></span><span>Kiểm tra cập nhật</span></a>
						<?php elseif ( $standalone ) : ?>
							<button type="button" class="nah-abg__menu-item" data-install-app hidden><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 18v3h14v-3"/></svg></span><span data-install-label>Cài Webapp</span></button>
						<?php else : ?>
							<a class="nah-abg__menu-item" href="<?php echo $app_url; ?>" target="_blank" rel="noopener"><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 18v3h14v-3"/></svg></span><span>Cài Webapp</span></a>
						<?php endif; ?>
						<?php if ( ! $android_shell ) : ?>
							<button type="button" class="nah-abg__menu-item" data-abg-check-update><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M18.5 9A7 7 0 0 0 6 6.5L4 9M5.5 15A7 7 0 0 0 18 17.5L20 15"/></svg></span><span data-abg-check-update-label>Kiểm tra cập nhật</span></button>
						<?php endif; ?>
						<?php if ( ! $android_shell && $android_apk_url ) : ?>
							<a class="nah-abg__menu-item" href="<?php echo esc_url( $android_apk_url ); ?>" target="_blank" rel="noopener noreferrer" data-android-download><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M12 7v7m0 0 3-3m-3 3-3-3M10 18h4"/></svg></span><span>Tải ứng dụng Android</span></a>
						<?php endif; ?>
						<button type="button" class="nah-abg__menu-item" data-abg-info="about"><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 10v6M12 7h.01"/></svg></span><span>Giới thiệu</span></button>
						<button type="button" class="nah-abg__menu-item nah-abg__menu-item--warning" data-abg-info="safety"><span class="nah-abg__menu-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3 20 6v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6z"/><path d="M12 8v5M12 16h.01"/></svg></span><span>Lưu ý An toàn</span></button>
					</div>
				</div>
			</header>

			<div class="nah-abg__info-overlay" data-abg-info-overlay hidden>
				<div class="nah-abg__info-panel" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-info-title">
					<button type="button" class="nah-abg__info-close" data-abg-info-close aria-label="Đóng">×</button>
					<section data-abg-info-panel="about" hidden>
						<h2 id="<?php echo esc_attr( $instance_id ); ?>-info-title">Giới thiệu</h2>
						<p>MEDIPHARM ABG là nền tảng học tập khí máu động mạch, kết nối phân tích ca bệnh, lý thuyết, ôn tập, thi thử với cách đặt kết quả trong bối cảnh lâm sàng.</p>
						<p>Dữ liệu được xử lý trên thiết bị; ứng dụng không lưu thông tin nhận dạng người bệnh.</p>
					</section>
					<section data-abg-info-panel="safety" hidden>
						<h2>Lưu ý An toàn</h2>
						<p>Công cụ phân tích khí máu chỉ nhằm mục đích hỗ trợ bác sĩ và sinh viên Y khoa xây dựng kỹ năng biện luận lâm sàng, không thay thế cho việc thăm khám và ra quyết định dựa trên hoàn cảnh thực tế và hướng dẫn chẩn đoán và điều trị của Cơ sở khám, chữa bệnh.</p>
					</section>
				</div>
			</div>

			<div class="nah-abg__trial-overlay" data-abg-trial-gate hidden>
				<div class="nah-abg__trial-dialog" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-trial-title">
					<button type="button" class="nah-abg__trial-close" data-abg-trial-close aria-label="Đóng">×</button>
					<div class="nah-abg__trial-copy">
						<span>MEDIPHARM ABG · THÀNH VIÊN</span>
						<h2 id="<?php echo esc_attr( $instance_id ); ?>-trial-title">Đã hết số lượt dùng thử</h2>
						<p>Vui lòng đăng nhập hoặc đăng ký tài khoản để truy cập đầy đủ.</p>
						<div class="nah-abg__trial-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-abg-login-open>Đăng nhập</button><a class="nah-abg__button nah-abg__button--ghost" href="<?php echo esc_url( home_url( '/dangky' ) ); ?>">Đăng ký</a></div>
					</div>
					<div class="nah-abg__trial-login" data-abg-trial-login hidden><?php echo $this->render_login_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				</div>
			</div>

			<?php if ( ! $android_shell ) : ?>
			<div class="nah-abg__notice nah-abg__notice--app" data-install-help hidden>
				<strong>Cài dưới dạng ứng dụng:</strong> <span data-install-help-text>Mở trình đơn của trình duyệt và chọn “Thêm vào màn hình chính” hoặc “Cài đặt ứng dụng”.</span>
			</div>
			<?php endif; ?>

			<?php echo $trial['cookie_script']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<div class="nah-abg__workspace-frame">
			<nav class="nah-abg__workspace-tabs nah-abg__app-nav" aria-label="Điều hướng ứng dụng">
				<button type="button" class="nah-abg__workspace-current" data-workspace-menu-toggle aria-expanded="false" aria-controls="<?php echo esc_attr( $instance_id ); ?>-workspace-tab-list"><span data-workspace-current-label>Trang chủ</span><i aria-hidden="true">⌄</i></button>
				<div class="nah-abg__workspace-tab-list" id="<?php echo esc_attr( $instance_id ); ?>-workspace-tab-list" role="tablist" data-workspace-tab-list>
					<button type="button" class="nah-abg__workspace-tab is-active" role="tab" aria-selected="true" data-workspace-tab="home"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11.5 12 4l9 7.5V21h-6v-6H9v6H3z"/></svg><span>Trang chủ</span></button>
					<button type="button" class="nah-abg__workspace-tab" role="tab" aria-selected="false" data-workspace-tab="analysis"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></svg><span>Phân tích</span></button>
					<button type="button" class="nah-abg__workspace-tab" role="tab" aria-selected="false" data-workspace-tab="cases"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3v5a3 3 0 0 0 6 0V3M12 11v2a5 5 0 0 0 5 5h1"/><circle cx="19" cy="18" r="2"/></svg><span>Ca lâm sàng</span></button>
					<button type="button" class="nah-abg__workspace-tab" role="tab" aria-selected="false" data-workspace-tab="theory"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v18H7.5A3.5 3.5 0 0 0 4 23zM20 5.5A3.5 3.5 0 0 0 16.5 2H13v18h3.5A3.5 3.5 0 0 1 20 23z"/></svg><span>Học tập</span></button>
				</div>
			</nav>

			<section class="nah-abg__app-home nah-abg__app-home--v680" id="<?php echo esc_attr( $instance_id ); ?>-home" role="tabpanel" data-workspace-panel="home">
				<section class="nah-abg__v680-hero" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-home-title">
					<div class="nah-abg__v680-hero-copy">
						<h1 id="<?php echo esc_attr( $instance_id ); ?>-home-title">Phân tích khí máu động mạch</h1>
						<p>Diễn giải có cấu trúc từ pH, PaCO₂, HCO₃⁻ đến thông khí và oxy hóa.</p>
						<button type="button" class="nah-abg__v680-primary" data-home-workspace="analysis">Bắt đầu phân tích <span aria-hidden="true">→</span></button>
					</div>
					<div class="nah-abg__v680-hero-visual" aria-hidden="true"><img class="nah-abg__v6112-hero-logo" src="<?php echo esc_url( MEDIPHARM_ABG_SUITE_URL . 'assets/icons/brand-abg.png' ); ?>" alt="" width="256" height="256" decoding="async"></div>
				</section>

				<section class="nah-abg__v680-quick" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-quick-title">
					<header><h2 id="<?php echo esc_attr( $instance_id ); ?>-quick-title">Bắt đầu nhanh</h2></header>
					<div class="nah-abg__v680-quick-grid">
						<button type="button" data-home-workspace="analysis"><span class="is-blue">01</span><div><strong>Phân tích mới</strong><small>Nhập khí máu và diễn giải từng bước.</small></div><b>→</b></button>
						<button type="button" data-home-workspace="cases"><span class="is-red">02</span><div><strong>Ca lâm sàng</strong><small>Luyện suy luận từ tình huống thực tế.</small></div><b>→</b></button>
						<button type="button" data-home-workspace="theory" data-canonical-tab="dictionary"><span class="is-cyan">03</span><div><strong>Từ điển</strong><small>Tra cứu nhanh thông số và thuật ngữ.</small></div><b>→</b></button>
						<button type="button" data-home-workspace="theory" data-canonical-continue><span class="is-violet">04</span><div><strong>Tiếp tục học</strong><small data-canonical-continue-label>6 chuyên đề khí máu chuyên sâu.</small></div><b>→</b></button>
					</div>
				</section>

				<section class="nah-abg__v680-home-row">
					<article class="nah-abg__v680-home-card" data-canonical-recent>
						<header><div><small>TIẾP TỤC</small><h2>Gần đây</h2></div></header>
						<div data-canonical-recent-body><p>Chọn một chuyên đề để bắt đầu; tiến độ sẽ được lưu trên thiết bị.</p></div>
					</article>
					<article class="nah-abg__v680-home-card" data-canonical-suggestion>
						<header><div><small>GỢI Ý HÔM NAY</small><h2>Học theo cơ chế</h2></div></header>
						<div data-canonical-suggestion-body><p>Ôn nền tảng sinh lý trước khi chuyển sang rối loạn phối hợp và bệnh cảnh lâm sàng.</p></div>
					</article>
				</section>
			</section>
			<div class="nah-abg__workspace-panel" id="<?php echo esc_attr( $instance_id ); ?>-analysis" role="tabpanel" data-workspace-panel="analysis" hidden>
			<header class="nah-abg__clinical-head">
				<div><h2>Phân tích khí máu</h2><p>Nhập dữ liệu → Phân tích → Kết luận.</p></div>
			</header>
			<nav class="nah-abg__progress" aria-label="Tiến trình phân tích">
				<ol>
					<li class="is-active" data-progress-step="1"><span>1</span><small>Bối cảnh</small></li>
					<li data-progress-step="2"><span>2</span><small>Khí máu</small></li>
					<li data-progress-step="3"><span>3</span><small>Xét nghiệm</small></li>
					<li data-progress-step="4"><span>4</span><small>Oxy hóa</small></li>
					<li data-progress-step="5"><span>5</span><small>Kết quả</small></li>
				</ol>
			</nav>

			<form class="nah-abg__form" novalidate data-abg-form>
				<section class="nah-abg__panel is-active" data-form-step="1" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-step-1">
					<div class="nah-abg__section-heading">
						<div class="nah-abg__step-number">01</div>
						<div>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-step-1">Thông tin ca bệnh</h3>
							<p>Chỉ nhập dữ kiện có liên quan đến diễn giải; không nhập thông tin định danh.</p>
						</div>
					</div>

					<div class="nah-abg__grid nah-abg__grid--2">
						<fieldset class="nah-abg__field">
							<legend>Loại mẫu</legend>
							<div class="nah-abg__segmented">
								<label>
									<input type="radio" name="sampleType" value="arterial" checked>
									<span>Động mạch</span>
								</label>
								<label>
									<input type="radio" name="sampleType" value="venous">
									<span>Tĩnh mạch</span>
								</label>
							</div>
						</fieldset>

						<fieldset class="nah-abg__field">
							<legend>Hệ đơn vị sinh hóa</legend>
							<div class="nah-abg__segmented">
								<label>
									<input type="radio" name="unitSystem" value="si" checked>
									<span>Đơn vị SI</span>
								</label>
								<label>
									<input type="radio" name="unitSystem" value="us">
									<span>Hoa Kỳ</span>
								</label>
							</div>
						</fieldset>

						<label class="nah-abg__field">
							<span>Đơn vị áp suất khí máu</span>
							<select name="gasPressureUnit" data-gas-pressure-unit>
								<option value="mmhg">mmHg (quy ước lâm sàng)</option>
								<option value="kpa">kPa</option>
							</select>
							<small>Có thể nhập PaO₂/PaCO₂ bằng kPa; công cụ tự quy đổi.</small>
						</label>

						<label class="nah-abg__field">
							<span>Tuổi <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="age" inputmode="numeric" placeholder="Ví dụ: 65" data-numeric>
								<small>tuổi</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Giới tính sinh học</span>
							<select name="sex">
								<option value="unspecified">Không chọn</option>
								<option value="female">Nữ</option>
								<option value="male">Nam</option>
							</select>
							<small>Dùng khi đối chiếu hemoglobin và creatinin.</small>
						</label>

						<label class="nah-abg__field">
							<span>Bối cảnh rối loạn hô hấp</span>
							<select name="chronicity">
								<option value="auto">Tự động đối chiếu cấp và mạn</option>
								<option value="acute">Cấp tính</option>
								<option value="chronic">Mạn tính (≥ 3–5 ngày)</option>
							</select>
						</label>

						<label class="nah-abg__field">
							<span>Bối cảnh chăm sóc</span>
							<select name="clinicalSetting" data-clinical-setting>
								<option value="unspecified">Chưa chọn</option>
								<option value="emergency">Cấp cứu</option>
								<option value="critical-care">Hồi sức tích cực</option>
								<option value="inpatient">Nội trú</option>
								<option value="outpatient">Ngoại trú</option>
								<option value="peri-procedure">Quanh thủ thuật hoặc phẫu thuật</option>
								<option value="follow-up">Theo dõi diễn biến</option>
							</select>
							<small>Giúp đặt kết quả khí máu vào đúng hoàn cảnh sử dụng.</small>
						</label>

						<label class="nah-abg__field">
							<span>Câu hỏi lâm sàng cần làm rõ</span>
							<select name="clinicalFocus" data-clinical-focus>
								<option value="general">Diễn giải tổng thể</option>
								<option value="acidbase">Rối loạn toan–kiềm</option>
								<option value="oxygenation">Oxy hóa máu</option>
								<option value="ventilation">Thông khí</option>
								<option value="mixed">Rối loạn phối hợp</option>
								<option value="sample">Độ tin cậy của mẫu</option>
								<option value="trend">Theo dõi thay đổi theo thời gian</option>
							</select>
							<small>Ứng dụng dùng lựa chọn này để ưu tiên các điểm cần đối chiếu; không tự xác lập chẩn đoán.</small>
						</label>

						<label class="nah-abg__field nah-abg__field--full">
							<span>Mô tả ca bệnh <em>không bắt buộc</em></span>
							<textarea name="caseSummary" rows="4" maxlength="2500" placeholder="Triệu chứng, bệnh sử, dấu hiệu sinh tồn, chẩn đoán đang nghĩ tới, điều trị trước khi lấy mẫu… Không nhập thông tin định danh."></textarea>
							<small>Tối đa 2.500 ký tự; nội dung được đưa vào bản kết luận nhưng không được gửi hoặc lưu trên máy chủ.</small>
						</label>
					</div>

					<details class="nah-abg__context-picker">
						<summary>Chọn các dữ kiện lâm sàng liên quan</summary>
						<div class="nah-abg__check-grid">
							<label><input type="checkbox" name="clinicalContexts[]" value="sepsis"> Nhiễm trùng huyết</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="shock"> Sốc/giảm tưới máu</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="diabetes"> Đái tháo đường/tăng đường huyết</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="renal-failure"> Suy thận</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="vomiting"> Nôn/hút dịch dạ dày</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="diarrhea"> Tiêu chảy/mất HCO₃⁻</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="copd"> COPD/hen/tắc nghẽn</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="cns-depressant"> An thần/opioid/ức chế thần kinh</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="neuromuscular"> Bệnh thần kinh–cơ</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="ohs-osa"> Giảm thông khí do béo phì/ngưng thở khi ngủ</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="pulmonary-embolism"> Nghi thuyên tắc phổi</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="pain-anxiety"> Đau/lo âu/tăng thông khí</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="liver-disease"> Bệnh gan</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="pregnancy"> Thai kỳ</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="salicylate"> Dùng/ngộ độc salicylat</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="alcohol-starvation"> Rượu/nhịn đói</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="toxic-alcohol"> Nghi methanol/ethylene glycol</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="diuretic"> Đang dùng lợi tiểu</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="saline-load"> Truyền nhiều NaCl 0,9%</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="seizure"> Co giật gần đây</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="sglt2"> Đang dùng thuốc ức chế SGLT2</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="gi-fistula"> Rò/dẫn lưu tụy–mật–ruột</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="carbonic-anhydrase"> Acetazolamide/topiramate</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="mineralocorticoid"> Nghi cường mineralocorticoid</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="hypertension"> Tăng huyết áp</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="alkali-load"> Tải bicarbonat/citrate/antacid</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="airway-obstruction"> Dị vật/nút nhầy/tắc ống nội khí quản</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="cns-injury"> Tổn thương thần kinh trung ương</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="chest-wall"> Bệnh thành ngực/hạn chế nặng</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="fever"> Sốt/tăng chuyển hóa</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="high-altitude"> Độ cao/oxy khí hít vào thấp</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="lactate-drug"> Thuốc có thể tăng lactat</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="smoke-fire"> Khói cháy/khí thải/không gian kín</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="oxidant-drug"> Thuốc/chất oxy hóa gây MetHb</label>
							<label><input type="checkbox" name="clinicalContexts[]" value="smoker"> Có hút thuốc</label>
						</div>
					</details>

					<details class="nah-abg__context-picker nah-abg__sample-picker">
						<summary>Danh sách kiểm tra chất lượng mẫu và tiền phân tích</summary>
						<div class="nah-abg__grid nah-abg__grid--2">
							<label class="nah-abg__field">
								<span>Thời gian từ lấy mẫu đến phân tích <em>nếu biết</em></span>
								<div class="nah-abg__input-wrap">
									<input type="text" name="sampleDelayMinutes" inputmode="decimal" placeholder="Ví dụ: 8" data-numeric>
									<small>phút</small>
								</div>
							</label>
							<div class="nah-abg__notice">
								Chỉ đánh dấu yếu tố có thật hoặc nghi ngờ; để trống không đồng nghĩa đã xác nhận mẫu hoàn hảo.
							</div>
						</div>
						<div class="nah-abg__check-grid">
							<label><input type="checkbox" name="sampleIssues[]" value="air-bubbles"> Có bọt khí</label>
							<label><input type="checkbox" name="sampleIssues[]" value="analysis-delay"> Chậm phân tích/bảo quản không rõ</label>
							<label><input type="checkbox" name="sampleIssues[]" value="liquid-heparin"> Heparin lỏng/bơm tiêm không chuẩn</label>
							<label><input type="checkbox" name="sampleIssues[]" value="line-contamination"> Nghi nhiễm dịch đường truyền</label>
							<label><input type="checkbox" name="sampleIssues[]" value="poor-mixing-clot"> Trộn không đủ/vi cục/đông</label>
							<label><input type="checkbox" name="sampleIssues[]" value="hemolysis"> Nghi tan máu</label>
							<label><input type="checkbox" name="sampleIssues[]" value="unstable-support"> FiO₂/thông khí vừa thay đổi</label>
						</div>
					</details>

					<div class="nah-abg__demo">
						<label for="<?php echo esc_attr( $instance_id ); ?>-demo">Nạp ca mẫu vào công cụ</label>
						<div>
							<select id="<?php echo esc_attr( $instance_id ); ?>-demo" data-demo-select>
								<option value="">— Chọn ca thực hành —</option>
								<option value="normal">Khí máu bình thường</option>
								<option value="hagma">Toan lactic tăng khoảng trống anion</option>
								<option value="dka">Nhiễm toan ceton do đái tháo đường</option>
								<option value="acute-resp-acidosis">Toan hô hấp cấp</option>
								<option value="mixed">Toan chuyển hóa phối hợp toan hô hấp</option>
								<option value="smoke-exposure">Ngộ độc carbon monoxit – PaO₂ có thể bình thường</option>
								<option value="resp-alkalosis">Kiềm hô hấp cấp do tăng thông khí</option>
								<option value="metabolic-alkalosis">Kiềm chuyển hóa do nôn hoặc lợi tiểu</option>
								<option value="copd-chronic">COPD – toan hô hấp mạn có bù</option>
								<option value="salicylate-mixed">Salicylat – rối loạn toan–kiềm phối hợp</option>
								<option value="nagma-diarrhea">Tiêu chảy – toan chuyển hóa tăng clo</option>
								<option value="pe-hypoxemia">Thuyên tắc phổi – giảm oxy máu</option>
								<option value="ards-oxygenation">Suy hô hấp cấp – đánh giá oxy hóa khi thở máy</option>
								<option value="sample-air-bubble">Sai số tiền phân tích – bọt khí trong mẫu</option>
								<option value="pregnancy-resp-alk">Thai kỳ – kiềm hô hấp sinh lý</option>
								<option value="opioid-hypoventilation">Opioid – giảm thông khí</option>
								<option value="renal-failure-hagma">Suy thận – toan chuyển hóa</option>
								<option value="vomiting-plus-resp-alk">Nôn và tăng thông khí – kiềm phối hợp</option>
								<option value="saline-nagma">Sau truyền NaCl 0,9% – toan tăng clo</option>
								<option value="ketoacidosis-sglt2">Thuốc ức chế SGLT2 – nhiễm toan ceton</option>
								<option value="methanol-pattern">Nghi ngộ độc methanol – khoảng trống anion và thẩm thấu</option>
								<option value="seizure-lactate">Co giật – tăng lactat thoáng qua</option>
								<option value="neuromuscular-hypercapnia">Yếu cơ hô hấp – tăng CO₂</option>
								<option value="high-altitude">Độ cao – giảm oxy máu</option>
								<option value="hfnc-hypoxemia">Oxy dòng cao – giảm oxy máu</option>
								<option value="niv-copd">COPD – theo dõi khi thông khí không xâm nhập</option>
								<option value="vbg-dka">Khí máu tĩnh mạch – nhiễm toan ceton</option>
								<option value="methemoglobinemia">Methemoglobin – chênh lệch độ bão hòa oxy</option>
								<option value="mixed-hagma-alkalosis">pH gần bình thường – rối loạn phối hợp</option>
								<option value="post-intubation-hyperventilation">Sau đặt nội khí quản – tăng thông khí</option>
								<option value="ventilator-low-vt-ards">ARDS – thở máy bảo vệ phổi</option>
								<option value="ventilator-autopeep-copd">COPD thở máy – nghi bẫy khí</option>
								<option value="ventilator-hypercapnia-adjust">Thở máy – PaCO₂ sau chỉnh thông khí</option>
								<option value="ventilator-overventilation-serial">Thở máy – quá thông khí theo chuỗi</option>
								<option value="niv-copd-response">NIV COPD – đáp ứng cải thiện</option>
								<option value="niv-copd-failure">NIV COPD – xu hướng thất bại</option>
								<option value="hfnc-pneumonia-response">HFNC – oxy hóa cải thiện</option>
								<option value="hfnc-worsening-hypoxemia">HFNC – giảm oxy xấu đi</option>
								<option value="septic-shock-lactate-clearance">Sốc nhiễm trùng – lactat giảm</option>
								<option value="septic-shock-lactate-persistent">Sốc nhiễm trùng – lactat dai dẳng</option>
								<option value="co-exposure-delayed-sample">Carbon monoxit – mẫu lấy muộn</option>
								<option value="methemoglobin-benzocaine">Methemoglobin – PaO₂ cao, SpO₂ thấp</option>
								<option value="methanol-late-osm-gap">Methanol đến muộn – khoảng trống thẩm thấu</option>
								<option value="ethylene-glycol-acidosis">Ethylene glycol – toan và khoảng trống</option>
								<option value="ckd-acidosis-hyperkalemia">Bệnh thận mạn – toan và tăng kali</option>
								<option value="renal-tubular-acidosis">Toan tăng clo – cơ chế ống thận</option>
								<option value="pregnancy-hyperemesis">Thai kỳ – nôn và kiềm phối hợp</option>
								<option value="pregnancy-respiratory-deterioration">Thai kỳ – PaCO₂ tăng tương đối</option>
								<option value="altitude-acclimatization">Độ cao – thích nghi thông khí</option>
								<option value="altitude-pulmonary-edema">Độ cao – giảm oxy vượt mức dự kiến</option>
							</select>
							<button type="button" class="nah-abg__button nah-abg__button--ghost" data-load-demo>Nạp ca</button>
						</div>
					</div>

				</section>

				<section class="nah-abg__panel" data-form-step="2" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-step-2" hidden>
					<div class="nah-abg__section-heading">
						<div class="nah-abg__step-number">02</div>
						<div>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-step-2">Khí máu cốt lõi</h3>
							<p>Nhập các thông số chính trước; các chỉ số bổ sung chỉ mở khi cần.</p>
						</div>
					</div>

					<div class="nah-abg__grid nah-abg__grid--3">
						<label class="nah-abg__field">
							<span>pH <b>*</b></span>
							<input type="text" name="ph" inputmode="decimal" placeholder="7,40" autocomplete="off" data-numeric required>
							<small>Tham chiếu thường dùng: 7,35–7,45</small>
						</label>

						<label class="nah-abg__field">
							<span>PaCO₂ <b>*</b></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="paco2" inputmode="decimal" placeholder="40" autocomplete="off" data-numeric required>
								<small data-pressure-unit-label>mmHg</small>
							</div>
							<small data-paco2-reference>Tham chiếu: 35–45 mmHg</small>
						</label>

						<label class="nah-abg__field">
							<span>HCO₃⁻ <b>*</b></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="hco3" inputmode="decimal" placeholder="24" autocomplete="off" data-numeric required>
								<small>mmol/L</small>
							</div>
							<small>Tham chiếu: 22–26 mmol/L</small>
						</label>

						<label class="nah-abg__field">
							<span>PaO₂ <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="pao2" inputmode="decimal" placeholder="90" autocomplete="off" data-numeric>
								<small data-pressure-unit-label>mmHg</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>SaO₂ <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="sao2" inputmode="decimal" placeholder="97" autocomplete="off" data-numeric>
								<small>%</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>SpO₂ tại thời điểm lấy mẫu <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="spo2" inputmode="decimal" placeholder="97" autocomplete="off" data-numeric>
								<small>%</small>
							</div>
							<small>Dùng để phát hiện bất tương hợp với SaO₂ hoặc kết quả đồng oxy kế; chỉ ghi khi tín hiệu đo đáng tin cậy.</small>
						</label>

						<label class="nah-abg__field">
							<span>Lactat <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="lactate" inputmode="decimal" placeholder="1,2" autocomplete="off" data-numeric>
								<small>mmol/L</small>
							</div>
							<small>Thông thường &lt; 2 mmol/L; ≥ 4 mmol/L là mức cảnh báo.</small>
						</label>

						<label class="nah-abg__field">
							<span>Lactat lần trước <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="priorLactate" inputmode="decimal" placeholder="Ví dụ: 6,0" autocomplete="off" data-numeric>
								<small>mmol/L</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Khoảng cách hai lần đo lactat</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="lactateIntervalHours" inputmode="decimal" placeholder="Ví dụ: 2" autocomplete="off" data-numeric>
								<small>giờ</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>COHb từ đồng oxy kế <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="cohb" inputmode="decimal" placeholder="0,5" autocomplete="off" data-numeric>
								<small>%</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>MetHb từ đồng oxy kế <em>không bắt buộc</em></span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="methb" inputmode="decimal" placeholder="0,8" autocomplete="off" data-numeric>
								<small>%</small>
							</div>
						</label>
					</div>

					<div class="nah-abg__notice">
						PaO₂ phản ánh oxy hòa tan và có thể vẫn bình thường trong ngộ độc carbon monoxit hoặc tăng methemoglobin. Khi nghi ngờ, cần đo bằng đồng oxy kế; đo độ bão hòa oxy ngoại vi thông thường không đủ để loại trừ.
					</div>
				</section>

				<section class="nah-abg__panel" data-form-step="3" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-step-3" hidden>
					<div class="nah-abg__section-heading">
						<div class="nah-abg__step-number">03</div>
						<div>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-step-3">Xét nghiệm bổ sung</h3>
							<p>Nhập các xét nghiệm đang có. Có thể để trống những trường chưa được thực hiện.</p>
						</div>
					</div>

					<div class="nah-abg__grid nah-abg__grid--3">
						<label class="nah-abg__field">
							<span>Na⁺</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="sodium" inputmode="decimal" placeholder="140" data-numeric>
								<small>mmol/L</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Cl⁻</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="clorid" inputmode="decimal" placeholder="104" data-numeric>
								<small>mmol/L</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>K⁺</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="potassium" inputmode="decimal" placeholder="4,0" data-numeric>
								<small>mmol/L</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Albumin</span>
							<div class="nah-abg__compound">
								<input type="text" name="albumin" inputmode="decimal" placeholder="40" data-numeric>
								<select name="albuminUnit" data-unit-role="albumin" aria-label="Đơn vị albumin">
									<option value="gl">g/L</option>
									<option value="gdl">g/dL</option>
								</select>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Glucose</span>
							<div class="nah-abg__compound">
								<input type="text" name="glucose" inputmode="decimal" placeholder="7,0" data-numeric>
								<select name="glucoseUnit" data-unit-role="glucose" aria-label="Đơn vị glucose">
									<option value="mmol">mmol/L</option>
									<option value="mgdl">mg/dL</option>
								</select>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Urê / nitơ urê máu</span>
							<div class="nah-abg__compound">
								<input type="text" name="urea" inputmode="decimal" placeholder="5,0" data-numeric>
								<select name="ureaUnit" data-unit-role="urea" aria-label="Loại và đơn vị urê">
									<option value="urea-mmol">Urê mmol/L</option>
									<option value="bun-mgdl">Nitơ urê máu mg/dL</option>
								</select>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Creatinin</span>
							<div class="nah-abg__compound">
								<input type="text" name="creatinine" inputmode="decimal" placeholder="88" data-numeric>
								<select name="creatinineUnit" data-unit-role="creatinine" aria-label="Đơn vị creatinin">
									<option value="umol">µmol/L</option>
									<option value="mgdl">mg/dL</option>
								</select>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>β-hydroxybutyrat/ceton máu</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="ketones" inputmode="decimal" placeholder="0,3" data-numeric>
								<small>mmol/L</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Độ thẩm thấu đo được</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="measuredOsm" inputmode="decimal" placeholder="290" data-numeric>
								<small>mOsm/kg</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Cl⁻ niệu</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="urineChloride" inputmode="decimal" placeholder="20" data-numeric>
								<small>mmol/L</small>
							</div>
							<small>Hữu ích khi phân loại kiềm chuyển hóa.</small>
						</label>

						<label class="nah-abg__field">
							<span>pH niệu</span>
							<input type="text" name="urinePh" inputmode="decimal" placeholder="5,5" data-numeric>
							<small>Hữu ích khi đánh giá toan ống thận.</small>
						</label>
					</div>

					<div class="nah-abg__notice">
						Nếu có toan chuyển hóa nhưng thiếu Na⁺, Cl⁻, albumin, lactat, ceton hoặc chức năng thận, công cụ sẽ liệt kê các xét nghiệm cần bổ sung thay vì suy đoán.
					</div>
				</section>

				<section class="nah-abg__panel" data-form-step="4" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-step-4" hidden>
					<div class="nah-abg__section-heading">
						<div class="nah-abg__step-number">04</div>
						<div>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-step-4">Oxy hóa và hỗ trợ hô hấp</h3>
							<p>Ghi phương thức hỗ trợ và FiO₂ tại thời điểm lấy mẫu để diễn giải oxy hóa chính xác hơn.</p>
						</div>
					</div>

					<div class="nah-abg__grid nah-abg__grid--3">
						<label class="nah-abg__field">
							<span>Phương thức hỗ trợ</span>
							<select name="oxygenDevice">
								<option value="room-air">Khí phòng</option>
								<option value="conventional">Oxy gọng kính/mặt nạ</option>
								<option value="hfnc">Oxy dòng cao qua gọng mũi</option>
								<option value="niv">Thông khí không xâm nhập</option>
								<option value="invasive">Thông khí xâm nhập</option>
								<option value="unknown">Không rõ</option>
							</select>
						</label>

						<label class="nah-abg__field">
							<span>FiO₂</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="fio2" inputmode="decimal" value="21" data-numeric>
								<small>%</small>
							</div>
							<small>Khí phòng = 21%; FiO₂ ước tính từ oxy lưu lượng thấp có sai số.</small>
						</label>

						<label class="nah-abg__field">
							<span>Áp lực dương cuối thì thở ra (PEEP/EPAP)</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="peep" inputmode="decimal" placeholder="5" data-numeric>
								<small>cmH₂O</small>
							</div>
						</label>

						<label class="nah-abg__field">
							<span>Áp suất khí quyển</span>
							<div class="nah-abg__input-wrap">
								<input type="text" name="atmosphericPressure" inputmode="decimal" value="760" data-numeric>
								<small>mmHg</small>
							</div>
							<small>Mặc định mực nước biển.</small>
						</label>

						<label class="nah-abg__field">
							<span>Hemoglobin</span>
							<div class="nah-abg__compound">
								<input type="text" name="hemoglobin" inputmode="decimal" placeholder="135" data-numeric>
								<select name="hemoglobinUnit" data-unit-role="hemoglobin" aria-label="Đơn vị hemoglobin">
									<option value="gl">g/L</option>
									<option value="gdl">g/dL</option>
								</select>
							</div>
						</label>
					</div>

					<div class="nah-abg__notice" data-venous-warning hidden>
						Mẫu tĩnh mạch không được dùng thay cho mẫu động mạch để đánh giá PaO₂, tỷ số PaO₂/FiO₂ hoặc chênh áp oxy phế nang–động mạch.
					</div>
				</section>

				<section class="nah-abg__panel nah-abg__panel--results" data-form-step="5" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-step-5" hidden>
					<div class="nah-abg__section-heading">
						<div class="nah-abg__step-number">05</div>
						<div>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-step-5">Kết quả phân tích</h3>
							<p>Kết luận được trình bày theo rối loạn chính, bù trừ, rối loạn phối hợp và oxy hóa.</p>
						</div>
					</div>

					<div class="nah-abg__result-shell" data-result-shell aria-live="polite">
						<div class="nah-abg__empty">
							<p>Chọn <strong>Phân tích khí máu</strong> để tạo kết quả.</p>
						</div>
					</div>

					<div class="nah-abg__result-actions" data-result-actions hidden>
						<button type="button" class="nah-abg__button nah-abg__button--ghost" data-copy-result>Sao chép kết luận</button>
						<button type="button" class="nah-abg__button nah-abg__button--ghost" data-print-result>In kết quả</button>
						<button type="button" class="nah-abg__button nah-abg__button--ghost" data-save-trend>Lưu mốc theo dõi</button>
						<button type="button" class="nah-abg__button nah-abg__button--ghost" data-reset-form>Làm ca mới</button>
					</div>

					<section class="nah-abg__serial-panel">
						<div class="nah-abg__serial-head"><div><strong>Theo dõi chuỗi khí máu</strong><small>So sánh các lần đo trong cùng phiên làm việc.</small></div><button type="button" class="nah-abg__button nah-abg__button--ghost nah-abg__button--small" data-clear-trend>Xóa chuỗi</button></div>
						<div data-serial-trend></div>
					</section>
				</section>

				<div class="nah-abg__errors" data-form-errors role="alert" hidden></div>

				<footer class="nah-abg__form-nav">
					<button type="button" class="nah-abg__button nah-abg__button--ghost" data-prev-step hidden>← Quay lại</button>
					<div class="nah-abg__nav-spacer"></div>
					<button type="button" class="nah-abg__button nah-abg__button--primary" data-next-step>Tiếp tục →</button>
					<button type="submit" class="nah-abg__button nah-abg__button--primary" data-analyze hidden>Phân tích khí máu</button>
				</footer>
			</form>

			<details class="nah-abg__references">
				<summary>Cơ sở chuyên môn và giới hạn sử dụng</summary>
				<div>
					<p>Các phép tính và diễn giải dựa trên phương trình Henderson–Hasselbalch, khoảng trống anion, công thức Winter, phân tích delta, các quy tắc bù trừ, cơ chế giảm oxy, đồng oxy kế và dữ kiện lâm sàng có cấu trúc.</p>
					<ul>
						<li>Toffaletti JG, Rackley CR. <em>Khí máu và các Xét nghiệm trong Hồi sức Cấp cứu</em>, bản dịch tiếng Việt có bản quyền của Lê Đình Sáng từ ấn bản thứ ba của Toffaletti JG và Rackley CR.</li>
						<li>Hội Lồng ngực Hoa Kỳ. <a href="https://www.thoracic.org/professionals/clinical-resources/critical-care/clinical-education/abgs.php" target="_blank" rel="noopener noreferrer">Diễn giải khí máu động mạch</a>.</li>
						<li>Hiệp hội Chăm sóc Hô hấp Hoa Kỳ. <a href="https://www.aarc.org/wp-content/uploads/2025/03/davis-et-al-2013-aarc-clinical-practice-guideline-blood-gas-analysis-and-hemoximetry-2013.pdf" target="_blank" rel="noopener noreferrer">Phân tích khí máu và đồng oxy kế</a>.</li>
						<li>Viện Tiêu chuẩn Lâm sàng và Xét nghiệm. <a href="https://clsi.org/shop/standards/c46/" target="_blank" rel="noopener noreferrer">C46: Phân tích khí máu, pH và các phép đo liên quan</a>.</li>
						<li>Piraino T và cộng sự. <a href="https://www.aarc.org/wp-content/uploads/2022/10/cpg-clinical-mangement-adult-o2-acute-settings.pdf" target="_blank" rel="noopener noreferrer">Sử dụng oxy ở người bệnh người lớn trong chăm sóc cấp tính</a>.</li>
						<li>Umpierrez GE và cộng sự. <a href="https://doi.org/10.2337/dci24-0032" target="_blank" rel="noopener noreferrer">Các cấp cứu tăng đường huyết ở người lớn đái tháo đường</a>.</li>
						<li>Matthay MA và cộng sự. <a href="https://doi.org/10.1164/rccm.202303-0558WS" target="_blank" rel="noopener noreferrer">Định nghĩa toàn cầu mới về hội chứng suy hô hấp cấp tiến triển</a>.</li>
						<li>Prescott HC và cộng sự. <a href="https://www.sccm.org/clinical-resources/guidelines/guidelines/surviving-sepsis-campaign-international-guidelines-for-management-of-sepsis-and-septic-shock-2026" target="_blank" rel="noopener noreferrer">Hướng dẫn quốc tế về nhiễm trùng huyết và sốc nhiễm trùng 2026</a>.</li>
						<li>Trung tâm Kiểm soát và Phòng ngừa Dịch bệnh Hoa Kỳ. <a href="https://www.cdc.gov/carbon-monoxide/hcp/clinical-guidance/index.html" target="_blank" rel="noopener noreferrer">Hướng dẫn lâm sàng về ngộ độc carbon monoxit</a>.</li>
					</ul>
					<p>Phạm vi hiện tại: người lớn; chưa có nội dung chuyên biệt cho trẻ em và sơ sinh. Thai kỳ chỉ được dùng như một dữ kiện chẩn đoán phân biệt. Tỷ số PaO₂/FiO₂ đơn độc không xác lập chẩn đoán hội chứng suy hô hấp cấp tiến triển. Xu hướng lactat và đồng oxy kế không thay thế đánh giá lâm sàng. Hướng xử trí không bao gồm liều thuốc và phải được đối chiếu với hướng dẫn chuyên môn tại cơ sở.</p>
				</div>
			</details>
			</div>


			<section class="nah-abg__learn-workspace nah-abg__learn-workspace--v680" id="<?php echo esc_attr( $instance_id ); ?>-learn" role="tabpanel" data-workspace-panel="learn" hidden>
				<section class="nah-abg__canonical-learning" data-canonical-workspace="learning">
					<header class="nah-abg__v680-page-head">
						<div><h2>Học khí máu theo chuyên đề</h2><p>Từ điển để tra cứu nhanh; chuyên đề để học sâu; Ôn luyện tích hợp toàn bộ câu hỏi, đáp án, giải thích và ý nghĩa lâm sàng.</p></div>
						<span class="nah-abg__v680-content-version" data-canonical-version>Đang tải nội dung…</span>
					</header>
					<nav class="nah-abg__v680-learning-tabs" aria-label="Nội dung học tập">
						<button type="button" class="is-active" data-canonical-tab="topics"><span class="nah-abg__v6103-tab-icon" aria-hidden="true">▤</span><span>Chuyên đề</span></button>
						<button type="button" data-canonical-tab="dictionary"><span class="nah-abg__v6103-tab-icon" aria-hidden="true">A–Z</span><span>Từ điển</span></button>
						<button type="button" data-canonical-tab="review"><span class="nah-abg__v6103-tab-icon" aria-hidden="true">✓</span><span>Ôn luyện</span></button>
					</nav>
					<div class="nah-abg__v680-load" data-canonical-status><span></span>Đang nạp bộ nội dung chuyên môn…</div>
					<section class="nah-abg__v680-panel" data-canonical-panel="dictionary" hidden><div class="nah-abg__v680-toolbar"><label><span>Tìm thuật ngữ</span><input type="search" data-canonical-dictionary-search placeholder="Ví dụ: PaCO₂, khoảng trống anion, PEEP"></label></div><div class="nah-abg__v680-dictionary" data-canonical-dictionary></div></section>
					<section class="nah-abg__v680-panel is-active" data-canonical-panel="topics"><div class="nah-abg__v680-topic-layout"><aside data-canonical-topic-list></aside><article data-canonical-topic-detail><div class="nah-abg__v680-empty"><strong>6 chuyên đề cốt lõi</strong><p>Chọn một chuyên đề. Nội dung sẽ mở ngay trong khung đọc hiện tại và có nút Quay lại danh sách.</p></div></article></div></section>
					<section class="nah-abg__v680-panel" data-canonical-panel="review" hidden><div class="nah-abg__v680-toolbar"><label><span>Tìm câu hỏi ôn luyện</span><input type="search" data-canonical-review-search placeholder="Nhập câu hỏi, đáp án hoặc nội dung cần làm rõ"></label></div><div class="nah-abg__v680-review" data-canonical-review></div></section>
				</section>

				<section class="nah-abg__canonical-cases" data-canonical-workspace="cases" data-classroom hidden>
					<header class="nah-abg__v680-page-head"><div><h2>Ca lâm sàng</h2><p>Học phân tích khí máu trong toàn bộ bối cảnh người bệnh: bệnh sử, khám lâm sàng, chẩn đoán sơ bộ, xét nghiệm, khí máu, lập luận chẩn đoán, chẩn đoán phân biệt và hướng xử trí.</p></div></header>
					<div class="nah-abg__v680-case-grid" data-canonical-cases></div>
				</section>

				<section class="nah-abg__canonical-profile" data-canonical-workspace="profile" hidden>
					<header class="nah-abg__v680-page-head"><div><h2>Tiến độ học tập</h2><p>Theo dõi chuyên đề đã mở, phần đã đọc và nội dung gần nhất trên thiết bị này.</p></div></header>
					<div data-canonical-progress></div>
				</section>
			</section>

			</div><!-- /.nah-abg__workspace-frame -->

			<nav class="nah-abg__mobile-dock nah-abg__mobile-dock--v680" aria-label="Điều hướng nhanh">
				<button type="button" class="is-active" data-home-workspace="home"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11.5 12 4l9 7.5V21h-6v-6H9v6H3z"/></svg><span>Trang chủ</span></button>
				<button type="button" data-home-workspace="analysis"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></svg><span>Phân tích</span></button>
				<button type="button" data-home-workspace="cases"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3v5a3 3 0 0 0 6 0V3M12 11v2a5 5 0 0 0 5 5h1"/><circle cx="19" cy="18" r="2"/></svg><span>Ca lâm sàng</span></button>
				<button type="button" data-home-workspace="theory"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v18H7.5A3.5 3.5 0 0 0 4 23zM20 5.5A3.5 3.5 0 0 0 16.5 2H13v18h3.5A3.5 3.5 0 0 1 20 23z"/></svg><span>Học tập</span></button>
			</nav>
			<footer class="nah-abg__app-footer nah-abg__app-footer--v601 nah-abg__app-footer--v609">
				<p class="nah-abg__footer-app"><strong>MEDIPHARM ABG</strong> <span>· Phiên bản v<?php echo esc_html( MEDIPHARM_ABG_SUITE_VERSION ); ?></span></p>
				<p class="nah-abg__footer-author">Phát triển bởi: <strong>THƯ VIỆN MEDIPHARM</strong></p>
				<div class="nah-abg__footer-access">
				<?php if ( $trial['member'] ) : ?>
					<span class="nah-abg__footer-member">Thành viên · Toàn quyền truy cập</span>
				<?php else : ?>
					<span>Vui lòng <button type="button" class="nah-abg__footer-access-link" data-abg-login-open>Đăng nhập</button> hoặc <a href="<?php echo esc_url( home_url( '/dangky' ) ); ?>">Đăng ký tài khoản</a> để truy cập đầy đủ mọi nội dung.</span>
				<?php endif; ?>
				</div>
				<?php if ( ! $trial['member'] ) : ?>
					<p class="nah-abg__footer-trial">Còn <strong data-abg-trial-remaining><?php echo esc_html( (string) $trial['remaining'] ); ?></strong>/<?php echo esc_html( (string) $trial['limit'] ); ?> lượt dùng thử.</p>
				<?php endif; ?>
			</footer>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Add a simple usage page under Tools.
	 */
	public function register_admin_page() {
		add_management_page(
			'NAH Phân tích Khí máu',
			'NAH Khí máu',
			'manage_options',
			'medipharm-abg-suite',
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Render usage instructions.
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>NAH Phân tích Khí máu</h1>
			<p>Chèn shortcode sau vào bài viết hoặc trang bằng Classic Editor:</p>
			<p><code>[nah_abg_analyzer]</code></p>
			<p>Có thể đổi tiêu đề:</p>
			<p><code>[nah_abg_analyzer title="Phân tích khí máu động mạch"]</code></p>
			<p>Module tương tác cho Trang chủ:</p>
			<p><code>[medipharm_abg_launcher]</code></p>
			<hr>
			<h2>Phiên bản <?php echo esc_html( MEDIPHARM_ABG_SUITE_VERSION ); ?></h2>
			<p>Dữ liệu được xử lý hoàn toàn trên thiết bị của người dùng, không dùng API và không ghi vào cơ sở dữ liệu WordPress.</p>
			<p>Để cài dưới dạng ứng dụng và sử dụng ngoại tuyến, trang chứa shortcode phải được truy cập qua HTTPS. Trình duyệt sẽ hiển thị nút <strong>Cài Webapp</strong> khi đủ điều kiện.</p>
		</div>
		<?php
	}
}

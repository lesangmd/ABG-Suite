# MEDIPHARM ABG Suite v6.7.3 — Dark Menu Surface Hotfix

## Scope
Corrective dark-mode release only. No clinical calculation, content, authentication or navigation changes.

## Changes
- Fixes the Header Menu surface remaining white while dark mode is active.
- Restores readable contrast for utility labels, icons, theme toggle, install/download actions and About.
- Keeps the supplemental Ca lâm sàng / Tiến độ cards on the same dark surface system.
- Harmonizes hover/focus and safety-warning colors with the v6.7.1 dark palette.
- Applies the fix on mobile, foldable, tablet and desktop menu popovers.

## Invariants
- `nah-abg-core.js` unchanged.
- Menu deduplication contract from v6.7.2 unchanged.
- Bottom Dock contract unchanged.

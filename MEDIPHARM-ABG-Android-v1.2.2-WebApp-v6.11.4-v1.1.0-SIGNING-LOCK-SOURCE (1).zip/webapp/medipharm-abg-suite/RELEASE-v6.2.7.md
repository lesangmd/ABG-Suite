# MEDIPHARM ABG Suite v6.2.7

- Menu Android: Đăng nhập, Đăng ký tài khoản, Kiểm tra cập nhật.
- Không hiển thị Cài ứng dụng trong Android native shell.
- Web download sử dụng stable alias `MEDIPHARM-ABG-latest.apk`.
- Không thay đổi engine phân tích khí máu, ngân hàng câu hỏi hoặc nội dung chuyên môn.

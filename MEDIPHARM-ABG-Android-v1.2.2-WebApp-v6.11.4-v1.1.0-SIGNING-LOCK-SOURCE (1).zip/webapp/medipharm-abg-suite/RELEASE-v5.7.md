# MEDIPHARM ABG Suite v5.7 — Error Pattern & Targeted Remediation

**Parent production candidate:** v5.6 — Advanced Clinical Content Expansion  
**Parent SHA-256:** `aad2bc2fed2c44e5b718bf6b37fe13d2973c168d5ca548c9500dca2ea597be02`

## Scope
- Add a seven-pattern local error taxonomy instead of treating assessment as score-only.
- Record targeted remediation state inside the existing `medipharm_abg_learning_v30` learning object.
- Add a dedicated **Lộ trình cải thiện** dashboard and post-exam targeted-remediation block.
- Link priority errors back to the relevant handbook lesson, flashcard domain and clinical practice case.
- Add per-exam `errorPatterns` summaries while preserving all existing scoring semantics.
- Redesign the public ABG launcher as one compact card.
- Provide companion homepage releases for SachYHoc and YHocLamSang that remove the duplicate outer ABG heading/CTA so the complete homepage module occupies one card only.

## Error taxonomy
1. Thiếu kiến thức nền.
2. Sai trình tự suy luận.
3. Sai tính toán.
4. Bỏ sót bối cảnh lâm sàng.
5. Sai đánh giá oxy hóa/thông khí.
6. Bỏ sót chất lượng mẫu.
7. Sai diễn giải khí máu nối tiếp.

## Preserved invariants
- 220 canonical assessment items and six question formats.
- Six mock-test packs and v5.5 blueprint generator.
- 50 handbook lessons and 50 clinical cases.
- Existing 10-launch guest trial/access policy and provider-owned login forms.
- Existing route `/phan-tich-khi-mau-app/`.
- Existing localStorage key; no new learning storage key.
- No new learning AJAX, polling or remote analytics.
- Calculation core remains byte-identical.

## Homepage compact integration
- SachYHoc companion: v0.71.3 from exact v0.71.2.
- YHocLamSang companion: v1.09.19 from exact v1.09.18.
- The host page renders only `[medipharm_abg_launcher]`; the redundant outer heading/description/CTA is removed.
- Desktop, tablet and mobile all retain exactly one ABG card; only the internal grid changes responsively.
- If ABG Suite is inactive, no homepage ABG module is rendered.

## Competency boundary
The remediation dashboard is a self-learning aid. Error counts and improvement states are not a clinical competency score, credential or certification.

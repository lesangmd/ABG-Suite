# MEDIPHARM ABG Suite v6.2.8 — Android Login & Webapp Label Fix

- Android native shell no longer shows “Về Trang chủ” in the application menu.
- Adds a native-callable login hook that opens the existing Medipharm membership login form without navigating to `?access=member`.
- Renames the PWA installation action from “Cài ứng dụng” to “Cài Webapp”.
- Android install/download separation remains unchanged.
- ABG calculation engine, learning content, question banks and clinical cases are unchanged.

# MEDIPHARM ABG Suite v6.3.6 — Focused Clinical Home

## Phạm vi
- Thiết kế lại Trang chủ theo mockup đã duyệt: gọn, có trọng tâm, ưu tiên hành trình lâm sàng và học tập.
- Header: logo, hộp tìm kiếm một lớp, Tài khoản, Menu.
- Điều hướng: Trang chủ, Phân tích khí máu, Học tập, Ca lâm sàng, Ôn luyện, Tiến độ; bổ sung icon chuyên môn.
- Hero: tiêu đề chuyên môn “Khí máu lâm sàng”, mô tả toan–kiềm, thông khí, oxy hóa.
- 5 module chính hiển thị đồng cấp, responsive.
- Tiếp tục học và Tiến độ học tập gom thành một cụm tóm tắt.

## Không thay đổi
- Thuật toán phân tích khí máu.
- Ngân hàng bài học, ca bệnh, câu hỏi và thi thử.
- Cơ chế thành viên, trial, PWA và đường dẫn Android.
- Hệ nhận diện O₂/CO₂ từ v6.3.4.

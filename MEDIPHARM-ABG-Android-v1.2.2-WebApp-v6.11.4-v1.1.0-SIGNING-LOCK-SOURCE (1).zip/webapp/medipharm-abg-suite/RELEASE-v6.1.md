# MEDIPHARM ABG Suite v6.1 — Responsive Home Information Architecture Redesign

Built directly from canonical v6.0.9.

- Simplifies tablet/mobile Home into four primary blocks: hero, Continue today, Choose how to learn, and compact Learning profile.
- Hides the rotating learning feed and secondary topic tiles on <=1024px to reduce vertical density.
- Converts learning destinations into compact task-oriented navigation rows.
- Rewrites Home labels/copy to user-facing Vietnamese clinical language and removes internal implementation vocabulary.
- Preserves the calculation core, assessment/content corpus, trial policy, shared dark-mode ownership, Search Dock layering, route, and local storage.

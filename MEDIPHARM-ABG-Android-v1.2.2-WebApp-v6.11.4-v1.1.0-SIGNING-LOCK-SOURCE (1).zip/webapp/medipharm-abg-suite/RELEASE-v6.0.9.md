# MEDIPHARM ABG Suite v6.0.9 — Tablet Outer Wrapper Dark Unification & Footer Information Order Hotfix

- Parent: v6.0.8.
- Tablet 701–1024 px dark mode now extends the ABG background beyond the app edge to cover residual host gutters.
- Footer order: MEDIPHARM ABG + version → author → member access notice → remaining trial count.
- Mobile density improvements from v6.0.8 retained.
- Shared dark-mode ownership from v6.0.7 retained.
- Calculation core and all clinical/learning data unchanged.

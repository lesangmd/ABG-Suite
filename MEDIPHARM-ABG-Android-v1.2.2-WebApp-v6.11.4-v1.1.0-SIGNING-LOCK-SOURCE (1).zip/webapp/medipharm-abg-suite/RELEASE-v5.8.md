# MEDIPHARM ABG Suite v5.8 — Longitudinal Assessment Intelligence

- Parent: v5.7.1.
- Adds longitudinal trends across up to 10 recent structured assessments.
- Adds score direction, recent stability, domain-level trend and due-review burden.
- All metrics are derived locally from the existing learning state. No network analytics and no new storage key.
- Does not claim or certify professional/clinical competence.
- Assessment corpus remains 220; handbook 50 lessons; case library 50 cases; calculation core unchanged.

# MEDIPHARM ABG Suite v6.5.0 — Dictionary-First Clinical Home

## Scope
- Rebuild Trang chủ theo mockup mới: header lâm sàng gọn, hero có trọng tâm, 5 module chính, Từ điển học tập, Hoạt động gần đây và Tài nguyên nổi bật.
- Desktop: 5 module trên một hàng, vùng học tập dạng từ điển và cột hoạt động/tài nguyên.
- Mobile: hero rút gọn, lưới module 2+3, Từ điển học tập full-width, bottom dock cố định.
- Foldable/tablet: responsive theo bề rộng thực; không ép giao diện điện thoại chỉ vì thiết bị cảm ứng.
- Header: MEDIPHARM ABG + Search + Tài khoản + Menu; placeholder tìm kiếm đổi sang thuật ngữ/ca lâm sàng/hướng dẫn.
- Thêm lọc Từ điển theo từ khóa và chữ cái.

## Preserved
- Calculation core không thay đổi.
- Luồng Phân tích, Học tập, Ca lâm sàng, Ôn luyện, Tiến độ giữ nguyên nghiệp vụ.
- Trial/member gate và đăng nhập MEDIPHARM giữ nguyên.

<?php
/**
 * Plugin Name: MEDIPHARM ABG Suite
 * Description: Nền tảng học tập khí máu động mạch tích hợp phân tích, lý thuyết, ôn tập, thi thử và ca lâm sàng.
 * Version: 6.11.4
 * Author: MEDIPHARM
 * Text Domain: medipharm-abg-suite
 * Requires at least: 5.9
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;
define('MEDIPHARM_ABG_SUITE_VERSION','6.11.4');
define('MEDIPHARM_ABG_SUITE_DIR',plugin_dir_path(__FILE__));
define('MEDIPHARM_ABG_SUITE_URL',plugin_dir_url(__FILE__));
require_once MEDIPHARM_ABG_SUITE_DIR.'class-medipharm-abg-suite-module.php';

function medipharm_abg_suite_app_url(){ return home_url('/phan-tich-khi-mau-app/'); }
function medipharm_abg_suite_android_apk_url(){
    return apply_filters(
        'medipharm_abg_suite_android_apk_url',
        'https://raw.githubusercontent.com/lesangmd/ABG-Suite/android-v1-channel/releases/MEDIPHARM-ABG-v1.1.0.apk'
    );
}
function medipharm_abg_suite_is_android_shell(){
    $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
    return false !== stripos( $ua, 'MEDIPHARMABGAndroid/' );
}
function medipharm_abg_suite_is_app_request(){
    return (int)get_query_var('medipharm_abg_suite_app') === 1 || preg_match('#/phan-tich-khi-mau-app/?$#', (string)wp_parse_url($_SERVER['REQUEST_URI'] ?? '',PHP_URL_PATH));
}
final class MEDIPHARM_ABG_Suite {
    const VERSION='6.11.4'; const VERSION_KEY='medipharm_abg_suite_version';
    public static function boot(){
        add_action('init',[__CLASS__,'rewrite'],1); add_filter('query_vars',[__CLASS__,'vars']);
        add_action('template_redirect',[__CLASS__,'pwa'],0); add_action('template_redirect',[__CLASS__,'android_auth'],0); add_action('template_redirect',[__CLASS__,'render'],1);
        add_action('wp_ajax_medipharm_abg_trial_action',[__CLASS__,'trial_action']); add_action('wp_ajax_nopriv_medipharm_abg_trial_action',[__CLASS__,'trial_action']);
        add_action('wp_ajax_medipharm_abg_login_form',[__CLASS__,'login_form']); add_action('wp_ajax_nopriv_medipharm_abg_login_form',[__CLASS__,'login_form']);
        add_action('wp_ajax_medipharm_abg_android_entitlement',[__CLASS__,'android_entitlement']); add_action('wp_ajax_nopriv_medipharm_abg_android_entitlement',[__CLASS__,'android_entitlement']);
        add_action('wp_ajax_medipharm_abg_android_login',[__CLASS__,'android_login']); add_action('wp_ajax_nopriv_medipharm_abg_android_login',[__CLASS__,'android_login']);
        add_action('wp_ajax_medipharm_abg_web_login',[__CLASS__,'web_login']); add_action('wp_ajax_nopriv_medipharm_abg_web_login',[__CLASS__,'web_login']);
        add_shortcode('nah_abg_analyzer',[__CLASS__,'shortcode']); add_shortcode('medipharm_abg_launcher',[__CLASS__,'launcher']);
        add_action('wp_head',[__CLASS__,'meta'],3);
        if(get_option(self::VERSION_KEY)!==self::VERSION){ update_option(self::VERSION_KEY,self::VERSION,false); update_option('medipharm_abg_suite_flush',1,false); }
        add_action('init',[__CLASS__,'flush'],20);
    }
    public static function activate(){ self::rewrite(); flush_rewrite_rules(false); update_option(self::VERSION_KEY,self::VERSION,false); }
    public static function deactivate(){ flush_rewrite_rules(false); }
    public static function rewrite(){ add_rewrite_rule('^phan-tich-khi-mau-app/?$','index.php?medipharm_abg_suite_app=1','top'); }
    public static function vars($v){ $v[]='medipharm_abg_suite_app'; return $v; }
    public static function flush(){ if((int)get_option('medipharm_abg_suite_flush',0)===1){ flush_rewrite_rules(false); delete_option('medipharm_abg_suite_flush'); } }
    public static function module(){ return MEDIPHARM_ABG_Suite_Module::instance(); }
    public static function pwa(){ if(isset($_GET['nah_sdp_abg_manifest'])||isset($_GET['nah_sdp_abg_sw'])) self::module()->serve_pwa_endpoint(); }
    public static function android_auth(){ if(isset($_GET['medipharm_abg_android_auth'])) self::module()->serve_android_auth_page(); }
    public static function trial_action(){ self::module()->handle_trial_action(); }
    public static function login_form(){ self::module()->handle_login_form(); }
    public static function android_entitlement(){ self::module()->handle_android_entitlement(); }
    public static function android_login(){ self::module()->handle_android_login(); }
    public static function web_login(){ self::module()->handle_android_login(); }
    public static function shortcode($atts=[]){ return self::module()->render_analyzer($atts); }
    public static function launcher($atts=[]){ return self::module()->render_launcher($atts); }
    public static function meta(){ self::module()->output_pwa_meta(); }
    public static function render(){
        if(!medipharm_abg_suite_is_app_request()) return;
        self::module()->enqueue_assets(); $start='/phan-tich-khi-mau-app/';
        $manifest=add_query_arg(['nah_sdp_abg_manifest'=>'1','start'=>$start],home_url('/'));
        status_header(200); nocache_headers();
        ?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>MEDIPHARM ABG – Phân tích khí máu động mạch</title><meta name="description" content="Phân tích khí máu động mạch có cấu trúc, học chuyên đề, ôn luyện và thực hành ca lâm sàng trong cùng một ứng dụng."><meta name="theme-color" content="#0867d8"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="Khí máu"><link rel="manifest" href="<?php echo esc_url($manifest); ?>"><link rel="apple-touch-icon" href="<?php echo esc_url(MEDIPHARM_ABG_SUITE_URL.'assets/icons/icon-192.png'); ?>"><?php wp_head(); ?></head><body class="nah-sdp-abg-app-body"><main><?php echo self::module()->render_analyzer(['context'=>'standalone','title'=>'ABG','app_url'=>medipharm_abg_suite_app_url()]); ?></main><?php wp_footer(); ?></body></html><?php exit;
    }
}
register_activation_hook(__FILE__,['MEDIPHARM_ABG_Suite','activate']); register_deactivation_hook(__FILE__,['MEDIPHARM_ABG_Suite','deactivate']); MEDIPHARM_ABG_Suite::boot();

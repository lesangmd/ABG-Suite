# MEDIPHARM ABG Suite v6.1.4

## Generator Runtime, User-Facing Copy & Action Alignment Hotfix

Parent kỹ thuật: v6.1.3.

### Sửa lỗi runtime tạo đề
- Tạo đề luyện tập không còn phụ thuộc hoàn toàn vào request trial trước khi dựng câu hỏi trên thiết bị khách còn lượt hợp lệ.
- Đề được dựng ngay từ cấu hình hiện tại; lượt dùng thử được đối soát nền với máy chủ.
- Nếu máy chủ trả trạng thái không được phép, phiên vừa tạo bị thu hồi và access gate được hiển thị.
- Request access có timeout 8 giây để không còn trạng thái chờ vô hạn.
- `startExamUnlocked()` có guard lỗi và luôn hoàn nguyên trạng thái nút nếu generator thất bại.

### User-facing copy
- Bỏ badge kỹ thuật `v5.5` trên card Tạo đề luyện tập; thay bằng `ĐỀ`.
- Bỏ badge kỹ thuật `v6.0` trên Phiên học tích hợp; thay bằng `5 bước`.
- `Sinh đề theo cấu trúc` trên control người dùng đổi thành `Tạo đề theo mục tiêu`.
- Nhãn generator đổi thành `Tạo đề luyện tập`.

### Responsive action alignment
- CTA của các card Trang chủ được căn phải trên tablet/mobile: Mở công cụ, Khám phá ca bệnh, Khám phá bài học, Bắt đầu kiểm tra, Tạo đề mới.

### Không thay đổi
- Calculation core.
- Corpus 220 câu / 50 bài / 50 ca / 8 bộ thi.
- Scoring, route, localStorage, dark-mode owner, Search Dock layering và trial limit.

# MEDIPHARM ABG Suite v6.2.4 – Q&A Workspace Expansion & Full-Width Layout Hotfix

## Parent
- Exact parent: MEDIPHARM ABG Suite v6.2.3
- Parent SHA-256: `4499dd38c2a81d1f28da63ed2cff9b88db8547f2ce9d4861f84c00c7c32bb130`

## Thay đổi
- Mở rộng workspace **Hỏi & Đáp** ra toàn chiều rộng khả dụng; bỏ giới hạn `max-width: 920px` làm nội dung co ở giữa.
- Nâng thư viện giải đáp nhanh từ 12 lên **36 câu**, chia 4 nhóm: Nền tảng & toan–kiềm, Oxy hóa & thông khí, Chất lượng mẫu, Tình huống lâm sàng.
- Hợp nhất các câu tự kiểm tra mang tính giải thích từ Lý thuyết vào Hỏi & Đáp; giữ nguyên các câu luyện có chấm điểm trong Ôn tập để không làm lộ đáp án.
- Desktop dùng bố cục 2 nhóm mỗi hàng; tablet/mobile chuyển về một cột, full-width và tăng readability.
- User-facing copy được rà soát theo hướng tiếng Việt rõ ràng, tránh ngôn ngữ kỹ thuật nội bộ.

## Bất biến giữ nguyên
- 220 câu đánh giá canonical.
- 50 bài Sổ tay.
- 50 ca lâm sàng.
- 8 bộ thi thử, 6 dạng câu.
- Generator runtime fix v6.2.1 và unified content width v6.2.2.
- Trial policy, shared dark mode, Search Dock layering, route `/phan-tich-khi-mau-app/` và localStorage hiện hữu.
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

## QA
- PHP lint: 2/2 PASS.
- JavaScript syntax: 3/3 PASS.
- Regression/static: 85 PASS / 1 UI smoke SKIP / 0 FAIL.
- Q&A: 36/36 unique; 4/4 nhóm nội dung hợp lệ.
- CSS brace balance: main 2630/2630; launcher 46/46.
- ZIP CRC: chạy sau khi đóng gói.

# MEDIPHARM ABG Suite v6.10.6 — Balanced Viewport Reader Canvas

## Scope
- Rebalances the viewport popup on desktop so the reading surface is wider and less vertically dominant.
- Uses a resilient direct-body selector to avoid Theme/Super App width rules shrinking the dialog.
- Desktop target: up to 1440–1480 px wide and 940–960 px high, centered inside the usable viewport.
- Continues to reserve the live NAH Search Dock Pro right rail.
- Tablet uses the full available inset canvas; mobile remains full-screen.
- Reading content expands up to 1320 px while scrolling remains inside the modal body.
- No canonical learning-content or ABG calculation-core changes.

# MEDIPHARM ABG Suite v5.1 — Assessment Bank Expansion I

Baseline: **MEDIPHARM ABG Suite v5.0.1 – Lesson Summary Card Layout Hotfix**  
Baseline ZIP SHA-256: `749a48152627dbe9dc02e186204c3239a32afb8db538ac53f5f1847475e923bb`

## Implemented
- Expanded the canonical structured-assessment bank from **48 to 120 single-best-answer questions**.
- Preserved all **48 legacy questions** and added **72 new questions**.
- Balanced the bank to **30 questions/domain** and **10 basic + 10 intermediate + 10 advanced** in every domain.
- Added a canonical runtime taxonomy for all items: `domain`, `lesson_id`, `concept`, `difficulty`, `cognitive_level`, `error_pattern`, `source_scope`, `distractor_rationale`, `remediation_link`, `item_format`, `schema_version`.
- Retained compatibility aliases used by the existing engine; **no localStorage migration** is required.
- Linked the expanded bank across all **39 handbook lessons**.
- Added duplicate ID, exact/near-duplicate stem, answer-position bias, metadata completeness and lesson-reference gates.
- Updated user-facing assessment counts from 48 to 120.

## Preserved invariants
- Calculation core byte-identical: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- Existing scoring semantics and 12/16/20-question assessment blueprints unchanged.
- `medipharm_abg_learning_v30` local-first state contract unchanged.
- No new learning API/AJAX/background request.
- Route remains `/phan-tich-khi-mau-app/`.
- Super App, Theme and Search Dock unchanged.
- Accepted v5.0.1 lesson-summary layout hotfix retained exactly.

## Scope boundary
v5.1 is a content/taxonomy release. Case-linked bank, mixed-format engine, curated mock tests and blueprint-driven exam generation remain separate roadmap releases.

# MEDIPHARM ABG Suite v6.2 — Learning Navigation & Workspace Separation

Parent kỹ thuật: v6.1.5.

## Thay đổi chính

- Tách điều hướng thành 8 khu vực: Trang chủ, Phân tích, Lý thuyết, Hỏi & Đáp, Ca lâm sàng, Ôn tập, Thi thử và Hồ sơ học tập.
- Desktop dùng rail dọc 188 px để tận dụng không gian theo chiều dọc.
- Tablet/mobile chỉ hiện mục hiện tại; danh mục đầy đủ mở theo yêu cầu, tránh chiếm chiều cao thường trực.
- Lý thuyết dùng nguyên 50 bài Sổ tay hiện có.
- Hỏi & Đáp, Ca lâm sàng, Thi thử và Hồ sơ học tập được hiển thị ở chế độ tập trung, không còn lẫn các accordion không liên quan.
- Ôn tập gom thẻ ghi nhớ, câu hỏi theo chủ đề, nội dung cần củng cố và các bài luyện chuyên sâu.
- Trang chủ và các liên kết cũ được ánh xạ sang khu vực mới để giữ tương thích.
- URL `?view=theory|qa|cases|review|exam|profile` được hỗ trợ; `?view=learn` vẫn tương thích và mở Ôn tập.

## User-facing copy

- Bỏ tab tổng hợp “Học tập” khỏi điều hướng chính.
- Dùng các nhãn tiếng Việt theo nhiệm vụ người dùng, không dùng tên engine/schema/audit trong navigation.
- “Ôn thích ứng” trong các vùng có thể thấy được đổi sang ngôn ngữ “Ôn nội dung cần củng cố” hoặc “Ôn tập”.

## Bất biến

- 220 câu, 50 bài, 50 ca, 8 bộ thi, 6 dạng câu.
- Calculation core không đổi.
- Trial gate 10 lượt, shared dark mode, Search Dock layering, route và localStorage không đổi.

## QA

- 81 PASS / 1 UI smoke SKIP / 0 FAIL.
- PHP lint 2/2 PASS.
- JavaScript syntax 3/3 PASS.
- CSS balance: main 2515/2515; launcher 46/46.
- ZIP CRC PASS.

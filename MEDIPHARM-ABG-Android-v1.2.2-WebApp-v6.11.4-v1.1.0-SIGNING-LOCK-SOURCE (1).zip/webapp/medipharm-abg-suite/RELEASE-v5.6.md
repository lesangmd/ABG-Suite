# MEDIPHARM ABG Suite v5.6 — Advanced Clinical Content Expansion

**Parent:** v5.5 — Blueprint-Driven Exam Generator & Experience Redesign  
**Parent SHA-256:** `15639118a2443744d73803eea31e6717c9e36a791ef9c7b843c0a44f5c6893c5`

## Scope

v5.6 is a clinical-content expansion release. It does not change the calculation core, assessment corpus, mixed-format scoring, mock-test engine, exam generator, trial/access gate, localStorage schema, standalone route, Super App, Theme or Search Dock.

## Handbook expansion

The interactive handbook expands from **39 to 50 lessons**. Eleven new lessons cover:

40. Khí máu khi thở máy.
41. Khí máu nối tiếp sau chỉnh máy thở.
42. Hội chứng suy hô hấp cấp tiến triển: oxy hóa và bảo vệ phổi.
43. Thông khí không xâm nhập và tăng CO₂.
44. Oxy dòng cao và nhận diện xu hướng thất bại.
45. Sốc và lactat nối tiếp.
46. Đồng oxy kế và hemoglobin bất thường.
47. Cồn độc: khoảng trống anion và khoảng trống thẩm thấu theo thời gian.
48. Thận–chuyển hóa.
49. Khí máu trong thai kỳ.
50. Khí máu ở độ cao.

Every new lesson contains learning objectives, a worked clinical example, a self-check item, pitfalls/interpretive boundaries where appropriate, and a direct link to a related clinical case.

## Clinical-case expansion

The interactive case library expands from **30 to 50 cases**, adding 20 new cases:

- 4 mechanical-ventilation cases.
- 2 noninvasive-ventilation cases.
- 2 high-flow oxygen cases.
- 2 shock/serial-lactate cases.
- 2 dyshemoglobin/co-oximetry cases.
- 2 toxic-alcohol cases.
- 2 renal–metabolic cases.
- 2 pregnancy cases.
- 2 altitude cases.

Eight new cases are explicitly marked as **serial-ABG oriented**. The main case loader and the Classroom case selector are normalized to the same 50-case catalogue; this also closes the prior two-case discrepancy between those selectors.

## Evidence/currentness

The content-authoring registry adds current or still-relevant sources including AARC patient–ventilator assessment 2024, ERS high-flow nasal cannula guidance, Surviving Sepsis Campaign 2026, KDIGO 2024 CKD guidance, CDC carbon-monoxide guidance, Wilderness Medical Society 2024 altitude guidance, and peer-reviewed pregnancy/dyshemoglobinemia reviews. These sources are bundled as metadata only; **no remote source is fetched at runtime**.

## Preserved invariants

- Assessment bank: **220 items**, unchanged.
- Question formats: **6**, unchanged.
- Mock-test packs: **6**, unchanged.
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- Local-first learning/access architecture retained.
- Trial limit/access integration from v5.5 retained.
- Route remains `/phan-tich-khi-mau-app/`.

## QA summary

- PHP lint: 2/2 PASS.
- JavaScript syntax: 3/3 PASS.
- CSS brace integrity: main 1972/1972; launcher 51/51.
- Static/regression tests: 60 PASS / 1 browser-only UI smoke SKIP / 0 FAIL.
- v5.6 advanced-content gate: PASS.
- 20/20 new cases accepted by the unchanged calculation engine.
- 20/20 new cases pass Henderson–Hasselbalch consistency gate.
- Main case selector: 50/50; Classroom selector: 50/50; key sets identical.
- Calculation core unchanged.

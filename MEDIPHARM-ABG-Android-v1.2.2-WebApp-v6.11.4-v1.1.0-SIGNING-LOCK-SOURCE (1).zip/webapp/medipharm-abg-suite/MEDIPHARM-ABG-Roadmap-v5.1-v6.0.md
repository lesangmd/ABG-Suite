# MEDIPHARM ABG Suite — Roadmap v5.1 → v6.0

Status: Roadmap completed through v6.0 release candidate; production baseline remains the latest user-accepted release until runtime acceptance.

## v5.1 — Assessment Bank Expansion I — COMPLETED
- Assessment bank expanded to 120 standardized items with reusable taxonomy/metadata.

## v5.2 — Case-Based Question Bank — COMPLETED
- Added 60 case-linked questions and serial-ABG assessment metadata.

## v5.3 — Mixed-Format Assessment Engine — COMPLETED
- Added multiple response, ordering, matching, numeric calculation and structured case interpretation; six formats total including SBA.

## v5.4 — Mock Test Packs & Timed Simulation — COMPLETED
- Added six 30-item mock-test packs, timer, flag/review, navigation and post-test reporting.

## v5.5 — Blueprint-Driven Exam Generator — COMPLETED
- Added domain/difficulty/format blueprints, deterministic seed, anti-repeat logic, experience redesign and the 10-use guest access gate.

## v5.6 — Advanced Clinical Content Expansion — COMPLETED
- Handbook: **39 → 50 lessons**.
- Clinical library: **30 → 50 cases**.
- Adds mechanical ventilation, serial ABG after ventilator changes, ARDS oxygenation/lung protection, NIV, HFNC, shock/serial lactate, co-oximetry/dyshemoglobinemia, toxic alcohols, renal–metabolic interpretation, pregnancy and high-altitude physiology.
- Eight of the 20 new cases are explicitly serial-ABG oriented.
- Each new lesson retains objectives, worked example, self-check and linked practice case.
- Assessment bank remains 220 items; calculation core unchanged.

## v5.7 — Error Pattern & Targeted Remediation — COMPLETED
- Seven-pattern local error taxonomy: knowledge, reasoning sequence, calculation, clinical context, oxygenation/ventilation, sample quality and serial-ABG interpretation.
- Targeted remediation queue links priority errors to handbook lessons, flashcard review and related clinical cases.
- Post-exam `errorPatterns` summary and dedicated **Lộ trình cải thiện** dashboard.
- Uses the existing local-first learning object; no new learning storage key or network analytics.
- Homepage launcher is consolidated to one compact card on desktop/tablet/mobile.

## v5.8 — Longitudinal Assessment Intelligence — COMPLETED
- Add trends across attempts by domain, difficulty and item type.
- Show stability of performance and due-review burden without claiming professional competence certification.
- Integrate with the existing learning portfolio and self-learning milestones.

## v5.9 — Content Governance & Production Audit — COMPLETED
- Full answer-key/explanation and clinical-content audit.
- Duplicate/near-duplicate audit, Vietnamese editorial lint, clinical consistency, accessibility, responsive and Dark-mode matrix.
- Rebalance mock-test/blueprint distributions and freeze the v6.0 corpus only after gates pass.

## v6.0 — Integrated ABG Learning & Assessment Platform — CURRENT RELEASE CANDIDATE
- Consolidate handbook, practice, adaptive review, flashcards, cases, mock tests, exam generator and learning portfolio.
- Minimum target remains ≥200 validated assessment items, ≥50 lessons, ≥50 clinical cases, ≥8 mock-test packs and ≥5 formats.
- Preserve local-first privacy and the calculation core unless a separately governed clinical-core update is explicitly approved.

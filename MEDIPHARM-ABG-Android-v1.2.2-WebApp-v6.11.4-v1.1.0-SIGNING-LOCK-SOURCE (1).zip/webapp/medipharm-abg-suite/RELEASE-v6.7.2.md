# MEDIPHARM ABG Suite v6.7.2 — Menu Deduplication & Dock Role Separation

## Scope
Corrective navigation release only. No clinical calculation, content, authentication or data changes.

## Changes
- Header Menu no longer repeats the primary Dock destinations: Trang chủ, Phân tích, Học tập and Ôn luyện.
- Removed the redundant “Về Trang chủ” item; the Dock and ABG brand already provide Home navigation.
- Header Menu keeps only supplemental destinations not present on the Dock: Ca lâm sàng and Tiến độ.
- Theme, WebApp install, Android download, Giới thiệu and Lưu ý An toàn remain as utility actions.
- Supplemental navigation is presented as a compact two-card row to reduce menu height and visual repetition.

## Invariants
- `nah-abg-core.js` unchanged.
- Bottom Dock contract unchanged: Trang chủ · Phân tích · Học tập · Ôn luyện · Thêm.
- “Thêm” bottom sheet continues to expose secondary navigation and utility access.

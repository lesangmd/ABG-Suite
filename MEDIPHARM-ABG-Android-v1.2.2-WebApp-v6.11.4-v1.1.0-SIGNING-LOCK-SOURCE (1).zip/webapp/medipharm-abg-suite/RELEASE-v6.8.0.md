# MEDIPHARM ABG Suite v6.8.0 — Information Architecture Reset

- Parent: v6.7.4.
- Giữ nguyên lõi tính toán khí máu.
- Trang chủ rút gọn thành Hero + 4 hành động chính + Tiếp tục/Gợi ý.
- Điều hướng chính: Trang chủ · Phân tích · Ca lâm sàng · Học tập; mobile có thêm Thêm.
- Học tập nạp trực tiếp MEDIPHARM ABG Learning Canonical v1.0.1 từ `assets/data/learning/`.
- Bốn khu vực học tập: Từ điển · Chuyên đề · Hỏi đáp · Ôn luyện.
- 6 chuyên đề / 36 phần nội dung lớn; không còn 50 bài nhỏ nhúng trực tiếp trong HTML.
- Liên kết chéo Chuyên đề ↔ Từ điển ↔ Hỏi đáp ↔ Ôn luyện ↔ Ca lâm sàng.
- Việt hóa các cụm tiếng Anh còn sót; tiếng Anh chỉ giữ trong ngoặc khi hữu ích cho tra cứu.
- Ca lâm sàng lấy danh mục từ canonical và mở dữ liệu mẫu vào công cụ Phân tích.
- Tiến độ đọc chuyên đề lưu cục bộ trên thiết bị.

# MEDIPHARM ABG Suite v6.3.3 — Result Summary & Component Contrast Fix

Parent: v6.3.2 — Visual Refinement & Accent System.

## Mục tiêu
Corrective presentation release tập trung vào kết quả phân tích và độ tương phản component. Calculation core, clinical rules và corpus chuyên môn không thay đổi.

## Sửa lỗi chính
- Sửa regression v6.3.2 làm `Kết quả phân tích tổng hợp` dùng gradient sáng nhưng vẫn kế thừa chữ trắng từ theme summary cũ.
- Light mode dùng explicit dark-text contract; Dark mode có explicit light-text contract, không còn phụ thuộc cascade mơ hồ.
- Summary panel được phân lớp rõ: conclusion → explanation → reasoning → case context → core vitals.

## Component contrast
- Primary CTA có gradient đậm hơn và contrast chữ trắng ổn định.
- Ghost/secondary actions có border/text rõ hơn.
- `Sao chép kết luận` là primary action trong result actions; `Lưu mốc theo dõi` dùng secondary accent nhẹ.
- Result cards tăng surface separation, index badge và title hierarchy.
- Status badges có cả fill + border + text state để không phụ thuộc màu nền nhạt.
- Alert/reference surfaces được phân biệt rõ hơn ở cả Light/Dark.

## Responsive
- Mobile summary giảm padding, vitals 2 cột.
- Result actions xếp 1 cột để CTA đủ vùng chạm và không vỡ chữ.
- Result card giữ grid index + content và badge không bị ép hẹp.

## Không thay đổi
- `assets/js/nah-abg-core.js`.
- Clinical formulas/rules.
- Case bank, mixed-format bank, mock-test packs, assessment schema.
- Authentication/trial/Android bridge contracts.

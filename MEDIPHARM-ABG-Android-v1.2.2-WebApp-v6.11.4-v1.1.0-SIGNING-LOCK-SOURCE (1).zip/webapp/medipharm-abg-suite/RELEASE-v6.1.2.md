# MEDIPHARM ABG Suite v6.1.2 — Tablet Learning Card Layout Hotfix

Parent: v6.1.1 (`8cec055e67692605ef64d56ff8107be4baa87413f574556688c6df8b7278d51c`).

## Scope
- Sửa layout các card “Chọn cách bạn muốn học” trên tablet/mobile.
- Loại cột CTA hẹp gây bẻ chữ theo chiều dọc.
- Card dùng cấu trúc badge + tiêu đề, mô tả, CTA ở hàng riêng.
- Không thay nội dung, điều hướng, calculation core, trial gate, shared dark mode hoặc Search Dock.

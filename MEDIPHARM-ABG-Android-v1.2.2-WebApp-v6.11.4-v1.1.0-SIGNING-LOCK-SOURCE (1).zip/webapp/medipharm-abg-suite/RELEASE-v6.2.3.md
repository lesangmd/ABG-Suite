# MEDIPHARM ABG Suite v6.2.3

## Theory Experience, Mechanism Diagram & Accordion Layout Hotfix

Parent: **v6.2.2** (`d3fd4bb5ad1fb9127f9ed3774505c164bd21ad79ca3dba8cb732bb5ba6b575a6`)

### Thay đổi
- Đổi hero **Lý thuyết khí máu động mạch** từ nền nâu/vàng đậm sang hệ teal–slate dịu, nền gradient nhẹ và ưu tiên bề mặt trung tính.
- Chuẩn hóa hệ màu module: màu đậm chỉ dùng cho CTA/accent; card chỉ có tint nhẹ từ trái và phai nhanh về nền chính ở bên phải.
- Chuyển các phần mở đầu lớn của Lý thuyết sang accordion native để người học tới nội dung 50 bài sớm hơn.
- Thu gọn **Mục tiêu phần lý thuyết**, Bản đồ kiến thức, Nhìn nhanh, chuyên đề toan–kiềm, oxy hóa/thông khí, chất lượng mẫu và tích hợp bệnh cảnh.
- Sửa **Từ FiO₂ đến PaO₂, từ PaCO₂ đến thông khí phế nang**: desktop 5 node ngang; tablet 3+2 node; mobile một chuỗi dọc có connector rõ.
- Không thay đổi nội dung lâm sàng, calculation core, assessment corpus, trial policy hoặc generator runtime.

### Invariants
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`
- 220 câu đánh giá / 50 bài / 50 ca / 8 bộ thi thử.
- Route `/phan-tich-khi-mau-app/` và localStorage hiện hữu giữ nguyên.

# MEDIPHARM ABG Suite v6.7.1 — Dark Mode Harmonization Hotfix

## Scope
Corrective visual release only. No clinical calculation, content, access, route or authentication changes.

## Fixes
- Added explicit dark variants for every v6.7.0 mockup surface instead of allowing hard-coded light cards to override the theme.
- Dark Home now harmonizes Hero, action cards, sample cases, Q&A and dictionary surfaces.
- Dark Analysis now harmonizes the clinical header and progress rail with the form surface.
- Dark mobile dock now uses the same dark surface hierarchy and remains edge-anchored.
- Dark “Thêm” bottom sheet now uses readable dark surfaces, controls and labels.
- Search, account/menu controls and login dialog receive matching dark surfaces and contrast.

## Invariants
- `nah-abg-core.js` unchanged.
- No changes to formulas, case bank, assessment data, authentication, membership or localStorage contracts.

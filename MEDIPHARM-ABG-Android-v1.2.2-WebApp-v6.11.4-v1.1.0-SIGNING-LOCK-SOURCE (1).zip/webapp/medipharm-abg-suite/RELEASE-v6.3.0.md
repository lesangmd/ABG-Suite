# MEDIPHARM ABG Suite v6.3.0 — Clinical Workspace Redesign

Parent: v6.2.10.

## Clinical information architecture

- Opens directly in **Phân tích** instead of the historical dashboard.
- Reduces top-level navigation to five clinical workspaces: **Phân tích · Học tập · Ca lâm sàng · Ôn luyện · Tiến độ**.
- Moves **Hỏi & Đáp** and **Kiểm tra** under Học tập through a local sub-navigation layer.
- Keeps historical Home content in the codebase for compatibility but removes it from primary navigation.

## Visual system

- Replaces decorative card/gradient emphasis with flat clinical surfaces, restrained borders and compact spacing.
- Uses color primarily for state and hierarchy rather than decoration.
- Adds an analysis header that states purpose, privacy expectation and processing context.
- Converts the five-step analyzer to a denser clinical sequence with clearer input hierarchy.
- Uses tabular numerals for laboratory values and calculations.
- Mobile keeps a sticky analysis action area and a compact workspace selector.
- Dark mode receives the same clinical hierarchy rather than a simple color inversion.

## Regression contract

Presentation/IA only. `nah-abg-core.js`, clinical formulas/rules, case bank, mixed-format bank, mock-test packs and assessment schema remain byte-for-byte unchanged from v6.2.10.

Android v1.3.0 is intentionally **not** built from this release yet. The webapp must be accepted first; only then should a new offline SQLite snapshot be generated.

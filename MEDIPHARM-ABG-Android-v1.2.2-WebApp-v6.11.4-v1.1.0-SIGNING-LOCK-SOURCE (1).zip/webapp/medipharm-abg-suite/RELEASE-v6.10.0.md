# MEDIPHARM ABG Suite v6.10.0 — Clinical Context & Host Canvas Alignment

- Primary navigation now uses one label only: Trang chủ, Phân tích, Ca lâm sàng, Học tập.
- Rebuilds all 13 canonical clinical examples as complete cases: history, examination, preliminary diagnosis, investigations including ABG, self-analysis prompts, diagnostic reasoning, differential diagnosis, management/treatment direction and learning points.
- Clinical cases remain fully separate from the ABG analysis tool and use single-view navigation with a Back control.
- Detailed diagnostic reasoning is placed behind an explicit learner reveal so users can reason first.
- Increases case-reading typography and spacing.
- Reasserts the MEDIPHARM Theme/Super App unified fullscreen canvas contract and reserves the larger of `--med-host-right-rail-safe` / `--nah-sdp-safe-right` on desktop.
- Canonical Learning upgraded to v1.2.0.
- ABG calculation core and clinical calculation logic are unchanged.

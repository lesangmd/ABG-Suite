# MEDIPHARM ABG Suite v6.2.9 — Android Offline Authentication Bridge

- Adds a minimal Android-only authentication surface at `?medipharm_abg_android_auth=1`.
- Adds `admin-ajax.php?action=medipharm_abg_android_entitlement` for cookie-authenticated membership verification.
- Reuses the existing MEDIPHARM membership policy; does not create a parallel account system.
- Default offline entitlement window requested by Android is 90 days and can be overridden by the `medipharm_abg_android_entitlement_until` filter.
- No changes to ABG calculation engine, learning content, UI CSS, assessment banks, or browser trial behavior.

# MEDIPHARM ABG Suite v6.11.0 — Blood Gas Dictionary Data Expansion

- Parent: v6.10.6.
- Canonical Learning: v1.4.0.
- Nhập 300 thuật ngữ/công thức từ tài liệu đính kèm; tổng dữ liệu Từ điển Khí máu: 306.
- Hiển thị định nghĩa đầy đủ, thuật ngữ nguồn, phiên âm và nhóm nội dung.
- Công thức Office Math được bảo toàn cấu trúc khi chuyển sang JSON.
- Không thay đổi calculation core, ca lâm sàng, Hỏi đáp hoặc bố cục popup.

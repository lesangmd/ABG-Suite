# MEDIPHARM ABG Suite v6.11.1 — Clinical Case List & Android Download Hotfix

- Sửa 7 nhóm xử trí ca lâm sàng bị tách từng ký tự thành từng bullet, trong đó có mục “Đường thở” của ca hen cấp nặng.
- Bổ sung lớp phòng vệ tại renderer để chuỗi hoặc mảng ký tự không thể tạo danh sách từng chữ.
- WebApp tải Android trực tiếp từ kênh `android-v1-channel`, bản `MEDIPHARM-ABG-v1.1.0.apk`.
- Canonical Learning nâng lên v1.5.1; 25 ca lâm sàng và calculation core giữ nguyên về nội dung chuyên môn ngoài sửa cấu trúc danh sách.

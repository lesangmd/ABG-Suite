# MEDIPHARM ABG Suite v5.3 – Mixed-Format Assessment Engine

## Baseline

Built directly from **MEDIPHARM ABG Suite v5.2 – Case-Based Question Bank**.
Baseline ZIP SHA-256: `329f713a677f85f61c2ce10a89a65ca94a78d8e7971cd8717e8d5c9879a48de4`.

## Scope

- Preserve all **180** v5.2 single-best-answer questions byte-for-byte.
- Add **40** production mixed-format items, raising the canonical assessment corpus to **220 items**.
- Add five new formats: multiple-response, ordering, matching, numeric calculation, and structured case interpretation.
- Add **Hỗn hợp · 20 câu**: one item of each new format in each of four domains.
- Preserve existing quick/standard/advanced/case blueprints as single-best-answer workflows.
- Add responsive and Dark-mode rendering for all new controls and review states.

## Scoring rules

- Multiple-response: exact set.
- Ordering: exact order.
- Matching: all pairs exact.
- Numeric calculation: absolute tolerance defined by the item.
- Structured case interpretation: all fields exact.
- No partial credit in v5.3.

## Compatibility

- Calculation core unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- Existing localStorage key/schema remains in place; no migration.
- No new network learning requests.
- Route remains `/phan-tich-khi-mau-app/`.
- Super App, Theme and Search Dock are unchanged.

## QA

- PHP lint: 2/2 PASS.
- JavaScript syntax: 2/2 PASS.
- Static/regression: 57 PASS / 1 UI smoke SKIP / 0 FAIL.
- CSS braces: 1886/1886 main; 20/20 launcher.
- Mixed-format gate: PASS.
- Numeric formula checks: 8/8 PASS.
- Structured formula spot checks: 4/4 PASS.
- Duplicate IDs/exact duplicate mixed stems: none.
- Maximum mixed-item token Jaccard: **0.5909**, below 0.80 gate.

## Roadmap boundary

v5.3 provides the mixed-format engine and production corpus. Timed simulations, flag/review exam workflow and curated mock-test packs remain reserved for **v5.4 – Mock Test Packs & Timed Simulation**.

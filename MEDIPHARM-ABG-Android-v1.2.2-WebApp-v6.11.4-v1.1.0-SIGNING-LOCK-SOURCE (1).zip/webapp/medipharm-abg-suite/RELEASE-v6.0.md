# MEDIPHARM ABG Suite v6.0 — Integrated ABG Learning & Assessment Platform

**Parent:** v5.9 — Content Governance & Production Audit  
**Parent SHA-256:** `a41c8dd8e123fac49d86556aa7848a42260551713f1840cb6ff7c19f562e0312`  
**Policy:** integration-only over the v5.9 frozen corpus.

## Platform scope
- 220 validated assessment items, unchanged from the frozen v5.9 corpus.
- 50 handbook lessons.
- 50 clinical cases.
- 8 deterministic mock-test packs.
- 6 assessment formats.
- Blueprint-driven generator, timed simulation, remediation and longitudinal intelligence preserved.

## v6.0 integration
- Adds **Phiên học tích hợp** as the default learning entry point.
- Five linked steps: Học trọng tâm → Ôn thẻ → Luyện thích ứng → Áp dụng ca → Đánh giá.
- Recommendation reuses existing local learning metrics and due-review queues.
- Direct shortcut to the exam generator remains available.
- Generator-facing copy is normalized to Vietnamese (`mã đề`, `sinh đề theo cấu trúc`) while internal deterministic seed mechanics remain unchanged.

## Locked invariants
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- localStorage key remains `medipharm_abg_learning_v30`.
- Trial gate remains 10 guest uses.
- Canonical app route remains `/phan-tich-khi-mau-app/`.
- No network analytics, polling or new background requests.
- v5.9 corpus governance freeze is preserved; v6.0 does not alter assessment content.

## Acceptance
Release candidate only until WordPress/runtime smoke testing passes on production/staging.

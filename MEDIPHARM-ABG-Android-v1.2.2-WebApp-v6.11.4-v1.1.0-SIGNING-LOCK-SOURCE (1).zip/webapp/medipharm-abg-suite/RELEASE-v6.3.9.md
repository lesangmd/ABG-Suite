# MEDIPHARM ABG Suite v6.3.9 — Mobile Layout & Minimal Login Corrective

- Fixes mobile/foldable module-card overlap with explicit grid placement.
- Rebuilds the analysis progress rail as a five-column responsive grid with no horizontal overflow.
- Adds a universal in-app `[hidden]` guard so hidden analysis actions cannot be forced visible by button display rules.
- Replaces nested Membership provider markup inside the ABG modal with a compact two-field ABG login form. Authentication still uses WordPress sign-on and the existing MEDIPHARM membership entitlement policy before access is granted.
- Removes duplicate provider title, save-login checkbox, browser-password note and duplicate registration CTA from the ABG login modal.
- Keeps calculation core, corpus, trial policy, route, localStorage and Android package unchanged.

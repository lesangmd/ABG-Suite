# MEDIPHARM ABG Suite v6.4.1 — Mobile Geometry & More Navigation Corrective

## Mục tiêu
Sửa dứt điểm hiện tượng icon đè tiêu đề/mô tả trên Trang chủ mobile/foldable và làm nút **Thêm** ở bottom navigation hoạt động độc lập, không phụ thuộc vào việc mô phỏng click của Menu header.

## Điều chỉnh
- Phone <=560 px: các module dùng một hàng ngang cố định `icon | nội dung | mũi tên`; không còn chồng lớp giữa icon, tiêu đề và mô tả.
- Foldable/tablet 561–900 px: 2 cột, nhưng từng card vẫn dùng geometry 3 cột an toàn.
- Nút **Thêm** mở bottom sheet riêng gồm: Ca lâm sàng, Tiến độ, Tài khoản và Trình đơn.
- Bottom sheet hỗ trợ đóng bằng backdrop, nút × và phím Escape.
- Giữ nguyên hero, header/search, đăng nhập tối giản và ABG core của v6.4.0.

## Scope
Không thay đổi công thức, dữ liệu chuyên môn hoặc `nah-abg-core.js`.

# MEDIPHARM ABG Suite v6.3.2 — Visual Refinement & Accent System

Parent: v6.3.1 — Responsive & Dark Mode Harmonization.

## Phạm vi
Bản này chỉ tinh chỉnh presentation layer. Calculation core, clinical rules và corpus chuyên môn không thay đổi.

## Hệ visual mới
- Primary accent: teal–aqua.
- Secondary accent: indigo nhẹ.
- Educational/warning accent: amber có kiểm soát.
- Gradient chỉ dùng ở CTA chính, trạng thái active và một số featured surfaces.
- Content cards và form nhập liệu vẫn ưu tiên nền phẳng, border rõ và tương phản đọc tốt.

## Thành phần được refine
- App header, logo, Search Dock và menu.
- Main workspace navigation và clinical header.
- Analysis stepper, section badge, form controls và segmented controls.
- Primary/secondary CTA states.
- Featured cards: result summary, theory overview, handbook hero, case intro, assessment intro.
- Learning cards, Q&A groups, case cards và assessment surfaces.
- Dark-mode accent/elevation hierarchy tương ứng.

## Không thay đổi
- `assets/js/nah-abg-core.js`.
- Clinical formulas/rules.
- Case bank, mixed-format bank, mock-test packs, assessment schema.
- Trial/access policy, Android auth bridge, route và localStorage contract.

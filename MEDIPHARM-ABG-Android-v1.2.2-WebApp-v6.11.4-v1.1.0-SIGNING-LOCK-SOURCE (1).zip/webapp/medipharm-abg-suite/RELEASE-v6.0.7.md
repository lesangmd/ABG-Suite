# MEDIPHARM ABG Suite v6.0.7 — Shared Dark-Mode Ownership Hotfix

- Parent: v6.0.6.
- Fixes two-way dark-mode synchronization with SachYHoc/YHocLamSang Super App + Theme.
- ABG no longer sends the private `medipharm:theme-toggle-request` event.
- When `[data-syh-theme-toggle]` exists, ABG invokes that canonical host control, allowing the host to update classes, persistence and all website surfaces together.
- ABG listens to `nah-sdp:theme-change` and mirrors host state immediately.
- `nah_abg_theme` is retained only as standalone fallback when no canonical host theme owner is present.
- Calculation core and clinical/learning corpus are unchanged.

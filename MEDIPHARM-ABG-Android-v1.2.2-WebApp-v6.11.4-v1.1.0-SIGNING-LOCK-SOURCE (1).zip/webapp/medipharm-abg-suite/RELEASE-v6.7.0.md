# MEDIPHARM ABG Suite v6.7.0 — Mockup-Aligned Clinical UI

## Scope
Visual/UI release only. Clinical calculation core and learning datasets remain unchanged.

## Home
- Rebuilt Home hierarchy to match the approved mockup: clinical hero, five primary cards, sample cases, quick Q&A and dictionary learning.
- Removed recent-activity clutter from the primary Home hierarchy.
- Increased title, card-title and description typography for mobile and foldable readability.
- Added richer card surfaces, medical gradients, biomarker orbs and an abstract lung illustration.
- Sample cases are visual cards rather than flat rows.

## Responsive
- Desktop: five primary cards in one row, three case cards, three Q&A cards and three-column dictionary.
- Tablet/foldable: adaptive 3+2 action layout and two-column dictionary.
- Mobile: 2+2+1 action layout, horizontally scrollable sample-case cards, single-column Q&A and dictionary.
- Mobile dock is anchored to the bottom edge with safe-area padding only.

## Analysis and login
- Stronger typography and spacing in the ABG analysis header and progress rail.
- Login typography and surfaces harmonized with the approved mockup.

## Invariants
- No changes to `nah-abg-core.js`.
- No change to calculation formulas, assessment banks, case datasets, authentication contracts or access rules.

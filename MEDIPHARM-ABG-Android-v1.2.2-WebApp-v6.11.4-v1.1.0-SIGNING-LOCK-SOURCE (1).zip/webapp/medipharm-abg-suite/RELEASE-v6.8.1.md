# MEDIPHARM ABG Suite v6.8.1 — Escaped Indentation Rendering Hotfix

Parent: v6.8.0.

## Corrective scope
- Removes literal `\t` strings accidentally written into the v6.8.0 PHP/HTML template.
- Restores normal responsive layout for Hero, primary navigation, canonical learning workspace and mobile Dock.
- Canonical Learning content remains v1.0.1.
- Clinical calculation core is unchanged.

## Root cause
The v6.8.0 build generator used raw Python strings containing `\t` for indentation. Those characters were emitted as visible text nodes in HTML rather than whitespace. In CSS Grid/Flex containers, they also became layout items and displaced Dock/navigation buttons.

## Regression gate
The release fails QA if `class-medipharm-abg-suite-module.php` contains any literal backslash-tab sequence.

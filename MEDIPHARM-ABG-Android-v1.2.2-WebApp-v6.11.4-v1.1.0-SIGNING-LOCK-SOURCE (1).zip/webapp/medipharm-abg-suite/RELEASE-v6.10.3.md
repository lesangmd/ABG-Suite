# MEDIPHARM ABG Suite v6.10.3 — Desktop Learning Master–Detail Navigation

- Desktop Học tập chuyển sang bố cục master–detail: rail module dọc bên trái, cửa sổ nội dung bên phải.
- Thứ tự module: Chuyên đề → Từ điển → Hỏi đáp → Ôn luyện.
- Chuyên đề gần nhất (hoặc Chuyên đề 01) mở mặc định trong cửa sổ nội dung trên desktop.
- Chi tiết có nút “Quay lại danh sách”.
- Mobile/tablet giữ điều hướng ngang hiện hành.
- Không thay đổi canonical content, ca lâm sàng hay thuật toán khí máu.

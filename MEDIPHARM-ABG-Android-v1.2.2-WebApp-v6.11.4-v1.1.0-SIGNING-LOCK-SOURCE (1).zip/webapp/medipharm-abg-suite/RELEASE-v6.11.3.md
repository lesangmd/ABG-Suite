# MEDIPHARM ABG Suite v6.11.3 — Unified Review & Responsive Reader Hotfix

- Parent: v6.11.2.
- Học tập: bỏ tab **Hỏi đáp** độc lập; toàn bộ 38 câu hỏi được hợp nhất vào **Ôn luyện** theo 6 chuyên đề.
- Ôn luyện: câu hỏi dùng accordion nội tuyến; đáp án, giải thích, ý nghĩa lâm sàng và liên kết chuyên đề hiển thị ngay tại chỗ, không mở popup.
- Từ điển: mỗi mục từ hiển thị đầy đủ định nghĩa, thuật ngữ nguồn, phiên âm và bí danh khi có; không mở popup khi chọn mục từ.
- Điều hướng tương thích: các deep-link/route cũ tới `qa` được chuyển sang `review`.
- Popup còn lại (Chuyên đề/Ca lâm sàng): giới hạn theo `100dvh`, tránh overflow ngang, hỗ trợ safe-area, tablet/mobile/foldable và header co giãn.
- Không thay calculation core, corpus chuyên môn, authentication/entitlement hoặc Android release channel.

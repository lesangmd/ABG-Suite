# MEDIPHARM ABG Suite v6.2.2 — Unified Content Width & Mobile Wrapper Flattening Hotfix

## Parent
- Exact parent: MEDIPHARM-ABG-Suite-v6.2.1.zip
- Scope: responsive presentation only.

## Fixed
- All top-level workspaces now use one 100% content-width contract inside the available workspace column.
- Removed legacy centered/max-width caps that made Review, Profile, Exam and handbook content appear narrower than Home/Analysis.
- Tablet workspace panels no longer add a second horizontal outer padding layer.
- Mobile treats the ABG root/workspace shells as a viewport canvas instead of nested cards.
- Mobile removes redundant outer borders, radii, shadows and horizontal wrapper padding, while retaining one 8px safe content gutter.

## Preserved
- 220 assessment items; 50 handbook lessons; 50 clinical cases; 8 mock-test packs.
- Trial policy, shared dark mode, Search Dock layering, route and localStorage.
- Calculation core unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

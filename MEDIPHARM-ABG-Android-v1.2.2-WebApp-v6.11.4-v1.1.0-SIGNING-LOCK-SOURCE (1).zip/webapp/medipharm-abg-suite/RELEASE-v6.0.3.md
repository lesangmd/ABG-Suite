# MEDIPHARM ABG Suite v6.0.3 — Trial Gate Navigation & Action-Level Access Hotfix

**Parent release:** v6.0.2 — Access Gate & Search Dock Layering Hotfix  
**Parent SHA-256:** `d8e73942836dcf1f1c96ffbf293d80ed88bb3ee59732b11b6ca659c178f7ef38`

## Mục tiêu

Sửa hành vi trial gate sau khi khách đã dùng đủ 10 lượt: URL `/phan-tich-khi-mau-app/` phải luôn mở được WebApp; quota chỉ được kiểm tra/tiêu hao khi người dùng thực sự chạy một hành động có tính sử dụng công cụ.

## Thay đổi

- Không còn chặn toàn route khi quota = 0.
- Mở/reload `/phan-tich-khi-mau-app/` không tiêu hao lượt dùng thử.
- Ba hành động được bảo vệ và tiêu hao quota:
  1. Chạy **Phân tích khí máu**.
  2. Bắt đầu **Bài đánh giá / Thi thử / Sinh đề**.
  3. Bắt đầu **Phiên ôn thích ứng**.
- Lượt thứ 10 vẫn được phép hoàn tất; từ hành động thứ 11 mới hiện gate.
- Gate hiển thị ngay trên nền WebApp và có thể đóng để tiếp tục xem giao diện/nội dung.
- Thông báo: **“Đã hết số lượt dùng thử. Vui lòng đăng nhập hoặc đăng ký tài khoản để truy cập đầy đủ.”**
- **Đăng nhập** mở form hiện có của Membership / Clinical Access trong overlay.
- Form đăng nhập được tải lười chỉ sau click; không render sẵn trên mọi lần mở WebApp.
- **Đăng ký** dẫn trực tiếp tới `/dangky`.
- Footer tách rõ link/nút Đăng ký và Đăng nhập.
- `?access=member` được giữ tương thích nhưng chỉ mở overlay đăng nhập, không thay toàn bộ WebApp.

## Giữ nguyên

- Calculation core.
- 220 câu canonical.
- 50 bài Sổ tay.
- 50 ca lâm sàng.
- 8 bộ thi thử.
- 6 dạng câu hỏi.
- Blueprint Exam Generator.
- Error Pattern & Targeted Remediation.
- Longitudinal Assessment Intelligence.
- Integrated Learning Session.
- localStorage `medipharm_abg_learning_v30`.
- Route `/phan-tich-khi-mau-app/`.
- Giới hạn 10 lượt.
- Search Dock layering fix của v6.0.2.

## Runtime / hiệu năng

- Không polling.
- Không request nền định kỳ.
- Có đúng một primitive `fetch()` dùng chung cho các request do người dùng chủ động kích hoạt:
  - xác nhận/tiêu hao lượt dùng thử;
  - tải form đăng nhập theo yêu cầu.
- Không tải form Membership/Clinical Access nếu người dùng không bấm Đăng nhập.

## QA

- PHP lint: 2/2 PASS.
- JavaScript syntax: PASS.
- Node regression/static: 68 PASS / 1 UI smoke SKIP / 0 FAIL.
- CSS brace integrity: main 2275/2275; launcher 46/46.
- `XMLHttpRequest`: 0.
- Calculation core SHA-256 unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

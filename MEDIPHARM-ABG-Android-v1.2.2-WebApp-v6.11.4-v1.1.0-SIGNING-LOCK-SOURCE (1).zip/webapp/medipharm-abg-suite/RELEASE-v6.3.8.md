# MEDIPHARM ABG Suite v6.3.8 — WebApp Home Link & Foldable Responsive Hotfix

- Logo O₂/CO₂ – ABG now targets `/phan-tich-khi-mau-app/`; JavaScript intercepts normal taps to return to the WebApp Home workspace without leaving the app.
- Corrects the previous `home_url('/')` fallback that redirected the logo to the website homepage.
- Adds coarse-pointer/foldable breakpoints up to 1366 CSS px, so unfolded devices do not inherit a cramped desktop navigation layout.
- Phones and foldable portrait use Logo + Account + Menu on the first row and a full-width search field below.
- Foldable/tablet layouts use 2–3 module columns and progressively collapse Hero / quick-analysis areas instead of squeezing five desktop cards.
- Mobile menu/account popovers use viewport-safe fixed positioning and dynamic viewport height.
- Adds container-query fallbacks for embedded/app-shell contexts.
- Calculation core, clinical formulas, corpus, trial policy, localStorage schema and Android package are unchanged.

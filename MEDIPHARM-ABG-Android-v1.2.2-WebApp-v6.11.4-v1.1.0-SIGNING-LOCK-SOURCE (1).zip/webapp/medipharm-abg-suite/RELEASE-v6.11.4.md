# MEDIPHARM ABG Suite v6.11.4

## Compact Dock & Unified Header Menu

- Parent: v6.11.3.
- Mobile/tablet/foldable Dock reduced from 5 to 4 destinations: Trang chủ, Phân tích, Ca lâm sàng, Học tập.
- Removed the duplicate “Thêm” Dock destination and its More sheet.
- Added “Kiểm tra cập nhật” to the existing header Menu for Web/WebApp; Android retains the existing native update action.
- “Giới thiệu” remains in the same header Menu, so update/about are available from one canonical menu.
- Clinical calculation core and content corpus are unchanged.

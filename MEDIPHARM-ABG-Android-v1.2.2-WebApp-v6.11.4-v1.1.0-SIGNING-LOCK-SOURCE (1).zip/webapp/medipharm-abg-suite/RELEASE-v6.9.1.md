# MEDIPHARM ABG Suite v6.9.1 — Analysis Workspace Simplification

- Simplifies only the Phân tích khí máu workspace.
- Keeps calculation core, clinical algorithms, canonical learning content and access logic unchanged.
- Uses progressive disclosure for advanced settings, optional blood-gas parameters, etiologic tests and advanced respiratory-support data.
- Removes the visible legacy demo loader from the analysis workflow; clinical examples remain in the dedicated Ca lâm sàng workspace.
- Enlarges analysis typography and input controls.
- Reduces nested card chrome and keeps one dominant clinical input surface.
- Keeps the 5-step workflow and existing validation/analysis behavior.
- Improves mobile/foldable layout and sticky action navigation.

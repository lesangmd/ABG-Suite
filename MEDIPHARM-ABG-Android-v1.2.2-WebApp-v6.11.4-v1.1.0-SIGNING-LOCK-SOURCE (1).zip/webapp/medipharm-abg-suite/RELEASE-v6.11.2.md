# MEDIPHARM ABG Suite v6.11.2 — Mockup Background Graphics Alignment

- Parent: v6.11.1.
- Scope: visual-only alignment for Home Hero and Login background artwork.
- Hero: pale clinical blue scene, lung motif, red/cyan/blue wave bands, foreground ABG brand mark.
- Login: full-screen mockup-style red/cyan/blue wave backdrop with top-right blue accent; white raised login card.
- No changes to calculation core, clinical content, learning corpus, trial entitlement, Android channel, navigation, or authentication logic.

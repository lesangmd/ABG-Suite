# MEDIPHARM ABG Suite v5.2 – Case-Based Question Bank

Baseline: v5.1 – Assessment Bank Expansion I
Baseline ZIP SHA-256: `7d09bb6b633b41a3608cef845673ecad7c2c8146eac622b7143bfdc9718caf26`

## Scope
- Append 60 case-linked single-best-answer questions: 20 cases × 3 questions.
- Expand canonical assessment bank from 120 to 180 questions.
- Preserve all 120 v5.1 questions.
- Add 8 serial-ABG cases (24 linked questions) and progressive-disclosure-ready metadata.
- Keep 45 questions in each domain after expansion.
- Add a case-only 20-question selection blueprint without changing scoring semantics.
- Add responsive Light/Dark case-context presentation.

## Locked invariants
- Calculation core SHA-256 remains `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- localStorage key/schema remains unchanged.
- Existing quick/standard/advanced assessment blueprints remain available.
- No runtime API/AJAX/fetch/background learning requests.
- Route `/phan-tich-khi-mau-app/`, Super App, Theme and Search Dock remain unchanged.

## Deferred by roadmap
- Multiple response, ordering, matching, numeric response and structured case-response formats remain v5.3 work.
- Curated timed mock-test packs remain v5.4.
- Blueprint-driven exam generator remains v5.5.

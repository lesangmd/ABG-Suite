# MEDIPHARM ABG Suite v6.7.4 — Dock Navigation & Title Deduplication Hotfix

- Fixes mobile bottom dock navigation for Trang chủ, Phân tích, Học tập and Ôn luyện using a delegated router that remains valid after responsive DOM/runtime changes.
- Keeps Thêm behavior unchanged.
- Removes duplicated hero kicker and duplicated analysis heading kicker.
- Preserves ABG calculation core byte-for-byte.

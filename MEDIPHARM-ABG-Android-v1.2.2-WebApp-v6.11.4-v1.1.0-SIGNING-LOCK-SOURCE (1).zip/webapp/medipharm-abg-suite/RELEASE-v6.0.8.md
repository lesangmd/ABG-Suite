# MEDIPHARM ABG Suite v6.0.9 — Tablet Dark Wrapper & Mobile Density Hotfix

- Parent: v6.0.7.
- Tablet 701–1024 px: edge-to-edge ABG shell in dark mode, removing light outer gutters.
- Mobile ≤700 px: flatter information hierarchy, less nested padding, larger key body text.
- Shared dark-mode ownership from v6.0.7 retained.
- Calculation core and all clinical/learning data unchanged.

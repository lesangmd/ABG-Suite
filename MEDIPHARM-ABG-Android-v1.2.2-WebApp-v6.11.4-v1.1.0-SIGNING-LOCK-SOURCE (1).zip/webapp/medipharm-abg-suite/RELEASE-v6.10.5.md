# MEDIPHARM ABG Suite v6.10.5 — Viewport-Adaptive Content Modal

## Scope
- Detail views for Clinical Cases, Topics/Lessons, Q&A, Review answers and Dictionary terms now open in a fixed viewport-adaptive modal.
- The underlying page no longer scrolls to detail content.
- A persistent top bar provides Back to list and Close actions.
- The modal reserves the live NAH Search Dock Pro right-rail safe area on desktop.
- Tablet uses an inset modal; mobile uses a full-screen reading surface.
- Long content scrolls only inside the reading pane, so the pointer can remain in the same viewport area.
- No calculation-core or canonical learning-content changes.

# MEDIPHARM ABG Suite v6.2.6

Android Download Menu Integration. Additive-only update from v6.2.5.

- Adds **Tải ứng dụng Android** to the application menu.
- Direct download target: `MEDIPHARM-ABG-v1.0.0.apk` on `lesangmd/ABG-Suite` GitHub main branch.
- Centralizes the APK URL behind `medipharm_abg_suite_android_apk_url` filter for future release changes.
- Suppresses the Android download item when the app is already running inside the native Android shell (`MEDIPHARMABGAndroid/*`).
- Calculation core, assessment content, lessons, cases, access logic, CSS and JavaScript are unchanged.

# MEDIPHARM ABG Suite v6.10.2 — Clinical Case Runtime Render Hotfix

Corrective release branched from v6.10.1.

## Fixed
- Restores opening of all 13 canonical clinical-case cards.
- Root cause: `saveProgress()` called `renderProgress()` without a root argument. The resulting JavaScript exception occurred inside `showCase()` before the detail HTML was rendered.
- Progress refresh now iterates over every active ABG root and passes each root explicitly.

## Preserved
- Clinical-case content v1.2.0 unchanged.
- Learning 2×2 desktop layout unchanged.
- Progress remains removed from Menu / Thêm.
- ABG calculation core unchanged.

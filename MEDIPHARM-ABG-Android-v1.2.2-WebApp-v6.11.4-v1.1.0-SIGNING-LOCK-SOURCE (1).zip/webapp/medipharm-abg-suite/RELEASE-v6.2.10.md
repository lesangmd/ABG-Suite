# MEDIPHARM ABG Suite v6.2.10

- Adds native Android credential authentication endpoint `admin-ajax.php?action=medipharm_abg_android_login`.
- Android sends credentials only over HTTPS; the app never stores the password.
- Successful authentication returns the 90-day offline entitlement payload directly, so Android no longer loads the website theme or account page.
- Existing WebApp, ABG calculation engine, trial policy and learning content are unchanged.

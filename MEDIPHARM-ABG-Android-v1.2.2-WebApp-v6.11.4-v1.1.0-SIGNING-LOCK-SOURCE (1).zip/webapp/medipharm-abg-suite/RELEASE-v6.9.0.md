# MEDIPHARM ABG Suite v6.9.0 — Single View Learning & Clinical Case Reset

- Single-view navigation for Chuyên đề, Từ điển, Hỏi đáp, Ôn luyện and Ca lâm sàng; detail opens in current view with Quay lại.
- 38 Hỏi đáp expanded with explanation and clinical application.
- 13 clinical cases separated from the analysis tool and expanded with history, examination, investigations, ABG, reasoning, conclusion and learning points.
- Typography raised across learning/case surfaces; no micro-font metadata in primary reading surfaces.
- Clinical calculator core unchanged.

# MEDIPHARM ABG Suite v6.4.0 — Mockup-Aligned Clinical Home Rebuild

## Mục tiêu
Tái cấu trúc Trang chủ WebApp theo ngôn ngữ thiết kế của mockup ABG đã duyệt, ưu tiên hierarchy lâm sàng, đồ họa nhẹ, tính nhất quán giữa Desktop, mobile và thiết bị gập.

## Thay đổi giao diện
- Header: logo ABG + wordmark, search một lớp, Tài khoản, Menu.
- Desktop navigation: 6 module theo một hàng, active state có dải màu đỏ–xanh–cyan.
- Hero: nền xanh nhạt, đồ họa phổi + logo O₂/CO₂, wave đỏ/xanh, một CTA chính.
- Module cards: 5 cards compact trên Desktop; 2 cột trên mobile/foldable portrait; Tiến độ full-width trên phone.
- Desktop: Nhập nhanh khí máu + Hoạt động gần đây ngay dưới modules.
- Mobile: thay quick-form bằng Tài liệu nhanh và bottom navigation cố định.
- Footer mobile ẩn để tránh cạnh tranh với bottom navigation.

## Đăng nhập
- Form đăng nhập được render trực tiếp trong WebApp; bỏ AJAX lazy-load để tránh cache/stale Membership form.
- Chỉ còn: Tên đăng nhập hoặc email, Mật khẩu, Hiện/Ẩn, Đăng nhập, Quên mật khẩu, Đăng ký tài khoản.
- Mobile hiển thị full-screen login surface; desktop dùng centered modal.

## Responsive
- Không dùng pointer:coarse để ép thiết bị gập vào layout phone.
- Layout dựa vào bề rộng thật của viewport/container:
  - >1080: Desktop.
  - 521–820: foldable/tablet compact, 2 cột + bottom dock.
  - <=520: phone, 2 cột compact + bottom dock.
- Analysis wizard giữ 5 bước vừa chiều rộng phone.

## Theme
- WebApp mặc định Light, không tự kế thừa dark mode từ website hoặc hệ điều hành.
- Theme toggle của ABG vẫn cho phép người dùng chủ động bật Dark.

## Scope
Không thay đổi `nah-abg-core.js`, công thức, dữ liệu chuyên môn hoặc logic xác thực quyền thành viên.

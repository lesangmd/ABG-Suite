# MEDIPHARM ABG Suite v5.4 – Mock Test Packs & Timed Simulation

Baseline: **v5.3 – Mixed-Format Assessment Engine**  
Baseline SHA-256: `bc65c277a8459efee8915f4127fff0792081ad41ce6f73203d41a7f4dee3eb79`

## Mục tiêu release

v5.4 triển khai tầng thi thử trên chính ngân hàng 220 câu đã khóa ở v5.3. Không thêm hoặc sửa nội dung câu hỏi; thay đổi nằm ở blueprint thi thử, timer, điều hướng và phân tích sau thi.

## Sáu bộ thi thử

1. **Nền tảng — 30 câu / 35 phút**: 10 cơ bản + 10 trung bình + 10 nâng cao.
2. **Toan–kiềm — 30 câu / 40 phút**: 10 cơ bản + 10 trung bình + 10 nâng cao.
3. **Oxy hóa/Thông khí — 30 câu / 40 phút**: 10 cơ bản + 10 trung bình + 10 nâng cao.
4. **Ca lâm sàng — 30 câu / 45 phút**: chỉ câu gắn ca; 8 cơ bản + 11 trung bình + 11 nâng cao.
5. **Suy luận nâng cao — 30 câu / 45 phút**: toàn bộ câu mức nâng cao; cân bằng 7/8/8/7 theo bốn miền.
6. **Tổng hợp — 30 câu / 45 phút**: 7/8/8/7 theo miền và 8/12/10 theo độ khó.

Mỗi pack có seed cố định trong v5.4 để cùng một pack có thành phần câu ổn định.

## Timed Simulation

- Chọn **Bấm giờ** hoặc **Không bấm giờ**.
- Các blueprint luyện tập cũ mặc định vẫn không bấm giờ.
- Khi chọn pack thi thử, giao diện mặc định chuyển sang bấm giờ nếu người dùng chưa tự chọn chế độ thời gian.
- Đồng hồ hiển thị liên tục trong khi làm bài.
- Khi hết giờ, bài được tự nộp; câu chưa hoàn tất được tính là chưa trả lời.
- Có thể đánh dấu câu, nhảy trực tiếp bằng navigator và nộp bài từ bất kỳ câu nào.

## Phân tích sau thi

Lưu thêm trong lịch sử assessment hiện có: pack/blueprint, timed/untimed, giới hạn thời gian, thời gian đã dùng, lý do kết thúc và số câu chưa hoàn tất. Không tạo storage key mới.

## Invariants

- Canonical bank: **220 câu**, không đổi.
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- Không thêm fetch/XHR/AJAX/background request.
- Route `/phan-tich-khi-mau-app/` không đổi.
- Super App, Theme và Search Dock không đổi.

## QA

PHP 2/2 PASS; JavaScript 2/2 PASS; CSS 1897/1897 + launcher 20/20; static/regression **58 PASS / 1 SKIP UI smoke / 0 FAIL**; v5.4 mock-pack/timer gate PASS.

# MEDIPHARM ABG Suite v5.5 — Blueprint-Driven Exam Generator & Experience Redesign

Baseline: exact MEDIPHARM ABG Suite v5.4 package SHA-256 `d1ff0153888c8687fa1e83ffbbf6b3fb83379399418712a4c41ee36c096f5e22`.

## 1. Blueprint-Driven Exam Generator
- Sinh đề 20/30/40 câu từ ngân hàng canonical 220 câu.
- Preset theo miền kiến thức, độ khó và dạng câu; quota số nguyên được phân bổ có kiểm soát.
- Seed xác định: cùng seed + cùng blueprint tạo lại cùng cấu trúc câu và thứ tự lựa chọn trong corpus v5.5.
- Anti-repeat tránh mạnh các câu đã xuất hiện trong ba lần sinh đề gần nhất; chỉ nới điều kiện khi pool không đủ.
- Giữ nguyên scoring của v5.3/v5.4; chưa dùng partial credit.

## 2. Experience redesign
- Trang chính ABG chuyển sang mosaic bất đối xứng; Phân tích, Học tập, Sổ tay, Kiểm tra và Sinh đề có màu, kích thước và trọng tâm khác nhau.
- Không dùng một kiểu card đồng nhất cho mọi công cụ.
- Launcher được viết lại thành module nhẹ có thử thách khí máu 20 giây, lối vào học/thi và tạo seed.

## 3. Guest trial / member gate
- Khách được tối đa 10 lượt mở đầy đủ ABG Suite trên trình duyệt.
- Launcher ở Trang chủ không tiêu lượt.
- Từ lượt thứ 11, app hiển thị form do plugin thành viên hiện hành sở hữu: `[syh_login]` trên SachYHoc hoặc `[yhls_login]` trên YHocLamSang.
- Nếu Super App host hiện diện, ABG dùng chính `is_active_member()` của host để bảo toàn quy tắc hết hạn/legacy account của Membership/Clinical Access.
- Counter là cookie first-party ký HMAC; không thêm bảng DB, AJAX, polling hay request nền. Đây là giới hạn dùng thử cục bộ theo trình duyệt, không phải entitlement chống reset đa thiết bị.

## 4. Locked invariants
- 220 câu canonical giữ nguyên nội dung.
- Calculation core SHA-256 `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.
- localStorage learning schema/key và route `/phan-tich-khi-mau-app/` không đổi.
- Super App/Theme/Search Dock không bị ABG Suite chiếm ownership.

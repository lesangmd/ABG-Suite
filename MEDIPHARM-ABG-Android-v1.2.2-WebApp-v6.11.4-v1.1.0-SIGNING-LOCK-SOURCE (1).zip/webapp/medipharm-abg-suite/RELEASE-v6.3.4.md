# MEDIPHARM ABG Suite v6.3.4 — O2/CO2 Brand System

- Parent: v6.3.3 Result Summary Component Contrast Fix.
- Branding-only visual patch; clinical algorithms, question banks and access logic unchanged.
- Canonical logo: O2/CO2 exchange symbol + ABG wordmark supplied/approved in the project conversation.
- Replaced WebApp/PWA icons at 192/512/1024 px and header brand mark.
- Unified visual palette across light/dark UI: arterial red, oxygenation blue, cyan exchange accent.
- Preserved white safe-zone and rounded-square app-icon geometry for launcher masks/cropping.
- Android companion target: v1.2.2 branding patch on the current v1.2.1 source baseline.

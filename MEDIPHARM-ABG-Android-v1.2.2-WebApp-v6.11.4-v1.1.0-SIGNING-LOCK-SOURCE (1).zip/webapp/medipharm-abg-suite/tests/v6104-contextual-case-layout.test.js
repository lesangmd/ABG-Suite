const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const cases=JSON.parse(fs.readFileSync(path.join(root,'assets/data/learning/cases.json'),'utf8'));
if(cases.length!==13)throw new Error('expected 13 cases');
for(const c of cases){
 for(const k of ['patient_profile','chief_complaint_vi','history_of_present_illness_vi','past_history','medications','vital_signs','physical_examination','investigations','abg','learning_questions']) if(!c[k]||!c[k].length&&Array.isArray(c[k])) throw new Error(c.id+' missing '+k);
 if(c.history_of_present_illness_vi.length<220)throw new Error(c.id+' HPI too short');
 if(c.learning_questions.length<2)throw new Error(c.id+' insufficient questions');
 c.learning_questions.forEach(q=>{if(!q.question_vi||!q.answer_vi||!q.discussion_vi)throw new Error(c.id+' incomplete QA')});
}
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-canonical-learning.js'),'utf8');
for(const token of ['Lý do vào viện','Bệnh sử hiện tại','Tiền sử','Thuốc đang dùng','Dấu hiệu sinh tồn','Khám lâm sàng','Cận lâm sàng','Câu hỏi học tập','Đáp án','Thảo luận']) if(!js.includes(token))throw new Error('renderer missing '+token);
console.log('PASS v6.10.4: 13 contextual cases + structured Question/Answer/Discussion');

const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(main.includes('Version: 6.3.7')&&main.includes("MEDIPHARM_ABG_SUITE_VERSION','6.3.7'"),'version');
ok(php.includes('PHÂN TÍCH KHÍ MÁU ĐỘNG MẠCH')&&php.includes('<h1>Phân tích khí máu động mạch</h1>'),'hero copy');
ok(php.includes('data-home-quick-abg')&&php.includes('Hoạt động gần đây'),'desktop lower panels');
ok(php.includes('nah-abg-login-shell--v637')&&php.includes('Truy cập MEDIPHARM ABG'),'branded login');
ok(php.includes('nah-abg__home-mobile-feature--v637'),'mobile feature');
ok(css.includes('v6.3.7 — Mockup-Aligned Clinical Home & Branded Login'),'css release');
ok(css.includes('.nah-abg__workspace-tabs.nah-abg__app-nav{display:none!important}'),'mobile nav hidden');
ok(css.includes('grid-template-columns:repeat(5,minmax(0,1fr))'),'desktop five modules');
ok(ui.includes('data-home-quick-abg')&&ui.includes('medipharm_abg_learning_v30'),'quick bridge/recent activity');
console.log('v6.3.7 mockup-aligned webapp checks: PASS');

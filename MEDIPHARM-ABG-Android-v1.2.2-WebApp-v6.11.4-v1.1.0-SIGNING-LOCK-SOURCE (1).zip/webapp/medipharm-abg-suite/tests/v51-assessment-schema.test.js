const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
const schemaPath=path.join(root,'ASSESSMENT-SCHEMA-v5.1.json');
const manifestPath=path.join(root,'ASSESSMENT-BANK-v5.1-MANIFEST.json');
assert(fs.existsSync(schemaPath),'missing assessment schema');
assert(fs.existsSync(manifestPath),'missing assessment manifest');
const schema=JSON.parse(fs.readFileSync(schemaPath,'utf8'));
const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
const required=['id','domain','lesson_id','concept','difficulty','cognitive_level','error_pattern','source_scope','distractor_rationale','remediation_link','item_format','schema_version'];
assert.deepStrictEqual(schema.required,required);
assert.deepStrictEqual(schema.properties.domain.enum,['foundation','acidbase','oxygen','clinical']);
assert.deepStrictEqual(schema.properties.difficulty.enum,['basic','intermediate','advanced']);
assert.deepStrictEqual(schema.properties.error_pattern.enum,['knowledge_gap','calculation_error','context_omission','sample_quality_error','mechanism_confusion']);
assert.strictEqual(schema.properties.item_format.const,'single_best_answer');
assert.strictEqual(schema.properties.schema_version.const,1);
for(const f of ['domain','lesson_id','concept','cognitive_level','error_pattern','source_scope','distractor_rationale','remediation_link','item_format','schema_version']){
  assert(new RegExp('x\\.'+f.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*=').test(ui),'runtime missing '+f);
}
assert.strictEqual(manifest.canonical_question_count,120);
assert.strictEqual(manifest.legacy_preserved,48);
assert.strictEqual(manifest.new_questions,72);
assert.deepStrictEqual(manifest.runtime_required_metadata,required.slice(1));
assert.strictEqual(manifest.storage_migration,false);
assert.strictEqual(manifest.scoring_semantics_changed,false);
// Accepted v5.0.1 summary-layout isolation must survive the v5.1 content expansion.
assert(css.includes('.nah-abg__reading-steps > li'),'direct-child reading-step selector lost');
assert(css.includes('.nah-abg__lesson-objectives li'),'lesson-objectives defensive selector lost');
const sha=crypto.createHash('sha256').update(core).digest('hex');
assert.strictEqual(sha,'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('PASS v5.1 canonical assessment schema + v5.0.1 layout preservation gate');

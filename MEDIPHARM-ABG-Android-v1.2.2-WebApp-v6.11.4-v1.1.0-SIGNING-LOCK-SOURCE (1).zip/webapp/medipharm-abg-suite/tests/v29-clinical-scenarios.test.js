'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
assert(main.includes('Version: 6.2.4'));
assert(main.includes("const VERSION='6.2.4'"));
[
 'Học qua tình huống lâm sàng',
 'Nhiễm toan ceton do đái tháo đường: đừng dừng ở pH thấp',
 'Thuốc ức chế SGLT2: glucose không quá cao vẫn có thể nhiễm toan ceton',
 'Sốc nhiễm trùng và tăng lactat: đọc cả giá trị và xu hướng',
 'COPD đợt cấp: tăng CO₂ là cấp hay trên nền mạn?',
 'Opioid và giảm thông khí: PaCO₂ là dấu vết của thông khí phế nang',
 'Nôn kéo dài: kiềm chuyển hóa cần đọc cùng clo và kali',
 'Tiêu chảy: toan chuyển hóa không tăng khoảng trống anion',
 'Salicylat: pH kiềm không loại trừ toan chuyển hóa',
 'Giảm oxy máu và tăng thông khí: khí máu định hướng cơ chế, không xác lập nguyên nhân',
 'Giảm oxy máu khi thở máy: PaO₂ chỉ có ý nghĩa khi biết FiO₂ và áp lực dương',
 'Ngộ độc carbon monoxit: PaO₂ bình thường không có nghĩa vận chuyển oxy bình thường',
 'Bọt khí trong mẫu: kiểm tra chất lượng trước khi giải thích sinh lý'
].forEach(x=>assert(mod.includes(x),'missing '+x));
assert.equal((mod.match(/data-handbook-case=/g)||[]).length,23);
assert.equal((mod.match(/data-case-review=/g)||[]).length,12);
assert(ui.includes('CASE_REVIEW_KEYS'));
assert(ui.includes("[data-handbook-case]"));
assert(ui.includes("[data-learning-review]"));
assert(ui.includes('Xem lại tình huống này trong phần Lý thuyết'));
assert(css.includes('v2.9 — Học qua tình huống lâm sàng'));
assert(css.includes('.nah-abg__case-reasoning'));
assert(css.includes('.nah-abg__case-mistake'));
assert.equal(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('ABG Suite v2.9 clinical scenarios PASS');

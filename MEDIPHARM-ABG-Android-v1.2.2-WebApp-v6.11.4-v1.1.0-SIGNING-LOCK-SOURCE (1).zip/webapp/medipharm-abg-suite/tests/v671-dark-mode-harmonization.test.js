const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(main.includes("MEDIPHARM_ABG_SUITE_VERSION','6.7.1"),'version');
ok(css.includes('v6.7.1 — Dark Mode Harmonization Hotfix'),'marker');
['.nah-abg__v670-hero','.nah-abg__v670-action','.nah-abg__v670-cases','.nah-abg__v670-qa','.nah-abg__v670-dictionary','.nah-abg__mobile-dock','.nah-abg__mobile-more-panel'].forEach(x=>ok(css.includes(x),x));
ok(css.includes('[data-theme="dark"]'),'dark selector');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
const hash=crypto.createHash('sha256').update(core).digest('hex');
ok(hash==='92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02','core hash');
console.log('v6.7.1 dark mode harmonization PASS');

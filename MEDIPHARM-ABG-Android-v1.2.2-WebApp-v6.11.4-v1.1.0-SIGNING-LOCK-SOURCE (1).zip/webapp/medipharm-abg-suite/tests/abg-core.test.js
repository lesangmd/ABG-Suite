'use strict';

const assert = require('assert');
const Core = require('../assets/js/nah-abg-core.js');

function analyze(input) {
	const result = Core.analyze(Object.assign({
		sampleType: 'arterial',
		unitSystem: 'si',
		gasPressureUnit: 'mmhg',
		oxygenDevice: 'room-air',
		fio2: 21,
		atmosphericPressure: 760
	}, input));
	assert.strictEqual(result.ok, true, result.errors ? result.errors.join('; ') : 'Analysis failed');
	assert.ok(Array.isArray(result.conclusionReasoning));
	assert.ok(result.conclusionReasoning.length >= 3);
	assert.ok(result.conclusionReasoning.every((item) => typeof item === 'string' && item.trim().length > 0));
	return result;
}

function near(actual, expected, tolerance, message) {
	assert.ok(Math.abs(actual - expected) <= tolerance, `${message}: expected ${expected}, got ${actual}`);
}

function hasId(items, id) {
	return items.some((item) => item.id === id);
}

assert.strictEqual(Core.version, '1.0');
assert.strictEqual(Core.reasoningVersion, '2.1');

// Strict number parsing: Vietnamese decimal comma is valid; units and ambiguous separators are not.
{
	assert.deepStrictEqual(Core.parseNumeric('7,40'), { value: 7.4, empty: false, valid: true });
	assert.deepStrictEqual(Core.parseNumeric(' 12.5 '), { value: 12.5, empty: false, valid: true });
	assert.strictEqual(Core.parseNumeric('7,4,0').valid, false);
	assert.strictEqual(Core.parseNumeric('40 mmHg').valid, false);
	assert.strictEqual(Core.parseNumeric('1e2').valid, false);
}

// Normal arterial blood gas.
{
	const result = analyze({ ph: '7,40', paco2: 40, hco3: 24, pao2: 95, sao2: 98 });
	assert.strictEqual(result.classification.primaryType, 'normal');
	assert.strictEqual(result.consistency.level, 'ok');
	near(result.oxygenation.pfRatio, 452, 1, 'Normal P/F');
	assert.strictEqual(result.referenceChecks.find((item) => item.field === 'pao2').state, 'normal');
}

// High-anion-gap metabolic acidosis with SI albumin and appropriate Winter compensation.
{
	const result = analyze({
		ph: 7.21,
		paco2: 25,
		hco3: 10,
		sodium: 138,
		chloride: 100,
		albumin: 32,
		albuminUnit: 'gl'
	});
	assert.strictEqual(result.classification.primaryType, 'metabolic_acidosis');
	assert.strictEqual(result.compensation.items[0].comparison.status, 'within');
	assert.strictEqual(result.anionGap.state, 'high');
	near(result.anionGap.corrected, 30, 0.1, 'Albumin-corrected anion gap');
	const reasoning = result.conclusionReasoning.join(' ');
	assert.match(reasoning, /pH 7,21 < 7,35/);
	assert.match(reasoning, /HCO₃⁻ 10 mmol\/L < 22 mmol\/L/);
	assert.match(reasoning, /PaCO₂ thực đo 25 mmHg; khoảng bù dự kiến 21–25 mmHg/);
	assert.match(reasoning, /Khoảng trống anion hiệu chỉnh albumin 30 mmol\/L > 14 mmol\/L/);
	assert.match(reasoning, /Henderson–Hasselbalch/);
	assert.match(result.summary, /3a\. Lập luận:/);
}

// The same biochemical values in US units normalize to SI internal values.
{
	const result = analyze({
		unitSystem: 'us',
		ph: 7.30,
		paco2: 30,
		hco3: 15,
		sodium: 140,
		chloride: 105,
		albumin: 3.2,
		albuminUnit: 'gdl',
		glucose: 90,
		glucoseUnit: 'mgdl',
		urea: 14,
		ureaUnit: 'bun-mgdl',
		creatinine: 1.2,
		creatinineUnit: 'mgdl',
		hemoglobin: 14,
		hemoglobinUnit: 'gdl',
		measuredOsm: 310
	});
	near(result.input.albumin, 3.2, 0.01, 'Albumin conversion');
	near(result.input.glucoseMmol, 5, 0.01, 'Glucose conversion');
	near(result.input.ureaContribution, 5, 0.01, 'BUN conversion');
	near(result.input.creatinineUmol, 106.1, 0.1, 'Creatinine conversion');
	near(result.input.hemoglobin, 14, 0.01, 'Hemoglobin conversion');
	near(result.osmolalGap.gap, 20, 0.1, 'US-unit osmolal gap');
}

// kPa input is converted before acid-base and oxygenation calculations.
{
	const result = analyze({
		gasPressureUnit: 'kpa',
		ph: 7.40,
		paco2: 5.333,
		hco3: 24,
		pao2: 12.666
	});
	near(result.input.paco2, 40, 0.1, 'PaCO2 kPa conversion');
	near(result.input.pao2, 95, 0.1, 'PaO2 kPa conversion');
	assert.strictEqual(Core.displayPressure(result.input.paco2, 'kpa').unit, 'kPa');
	assert.match(result.conclusionReasoning.join(' '), /5,33 kPa/);
}

// Invalid formatting and implausible ranges block analysis with field-specific errors.
{
	const malformed = Core.analyze({ ph: '7,40x', paco2: 40, hco3: 24 });
	assert.strictEqual(malformed.ok, false);
	assert.ok(malformed.fieldErrors.ph.length);

	const implausible = Core.analyze({ ph: 7.4, paco2: 400, hco3: 24 });
	assert.strictEqual(implausible.ok, false);
	assert.match(implausible.fieldErrors.paco2[0], /ngoài phạm vi nhập hợp lý/i);
}

// Metabolic acidosis with concurrent respiratory acidosis.
{
	const result = analyze({ ph: 7.12, paco2: 45, hco3: 14 });
	assert.strictEqual(result.classification.primaryType, 'metabolic_acidosis');
	assert.strictEqual(result.compensation.items[0].comparison.status, 'high');
	assert.match(result.compensation.items[0].comparison.message, /toan hô hấp phối hợp/i);
}

// Acute and chronic respiratory acidosis remain distinguishable.
{
	const acute = analyze({ ph: 7.24, paco2: 68, hco3: 28, chronicity: 'acute' });
	assert.strictEqual(acute.classification.primaryType, 'respiratory_acidosis');
	assert.strictEqual(acute.compensation.items[0].comparison.status, 'within');

	const chronic = analyze({ ph: 7.36, paco2: 60, hco3: 31, chronicity: 'chronic' });
	assert.strictEqual(chronic.classification.primaryType, 'compensated_or_mixed');
	assert.strictEqual(chronic.classification.resolvedPrimary, 'respiratory_acidosis');
	assert.strictEqual(
		chronic.compensation.items.find((item) => item.type === 'respiratory_acidosis').comparison.status,
		'within'
	);
	assert.ok(!chronic.differential.some((item) => /kiềm chuyển hóa/i.test(item.name)));
	assert.ok(!chronic.management.some((item) => /kiềm chuyển hóa/i.test(item.title)));
}

// Compensated metabolic alkalosis with a near-normal pH.
{
	const result = analyze({ ph: 7.44, paco2: 46, hco3: 34 });
	assert.strictEqual(result.classification.primaryType, 'compensated_or_mixed');
	assert.strictEqual(result.classification.resolvedPrimary, 'metabolic_alkalosis');
}

// Direct mixed disorders.
{
	const mixedAcid = analyze({ ph: 7.05, paco2: 58, hco3: 16 });
	assert.strictEqual(mixedAcid.classification.primaryType, 'mixed_acidosis');
	assert.strictEqual(mixedAcid.compensation.mode, 'direct-mixed');
	assert.match(mixedAcid.conclusionReasoning.join(' '), /hai quá trình cùng làm pH giảm/i);

	const mixedAlk = analyze({ ph: 7.58, paco2: 24, hco3: 32 });
	assert.strictEqual(mixedAlk.classification.primaryType, 'mixed_alkalosis');
}

// Acute respiratory alkalosis and metabolic alkalosis compensation.
{
	const respiratory = analyze({ ph: 7.53, paco2: 25, hco3: 21, chronicity: 'acute' });
	assert.strictEqual(respiratory.classification.primaryType, 'respiratory_alkalosis');
	assert.strictEqual(respiratory.compensation.items[0].comparison.status, 'within');

	const metabolic = analyze({ ph: 7.50, paco2: 47, hco3: 36 });
	assert.strictEqual(metabolic.classification.primaryType, 'metabolic_alkalosis');
	assert.strictEqual(metabolic.compensation.items[0].comparison.status, 'within');
}

// Venous samples never receive arterial oxygenation interpretation.
{
	const result = analyze({ sampleType: 'venous', ph: 7.31, paco2: 50, hco3: 25, pao2: 35 });
	assert.strictEqual(result.oxygenation.available, false);
	assert.strictEqual(result.oxygenation.reason, 'venous');
}

// DKA context produces a high-priority differential, tests, and non-dosing management direction.
{
	const result = analyze({
		ph: 7.12,
		paco2: 22,
		hco3: 7,
		sodium: 132,
		chloride: 96,
		potassium: 5.4,
		glucose: 24,
		glucoseUnit: 'mmol',
		ketones: 5.6,
		clinicalContexts: ['diabetes']
	});
	const keto = result.differential.find((item) => item.id === 'ketoacidosis');
	assert.ok(keto);
	assert.strictEqual(keto.priority, 3);
	assert.ok(result.additionalTests.some((item) => /hydroxybutyrat|ceton/i.test(item.test)));
	assert.ok(result.management.some((item) => /protocol nhiễm toan ceton/i.test(item.title)));
}

// Objective ketonemia still drives the DKA pathway when Na/Cl are not yet available.
{
	const result = analyze({
		ph: 7.14,
		paco2: 21,
		hco3: 7,
		glucose: 22,
		glucoseUnit: 'mmol',
		ketones: 4.8,
		clinicalContexts: ['diabetes']
	});
	assert.ok(hasId(result.differential, 'ketoacidosis'));
	assert.ok(result.management.some((item) => /protocol nhiễm toan ceton/i.test(item.title)));
	assert.ok(result.additionalTests.some((item) => /Na⁺, Cl⁻/i.test(item.test)));
}

// Severe hyperglycemia plus hyperosmolality suggests HHS even without a primary acid-base disorder.
{
	const result = analyze({
		ph: 7.40,
		paco2: 40,
		hco3: 24,
		sodium: 150,
		glucose: 40,
		glucoseUnit: 'mmol',
		ketones: 0.2,
		measuredOsm: 330,
		clinicalContexts: ['diabetes']
	});
	const crisis = result.differential.find((item) => item.id === 'hyperglycemic-crisis');
	assert.ok(crisis);
	assert.strictEqual(crisis.priority, 3);
	assert.match(crisis.name, /HHS/);
	assert.ok(result.management.some((item) => /cơn tăng đường huyết/i.test(item.title)));
}

// NAGMA and metabolic alkalosis are stratified using clinical context and urine chloride.
{
	const nagma = analyze({
		ph: 7.25,
		paco2: 30,
		hco3: 14,
		sodium: 140,
		chloride: 115,
		clinicalContexts: ['diarrhea']
	});
	assert.ok(hasId(nagma.differential, 'gi-loss'));

	const alkalosis = analyze({
		ph: 7.50,
		paco2: 47,
		hco3: 36,
		urineChloride: 10,
		clinicalContexts: ['vomiting']
	});
	assert.ok(hasId(alkalosis.differential, 'chloride-responsive-alkalosis'));
}

// Appropriate chronic respiratory alkalosis compensation is not mislabeled as metabolic acidosis.
{
	const result = analyze({ ph: 7.40, paco2: 25, hco3: 15, chronicity: 'chronic' });
	assert.strictEqual(result.classification.resolvedPrimary, 'respiratory_alkalosis');
	assert.strictEqual(result.anionGap.relevant, false);
	assert.ok(!result.differential.some((item) => ['rta', 'unclassified-metabolic-acidosis'].includes(item.id)));
	assert.ok(!result.management.some((item) => /toan chuyển hóa/i.test(item.title)));
}

// Hypoxemia with an elevated A-a gradient receives a mechanism-oriented differential.
{
	const result = analyze({
		ph: 7.47,
		paco2: 32,
		hco3: 23,
		pao2: 55,
		sao2: 88,
		age: 65
	});
	assert.strictEqual(result.oxygenation.aaState, 'high');
	const hypoxemia = result.differential.find((item) => item.id === 'hypoxemia-mechanism');
	assert.ok(hypoxemia);
	assert.match(hypoxemia.name, /A–a tăng/);
}

// Respiratory acidosis receives a generic hypoventilation differential when no cause context is supplied.
{
	const result = analyze({ ph: 7.24, paco2: 68, hco3: 28, chronicity: 'acute' });
	assert.ok(hasId(result.differential, 'other-hypoventilation'));
}

// Internal physiologic mismatches are surfaced as sanity warnings.
{
	const result = analyze({ ph: 7.40, paco2: 40, hco3: 24, pao2: 45, sao2: 99 });
	assert.ok(result.sanity.some((item) => /không phù hợp sinh lý/i.test(item.message)));
}

// Delta gap supplements delta ratio and identifies a second metabolic process.
{
	const pureHagma = analyze({
		ph: 7.21,
		paco2: 25,
		hco3: 10,
		sodium: 138,
		chloride: 100,
		albumin: 40,
		albuminUnit: 'gl'
	});
	near(pureHagma.anionGap.deltaGap, 2, 0.1, 'Pure HAGMA delta gap');
	assert.match(pureHagma.anionGap.deltaInterpretation, /HAGMA đơn thuần/i);

	const mixedNagma = analyze({
		ph: 7.15,
		paco2: 25,
		hco3: 9,
		sodium: 140,
		chloride: 111,
		albumin: 40,
		albuminUnit: 'gl'
	});
	assert.ok(mixedNagma.anionGap.deltaGap <= -5);
	assert.match(mixedNagma.anionGap.deltaInterpretation, /phối hợp thêm toan chuyển hóa/i);
}

// The preanalytical checklist explains likely bias and moves verification to urgent.
{
	const result = analyze({
		ph: 7.40,
		paco2: 40,
		hco3: 24,
		pao2: 95,
		sao2: 98,
		sampleDelayMinutes: 45,
		sampleIssues: ['air-bubbles', 'liquid-heparin']
	});
	assert.strictEqual(result.sampleQuality.level, 'danger');
	assert.ok(result.sampleQuality.issues.some((item) => item.code === 'air-bubbles' && /PaO₂/i.test(item.effect)));
	assert.ok(result.sampleQuality.issues.some((item) => item.code === 'analysis-delay' && /lactat tăng/i.test(item.effect)));
	assert.strictEqual(result.protocolPath.find((item) => item.id === 'verify').status, 'urgent');
	assert.ok(result.additionalTests.some((item) => /Lấy lại mẫu đúng kỹ thuật/i.test(item.test)));
}

// Lactate trend is calculated without treating lactate clearance as a stand-alone target.
{
	const result = analyze({
		ph: 7.21,
		paco2: 25,
		hco3: 10,
		sodium: 138,
		chloride: 100,
		lactate: 4,
		priorLactate: 6,
		lactateIntervalHours: 2,
		clinicalContexts: ['shock']
	});
	assert.strictEqual(result.lactateAssessment.trend.direction, 'falling');
	near(result.lactateAssessment.trend.clearancePercent, 33.3, 0.1, 'Lactate decrease');
	assert.match(result.lactateAssessment.caution, /Không dùng riêng/i);
	assert.ok(hasId(result.causeAtlas, 'hyperlactatemia'));
}

// Hyperlactatemia without metabolic acidemia is not automatically called lactic acidosis.
{
	const result = analyze({ ph: 7.40, paco2: 40, hco3: 24, lactate: 3.1 });
	const lactate = result.differential.find((item) => item.id === 'lactic-acidosis');
	assert.ok(lactate);
	assert.match(lactate.name, /chưa đồng nghĩa toan lactic/i);
}

// Co-oximetry catches dyshemoglobinemia even when PaO2 is preserved.
{
	const result = analyze({
		ph: 7.32,
		paco2: 34,
		hco3: 17,
		pao2: 112,
		sao2: 72,
		spo2: 98,
		cohb: 27,
		methb: 0.8,
		sodium: 139,
		chloride: 104,
		clinicalContexts: ['smoke-fire']
	});
	assert.strictEqual(result.dyshemoglobin.level, 'danger');
	assert.ok(result.dyshemoglobin.findings.some((item) => item.code === 'cohb'));
	assert.ok(result.dyshemoglobin.findings.some((item) => item.code === 'saturation-discordance'));
	assert.ok(hasId(result.differential, 'carbon-monoxide'));
	assert.ok(hasId(result.causeAtlas, 'dyshemoglobin'));
	assert.ok(result.management.some((item) => /phơi nhiễm CO/i.test(item.title)));
}

// Hyperglycemia calculations expose corrected sodium and effective osmolality.
{
	const result = analyze({
		ph: 7.40,
		paco2: 40,
		hco3: 24,
		sodium: 150,
		glucose: 40,
		glucoseUnit: 'mmol',
		urea: 10,
		ureaUnit: 'urea-mmol',
		ketones: 0.2,
		clinicalContexts: ['diabetes']
	});
	near(result.hyperglycemia.correctedSodium, 159.9, 0.1, 'Corrected sodium');
	near(result.hyperglycemia.effectiveOsm, 340, 0.1, 'Effective osmolality');
	near(result.hyperglycemia.totalCalculatedOsm, 350, 0.1, 'Total calculated osmolality');
	assert.ok(hasId(result.causeAtlas, 'hyperglycemic-crisis'));
}

// Relevant cause atlases are comprehensive but remain scoped to the detected process.
{
	const respiratory = analyze({
		ph: 7.24,
		paco2: 68,
		hco3: 28,
		chronicity: 'acute',
		clinicalContexts: ['airway-obstruction', 'cns-injury']
	});
	const atlas = respiratory.causeAtlas.find((item) => item.id === 'respiratory-acidosis');
	assert.ok(atlas);
	const allCauses = atlas.groups.flatMap((group) => group.causes).join(' ');
	assert.match(allCauses, /Opioid/i);
	assert.match(allCauses, /ống nội khí quản/i);
	assert.match(allCauses, /Guillain/i);
	assert.match(allCauses, /Tái hít CO₂/i);
	assert.ok(hasId(respiratory.differential, 'airway-obstruction'));
	assert.ok(hasId(respiratory.differential, 'cns-injury-hypoventilation'));
}

// Each major result pattern activates the matching cause map rather than an unrelated flat list.
{
	const nagma = analyze({
		ph: 7.25,
		paco2: 30,
		hco3: 14,
		sodium: 140,
		chloride: 115,
		clinicalContexts: ['gi-fistula']
	});
	assert.ok(hasId(nagma.causeAtlas, 'nagma'));
	assert.ok(!hasId(nagma.causeAtlas, 'hagma'));

	const alkalosis = analyze({
		ph: 7.50,
		paco2: 47,
		hco3: 36,
		urineChloride: 32,
		clinicalContexts: ['hypertension', 'mineralocorticoid']
	});
	assert.ok(hasId(alkalosis.causeAtlas, 'metabolic-alkalosis'));
	assert.ok(hasId(alkalosis.differential, 'mineralocorticoid-excess'));

	const respiratoryAlkalosis = analyze({
		ph: 7.53,
		paco2: 25,
		hco3: 21,
		chronicity: 'acute',
		clinicalContexts: ['high-altitude']
	});
	assert.ok(hasId(respiratoryAlkalosis.causeAtlas, 'respiratory-alkalosis'));
	assert.ok(hasId(respiratoryAlkalosis.differential, 'high-altitude'));
}

// MetHb and smoker-specific COHb thresholds are handled without relying on PaO2.
{
	const methemoglobin = analyze({
		ph: 7.40,
		paco2: 40,
		hco3: 24,
		pao2: 100,
		spo2: 85,
		methb: 24,
		clinicalContexts: ['oxidant-drug']
	});
	assert.ok(hasId(methemoglobin.differential, 'methemoglobinemia'));
	assert.ok(methemoglobin.alerts.some((item) => /MetHb tăng/i.test(item.message)));

	const smoker = analyze({
		ph: 7.40,
		paco2: 40,
		hco3: 24,
		cohb: 5,
		clinicalContexts: ['smoker']
	});
	assert.ok(!hasId(smoker.differential, 'carbon-monoxide'));
	const smokerCheck = smoker.referenceChecks.find((item) => item.field === 'cohb');
	assert.strictEqual(smokerCheck.state, 'normal');
	assert.match(smokerCheck.reference, /9%/);
}

// New numeric fields preserve strict parsing and wide plausibility guards.
{
	const malformed = Core.analyze({
		ph: 7.4,
		paco2: 40,
		hco3: 24,
		priorLactate: '6 mmol/L'
	});
	assert.strictEqual(malformed.ok, false);
	assert.ok(malformed.fieldErrors.priorLactate.length);

	const impossible = Core.analyze({
		ph: 7.4,
		paco2: 40,
		hco3: 24,
		methb: 120
	});
	assert.strictEqual(impossible.ok, false);
	assert.ok(impossible.fieldErrors.methb.length);
}

// Venous blood receives an explicit limitation note and never an oxygenation pathway.
{
	const result = analyze({ sampleType: 'venous', ph: 7.31, paco2: 50, hco3: 25, pao2: 35 });
	assert.match(result.sampleQuality.venousNote, /không được dùng PaO₂ tĩnh mạch/i);
	assert.strictEqual(result.oxygenation.available, false);
}

console.log('All NAH ABG core tests passed.');

const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const launcher=fs.readFileSync(path.join(root,'assets/js/nah-abg-launcher.js'),'utf8');
const launcherCss=fs.readFileSync(path.join(root,'assets/css/nah-abg-launcher.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let d=0,q='',e=false;for(let i=start;i<src.length;i++){const c=src[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='[')d++;else if(c===']'){d--;if(d===0)return src.slice(start,i+1);}}throw new Error(marker);}
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let d=0,q='',e=false;for(let i=start;i<src.length;i++){const c=src[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return src.slice(start,i+1);}}throw new Error(marker);}
function fnSource(name){const marker='function '+name+'(';const s=ui.indexOf(marker);assert(s>=0,name);const b=ui.indexOf('{',s);let d=0,q='',e=false;for(let i=b;i<ui.length;i++){const c=ui[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return ui.slice(s,i+1);}}throw new Error(name);}
function sha(s){return crypto.createHash('sha256').update(s).digest('hex');}
function counts(arr,field){return arr.reduce((o,x)=>(o[x[field]]=(o[x[field]]||0)+1,o),{});}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
// Exact v5.4 question corpus remains byte-identical at the canonical source blocks.
assert.strictEqual(sha(extractArray(ui,'var LEARNING_QUESTIONS')),'3203d1ee4331a6ffa2fe5956c6d341d58dd0a7d368ae2cae765ad1434188e027');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS')),'541ea4cc17cb562e2b932477cf1fbf17e3e9a8c04370f075fa5da181b96f5d34');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_V51_QUESTIONS')),'d72d797771190fdd073e2a99d2318ce4d42c2050f2d8c681e071018df9814d1b');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS')),'023951c212eb4129660700c8643f4437c14116b5bfc3a2bf61c6a53a79390ee8');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_V53_MIXED_QUESTIONS')),'0f2a93823743ab2e38db931ec81c2a9e3be5c93a5b4eaae125ff3a8705f57f3d');
assert.strictEqual(sha(extractObject(ui,'var ASSESSMENT_DIFFICULTY')),'642024087976ca7ffb9b29f6e5f196f371740da43639132ec34f6d5fe0b84a2f');
// Generator UI / algorithm contract.
for(const token of ['value="generator"','data-exam-generator-panel','data-generator-total','data-generator-domain','data-generator-difficulty','data-generator-format','data-generator-seed','data-generator-antirepeat','data-home-generator'])assert(mod.includes(token),token);
for(const token of ['generator:{label:', 'buildGeneratedExam', 'generatorWeights', 'recentGeneratorItemIds', 'examGeneratorConfig', 'itemIds:examQuestions.map', "blueprint')==='generator"])assert(ui.includes(token),token);
for(const token of ['nah-abg__generator-panel','nah-abg__home-card--generator','nah-abg-access-gate','nah-abg__access-status'])assert(css.includes(token),token);
// Access gate uses provider-owned forms and a signed first-party counter; launcher does not consume trials.
assert(mod.includes("apply_filters( 'medipharm_abg_trial_limit', 10 )"));
assert(mod.includes("shortcode_exists( 'syh_login' )"));assert(mod.includes("shortcode_exists( 'yhls_login' )"));assert(mod.includes("class_exists( 'SYH_Super_App' )"));assert(mod.includes("class_exists( 'YHLS_Super_App' )"));assert(mod.includes("is_active_member( $user_id )"));
assert(mod.includes("hash_hmac( 'sha256'"));assert(mod.includes("wp_salt( 'auth' )"));assert(mod.includes("$this->trial_access_status( false )"));assert(mod.includes("$this->trial_access_status( true )"));assert(mod.includes("handle_trial_action"));
assert(plugin.includes('wp_ajax_medipharm_abg_trial_action'));assert(mod.includes("admin_url( 'admin-ajax.php' )"));
assert(launcher.includes('data-abg-launcher-generate')||launcher.includes('makeSeed'));assert(launcherCss.includes('nah-abg-launcher__compact-card'));assert(!launcherCss.includes('nah-abg-launcher__mosaic')); // v5.7 homepage presentation contract
// Exercise generator against the real 220-item bank.
const sandbox={Set,Number,Math,String,Array,Object,JSON,Date};vm.createContext(sandbox);
for(const n of ['shuffled','seededShuffled','prepareAssessmentItem','allocatePlan','expandPlan','generatorWeights','recentGeneratorItemIds','buildGeneratedExam'])vm.runInContext(fnSource(n),sandbox);
const learning=vm.runInContext('('+extractArray(ui,'var LEARNING_QUESTIONS')+')',sandbox);
const extra=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS')+')',sandbox);
const v51=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V51_QUESTIONS')+')',sandbox);
const v52=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS')+')',sandbox);
const v53=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V53_MIXED_QUESTIONS')+')',sandbox);
const diff=vm.runInContext('('+extractObject(ui,'var ASSESSMENT_DIFFICULTY')+')',sandbox);
sandbox.ASSESSMENT_MIXED_FORMATS=['multiple_response','ordering','matching','numeric_calculation','structured_case_interpretation'];
sandbox.ASSESSMENT_BANK=learning.map(q=>Object.assign({},q,{difficulty:diff[q.id]||'intermediate',item_format:'single_best_answer',case_linked:false,adaptive:true})).concat(extra.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v51.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v52.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v53.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false})));
sandbox.state={assessment:{history:[]}};
assert.strictEqual(sandbox.ASSESSMENT_BANK.length,220);
const cfg={total:30,domain:'balanced',difficulty:'balanced',format:'mixed',seed:551234,antiRepeat:false};
const a=sandbox.buildGeneratedExam(cfg),b=sandbox.buildGeneratedExam(cfg);
assert.strictEqual(a.length,30);assert.strictEqual(new Set(a.map(x=>x.id)).size,30);assert.deepStrictEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)),'same seed must reproduce item and option order');
const dc=counts(a,'topic'),lc=counts(a,'difficulty'),fc=counts(a,'item_format');
assert(Math.max(...Object.values(dc))-Math.min(...Object.values(dc))<=1,'balanced domains');
assert.strictEqual(Object.values(lc).reduce((x,y)=>x+y,0),30);assert.strictEqual(Object.values(fc).reduce((x,y)=>x+y,0),30);assert(Object.keys(fc).length>=4,'mixed generator should use several formats');
const sba=sandbox.buildGeneratedExam({total:40,domain:'acidbase',difficulty:'advanced',format:'sba',seed:551235,antiRepeat:false});assert.strictEqual(sba.length,40);assert(sba.every(x=>x.item_format==='single_best_answer'));assert.strictEqual(new Set(sba.map(x=>x.id)).size,40);assert((counts(sba,'topic').acidbase||0)>=20,'focused domain should receive majority');
const heavy=sandbox.buildGeneratedExam({total:40,domain:'balanced',difficulty:'balanced',format:'mixed_heavy',seed:551236,antiRepeat:false});assert.strictEqual(heavy.length,40);assert(Object.keys(counts(heavy,'item_format')).length>=5,'mixed-heavy format breadth');
sandbox.state.assessment.history=[{blueprint:'generator',itemIds:a.map(x=>x.id)}];const c=sandbox.buildGeneratedExam({total:30,domain:'balanced',difficulty:'balanced',format:'mixed',seed:551237,antiRepeat:true});const overlap=c.filter(x=>a.some(y=>y.id===x.id)).length;assert(overlap<=3,'anti-repeat should strongly avoid recent generator items');
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('PASS v5.6 blueprint generator + visual hierarchy + trial access gate');

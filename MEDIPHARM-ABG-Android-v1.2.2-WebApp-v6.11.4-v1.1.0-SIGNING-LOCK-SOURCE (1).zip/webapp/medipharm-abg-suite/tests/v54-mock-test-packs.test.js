const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let d=0,q='',e=false;for(let i=start;i<src.length;i++){const c=src[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='[')d++;else if(c===']'){d--;if(d===0)return src.slice(start,i+1);}}throw new Error(marker);}
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let d=0,q='',e=false;for(let i=start;i<src.length;i++){const c=src[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return src.slice(start,i+1);}}throw new Error(marker);}
function fnSource(name){const marker='function '+name+'(';const s=ui.indexOf(marker);assert(s>=0,name);const b=ui.indexOf('{',s);let d=0,q='',e=false;for(let i=b;i<ui.length;i++){const c=ui[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return ui.slice(s,i+1);}}throw new Error(name);}
function sha(s){return crypto.createHash('sha256').update(s).digest('hex');}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
for(const key of ['mock_foundation','mock_acidbase','mock_oxygen','mock_clinical','mock_advanced','mock_comprehensive']){assert(ui.includes(key+':{label:'),key);assert(mod.includes('value="'+key+'"'),key+' option');}
for(const token of ['data-assessment-timing','data-exam-timer','data-exam-submit-now','examFinishedReason','finishedReason','timeLimitSec','elapsedSec'])assert(ui.includes(token)||mod.includes(token),token);
for(const token of ['nah-abg__assessment-controls','nah-abg__exam-clock','nah-abg__mock-result-meta'])assert(css.includes(token),token);
assert(ui.includes("examFinishedReason='timeout';finishExam()"));
assert(mod.includes('<option value="untimed" selected>Không bấm giờ</option>'));assert(ui.includes("assessmentTimingSelect.value=(bp.mockPack||bp.generator)?'timed':'untimed'"));
assert(ui.includes("window.confirm('Còn '+unanswered+' câu chưa trả lời hoặc chưa hoàn tất. Vẫn nộp bài?')"));
// Preserve canonical v5.3 question content.
assert.strictEqual(sha(extractArray(ui,'var LEARNING_QUESTIONS')),'3203d1ee4331a6ffa2fe5956c6d341d58dd0a7d368ae2cae765ad1434188e027');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS')),'541ea4cc17cb562e2b932477cf1fbf17e3e9a8c04370f075fa5da181b96f5d34');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_V51_QUESTIONS')),'d72d797771190fdd073e2a99d2318ce4d42c2050f2d8c681e071018df9814d1b');
assert.strictEqual(JSON.parse(extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS')).length,60);
assert.strictEqual(JSON.parse(extractArray(ui,'var ASSESSMENT_V53_MIXED_QUESTIONS')).length,40);
const sandbox={Set,Number,Math,String,Array,Object,JSON};vm.createContext(sandbox);
for(const n of ['shuffled','prepareAssessmentItem','seededShuffled','mockPool','takeMock','buildMockExam'])vm.runInContext(fnSource(n),sandbox);
const learning=vm.runInContext('('+extractArray(ui,'var LEARNING_QUESTIONS')+')',sandbox);
const extra=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS')+')',sandbox);
const v51=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V51_QUESTIONS')+')',sandbox);
const v52=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS')+')',sandbox);
const v53=vm.runInContext('('+extractArray(ui,'var ASSESSMENT_V53_MIXED_QUESTIONS')+')',sandbox);
const diff=vm.runInContext('('+extractObject(ui,'var ASSESSMENT_DIFFICULTY')+')',sandbox);
sandbox.ASSESSMENT_BANK=learning.map(q=>Object.assign({},q,{difficulty:diff[q.id]||'intermediate',item_format:'single_best_answer',case_linked:false,adaptive:true})).concat(extra.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v51.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v52.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false}))).concat(v53.map(q=>Object.assign({},q,{item_format:q.item_format||'single_best_answer',case_linked:!!q.case_id,adaptive:false})));
assert.strictEqual(sandbox.ASSESSMENT_BANK.length,220);
const packs={
 mock_foundation:{mockPack:true,total:30,minutes:35,seed:54011,topic:'foundation',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
 mock_acidbase:{mockPack:true,total:30,minutes:40,seed:54021,topic:'acidbase',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
 mock_oxygen:{mockPack:true,total:30,minutes:40,seed:54031,topic:'oxygen',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
 mock_clinical:{mockPack:true,total:30,minutes:45,seed:54041,caseOnly:true,difficultyPlan:{basic:8,intermediate:11,advanced:11}},
 mock_advanced:{mockPack:true,total:30,minutes:45,seed:54051,difficulty:'advanced',topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7}},
 mock_comprehensive:{mockPack:true,total:30,minutes:45,seed:54061,comprehensive:true,topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7},difficultyPlan:{basic:8,intermediate:12,advanced:10}}
};
function counts(arr,field){return arr.reduce((o,x)=>(o[x[field]]=(o[x[field]]||0)+1,o),{});}
for(const [k,bp] of Object.entries(packs)){const a=sandbox.buildMockExam(k,bp),b=sandbox.buildMockExam(k,bp);assert.strictEqual(a.length,30,k+' count');assert.strictEqual(new Set(a.map(x=>x.id)).size,30,k+' unique');assert.deepStrictEqual(a.map(x=>x.id),b.map(x=>x.id),k+' deterministic');}
for(const [k,topic] of [['mock_foundation','foundation'],['mock_acidbase','acidbase'],['mock_oxygen','oxygen']]){const a=sandbox.buildMockExam(k,packs[k]);assert(a.every(x=>x.topic===topic),k+' topic');assert.deepStrictEqual(counts(a,'difficulty'),{basic:10,intermediate:10,advanced:10});}
{const a=sandbox.buildMockExam('mock_clinical',packs.mock_clinical);assert(a.every(x=>x.case_linked), 'clinical case-only');assert.deepStrictEqual(counts(a,'difficulty'),{basic:8,intermediate:11,advanced:11});}
{const a=sandbox.buildMockExam('mock_advanced',packs.mock_advanced);assert(a.every(x=>x.difficulty==='advanced'),'advanced difficulty');assert.deepStrictEqual(counts(a,'topic'),{foundation:7,acidbase:8,oxygen:8,clinical:7});}
{const a=sandbox.buildMockExam('mock_comprehensive',packs.mock_comprehensive);assert.deepStrictEqual(counts(a,'topic'),{foundation:7,acidbase:8,oxygen:8,clinical:7});assert.deepStrictEqual(counts(a,'difficulty'),{basic:8,intermediate:12,advanced:10});}
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
assert(plugin.includes("home_url('/phan-tich-khi-mau-app/')"));
console.log('PASS inherited v5.4 mock-test packs + timed simulation gate on v5.6');

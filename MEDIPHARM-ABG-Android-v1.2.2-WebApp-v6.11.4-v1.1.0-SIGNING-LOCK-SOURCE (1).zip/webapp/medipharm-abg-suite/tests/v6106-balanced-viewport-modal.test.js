const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
assert(plugin.includes('Version: 6.10.6')&&plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.10.6'"));
[
 'body.nah-abg-viewport-modal-open > .nah-abg__viewport-overlay',
 'width:min(96%,1440px)',
 'max-width:1480px',
 'max-height:960px',
 'max-width:1320px',
 '--med-host-right-rail-safe',
 '--nah-sdp-safe-right'
].forEach(x=>assert(css.includes(x),x));
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('PASS v6.10.6 balanced viewport modal');

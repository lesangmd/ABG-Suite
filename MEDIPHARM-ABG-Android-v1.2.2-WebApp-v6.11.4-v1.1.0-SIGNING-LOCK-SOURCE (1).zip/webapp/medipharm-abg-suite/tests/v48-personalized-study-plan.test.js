const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
function ok(x,m){if(!x){console.error('FAIL',m);process.exit(1)}}
ok(main.includes('Version: 6.2.4')&&main.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"),'version 4.8');
ok(php.includes('data-home-v48-plan')&&php.includes('data-v48-session-plan'),'v4.8 plan surfaces');
ok(php.includes('<h3>Kế hoạch hôm nay</h3>')&&php.includes('Phiên học gợi ý khoảng 15 phút'),'editorial plan copy');
ok(js.includes('function v48PlanItems()')&&js.includes('function renderV48Plan()'),'v4.8 planner functions');
ok(js.includes('dueQuestionCount()')&&js.includes('dueCardCount()')&&js.includes('recommendedTopic()'),'planner uses existing learning intelligence');
ok(!js.includes('XMLHttpRequest'),'no XHR calls');ok((js.match(/fetch\(/g)||[]).length===1&&js.includes('function requestTrialUse(actionName, onAllowed)'),'only action-driven trial request');
ok(css.includes('.nah-abg__v48-plan')&&css.includes('.nah-abg__v48-plan-step'),'v4.8 responsive styling');
console.log('PASS v4.8 personalized study plan gate');

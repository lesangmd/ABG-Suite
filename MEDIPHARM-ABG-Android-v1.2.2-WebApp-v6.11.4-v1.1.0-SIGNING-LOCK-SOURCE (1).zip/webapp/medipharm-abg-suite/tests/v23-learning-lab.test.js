'use strict';
const fs=require('fs'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
assert(main.includes('Version: 6.2.4'));
assert(ui.includes('var LEARNING_CASES'));
assert(mod.includes('Thử sức với ca lâm sàng'));
['Học có hướng dẫn','Tự phân tích','Kiểm tra'].forEach(x=>assert(mod.includes(x)));
const caseCount=(ui.match(/caseSummary:/g)||[]).length;
assert(caseCount>=30,'expected >=30 learning cases, got '+caseCount);
['canonical','baseline','append-only','regression','reasoningVersion','oxygenationVersion','pipeline',' QA ','debug'].forEach(term=>{
  assert(!ui.toLowerCase().includes(term.toLowerCase()),'public UI contains internal term '+term);
  assert(!mod.toLowerCase().includes(term.toLowerCase()),'public PHP contains internal term '+term);
});
console.log('ABG Suite v2.3 Clinical Learning Lab PASS ('+caseCount+' cases)');

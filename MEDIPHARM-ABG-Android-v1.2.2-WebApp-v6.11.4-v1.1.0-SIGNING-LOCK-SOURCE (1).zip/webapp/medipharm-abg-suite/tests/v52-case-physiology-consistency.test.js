const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='[')depth++;else if(c===']'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('array not closed');}
const items=JSON.parse(extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS'));
let checked=0;
for(const x of items){
  const v=x.case_vignette||'';
  const ph=/pH\s*([0-9]+,[0-9]+)/.exec(v), pco=/PaCO₂\s*([0-9]+)/.exec(v), hco=/HCO₃⁻\s*([0-9]+)/.exec(v);
  if(!ph||!pco||!hco)continue;
  const pH=Number(ph[1].replace(',','.')), PaCO2=Number(pco[1]), HCO3=Number(hco[1]);
  const derived=6.1+Math.log10(HCO3/(0.03*PaCO2));
  assert(Math.abs(pH-derived)<=0.04,`${x.id} Henderson-Hasselbalch mismatch: stated ${pH}, derived ${derived.toFixed(3)}`);
  checked++;
}
assert(checked>=9,'expected >=9 fully specified pH/PaCO2/HCO3 case states');
console.log('PASS v5.2 case physiology consistency gate; triplets checked',checked);

const fs=require('fs');const assert=require('assert');
const php=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
const main=fs.readFileSync('medipharm-abg-suite.php','utf8');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
assert(main.includes('Version: 6.2.4'));assert(main.includes("const VERSION='6.2.4'"));
assert(php.includes('class="nah-abg__brand-title"'));assert(!php.includes('<strong>ABG</strong>'));
assert(php.includes('aria-label="Trình đơn"'));assert(php.includes('title="Trình đơn"'));assert(!php.includes('<span>Trình đơn</span>'));
assert(css.includes('v4.3.2 — Header Identity Simplification'));assert(css.includes('.nah-abg__brand-title'));
console.log('v4.4 targeted gate PASS');

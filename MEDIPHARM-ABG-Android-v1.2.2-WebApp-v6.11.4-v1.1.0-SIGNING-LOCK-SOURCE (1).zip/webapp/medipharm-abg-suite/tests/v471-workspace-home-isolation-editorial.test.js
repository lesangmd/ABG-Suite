const fs=require('fs');const path=require('path');
const root=path.resolve(__dirname,'..');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function ok(x,m){if(!x){console.error('FAIL',m);process.exit(1)}}
ok(css.includes('.nah-abg__app-home[hidden]'),'explicit home hidden contract');
ok(css.includes('[data-workspace-panel][hidden]'),'workspace hidden contract');
ok(!php.includes('Mỗi lần tải Trang chủ, ứng dụng chọn một tổ hợp nội dung khác từ ngân hàng học tập cục bộ.'),'technical local-bank copy removed');
ok(php.includes('Một phút để nhớ điều quan trọng, thử một câu nhanh và chạm vào một tình huống lâm sàng.'),'editorial feed copy');
ok(js.includes('publicCopy(pearl.text)'),'home pearl passes publicCopy');
ok(js.includes('publicCopy(quiz.q)'),'home quiz passes publicCopy');
ok(js.includes('mất tương hợp thông khí/tưới máu'),'VQ mismatch localized');
console.log('PASS v4.8 workspace isolation/editorial gate');

const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');

assert(main.includes('Version: 6.2.4'));
assert(php.includes('Phiên bản v<?php echo esc_html( MEDIPHARM_ABG_SUITE_VERSION ); ?>'));
assert(php.includes('nah-abg__learning-accordion'));
assert(php.includes('Câu hỏi theo chủ đề') && php.includes('Thẻ ghi nhớ') && php.includes('Thi và đánh giá') && php.includes('Tiến độ học tập'));

assert(ui.includes('function setupHandbookAccordion(root, stickyScroll)'));
assert(ui.includes("document.createElement('details')"));
assert(ui.includes('details.open = index === 0'));
assert(ui.includes("tocLabel.textContent = 'Mục lục sổ tay'"));
assert(ui.includes("btn.setAttribute('aria-expanded',active?'true':'false')"));
assert(ui.includes('handbookAccordion.open(theoryTarget, true)'));

assert(css.includes('.nah-abg__handbook-accordion-summary'));
assert(css.includes('.nah-abg__toc-accordion'));
assert(css.includes('.nah-abg__learning-accordion-item'));
assert(css.includes('@media (max-width: 700px)'));

console.log('v3.1 retained compact handbook/learning accordion layout: PASS');

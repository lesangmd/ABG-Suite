const fs=require('fs');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
const js=fs.readFileSync('assets/js/nah-abg-canonical-learning.js','utf8');
const php=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
for(const token of ['grid-template-columns:220px minmax(0,1fr)','grid-area:rail','grid-area:main']) if(!css.includes(token)) throw new Error(token);
for(const token of ['data-canonical-tab="topics"','data-canonical-tab="dictionary"','data-canonical-tab="qa"','data-canonical-tab="review"']) if(!php.includes(token)) throw new Error(token);
if(!js.includes("backButton('Quay lại danh sách','topics')")) throw new Error('back label');
if(!js.includes("window.matchMedia('(min-width: 901px)')")) throw new Error('desktop default detail');
console.log('v6.10.3 learning master-detail PASS');

const assert=require('assert');
const fs=require('fs'),vm=require('vm'),path=require('path');
const oldCore=require('./fixtures/nah-abg-core-v2.1-canonical.js');
const newCore=require('../assets/js/nah-abg-core.js');
const cases=[
 {ph:7.40,paco2:40,hco3:24,pao2:95,spo2:98,fio2:21,oxygenDevice:'room-air',sodium:140,chloride:104,albumin:40,albuminUnit:'gl'},
 {ph:7.21,paco2:25,hco3:10,pao2:92,spo2:96,fio2:21,oxygenDevice:'room-air',sodium:138,chloride:100,albumin:40,albuminUnit:'gl',lactate:6},
 {ph:7.28,paco2:60,hco3:27,pao2:58,spo2:88,fio2:28,oxygenDevice:'conventional',sodium:139,chloride:101,albumin:35,albuminUnit:'gl',chronicity:'acute'},
 {ph:7.36,paco2:60,hco3:33,pao2:61,spo2:89,fio2:28,oxygenDevice:'conventional',sodium:140,chloride:98,albumin:38,albuminUnit:'gl',chronicity:'chronic'},
 {ph:7.33,paco2:46,hco3:24,pao2:62,spo2:90,fio2:60,oxygenDevice:'invasive',peep:10},
 {ph:7.46,paco2:20,hco3:14,pao2:108,spo2:99,fio2:21,oxygenDevice:'room-air'},
 {sampleType:'venous',ph:7.32,paco2:48,hco3:24,pao2:35,spo2:94,fio2:21}
];
const additive=new Set(['oxygenationAdvanced']);
function projection(r){ const out={}; Object.keys(r).forEach(k=>{if(!additive.has(k))out[k]=r[k]}); return out; }
cases.forEach((input,i)=>assert.deepStrictEqual(projection(newCore.analyze(input)),oldCore.analyze(input),`v2.1 output changed case ${i+1}`));
console.log(`ABG Suite v2.2 vs v2.1 regression PASS (${cases.length}/${cases.length})`);

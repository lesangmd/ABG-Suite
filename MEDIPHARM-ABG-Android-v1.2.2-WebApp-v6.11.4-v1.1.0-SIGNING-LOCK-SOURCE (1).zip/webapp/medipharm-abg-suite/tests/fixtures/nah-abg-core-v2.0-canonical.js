(function (root, factory) {
	'use strict';

	if (typeof module === 'object' && module.exports) {
		module.exports = factory();
	} else {
		root.NAHABGCore = root.NAHABGCore || factory();
	}
}(typeof self !== 'undefined' ? self : this, function () {
	'use strict';

	var VERSION = '1.0';
	var MMHG_PER_KPA = 7.50062;
	var NORMAL = Object.freeze({
		phLow: 7.35,
		phHigh: 7.45,
		paco2Center: 40,
		paco2Low: 35,
		paco2High: 45,
		hco3Center: 24,
		hco3Low: 22,
		hco3High: 26,
		anionGapCenter: 12,
		anionGapLow: 10,
		anionGapHigh: 14
	});

	var FIELD_LABELS = Object.freeze({
		age: 'Tuổi',
		ph: 'pH',
		paco2: 'PaCO₂',
		hco3: 'HCO₃⁻',
		pao2: 'PaO₂',
		sao2: 'SaO₂',
		spo2: 'SpO₂',
		lactate: 'Lactat',
		priorLactate: 'Lactat trước đó',
		lactateIntervalHours: 'Khoảng cách hai lần đo lactat',
		sampleDelayMinutes: 'Thời gian từ lấy mẫu đến phân tích',
		cohb: 'COHb',
		methb: 'MetHb',
		sodium: 'Na⁺',
		chloride: 'Cl⁻',
		potassium: 'K⁺',
		albumin: 'Albumin',
		glucose: 'Glucose',
		urea: 'Urê/BUN',
		creatinine: 'Creatinin',
		ketones: 'Ceton máu',
		measuredOsm: 'Độ thẩm thấu đo được',
		urineChloride: 'Cl⁻ niệu',
		urinePh: 'pH niệu',
		fio2: 'FiO₂',
		peep: 'PEEP/EPAP',
		atmosphericPressure: 'Áp suất khí quyển',
		hemoglobin: 'Hemoglobin'
	});

	function round(value, digits) {
		var precision = typeof digits === 'number' ? digits : 1;
		var factor = Math.pow(10, precision);
		return Math.round((value + Number.EPSILON) * factor) / factor;
	}

	function inRange(value, low, high) {
		return value >= low && value <= high;
	}

	function statusFromRange(actual, low, high) {
		if (actual < low) {
			return 'low';
		}
		if (actual > high) {
			return 'high';
		}
		return 'normal';
	}

	/**
	 * Strict numeric parser. Decimal comma and decimal point are accepted.
	 * Thousands separators, units, scientific notation and multiple separators
	 * are intentionally rejected to prevent silent clinical-data corruption.
	 */
	function parseNumeric(value) {
		if (value === null || value === undefined || value === '') {
			return { value: null, empty: true, valid: true };
		}

		if (typeof value === 'number') {
			return Number.isFinite(value)
				? { value: value, empty: false, valid: true }
				: { value: null, empty: false, valid: false };
		}

		var text = String(value).trim();
		if (!text) {
			return { value: null, empty: true, valid: true };
		}

		if (!/^[+-]?(?:\d+(?:[.,]\d+)?|[.,]\d+)$/.test(text)) {
			return { value: null, empty: false, valid: false };
		}

		var parsed = Number(text.replace(',', '.'));
		return Number.isFinite(parsed)
			? { value: parsed, empty: false, valid: true }
			: { value: null, empty: false, valid: false };
	}

	function normalizeContexts(value) {
		var contexts = [];
		if (Array.isArray(value)) {
			contexts = value;
		} else if (typeof value === 'string' && value) {
			contexts = [value];
		}

		return contexts.map(function (item) {
			return String(item).trim();
		}).filter(Boolean);
	}

	function normalizeInput(raw) {
		var source = raw || {};
		var formatErrors = {};
		var rawValues = {};

		function read(field) {
			var parsed = parseNumeric(source[field]);
			rawValues[field] = parsed.value;
			if (!parsed.valid) {
				formatErrors[field] = FIELD_LABELS[field] + ': định dạng số không hợp lệ.';
			}
			return parsed.value;
		}

		var unitSystem = source.unitSystem === 'us' ? 'us' : 'si';
		var gasPressureUnit = source.gasPressureUnit === 'kpa' ? 'kpa' : 'mmhg';
		var albuminUnit = source.albuminUnit === 'gdl' ? 'gdl' : (unitSystem === 'us' ? 'gdl' : 'gl');
		var glucoseUnit = source.glucoseUnit === 'mgdl' ? 'mgdl' : (unitSystem === 'us' ? 'mgdl' : 'mmol');
		var ureaUnit = source.ureaUnit === 'bun-mgdl' ? 'bun-mgdl' : (unitSystem === 'us' ? 'bun-mgdl' : 'urea-mmol');
		var creatinineUnit = source.creatinineUnit === 'mgdl' ? 'mgdl' : (unitSystem === 'us' ? 'mgdl' : 'umol');
		var hemoglobinUnit = source.hemoglobinUnit === 'gdl' ? 'gdl' : (unitSystem === 'us' ? 'gdl' : 'gl');

		var paco2Raw = read('paco2');
		var pao2Raw = read('pao2');
		var albuminRaw = read('albumin');
		var glucoseRaw = read('glucose');
		var ureaRaw = read('urea');
		var creatinineRaw = read('creatinine');
		var hemoglobinRaw = read('hemoglobin');
		var fio2Raw = read('fio2');

		var caseSummary = source.caseSummary === null || source.caseSummary === undefined
			? ''
			: String(source.caseSummary).trim();

		return {
			sampleType: source.sampleType === 'venous' ? 'venous' : 'arterial',
			unitSystem: unitSystem,
			gasPressureUnit: gasPressureUnit,
			albuminUnit: albuminUnit,
			glucoseUnit: glucoseUnit,
			ureaUnit: ureaUnit,
			creatinineUnit: creatinineUnit,
			hemoglobinUnit: hemoglobinUnit,
			chronicity: ['acute', 'chronic'].indexOf(source.chronicity) >= 0 ? source.chronicity : 'auto',
			sex: ['female', 'male'].indexOf(source.sex) >= 0 ? source.sex : 'unspecified',
			oxygenDevice: ['room-air', 'conventional', 'hfnc', 'niv', 'invasive', 'unknown'].indexOf(source.oxygenDevice) >= 0
				? source.oxygenDevice
				: 'room-air',
			clinicalContexts: normalizeContexts(source.clinicalContexts || source['clinicalContexts[]']),
			sampleIssues: normalizeContexts(source.sampleIssues || source['sampleIssues[]']),
			caseSummary: caseSummary,
			age: read('age'),
			ph: read('ph'),
			paco2: paco2Raw === null ? null : (gasPressureUnit === 'kpa' ? paco2Raw * MMHG_PER_KPA : paco2Raw),
			hco3: read('hco3'),
			pao2: pao2Raw === null ? null : (gasPressureUnit === 'kpa' ? pao2Raw * MMHG_PER_KPA : pao2Raw),
			sao2: read('sao2'),
			spo2: read('spo2'),
			lactate: read('lactate'),
			priorLactate: read('priorLactate'),
			lactateIntervalHours: read('lactateIntervalHours'),
			sampleDelayMinutes: read('sampleDelayMinutes'),
			cohb: read('cohb'),
			methb: read('methb'),
			sodium: read('sodium'),
			chloride: read('chloride'),
			potassium: read('potassium'),
			albumin: albuminRaw === null ? null : (albuminUnit === 'gl' ? albuminRaw / 10 : albuminRaw),
			glucoseMmol: glucoseRaw === null ? null : (glucoseUnit === 'mgdl' ? glucoseRaw / 18 : glucoseRaw),
			ureaContribution: ureaRaw === null ? null : (ureaUnit === 'bun-mgdl' ? ureaRaw / 2.8 : ureaRaw),
			creatinineUmol: creatinineRaw === null ? null : (creatinineUnit === 'mgdl' ? creatinineRaw * 88.4 : creatinineRaw),
			ketones: read('ketones'),
			measuredOsm: read('measuredOsm'),
			urineChloride: read('urineChloride'),
			urinePh: read('urinePh'),
			fio2: fio2Raw === null ? null : (fio2Raw > 1 ? fio2Raw / 100 : fio2Raw),
			peep: read('peep'),
			atmosphericPressure: read('atmosphericPressure'),
			hemoglobin: hemoglobinRaw === null ? null : (hemoglobinUnit === 'gl' ? hemoglobinRaw / 10 : hemoglobinRaw),
			_raw: rawValues,
			_formatErrors: formatErrors
		};
	}

	function hasContext(input, name) {
		return input.clinicalContexts.indexOf(name) >= 0;
	}

	function validate(input) {
		var errors = [];
		var warnings = [];
		var fieldErrors = {};

		function addError(field, message) {
			if (!fieldErrors[field]) {
				fieldErrors[field] = [];
			}
			fieldErrors[field].push(message);
			errors.push(message);
		}

		Object.keys(input._formatErrors).forEach(function (field) {
			addError(field, input._formatErrors[field] + ' Chỉ nhập số, dùng dấu phẩy hoặc dấu chấm cho phần thập phân.');
		});

		[
			['ph', 'Vui lòng nhập pH.'],
			['paco2', 'Vui lòng nhập PaCO₂.'],
			['hco3', 'Vui lòng nhập HCO₃⁻.']
		].forEach(function (required) {
			if (input[required[0]] === null && !input._formatErrors[required[0]]) {
				addError(required[0], required[1]);
			}
		});

		function hardRange(field, value, low, high, label, unit) {
			if (value !== null && !inRange(value, low, high)) {
				addError(
					field,
					label + ' nằm ngoài phạm vi nhập hợp lý (' + low + '–' + high + (unit ? ' ' + unit : '') + '). Kiểm tra giá trị và đơn vị.'
				);
			}
		}

		hardRange('ph', input.ph, 6.5, 8, 'pH', '');
		hardRange('paco2', input.paco2, 5, 200, 'PaCO₂ sau quy đổi', 'mmHg');
		hardRange('hco3', input.hco3, 1, 80, 'HCO₃⁻', 'mmol/L');
		hardRange('pao2', input.pao2, 5, 700, 'PaO₂ sau quy đổi', 'mmHg');
		hardRange('sao2', input.sao2, 1, 100, 'SaO₂', '%');
		hardRange('spo2', input.spo2, 1, 100, 'SpO₂', '%');
		hardRange('lactate', input.lactate, 0, 30, 'Lactat', 'mmol/L');
		hardRange('priorLactate', input.priorLactate, 0, 30, 'Lactat trước đó', 'mmol/L');
		hardRange('lactateIntervalHours', input.lactateIntervalHours, 0.05, 168, 'Khoảng cách hai lần đo lactat', 'giờ');
		hardRange('sampleDelayMinutes', input.sampleDelayMinutes, 0, 1440, 'Thời gian từ lấy mẫu đến phân tích', 'phút');
		hardRange('cohb', input.cohb, 0, 80, 'COHb', '%');
		hardRange('methb', input.methb, 0, 100, 'MetHb', '%');
		hardRange('sodium', input.sodium, 80, 200, 'Na⁺', 'mmol/L');
		hardRange('chloride', input.chloride, 50, 160, 'Cl⁻', 'mmol/L');
		hardRange('potassium', input.potassium, 1, 10, 'K⁺', 'mmol/L');
		hardRange('albumin', input.albumin, 0.5, 7, 'Albumin sau quy đổi', 'g/dL');
		hardRange('glucose', input.glucoseMmol, 0.5, 100, 'Glucose sau quy đổi', 'mmol/L');
		hardRange('urea', input.ureaContribution, 0, 120, 'Urê/BUN sau quy đổi', 'mmol/L');
		hardRange('creatinine', input.creatinineUmol, 10, 3000, 'Creatinin sau quy đổi', 'µmol/L');
		hardRange('ketones', input.ketones, 0, 15, 'Ceton máu', 'mmol/L');
		hardRange('measuredOsm', input.measuredOsm, 150, 500, 'Độ thẩm thấu đo được', 'mOsm/kg');
		hardRange('urineChloride', input.urineChloride, 0, 300, 'Cl⁻ niệu', 'mmol/L');
		hardRange('urinePh', input.urinePh, 4, 9, 'pH niệu', '');
		hardRange('fio2', input.fio2, 0.21, 1, 'FiO₂', '');
		hardRange('peep', input.peep, 0, 30, 'PEEP/EPAP', 'cmH₂O');
		hardRange('atmosphericPressure', input.atmosphericPressure, 400, 800, 'Áp suất khí quyển', 'mmHg');
		hardRange('hemoglobin', input.hemoglobin, 2, 25, 'Hemoglobin sau quy đổi', 'g/dL');
		hardRange('age', input.age, 18, 110, 'Tuổi', 'tuổi');

		if (input.age !== null && Math.floor(input.age) !== input.age) {
			addError('age', 'Tuổi phải là số nguyên.');
		}

		if (input.caseSummary.length > 2500) {
			errors.push('Mô tả ca bệnh vượt quá 2.500 ký tự.');
		}

		if (input.sampleType === 'venous' && input.pao2 !== null) {
			warnings.push('PaO₂ của mẫu tĩnh mạch không được dùng để đánh giá oxy hóa máu động mạch.');
		}

		if (input.priorLactate !== null && input.lactate === null) {
			warnings.push('Đã nhập lactat trước đó nhưng chưa nhập lactat hiện tại; chưa thể đánh giá xu hướng.');
		}

		if (input.lactateIntervalHours !== null && input.priorLactate === null) {
			warnings.push('Đã nhập khoảng cách đo nhưng thiếu lactat trước đó; chưa thể đánh giá xu hướng.');
		}

		if (input.sampleDelayMinutes !== null && input.sampleDelayMinutes > 15) {
			warnings.push('Mẫu được phân tích sau hơn 15 phút; cần đối chiếu loại bơm tiêm, nhiệt độ và quy trình vận chuyển vì pH, PaO₂, PaCO₂ và lactat có thể thay đổi.');
		}

		if ((input.sodium === null) !== (input.chloride === null)) {
			warnings.push('Cần nhập đồng thời Na⁺ và Cl⁻ để tính khoảng trống anion.');
		}

		if (input.gasPressureUnit === 'kpa' && input._raw.paco2 !== null && input._raw.paco2 > 20) {
			warnings.push('PaCO₂ được chọn đơn vị kPa nhưng giá trị nhập khá cao; kiểm tra xem số liệu gốc có phải mmHg hay không.');
		}

		if (input.albuminUnit === 'gl' && input._raw.albumin !== null && input._raw.albumin < 10) {
			warnings.push('Albumin đang chọn g/L nhưng giá trị < 10; kiểm tra nhầm lẫn giữa g/L và g/dL.');
		}

		if (input.hemoglobinUnit === 'gl' && input._raw.hemoglobin !== null && input._raw.hemoglobin < 30) {
			warnings.push('Hemoglobin đang chọn g/L nhưng giá trị < 30; kiểm tra nhầm lẫn giữa g/L và g/dL.');
		}

		if (input.oxygenDevice === 'room-air' && input.fio2 !== null && Math.abs(input.fio2 - 0.21) > 0.01) {
			warnings.push('Đã chọn khí phòng nhưng FiO₂ khác 21%; cần sửa phương thức hỗ trợ hoặc FiO₂.');
		}

		if (input.oxygenDevice === 'room-air' && input.peep !== null && input.peep > 0) {
			warnings.push('Đã chọn khí phòng nhưng có PEEP/EPAP; kiểm tra lại phương thức hỗ trợ hô hấp.');
		}

		return {
			errors: errors,
			warnings: warnings,
			fieldErrors: fieldErrors
		};
	}

	function displayPressure(mmhg, unit) {
		if (mmhg === null) {
			return null;
		}
		return unit === 'kpa'
			? { value: round(mmhg / MMHG_PER_KPA, 2), unit: 'kPa' }
			: { value: round(mmhg, 1), unit: 'mmHg' };
	}

	function referenceCheck(field, label, value, low, high, unit, options) {
		var settings = options || {};
		var state = statusFromRange(value, low, high);
		if (settings.criticalLow !== undefined && value < settings.criticalLow) {
			state = 'critical';
		}
		if (settings.criticalHigh !== undefined && value > settings.criticalHigh) {
			state = 'critical';
		}

		return {
			field: field,
			label: label,
			value: round(settings.displayValue !== undefined ? settings.displayValue : value, settings.digits === undefined ? 1 : settings.digits),
			unit: unit || '',
			state: state,
			reference: settings.reference || (low + '–' + high + (unit ? ' ' + unit : '')),
			note: settings.note || ''
		};
	}

	function assessReferenceRanges(input) {
		var checks = [];
		var pressureUnit = input.gasPressureUnit;
		var paco2Display = displayPressure(input.paco2, pressureUnit);
		var pao2Display = displayPressure(input.pao2, pressureUnit);

		if (input.ph !== null) {
			checks.push(referenceCheck('ph', 'pH', input.ph, 7.35, 7.45, '', { digits: 3, criticalLow: 7.2, criticalHigh: 7.6 }));
		}
		if (input.paco2 !== null) {
			checks.push(referenceCheck(
				'paco2',
				'PaCO₂',
				input.paco2,
				35,
				45,
				paco2Display.unit,
				{
					displayValue: paco2Display.value,
					digits: pressureUnit === 'kpa' ? 2 : 1,
					reference: pressureUnit === 'kpa' ? '4,7–6,0 kPa' : '35–45 mmHg'
				}
			));
		}
		if (input.hco3 !== null) {
			checks.push(referenceCheck('hco3', 'HCO₃⁻', input.hco3, 22, 26, 'mmol/L', { criticalLow: 10, criticalHigh: 40 }));
		}
		if (input.pao2 !== null && input.sampleType === 'arterial' && (input.fio2 === null || input.fio2 <= 0.22)) {
			checks.push(referenceCheck(
				'pao2',
				'PaO₂ trên khí phòng',
				input.pao2,
				80,
				100,
				pao2Display.unit,
				{
					displayValue: pao2Display.value,
					digits: pressureUnit === 'kpa' ? 2 : 1,
					criticalLow: 60,
					reference: pressureUnit === 'kpa' ? '10,7–13,3 kPa (phụ thuộc tuổi)' : '80–100 mmHg (phụ thuộc tuổi)'
				}
			));
		}
		if (input.sao2 !== null) {
			var targetLow = hasContext(input, 'copd') ? 88 : 94;
			var targetHigh = hasContext(input, 'copd') ? 92 : 98;
			checks.push(referenceCheck(
				'sao2',
				'SaO₂',
				input.sao2,
				targetLow,
				targetHigh,
				'%',
				{
					criticalLow: 85,
					reference: targetLow + '–' + targetHigh + '% (mục tiêu oxy tham khảo)',
					note: hasContext(input, 'copd') ? 'Đang dùng mục tiêu tham khảo cho COPD.' : ''
				}
			));
		}
		if (input.spo2 !== null) {
			var spo2TargetLow = hasContext(input, 'copd') ? 88 : 94;
			var spo2TargetHigh = hasContext(input, 'copd') ? 92 : 98;
			checks.push(referenceCheck(
				'spo2',
				'SpO₂',
				input.spo2,
				spo2TargetLow,
				spo2TargetHigh,
				'%',
				{
					criticalLow: 85,
					reference: spo2TargetLow + '–' + spo2TargetHigh + '% (mục tiêu oxy tham khảo)',
					note: 'Pulse oximetry có thể sai lệch khi có COHb/MetHb hoặc tưới máu ngoại vi kém.'
				}
			));
		}
		if (input.lactate !== null) {
			checks.push(referenceCheck('lactate', 'Lactat', input.lactate, 0.5, 2, 'mmol/L', { criticalHigh: 4 }));
		}
		if (input.cohb !== null) {
			var cohbHigh = hasContext(input, 'smoker') ? 9 : 2;
			checks.push(referenceCheck(
				'cohb',
				'COHb',
				input.cohb,
				0,
				cohbHigh,
				'%',
				{
					criticalHigh: 25,
					reference: hasContext(input, 'smoker') ? '≤ 9% ở người hút thuốc' : '≤ 2% ở người không hút thuốc',
					note: 'Mức COHb không phản ánh đầy đủ độ nặng và có thể giảm sau khi đã thở oxy.'
				}
			));
		}
		if (input.methb !== null) {
			checks.push(referenceCheck(
				'methb',
				'MetHb',
				input.methb,
				0,
				1.5,
				'%',
				{
					criticalHigh: 20,
					reference: '0–1,5%',
					note: 'Triệu chứng có thể xuất hiện ở mức thấp hơn khi dự trữ vận chuyển oxy kém.'
				}
			));
		}
		if (input.sodium !== null) {
			checks.push(referenceCheck('sodium', 'Na⁺', input.sodium, 135, 145, 'mmol/L', { criticalLow: 120, criticalHigh: 160 }));
		}
		if (input.chloride !== null) {
			checks.push(referenceCheck('chloride', 'Cl⁻', input.chloride, 98, 107, 'mmol/L'));
		}
		if (input.potassium !== null) {
			checks.push(referenceCheck('potassium', 'K⁺', input.potassium, 3.5, 5, 'mmol/L', { criticalLow: 2.5, criticalHigh: 6.5 }));
		}
		if (input.albumin !== null) {
			var albuminDisplay = input.albuminUnit === 'gl' ? input.albumin * 10 : input.albumin;
			checks.push(referenceCheck(
				'albumin',
				'Albumin',
				input.albumin,
				3.5,
				5,
				input.albuminUnit === 'gl' ? 'g/L' : 'g/dL',
				{
					displayValue: albuminDisplay,
					reference: input.albuminUnit === 'gl' ? '35–50 g/L' : '3,5–5,0 g/dL'
				}
			));
		}
		if (input.glucoseMmol !== null) {
			var glucoseDisplay = input.glucoseUnit === 'mgdl' ? input.glucoseMmol * 18 : input.glucoseMmol;
			checks.push(referenceCheck(
				'glucose',
				'Glucose',
				input.glucoseMmol,
				3.9,
				7.8,
				input.glucoseUnit === 'mgdl' ? 'mg/dL' : 'mmol/L',
				{
					displayValue: glucoseDisplay,
					criticalLow: 3,
					criticalHigh: 33.3,
					reference: input.glucoseUnit === 'mgdl' ? '70–140 mg/dL (phụ thuộc thời điểm lấy mẫu)' : '3,9–7,8 mmol/L (phụ thuộc thời điểm lấy mẫu)'
				}
			));
		}
		if (input.ureaContribution !== null) {
			var ureaDisplay = input.ureaUnit === 'bun-mgdl' ? input.ureaContribution * 2.8 : input.ureaContribution;
			checks.push(referenceCheck(
				'urea',
				input.ureaUnit === 'bun-mgdl' ? 'BUN' : 'Urê',
				input.ureaContribution,
				2.5,
				7.5,
				input.ureaUnit === 'bun-mgdl' ? 'mg/dL' : 'mmol/L',
				{
					displayValue: ureaDisplay,
					reference: input.ureaUnit === 'bun-mgdl' ? '7–21 mg/dL' : '2,5–7,5 mmol/L'
				}
			));
		}
		if (input.creatinineUmol !== null) {
			var creatinineLow = input.sex === 'male' ? 62 : (input.sex === 'female' ? 53 : 53);
			var creatinineHigh = input.sex === 'male' ? 115 : (input.sex === 'female' ? 97 : 115);
			var creatinineDisplay = input.creatinineUnit === 'mgdl' ? input.creatinineUmol / 88.4 : input.creatinineUmol;
			checks.push(referenceCheck(
				'creatinine',
				'Creatinin',
				input.creatinineUmol,
				creatinineLow,
				creatinineHigh,
				input.creatinineUnit === 'mgdl' ? 'mg/dL' : 'µmol/L',
				{
					displayValue: creatinineDisplay,
					reference: input.creatinineUnit === 'mgdl'
						? round(creatinineLow / 88.4, 1) + '–' + round(creatinineHigh / 88.4, 1) + ' mg/dL'
						: creatinineLow + '–' + creatinineHigh + ' µmol/L',
					note: input.sex === 'unspecified' ? 'Khoảng tham chiếu rộng vì chưa chọn giới tính.' : ''
				}
			));
		}
		if (input.ketones !== null) {
			checks.push(referenceCheck('ketones', 'Ceton máu', input.ketones, 0, 0.6, 'mmol/L', { criticalHigh: 3, reference: '< 0,6 mmol/L' }));
		}
		if (input.measuredOsm !== null) {
			checks.push(referenceCheck('measuredOsm', 'Độ thẩm thấu đo được', input.measuredOsm, 275, 295, 'mOsm/kg'));
		}
		if (input.hemoglobin !== null) {
			var hbLow = input.sex === 'male' ? 13 : (input.sex === 'female' ? 12 : 12);
			var hbHigh = input.sex === 'male' ? 17 : (input.sex === 'female' ? 15 : 17);
			var hbDisplay = input.hemoglobinUnit === 'gl' ? input.hemoglobin * 10 : input.hemoglobin;
			checks.push(referenceCheck(
				'hemoglobin',
				'Hemoglobin',
				input.hemoglobin,
				hbLow,
				hbHigh,
				input.hemoglobinUnit === 'gl' ? 'g/L' : 'g/dL',
				{
					displayValue: hbDisplay,
					reference: input.hemoglobinUnit === 'gl' ? (hbLow * 10) + '–' + (hbHigh * 10) + ' g/L' : hbLow + '–' + hbHigh + ' g/dL',
					note: input.sex === 'unspecified' ? 'Khoảng tham chiếu rộng vì chưa chọn giới tính.' : ''
				}
			));
		}

		return checks;
	}

	function assessSampleQuality(input) {
		var issues = [];

		function add(code, level, title, effect, action) {
			if (!issues.some(function (item) { return item.code === code; })) {
				issues.push({
					code: code,
					level: level,
					title: title,
					effect: effect,
					action: action
				});
			}
		}

		if (input.sampleIssues.indexOf('air-bubbles') >= 0) {
			add(
				'air-bubbles',
				'danger',
				'Có bọt khí trong bơm tiêm',
				'PaO₂ và độ bão hòa có thể dịch về giá trị của khí phòng; vận chuyển khí nén làm sai lệch nặng hơn.',
				'Không dùng mẫu này để quyết định oxy hóa nếu sai lệch có thể ảnh hưởng xử trí; ưu tiên lấy lại mẫu đúng kỹ thuật.'
			);
		}
		if (input.sampleIssues.indexOf('analysis-delay') >= 0 || (input.sampleDelayMinutes !== null && input.sampleDelayMinutes > 15)) {
			var delayText = input.sampleDelayMinutes === null
				? 'Có ghi nhận chậm phân tích.'
				: 'Thời gian từ lấy mẫu đến phân tích khoảng ' + round(input.sampleDelayMinutes, 1) + ' phút.';
			add(
				'analysis-delay',
				input.sampleDelayMinutes !== null && input.sampleDelayMinutes > 30 ? 'danger' : 'warning',
				'Chậm phân tích hoặc bảo quản không rõ',
				delayText + ' Chuyển hóa tế bào có thể làm pH/PaO₂/glucose giảm và PaCO₂/lactat tăng.',
				'Đối chiếu vật chứa, nhiệt độ và SOP labo; cân nhắc lấy lại mẫu khi kết quả không phù hợp lâm sàng.'
			);
		}
		if (input.sampleIssues.indexOf('liquid-heparin') >= 0) {
			add(
				'liquid-heparin',
				'warning',
				'Dùng heparin lỏng hoặc bơm tiêm chưa chuẩn hóa',
				'Pha loãng có thể làm giảm PaCO₂, HCO₃⁻, kiềm dư và các điện giải.',
				'Kiểm tra loại bơm tiêm/chất chống đông; ưu tiên bơm tiêm khí máu có heparin khô cân bằng điện giải.'
			);
		}
		if (input.sampleIssues.indexOf('line-contamination') >= 0) {
			add(
				'line-contamination',
				'danger',
				'Nghi nhiễm dịch từ catheter/đường truyền',
				'Dịch rửa, thuốc hoặc dịch truyền có thể pha loãng hay làm sai lệch có hướng nhiều thông số.',
				'Đối chiếu kỹ thuật bỏ thể tích chết và lấy lại mẫu từ vị trí phù hợp trước quyết định lớn.'
			);
		}
		if (input.sampleIssues.indexOf('poor-mixing-clot') >= 0) {
			add(
				'poor-mixing-clot',
				'danger',
				'Mẫu trộn không đủ, có vi cục hoặc đông',
				'Phân bố tế bào không đồng đều và vi cục có thể làm kết quả không tin cậy hoặc ảnh hưởng máy phân tích.',
				'Không cố diễn giải kết quả nghi ngờ; trao đổi labo và lấy lại mẫu.'
			);
		}
		if (input.sampleIssues.indexOf('hemolysis') >= 0) {
			add(
				'hemolysis',
				'warning',
				'Nghi tan máu',
				'K⁺ và một số chất phân tích nội bào có thể tăng giả; tan máu khó phát hiện trực tiếp trong mẫu khí máu toàn phần.',
				'Kiểm tra lại K⁺ trên mẫu phù hợp và đối chiếu ECG/lâm sàng trước khi quy kết tăng kali thật.'
			);
		}
		if (input.sampleIssues.indexOf('unstable-support') >= 0) {
			add(
				'unstable-support',
				'warning',
				'FiO₂ hoặc thông khí vừa thay đổi',
				'PaO₂, PaCO₂, P/F và A–a có thể chưa phản ánh trạng thái ổn định tại cài đặt đang ghi.',
				'Ghi đúng thiết bị/cài đặt tại thời điểm lấy và đánh giá lại sau khi đủ thời gian cân bằng theo protocol tại cơ sở.'
			);
		}

		var level = 'ok';
		if (issues.some(function (item) { return item.level === 'danger'; })) {
			level = 'danger';
		} else if (issues.length) {
			level = 'warning';
		}

		return {
			level: level,
			issues: issues,
			message: issues.length
				? 'Có ' + issues.length + ' yếu tố tiền phân tích cần đối chiếu trước khi tin cậy hoàn toàn kết quả.'
				: 'Chưa ghi nhận yếu tố tiền phân tích bất lợi từ checklist đã nhập.',
			venousNote: input.sampleType === 'venous'
				? 'Mẫu tĩnh mạch có thể hỗ trợ đánh giá pH/HCO₃⁻ trong bối cảnh phù hợp, nhưng chênh lệch PaCO₂ biến thiên và không được dùng PaO₂ tĩnh mạch để đánh giá oxy hóa.'
				: ''
		};
	}

	function assessLactate(input) {
		if (input.lactate === null) {
			return {
				available: false,
				message: 'Chưa nhập lactat; không đánh giá được mức tăng hoặc xu hướng.'
			};
		}

		var state = input.lactate >= 4 ? 'high' : (input.lactate >= 2 ? 'elevated' : 'normal');
		var trend = null;
		if (input.priorLactate !== null && input.priorLactate > 0) {
			var change = input.lactate - input.priorLactate;
			var clearance = ((input.priorLactate - input.lactate) / input.priorLactate) * 100;
			var direction = change < -0.1 ? 'falling' : (change > 0.1 ? 'rising' : 'stable');
			trend = {
				previous: round(input.priorLactate, 1),
				current: round(input.lactate, 1),
				change: round(change, 1),
				clearancePercent: round(clearance, 1),
				direction: direction,
				intervalHours: input.lactateIntervalHours === null ? null : round(input.lactateIntervalHours, 1),
				message: direction === 'falling'
					? 'Lactat đang giảm; vẫn cần đối chiếu tưới máu, lâm sàng và nguyên nhân.'
					: (direction === 'rising'
						? 'Lactat đang tăng; cần đánh giá lại tưới máu, nguồn tạo lactat, thanh thải và đáp ứng điều trị.'
						: 'Lactat ít thay đổi giữa hai lần đo; cần diễn giải theo khoảng thời gian và diễn biến lâm sàng.')
			};
		}

		return {
			available: true,
			value: round(input.lactate, 1),
			state: state,
			label: state === 'high' ? 'Tăng rõ' : (state === 'elevated' ? 'Tăng' : 'Trong khoảng thường dùng'),
			trend: trend,
			message: state === 'normal'
				? 'Lactat không tăng theo ngưỡng 2 mmol/L, nhưng một giá trị đơn lẻ không loại trừ giảm tưới máu khu trú hoặc diễn biến sớm.'
				: 'Tăng lactat không đồng nghĩa mặc định với thiếu oxy mô; cần phân biệt tăng tạo do tưới máu/oxy hóa, tăng đường phân, thuốc và giảm thanh thải.',
			caution: 'Không dùng riêng “độ thanh thải lactat” làm đích hồi sức; cần kết hợp khám tưới máu, huyết động, nước tiểu, tri giác và xu hướng các cơ quan.'
		};
	}

	function assessDyshemoglobin(input) {
		var findings = [];
		var coThreshold = hasContext(input, 'smoker') ? 9 : 2;

		if (input.cohb !== null && input.cohb > coThreshold) {
			findings.push({
				code: 'cohb',
				level: input.cohb >= 25 ? 'danger' : 'warning',
				message: 'COHb ' + round(input.cohb, 1) + '% cao hơn ngưỡng hỗ trợ chẩn đoán trong bối cảnh '
					+ (hasContext(input, 'smoker') ? 'có hút thuốc' : 'không ghi nhận hút thuốc') + '.'
			});
		}
		if (input.methb !== null && input.methb > 1.5) {
			findings.push({
				code: 'methb',
				level: input.methb >= 20 ? 'danger' : 'warning',
				message: 'MetHb ' + round(input.methb, 1) + '% tăng; mức độ triệu chứng còn phụ thuộc Hb, bệnh tim–phổi và biểu hiện lâm sàng.'
			});
		}
		if (input.spo2 !== null && input.sao2 !== null && Math.abs(input.spo2 - input.sao2) > 5) {
			findings.push({
				code: 'saturation-discordance',
				level: 'warning',
				message: 'SpO₂ và SaO₂ chênh ' + round(Math.abs(input.spo2 - input.sao2), 1) + ' điểm phần trăm; cần xác minh phương pháp SaO₂ và cân nhắc co-oximetry.'
			});
		}
		if ((hasContext(input, 'smoke-fire') || hasContext(input, 'oxidant-drug')) && input.cohb === null && input.methb === null) {
			findings.push({
				code: 'missing-cooximetry',
				level: 'warning',
				message: 'Có bối cảnh phơi nhiễm gây dyshemoglobin nhưng chưa nhập COHb/MetHb.'
			});
		}

		return {
			available: input.cohb !== null || input.methb !== null || input.spo2 !== null || findings.length > 0,
			findings: findings,
			level: findings.some(function (item) { return item.level === 'danger'; })
				? 'danger'
				: (findings.length ? 'warning' : 'ok'),
			message: 'PaO₂ có thể bình thường hoặc cao trong ngộ độc CO/MetHb vì PaO₂ phản ánh oxy hòa tan; pulse oximetry hai bước sóng không loại trừ dyshemoglobin.'
		};
	}

	function assessHyperglycemia(input) {
		if (input.glucoseMmol === null) {
			return {
				available: false,
				message: 'Chưa nhập glucose.'
			};
		}

		var correctedSodium = null;
		var effectiveOsm = null;
		var totalCalculatedOsm = null;
		if (input.sodium !== null) {
			var glucoseExcess = Math.max(0, input.glucoseMmol - 5.6);
			correctedSodium = input.sodium + (1.6 * (glucoseExcess / 5.55));
			effectiveOsm = (2 * input.sodium) + input.glucoseMmol;
			totalCalculatedOsm = input.ureaContribution === null ? null : effectiveOsm + input.ureaContribution;
		}

		return {
			available: true,
			correctedSodium: correctedSodium === null ? null : round(correctedSodium, 1),
			effectiveOsm: effectiveOsm === null ? null : round(effectiveOsm, 1),
			totalCalculatedOsm: totalCalculatedOsm === null ? null : round(totalCalculatedOsm, 1),
			formula: 'Na⁺ hiệu chỉnh ước tính = Na⁺ đo + 1,6 × [(glucose − 5,6)/5,55]; độ thẩm thấu hiệu dụng = 2 × Na⁺ + glucose (mmol/L).',
			message: correctedSodium === null
				? 'Cần Na⁺ cùng thời điểm để ước tính Na⁺ hiệu chỉnh và độ thẩm thấu hiệu dụng.'
				: 'Na⁺ hiệu chỉnh là ước tính hỗ trợ trong tăng đường huyết; xu hướng Na⁺ và độ thẩm thấu khi điều trị quan trọng hơn một phép tính đơn lẻ.'
		};
	}

	function assessConsistency(input) {
		var calculatedHco3 = 0.03 * input.paco2 * Math.pow(10, input.ph - 6.1);
		var difference = Math.abs(calculatedHco3 - input.hco3);
		var level = 'ok';
		var message = 'Các giá trị pH, PaCO₂ và HCO₃⁻ phù hợp về mặt nội tại.';

		if (difference > 5) {
			level = 'danger';
			message = 'Sai khác lớn giữa HCO₃⁻ nhập vào và HCO₃⁻ ước tính. Cần kiểm tra phiếu xét nghiệm, đơn vị, loại HCO₃⁻ được báo cáo và chất lượng mẫu trước khi diễn giải.';
		} else if (difference > 3) {
			level = 'warning';
			message = 'Có sai khác đáng kể giữa HCO₃⁻ nhập vào và HCO₃⁻ ước tính; nên đối chiếu lại kết quả gốc.';
		}

		return {
			calculatedHco3: round(calculatedHco3, 1),
			difference: round(difference, 1),
			level: level,
			message: message,
			formula: 'HCO₃⁻ ước tính = 0,03 × PaCO₂ × 10^(pH − 6,1)'
		};
	}

	function classifyAcidBase(input) {
		var phState = 'normal';
		if (input.ph < NORMAL.phLow) {
			phState = 'acidemia';
		} else if (input.ph > NORMAL.phHigh) {
			phState = 'alkalemia';
		}

		var paco2High = input.paco2 > NORMAL.paco2High;
		var paco2Low = input.paco2 < NORMAL.paco2Low;
		var hco3High = input.hco3 > NORMAL.hco3High;
		var hco3Low = input.hco3 < NORMAL.hco3Low;
		var primaryType = 'indeterminate';
		var title = 'Chưa xác định được rối loạn nguyên phát';
		var explanation = 'Các giá trị nằm sát giới hạn hoặc không tạo thành mẫu hình điển hình. Cần đối chiếu diễn biến và khoảng tham chiếu của labo.';
		var candidates = [];

		if (phState === 'acidemia') {
			if (paco2High && hco3Low) {
				primaryType = 'mixed_acidosis';
				title = 'Toan hô hấp phối hợp toan chuyển hóa';
				explanation = 'PaCO₂ tăng và HCO₃⁻ giảm đều làm pH giảm; đây không phải đáp ứng bù trừ đơn thuần.';
			} else if (paco2High) {
				primaryType = 'respiratory_acidosis';
				title = 'Toan hô hấp nguyên phát';
				explanation = 'pH giảm theo hướng ngược với PaCO₂ tăng.';
			} else if (hco3Low) {
				primaryType = 'metabolic_acidosis';
				title = 'Toan chuyển hóa nguyên phát';
				explanation = 'pH và HCO₃⁻ cùng giảm; PaCO₂ cần được đối chiếu với công thức Winter.';
			}
		} else if (phState === 'alkalemia') {
			if (paco2Low && hco3High) {
				primaryType = 'mixed_alkalosis';
				title = 'Kiềm hô hấp phối hợp kiềm chuyển hóa';
				explanation = 'PaCO₂ giảm và HCO₃⁻ tăng đều làm pH tăng; đây không phải đáp ứng bù trừ đơn thuần.';
			} else if (paco2Low) {
				primaryType = 'respiratory_alkalosis';
				title = 'Kiềm hô hấp nguyên phát';
				explanation = 'pH tăng theo hướng ngược với PaCO₂ giảm.';
			} else if (hco3High) {
				primaryType = 'metabolic_alkalosis';
				title = 'Kiềm chuyển hóa nguyên phát';
				explanation = 'pH và HCO₃⁻ cùng tăng; PaCO₂ cần được đối chiếu với mức bù hô hấp dự kiến.';
			}
		} else {
			if (!paco2High && !paco2Low && !hco3High && !hco3Low) {
				primaryType = 'normal';
				title = 'Chưa ghi nhận rối loạn toan–kiềm rõ';
				explanation = 'pH, PaCO₂ và HCO₃⁻ đều trong khoảng tham chiếu sử dụng bởi công cụ.';
			} else if (paco2High && hco3High) {
				primaryType = 'compensated_or_mixed';
				title = 'Tăng PaCO₂ và HCO₃⁻ với pH trong giới hạn';
				explanation = 'Có thể là toan hô hấp đã bù, kiềm chuyển hóa đã bù hoặc hai quá trình phối hợp.';
				candidates = ['respiratory_acidosis', 'metabolic_alkalosis'];
			} else if (paco2Low && hco3Low) {
				primaryType = 'compensated_or_mixed';
				title = 'Giảm PaCO₂ và HCO₃⁻ với pH trong giới hạn';
				explanation = 'Có thể là toan chuyển hóa đã bù, kiềm hô hấp đã bù hoặc hai quá trình phối hợp.';
				candidates = ['metabolic_acidosis', 'respiratory_alkalosis'];
			} else if (paco2High && hco3Low) {
				primaryType = 'mixed_acidosis';
				title = 'Gợi ý toan hô hấp phối hợp toan chuyển hóa';
				explanation = 'Hai biến đổi đều theo hướng gây toan dù pH hiện còn trong khoảng tham chiếu.';
			} else if (paco2Low && hco3High) {
				primaryType = 'mixed_alkalosis';
				title = 'Gợi ý kiềm hô hấp phối hợp kiềm chuyển hóa';
				explanation = 'Hai biến đổi đều theo hướng gây kiềm dù pH hiện còn trong khoảng tham chiếu.';
			}
		}

		return {
			phState: phState,
			phLabel: phState === 'acidemia' ? 'Toan máu' : (phState === 'alkalemia' ? 'Kiềm máu' : 'pH trong giới hạn tham chiếu'),
			primaryType: primaryType,
			title: title,
			explanation: explanation,
			candidates: candidates,
			resolvedPrimary: null
		};
	}

	function evaluateExpected(actual, expected, tolerance, lowMessage, highMessage, withinMessage) {
		var low = expected - tolerance;
		var high = expected + tolerance;
		var status = actual < low ? 'low' : (actual > high ? 'high' : 'within');
		return {
			actual: round(actual, 1),
			expected: round(expected, 1),
			low: round(low, 1),
			high: round(high, 1),
			status: status,
			message: status === 'low' ? lowMessage : (status === 'high' ? highMessage : withinMessage)
		};
	}

	function respiratoryAcidosisCompensation(input) {
		var delta = Math.max(0, input.paco2 - 40) / 10;
		var acuteExpected = 24 + delta;
		var chronicExpected = 24 + (3.5 * delta);
		var tolerance = 2;
		var selected = input.chronicity;
		var acuteDistance = Math.abs(input.hco3 - acuteExpected);
		var chronicDistance = Math.abs(input.hco3 - chronicExpected);
		var phase = selected;
		var comparison;

		if (selected === 'acute') {
			comparison = evaluateExpected(input.hco3, acuteExpected, tolerance,
				'HCO₃⁻ thấp hơn mức bù cấp dự kiến: gợi ý kèm toan chuyển hóa.',
				'HCO₃⁻ cao hơn mức bù cấp dự kiến: cân nhắc kiềm chuyển hóa kèm theo hoặc tình trạng không hoàn toàn cấp.',
				'HCO₃⁻ phù hợp với mức bù dự kiến của toan hô hấp cấp.');
		} else if (selected === 'chronic') {
			comparison = evaluateExpected(input.hco3, chronicExpected, tolerance,
				'HCO₃⁻ thấp hơn mức bù mạn dự kiến: gợi ý kèm toan chuyển hóa hoặc chưa đủ thời gian bù.',
				'HCO₃⁻ cao hơn mức bù mạn dự kiến: gợi ý kèm kiềm chuyển hóa.',
				'HCO₃⁻ phù hợp với mức bù dự kiến của toan hô hấp mạn.');
		} else if (acuteDistance <= tolerance && chronicDistance > tolerance) {
			phase = 'acute';
			comparison = evaluateExpected(input.hco3, acuteExpected, tolerance, '', '', 'Mức HCO₃⁻ phù hợp hơn với toan hô hấp cấp.');
		} else if (chronicDistance <= tolerance && acuteDistance > tolerance) {
			phase = 'chronic';
			comparison = evaluateExpected(input.hco3, chronicExpected, tolerance, '', '', 'Mức HCO₃⁻ phù hợp hơn với toan hô hấp mạn.');
		} else if (acuteDistance <= tolerance && chronicDistance <= tolerance) {
			phase = 'either';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(Math.min(acuteExpected, chronicExpected) - tolerance, 1),
				high: round(Math.max(acuteExpected, chronicExpected) + tolerance, 1),
				status: 'within',
				message: 'Mức thay đổi còn tương thích với cả bối cảnh cấp và mạn; cần dựa vào diễn biến lâm sàng.'
			};
		} else if (input.hco3 < Math.min(acuteExpected, chronicExpected) - tolerance) {
			phase = 'mixed';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(acuteExpected - tolerance, 1),
				high: round(chronicExpected + tolerance, 1),
				status: 'low',
				message: 'HCO₃⁻ thấp hơn cả mức bù cấp và mạn: gợi ý toan chuyển hóa phối hợp.'
			};
		} else if (input.hco3 > Math.max(acuteExpected, chronicExpected) + tolerance) {
			phase = 'mixed';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(acuteExpected - tolerance, 1),
				high: round(chronicExpected + tolerance, 1),
				status: 'high',
				message: 'HCO₃⁻ cao hơn cả mức bù cấp và mạn: gợi ý kiềm chuyển hóa phối hợp.'
			};
		} else {
			phase = 'transition';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(acuteExpected - tolerance, 1),
				high: round(chronicExpected + tolerance, 1),
				status: 'within',
				message: 'Kết quả nằm giữa mức bù cấp và mạn; có thể là giai đoạn chuyển tiếp hoặc rối loạn phối hợp.'
			};
		}

		return {
			type: 'respiratory_acidosis',
			label: 'Bù trừ trong toan hô hấp',
			phase: phase,
			comparison: comparison,
			acuteExpected: round(acuteExpected, 1),
			chronicExpected: round(chronicExpected, 1),
			formula: 'Cấp: HCO₃⁻ tăng ≈ 1 mmol/L; mạn: tăng ≈ 3,5 mmol/L cho mỗi 10 mmHg PaCO₂ tăng.'
		};
	}

	function respiratoryAlkalosisCompensation(input) {
		var delta = Math.max(0, 40 - input.paco2) / 10;
		var acuteExpected = 24 - (2 * delta);
		var chronicHigh = 24 - (5 * delta);
		var chronicLow = 24 - (7 * delta);
		var chronicExpected = (chronicHigh + chronicLow) / 2;
		var tolerance = 2;
		var selected = input.chronicity;
		var acuteDistance = Math.abs(input.hco3 - acuteExpected);
		var chronicDistance = input.hco3 < chronicLow ? chronicLow - input.hco3 : (input.hco3 > chronicHigh ? input.hco3 - chronicHigh : 0);
		var phase = selected;
		var comparison;

		if (selected === 'acute') {
			comparison = evaluateExpected(input.hco3, acuteExpected, tolerance,
				'HCO₃⁻ thấp hơn mức bù cấp dự kiến: gợi ý kèm toan chuyển hóa.',
				'HCO₃⁻ cao hơn mức bù cấp dự kiến: gợi ý kèm kiềm chuyển hóa.',
				'HCO₃⁻ phù hợp với mức bù dự kiến của kiềm hô hấp cấp.');
		} else if (selected === 'chronic') {
			var low = chronicLow - tolerance;
			var high = chronicHigh + tolerance;
			var status = input.hco3 < low ? 'low' : (input.hco3 > high ? 'high' : 'within');
			comparison = {
				actual: round(input.hco3, 1),
				expected: round(chronicExpected, 1),
				low: round(low, 1),
				high: round(high, 1),
				status: status,
				message: status === 'low'
					? 'HCO₃⁻ thấp hơn mức bù mạn dự kiến: gợi ý kèm toan chuyển hóa.'
					: (status === 'high'
						? 'HCO₃⁻ cao hơn mức bù mạn dự kiến: gợi ý kèm kiềm chuyển hóa hoặc chưa đủ thời gian bù.'
						: 'HCO₃⁻ phù hợp với khoảng bù dự kiến của kiềm hô hấp mạn.')
			};
		} else if (acuteDistance <= tolerance && chronicDistance > tolerance) {
			phase = 'acute';
			comparison = evaluateExpected(input.hco3, acuteExpected, tolerance, '', '', 'Mức HCO₃⁻ phù hợp hơn với kiềm hô hấp cấp.');
		} else if (chronicDistance <= tolerance && acuteDistance > tolerance) {
			phase = 'chronic';
			comparison = {
				actual: round(input.hco3, 1),
				expected: round(chronicExpected, 1),
				low: round(chronicLow - tolerance, 1),
				high: round(chronicHigh + tolerance, 1),
				status: 'within',
				message: 'Mức HCO₃⁻ phù hợp hơn với kiềm hô hấp mạn.'
			};
		} else if (acuteDistance <= tolerance && chronicDistance <= tolerance) {
			phase = 'either';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(Math.min(chronicLow, acuteExpected) - tolerance, 1),
				high: round(Math.max(chronicHigh, acuteExpected) + tolerance, 1),
				status: 'within',
				message: 'Mức thay đổi còn tương thích với cả bối cảnh cấp và mạn; cần dựa vào diễn biến lâm sàng.'
			};
		} else if (input.hco3 < Math.min(chronicLow, acuteExpected) - tolerance) {
			phase = 'mixed';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(chronicLow - tolerance, 1),
				high: round(acuteExpected + tolerance, 1),
				status: 'low',
				message: 'HCO₃⁻ thấp hơn cả mức bù cấp và mạn: gợi ý toan chuyển hóa phối hợp.'
			};
		} else if (input.hco3 > Math.max(chronicHigh, acuteExpected) + tolerance) {
			phase = 'mixed';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(chronicLow - tolerance, 1),
				high: round(acuteExpected + tolerance, 1),
				status: 'high',
				message: 'HCO₃⁻ cao hơn cả mức bù cấp và mạn: gợi ý kiềm chuyển hóa phối hợp.'
			};
		} else {
			phase = 'transition';
			comparison = {
				actual: round(input.hco3, 1),
				expected: null,
				low: round(chronicLow - tolerance, 1),
				high: round(acuteExpected + tolerance, 1),
				status: 'within',
				message: 'Kết quả nằm giữa các khoảng dự kiến; cân nhắc giai đoạn chuyển tiếp hoặc rối loạn phối hợp.'
			};
		}

		return {
			type: 'respiratory_alkalosis',
			label: 'Bù trừ trong kiềm hô hấp',
			phase: phase,
			comparison: comparison,
			acuteExpected: round(acuteExpected, 1),
			chronicExpectedLow: round(chronicLow, 1),
			chronicExpectedHigh: round(chronicHigh, 1),
			formula: 'Cấp: HCO₃⁻ giảm ≈ 2 mmol/L; mạn: giảm ≈ 5–7 mmol/L cho mỗi 10 mmHg PaCO₂ giảm.'
		};
	}

	function compensationFor(type, input) {
		if (type === 'metabolic_acidosis') {
			var winter = (1.5 * input.hco3) + 8;
			return {
				type: type,
				label: 'Bù hô hấp trong toan chuyển hóa',
				comparison: evaluateExpected(input.paco2, winter, 2,
					'PaCO₂ thấp hơn khoảng dự kiến: gợi ý kiềm hô hấp phối hợp.',
					'PaCO₂ cao hơn khoảng dự kiến: gợi ý toan hô hấp phối hợp.',
					'PaCO₂ nằm trong khoảng bù hô hấp dự kiến.'),
				formula: 'Công thức Winter: PaCO₂ dự kiến = 1,5 × HCO₃⁻ + 8 ± 2.'
			};
		}
		if (type === 'metabolic_alkalosis') {
			var expectedPaco2 = 40 + (0.6 * (input.hco3 - 24));
			return {
				type: type,
				label: 'Bù hô hấp trong kiềm chuyển hóa',
				comparison: evaluateExpected(input.paco2, expectedPaco2, 5,
					'PaCO₂ thấp hơn khoảng dự kiến: gợi ý kiềm hô hấp phối hợp.',
					'PaCO₂ cao hơn khoảng dự kiến: gợi ý toan hô hấp phối hợp.',
					'PaCO₂ tương thích với mức bù hô hấp dự kiến.'),
				formula: 'PaCO₂ dự kiến ≈ 40 + 0,6 × (HCO₃⁻ − 24); dung sai ± 5 mmHg.'
			};
		}
		if (type === 'respiratory_acidosis') {
			return respiratoryAcidosisCompensation(input);
		}
		if (type === 'respiratory_alkalosis') {
			return respiratoryAlkalosisCompensation(input);
		}
		return null;
	}

	function assessCompensation(classification, input) {
		if (classification.primaryType === 'compensated_or_mixed') {
			return {
				mode: 'candidates',
				items: classification.candidates.map(function (candidate) {
					return compensationFor(candidate, input);
				}).filter(Boolean)
			};
		}

		var item = compensationFor(classification.primaryType, input);
		if (item) {
			return { mode: 'single', items: [item] };
		}
		if (classification.primaryType === 'mixed_acidosis' || classification.primaryType === 'mixed_alkalosis') {
			return {
				mode: 'direct-mixed',
				items: [],
				message: 'Hai quá trình nguyên phát cùng làm pH thay đổi theo một hướng; không nên mô tả một thành phần là “bù trừ” cho thành phần kia.'
			};
		}
		return { mode: 'not-applicable', items: [], message: 'Không có công thức bù trừ cần áp dụng cho mẫu hình hiện tại.' };
	}

	function resolveCandidateClassification(classification, compensation) {
		if (compensation.mode !== 'candidates') {
			return classification;
		}
		var compatible = compensation.items.filter(function (item) {
			return item.comparison.status === 'within';
		});
		if (compatible.length !== 1) {
			return classification;
		}

		var labels = {
			metabolic_acidosis: 'Toan chuyển hóa đã bù',
			metabolic_alkalosis: 'Kiềm chuyển hóa đã bù',
			respiratory_acidosis: 'Toan hô hấp đã bù',
			respiratory_alkalosis: 'Kiềm hô hấp đã bù'
		};
		classification.resolvedPrimary = compatible[0].type;
		classification.title = labels[compatible[0].type] + ' (gợi ý phù hợp nhất)';
		classification.explanation = compatible[0].comparison.message + ' Vẫn cần loại trừ rối loạn phối hợp bằng diễn biến lâm sàng.';
		return classification;
	}

	function assessAnionGap(input, classification, compensation) {
		var types = acidBaseTypes(classification);
		var relevant = types.indexOf('metabolic_acidosis') >= 0 || types.indexOf('mixed_acidosis') >= 0;

		if (compensation && compensation.items) {
			relevant = relevant || compensation.items.some(function (item) {
				return item.type.indexOf('respiratory_') === 0 && item.comparison.status === 'low';
			});
		}

		if (input.sodium === null || input.chloride === null) {
			return {
				available: false,
				relevant: relevant,
				message: relevant
					? 'Có thành phần toan chuyển hóa. Nên bổ sung Na⁺ và Cl⁻ cùng thời điểm để tính khoảng trống anion.'
					: 'Chưa nhập đủ Na⁺ và Cl⁻; khoảng trống anion chưa được tính.'
			};
		}

		var raw = input.sodium - (input.chloride + input.hco3);
		var corrected = input.albumin === null ? null : raw + (2.5 * (4 - input.albumin));
		var effective = corrected === null ? raw : corrected;
		var state = effective > 14 ? 'high' : (effective < 10 ? 'low' : 'normal');
		var deltaRatio = null;
		var deltaGap = null;
		var deltaInterpretation = null;

		if (effective > 12 && input.hco3 < 24) {
			var denominator = 24 - input.hco3;
			if (denominator > 0) {
				deltaRatio = (effective - 12) / denominator;
				deltaGap = (effective - 12) - denominator;
				deltaInterpretation = deltaGap <= -5
					? 'Khoảng trống delta ≤ −5 mmol/L: gợi ý HAGMA phối hợp thêm toan chuyển hóa khoảng trống anion bình thường.'
					: (deltaGap >= 5
						? 'Khoảng trống delta ≥ +5 mmol/L: gợi ý HAGMA phối hợp kiềm chuyển hóa hoặc HCO₃⁻ nền cao.'
						: 'Khoảng trống delta từ −4 đến +4 mmol/L: tương thích hơn với HAGMA đơn thuần; vẫn cần đối chiếu diễn biến.');
			}
		}

		return {
			available: true,
			relevant: relevant,
			raw: round(raw, 1),
			corrected: corrected === null ? null : round(corrected, 1),
			effective: round(effective, 1),
			state: state,
			stateLabel: state === 'high' ? 'Tăng' : (state === 'low' ? 'Thấp' : 'Trong khoảng tham chiếu'),
			deltaRatio: deltaRatio === null ? null : round(deltaRatio, 2),
			deltaGap: deltaGap === null ? null : round(deltaGap, 1),
			deltaInterpretation: deltaInterpretation,
			albuminMissing: input.albumin === null,
			formula: 'AG = Na⁺ − (Cl⁻ + HCO₃⁻); AG hiệu chỉnh = AG + 2,5 × (4 − albumin g/dL); khoảng trống delta = (AG − 12) − (24 − HCO₃⁻).'
		};
	}

	function formatReasoningNumber(value, digits) {
		if (value === null || value === undefined || !Number.isFinite(value)) {
			return '—';
		}
		return String(round(value, typeof digits === 'number' ? digits : 1)).replace('.', ',');
	}

	function reasoningPressure(value, unit) {
		var displayed = displayPressure(value, unit);
		return displayed
			? formatReasoningNumber(displayed.value, unit === 'kpa' ? 2 : 1) + ' ' + displayed.unit
			: '—';
	}

	function reasoningPressureRange(low, high, unit) {
		var displayedLow = displayPressure(low, unit);
		var displayedHigh = displayPressure(high, unit);
		if (!displayedLow || !displayedHigh) {
			return '—';
		}
		return formatReasoningNumber(displayedLow.value, unit === 'kpa' ? 2 : 1) + '–' +
			formatReasoningNumber(displayedHigh.value, unit === 'kpa' ? 2 : 1) + ' ' + displayedLow.unit;
	}

	function buildConclusionReasoning(input, classification, compensation, anionGap, consistency) {
		var reasons = [];
		var primaryType = classification.resolvedPrimary || classification.primaryType;

		if (classification.phState === 'acidemia') {
			reasons.push('pH ' + formatReasoningNumber(input.ph, 3) + ' < 7,35 → có toan máu.');
		} else if (classification.phState === 'alkalemia') {
			reasons.push('pH ' + formatReasoningNumber(input.ph, 3) + ' > 7,45 → có kiềm máu.');
		} else {
			reasons.push('pH ' + formatReasoningNumber(input.ph, 3) + ' nằm trong khoảng 7,35–7,45; pH bình thường không loại trừ rối loạn đã bù hoặc phối hợp.');
		}

		if (primaryType === 'metabolic_acidosis') {
			reasons.push('HCO₃⁻ ' + formatReasoningNumber(input.hco3, 1) + ' mmol/L < 22 mmol/L → có thành phần toan chuyển hóa.');
		} else if (primaryType === 'metabolic_alkalosis') {
			reasons.push('HCO₃⁻ ' + formatReasoningNumber(input.hco3, 1) + ' mmol/L > 26 mmol/L → có thành phần kiềm chuyển hóa.');
		} else if (primaryType === 'respiratory_acidosis') {
			reasons.push('PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' > ' + reasoningPressure(NORMAL.paco2High, input.gasPressureUnit) + ' → có thành phần toan hô hấp.');
		} else if (primaryType === 'respiratory_alkalosis') {
			reasons.push('PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' < ' + reasoningPressure(NORMAL.paco2Low, input.gasPressureUnit) + ' → có thành phần kiềm hô hấp.');
		} else if (primaryType === 'mixed_acidosis') {
			reasons.push(
				'PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' tăng theo hướng gây toan, đồng thời HCO₃⁻ ' +
				formatReasoningNumber(input.hco3, 1) + ' mmol/L giảm theo hướng gây toan → hai quá trình cùng làm pH giảm.'
			);
		} else if (primaryType === 'mixed_alkalosis') {
			reasons.push(
				'PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' giảm theo hướng gây kiềm, đồng thời HCO₃⁻ ' +
				formatReasoningNumber(input.hco3, 1) + ' mmol/L tăng theo hướng gây kiềm → hai quá trình cùng làm pH tăng.'
			);
		} else if (primaryType === 'normal') {
			reasons.push(
				'PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' và HCO₃⁻ ' +
				formatReasoningNumber(input.hco3, 1) + ' mmol/L đều trong khoảng tham chiếu của công cụ.'
			);
		} else if (classification.primaryType === 'compensated_or_mixed') {
			reasons.push(
				'PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' và HCO₃⁻ ' +
				formatReasoningNumber(input.hco3, 1) + ' mmol/L cùng lệch khoảng tham chiếu trong khi pH còn bình thường → cần phân biệt rối loạn đã bù với rối loạn phối hợp.'
			);
		} else {
			reasons.push(
				'PaCO₂ ' + reasoningPressure(input.paco2, input.gasPressureUnit) + ' và HCO₃⁻ ' +
				formatReasoningNumber(input.hco3, 1) + ' mmol/L chưa tạo thành mẫu hình nguyên phát điển hình.'
			);
		}

		var compensationItems = compensation.items || [];
		if (classification.resolvedPrimary) {
			compensationItems = compensationItems.filter(function (item) {
				return item.type === classification.resolvedPrimary;
			});
		}
		compensationItems.forEach(function (item) {
			var comparison = item.comparison;
			var actualText;
			var rangeText;

			if (item.type.indexOf('metabolic_') === 0) {
				actualText = reasoningPressure(comparison.actual, input.gasPressureUnit);
				rangeText = reasoningPressureRange(comparison.low, comparison.high, input.gasPressureUnit);
				reasons.push('PaCO₂ thực đo ' + actualText + '; khoảng bù dự kiến ' + rangeText + ' → ' + comparison.message);
			} else {
				actualText = formatReasoningNumber(comparison.actual, 1) + ' mmol/L';
				rangeText = formatReasoningNumber(comparison.low, 1) + '–' + formatReasoningNumber(comparison.high, 1) + ' mmol/L';
				reasons.push('HCO₃⁻ thực đo ' + actualText + '; khoảng bù dự kiến ' + rangeText + ' → ' + comparison.message);
			}
		});

		if (anionGap.relevant) {
			if (anionGap.available) {
				var agLabel = anionGap.corrected === null ? 'Khoảng trống anion' : 'Khoảng trống anion hiệu chỉnh albumin';
				var agValue = formatReasoningNumber(anionGap.effective, 1) + ' mmol/L';
				if (anionGap.state === 'high') {
					reasons.push(agLabel + ' ' + agValue + ' > 14 mmol/L → có tăng khoảng trống anion.');
				} else if (anionGap.state === 'low') {
					reasons.push(agLabel + ' ' + agValue + ' < 10 mmol/L → khoảng trống anion thấp.');
				} else {
					reasons.push(agLabel + ' ' + agValue + ' nằm trong khoảng 10–14 mmol/L.');
				}
			} else {
				reasons.push('Chưa nhập đủ Na⁺ và Cl⁻ nên chưa thể phân loại thành phần toan chuyển hóa theo khoảng trống anion.');
			}
		}

		var consistencyText = 'HCO₃⁻ ước tính theo Henderson–Hasselbalch là ' +
			formatReasoningNumber(consistency.calculatedHco3, 1) + ' mmol/L; sai khác ' +
			formatReasoningNumber(consistency.difference, 1) + ' mmol/L so với giá trị nhập';
		if (consistency.level === 'ok') {
			reasons.push(consistencyText + ' → bộ ba pH–PaCO₂–HCO₃⁻ nhất quán.');
		} else {
			reasons.push(consistencyText + ' → cần xác minh dữ liệu gốc trước khi sử dụng kết luận.');
		}

		return reasons;
	}

	function assessOsmolalGap(input) {
		if (input.measuredOsm === null || input.sodium === null || input.glucoseMmol === null || input.ureaContribution === null) {
			return {
				available: false,
				message: 'Cần độ thẩm thấu đo được, Na⁺, glucose và urê/BUN để tính khoảng trống thẩm thấu.'
			};
		}

		var calculated = (2 * input.sodium) + input.glucoseMmol + input.ureaContribution;
		var gap = input.measuredOsm - calculated;
		return {
			available: true,
			calculated: round(calculated, 1),
			gap: round(gap, 1),
			state: gap > 10 ? 'high' : (gap < -10 ? 'low' : 'normal'),
			message: gap > 10
				? 'Khoảng trống thẩm thấu tăng (> 10 mOsm/kg). Nếu phù hợp lâm sàng, cần đánh giá chất tan không đo được và khả năng ngộ độc.'
				: 'Khoảng trống thẩm thấu không tăng theo ngưỡng 10 mOsm/kg.',
			formula: 'Osm tính ≈ 2 × Na⁺ + glucose (mmol/L) + urê (mmol/L).'
		};
	}

	function assessOxygenation(input) {
		if (input.sampleType !== 'arterial') {
			return { available: false, reason: 'venous', message: 'Không diễn giải oxy hóa máu từ PaO₂ tĩnh mạch.' };
		}
		if (input.pao2 === null) {
			return { available: false, reason: 'missing-pao2', message: 'Chưa nhập PaO₂ nên chưa đánh giá được oxy hóa máu.' };
		}

		var fio2 = input.fio2;
		var atmosphericPressure = input.atmosphericPressure || 760;
		var pfRatio = fio2 === null ? null : input.pao2 / fio2;
		var pfState = null;
		var pfLabel = null;
		if (pfRatio !== null) {
			if (pfRatio <= 100) {
				pfState = 'severe';
				pfLabel = 'Suy giảm oxy hóa mức nặng theo P/F';
			} else if (pfRatio <= 200) {
				pfState = 'moderate';
				pfLabel = 'Suy giảm oxy hóa mức trung bình theo P/F';
			} else if (pfRatio <= 300) {
				pfState = 'mild';
				pfLabel = 'Suy giảm oxy hóa mức nhẹ theo P/F';
			} else {
				pfState = 'above-300';
				pfLabel = 'P/F > 300';
			}
		}

		var alveolarO2 = fio2 === null ? null : (fio2 * (atmosphericPressure - 47)) - (input.paco2 / 0.8);
		var aaGradient = alveolarO2 === null ? null : alveolarO2 - input.pao2;
		var expectedAa = null;
		var aaState = null;
		if (input.age !== null && fio2 !== null && fio2 <= 0.22 && atmosphericPressure >= 740) {
			expectedAa = (input.age / 4) + 4;
			aaState = aaGradient > expectedAa ? 'high' : 'not-high';
		}

		var arterialO2Content = input.hemoglobin !== null && input.sao2 !== null
			? (1.34 * input.hemoglobin * (input.sao2 / 100)) + (0.003 * input.pao2)
			: null;
		var mechanism = null;
		if (aaState === 'high') {
			mechanism = 'A–a tăng hướng tới V/Q không tương xứng, shunt phải–trái hoặc hạn chế khuếch tán.';
		} else if (aaState === 'not-high') {
			mechanism = 'A–a không tăng hướng tới giảm thông khí phế nang hoặc giảm oxy khí hít vào.';
		}

		return {
			available: true,
			pao2: input.pao2,
			fio2: fio2,
			pfRatio: pfRatio === null ? null : Math.round(pfRatio),
			pfState: pfState,
			pfLabel: pfLabel,
			alveolarO2: alveolarO2 === null ? null : round(alveolarO2, 1),
			aaGradient: aaGradient === null ? null : round(aaGradient, 1),
			expectedAa: expectedAa === null ? null : round(expectedAa, 1),
			aaState: aaState,
			aaCaution: fio2 !== null && (fio2 > 0.22 || atmosphericPressure < 740),
			arterialO2Content: arterialO2Content === null ? null : round(arterialO2Content, 1),
			mechanism: mechanism,
			contentCaution: input.cohb !== null || input.methb !== null
				? 'CaO₂ ước tính từ SaO₂ có thể không phản ánh đầy đủ phần hemoglobin bất thường; ưu tiên phân suất O₂Hb từ co-oximetry khi có.'
				: '',
			message: 'P/F phản ánh mức suy giảm oxy hóa nhưng không đủ để tự xác lập chẩn đoán ARDS; cần bối cảnh cấp, hình ảnh học và điều kiện hỗ trợ hô hấp.',
			formula: 'PAO₂ = FiO₂ × (P khí quyển − 47) − PaCO₂/0,8; A–a = PAO₂ − PaO₂.'
		};
	}

	function assessSanity(input, consistency, anionGap, oxygenation, validationWarnings) {
		var issues = validationWarnings.map(function (message) {
			return { level: 'warning', message: message };
		});

		if (consistency.level !== 'ok') {
			issues.push({ level: consistency.level, message: consistency.message });
		}
		if (input.sodium !== null && input.chloride !== null && input.sodium < input.chloride) {
			issues.push({ level: 'warning', message: 'Na⁺ thấp hơn Cl⁻; cần kiểm tra đơn vị, thời điểm lấy mẫu và kết quả gốc.' });
		}
		if (anionGap.available && anionGap.raw < 0) {
			issues.push({ level: 'warning', message: 'Khoảng trống anion âm: thường cần kiểm tra sai số xét nghiệm/đơn vị, giảm albumin hoặc cation không đo được.' });
		}
		if (input.sampleType === 'arterial' && input.pao2 !== null && input.sao2 !== null) {
			if (input.pao2 < 50 && input.sao2 > 95) {
				issues.push({ level: 'danger', message: 'PaO₂ thấp nhưng SaO₂ rất cao: cặp giá trị không phù hợp sinh lý thông thường; kiểm tra mẫu, đơn vị và nguồn số liệu.' });
			}
			if (input.pao2 > 100 && input.sao2 < 85) {
				issues.push({ level: 'danger', message: 'PaO₂ cao nhưng SaO₂ thấp: kiểm tra mẫu, co-oximetry, dyshemoglobin và sai sót nhập liệu.' });
			}
		}
		if (oxygenation.available && oxygenation.aaGradient !== null && oxygenation.aaGradient < -10) {
			issues.push({ level: 'warning', message: 'Khoảng chênh A–a âm rõ: kiểm tra FiO₂, áp suất khí quyển, PaO₂/PaCO₂ và thời điểm lấy mẫu.' });
		}

		return issues;
	}

	function assessAlerts(input, consistency, oxygenation, osmolalGap, sampleQuality, dyshemoglobin) {
		var alerts = [];
		if (input.ph < 7.2) {
			alerts.push({ level: input.ph < 7 ? 'critical' : 'danger', message: 'pH thấp rõ: cần đánh giá người bệnh và nguyên nhân khẩn trương.' });
		} else if (input.ph > 7.6) {
			alerts.push({ level: input.ph > 7.7 ? 'critical' : 'danger', message: 'pH tăng rất cao: cần đánh giá người bệnh và nguyên nhân khẩn trương.' });
		}
		if (input.sampleType === 'arterial' && input.pao2 !== null && input.pao2 < 60) {
			alerts.push({ level: 'danger', message: 'PaO₂ < 60 mmHg: có giảm oxy máu đáng kể.' });
		}
		if (input.sao2 !== null && input.sao2 < 90) {
			alerts.push({ level: 'danger', message: 'SaO₂ < 90%: có giảm bão hòa oxy đáng kể.' });
		}
		if (input.spo2 !== null && input.spo2 < 90) {
			alerts.push({ level: 'danger', message: 'SpO₂ < 90%: cần đánh giá ngay oxy hóa, tưới máu ngoại vi và độ tin cậy tín hiệu.' });
		}
		if (input.lactate !== null && input.lactate >= 4) {
			alerts.push({ level: 'danger', message: 'Lactat ≥ 4 mmol/L: cần đánh giá giảm tưới máu và các nguyên nhân tăng lactat.' });
		}
		if (input.potassium !== null && (input.potassium < 2.5 || input.potassium > 6.5)) {
			alerts.push({ level: 'critical', message: 'K⁺ ở mức nguy hiểm: cần xác minh nhanh, theo dõi điện tim và xử trí theo protocol.' });
		}
		if (input.glucoseMmol !== null && (input.glucoseMmol < 3 || input.glucoseMmol >= 33.3)) {
			alerts.push({ level: 'danger', message: 'Glucose ở mức cảnh báo; cần đánh giá và xử trí theo bối cảnh lâm sàng.' });
		}
		if (input.ketones !== null && input.ketones >= 3 && input.hco3 < 18) {
			alerts.push({ level: 'danger', message: 'Ceton máu ≥ 3 mmol/L kèm toan chuyển hóa: cần đánh giá ngay nhiễm toan ceton.' });
		}
		if (oxygenation.available && oxygenation.pfRatio !== null && oxygenation.pfRatio <= 100) {
			alerts.push({ level: 'danger', message: 'P/F ≤ 100: suy giảm oxy hóa mức nặng; P/F đơn độc không xác lập ARDS.' });
		}
		if (osmolalGap.available && osmolalGap.gap > 20) {
			alerts.push({ level: 'danger', message: 'Khoảng trống thẩm thấu > 20 mOsm/kg: cần khẩn trương loại trừ chất tan ngoại sinh/ngộ độc phù hợp bối cảnh.' });
		}
		if (dyshemoglobin.findings.some(function (item) { return item.code === 'cohb'; })) {
			alerts.push({
				level: dyshemoglobin.level === 'danger' ? 'danger' : 'warning',
				message: 'COHb tăng: đánh giá phơi nhiễm CO và xử trí khẩn theo triệu chứng/bối cảnh; không dùng riêng nồng độ COHb để phân tầng độ nặng.'
			});
		}
		if (dyshemoglobin.findings.some(function (item) { return item.code === 'methb'; })) {
			alerts.push({
				level: dyshemoglobin.level === 'danger' ? 'danger' : 'warning',
				message: 'MetHb tăng: đánh giá triệu chứng, ngừng tác nhân oxy hóa và hội chẩn chống độc/hồi sức theo protocol.'
			});
		}
		if (sampleQuality.level === 'danger') {
			alerts.push({ level: 'warning', message: 'Có yếu tố tiền phân tích nguy cơ cao; ưu tiên xác minh/lấy lại mẫu trước quyết định lớn nếu tình trạng cho phép.' });
		}
		if (consistency.level === 'danger') {
			alerts.push({ level: 'warning', message: 'Tính nhất quán pH–PaCO₂–HCO₃⁻ chưa đạt; ưu tiên xác minh mẫu trước quyết định lớn.' });
		}
		return alerts;
	}

	function acidBaseTypes(classification) {
		return classification.resolvedPrimary
			? [classification.resolvedPrimary]
			: [classification.primaryType].concat(classification.candidates || []);
	}

	function inferProcesses(classification, compensation) {
		var types = acidBaseTypes(classification);
		var processes = {
			metabolicAcidosis: types.indexOf('metabolic_acidosis') >= 0 || types.indexOf('mixed_acidosis') >= 0,
			metabolicAlkalosis: types.indexOf('metabolic_alkalosis') >= 0 || types.indexOf('mixed_alkalosis') >= 0,
			respiratoryAcidosis: types.indexOf('respiratory_acidosis') >= 0 || types.indexOf('mixed_acidosis') >= 0,
			respiratoryAlkalosis: types.indexOf('respiratory_alkalosis') >= 0 || types.indexOf('mixed_alkalosis') >= 0
		};

		(compensation.items || []).forEach(function (item) {
			if (item.type.indexOf('respiratory_') === 0) {
				if (item.comparison.status === 'low') {
					processes.metabolicAcidosis = true;
				}
				if (item.comparison.status === 'high') {
					processes.metabolicAlkalosis = true;
				}
			}
			if (item.type.indexOf('metabolic_') === 0) {
				if (item.comparison.status === 'low') {
					processes.respiratoryAlkalosis = true;
				}
				if (item.comparison.status === 'high') {
					processes.respiratoryAcidosis = true;
				}
			}
		});

		return processes;
	}

	function buildCauseAtlas(input, classification, anionGap, oxygenation, compensation, lactateAssessment, dyshemoglobin, hyperglycemia) {
		var atlas = [];
		var processes = inferProcesses(classification, compensation);

		function add(id, title, trigger, groups, note) {
			atlas.push({
				id: id,
				title: title,
				trigger: trigger,
				groups: groups,
				note: note || ''
			});
		}

		if (processes.metabolicAcidosis && (!anionGap.available || anionGap.state === 'high')) {
			add(
				'hagma',
				'Toan chuyển hóa tăng khoảng trống anion (HAGMA)',
				anionGap.available ? 'AG sử dụng ' + anionGap.effective + ' mmol/L.' : 'Chưa đủ Na⁺/Cl⁻ để xác định AG; giữ nhóm này trong danh sách rà soát.',
				[
					{
						label: 'Lactat – giảm tưới máu/thiếu oxy',
						causes: [
							'Sốc giảm thể tích, nhiễm trùng, tim hoặc tắc nghẽn',
							'Ngừng tim, suy tim nặng hoặc suy hô hấp/giảm oxy máu nặng',
							'Thiếu máu cục bộ vùng: ruột, chi hoặc cơ quan khác'
						]
					},
					{
						label: 'Lactat – không do giảm tưới máu đơn thuần',
						causes: [
							'Co giật, gắng sức/công thở quá mức hoặc kích thích β-adrenergic',
							'Suy gan/giảm thanh thải, thiếu thiamine, bệnh ác tính hoặc rối loạn ty thể',
							'Thuốc: metformin, linezolid, propofol, theophylline hoặc catecholamine'
						]
					},
					{
						label: 'Ceton và suy thận',
						causes: [
							'DKA, kể cả DKA glucose không quá cao liên quan SGLT2',
							'Nhiễm toan ceton do rượu hoặc nhịn đói',
							'Suy thận tiến triển/uremia'
						]
					},
					{
						label: 'Độc chất và nguyên nhân đặc hiệu không được bỏ sót',
						causes: [
							'Methanol, ethylene glycol hoặc propylene glycol',
							'Salicylat; cyanide hoặc carbon monoxide trong bối cảnh phù hợp',
							'5-oxoproline do dùng paracetamol kéo dài và D-lactat ở hội chứng ruột ngắn'
						]
					}
				],
				'AG bình thường không loại trừ lactat hoặc ceton tăng, đặc biệt khi albumin thấp; đo trực tiếp chất nghi ngờ.'
			);
		}

		if (processes.metabolicAcidosis && (!anionGap.available || anionGap.state !== 'high')) {
			add(
				'nagma',
				'Toan chuyển hóa khoảng trống anion bình thường/tăng chloride (NAGMA)',
				anionGap.available ? 'AG không tăng.' : 'Chưa đủ dữ liệu phân nhóm AG.',
				[
					{
						label: 'Mất HCO₃⁻ ngoài thận',
						causes: [
							'Tiêu chảy, hồi tràng nhân tạo hoặc dẫn lưu ruột',
							'Rò/dẫn lưu tụy, mật hoặc dịch ruột',
							'Niệu quản–đại tràng hoặc bàng quang tạo hình bằng ruột'
						]
					},
					{
						label: 'Nguyên nhân tại thận',
						causes: [
							'RTA type 1 (xa), type 2 (gần) hoặc type 4',
							'Giảm aldosteron/suy thượng thận; thuốc ức chế hệ renin–angiotensin, trimethoprim hoặc heparin',
							'Suy thận giai đoạn sớm hoặc bệnh ống–kẽ thận'
						]
					},
					{
						label: 'Thuốc, dịch và độc chất',
						causes: [
							'Tải chloride từ NaCl 0,9% hoặc dinh dưỡng/dịch giàu chloride',
							'Acetazolamide hoặc topiramate',
							'Toluene và một số độc chất gây mất bicarbonate/acid hóa niệu'
						]
					}
				],
				'K⁺, pH niệu và điện giải niệu cùng thời điểm giúp định hướng nhưng không được dùng một giá trị riêng lẻ để gán type RTA.'
			);
		}

		if (processes.metabolicAlkalosis) {
			add(
				'metabolic-alkalosis',
				'Kiềm chuyển hóa',
				input.urineChloride === null ? 'Chưa có Cl⁻ niệu để phân nhóm.' : 'Cl⁻ niệu ' + round(input.urineChloride, 1) + ' mmol/L.',
				[
					{
						label: 'Cl⁻ niệu thường thấp (<20 mmol/L)',
						causes: [
							'Nôn hoặc hút dịch dạ dày',
							'Lợi tiểu đã ngừng/giảm thể tích co kéo',
							'Mất chloride qua mồ hôi, sau tăng CO₂ mạn hoặc thiếu chloride đưa vào'
						]
					},
					{
						label: 'Cl⁻ niệu không thấp – huyết áp bình thường/thấp',
						causes: [
							'Đang dùng lợi tiểu quai hoặc thiazide',
							'Hội chứng Bartter hoặc Gitelman',
							'Hạ K⁺/Mg²⁺ nặng duy trì kiềm'
						]
					},
					{
						label: 'Cl⁻ niệu không thấp – tăng huyết áp',
						causes: [
							'Cường aldosteron nguyên phát hoặc thứ phát',
							'Cushing/corticoid có tác dụng mineralocorticoid',
							'Liddle, cam thảo hoặc mineralocorticoid ngoại sinh'
						]
					},
					{
						label: 'Tải kiềm',
						causes: [
							'Bicarbonate/citrate, truyền máu khối lượng lớn hoặc antacid',
							'Hội chứng calcium–alkali, đặc biệt khi chức năng thận giảm'
						]
					}
				],
				'Diễn giải Cl⁻ niệu phải xét thời điểm dùng lợi tiểu, chức năng thận, thể tích tuần hoàn và huyết áp.'
			);
		}

		if (processes.respiratoryAcidosis) {
			add(
				'respiratory-acidosis',
				'Toan hô hấp – giảm thông khí phế nang',
				'PaCO₂ tăng hoặc bù trừ gợi ý thành phần toan hô hấp.',
				[
					{
						label: 'Giảm drive hô hấp',
						causes: [
							'Opioid, thuốc an thần/gây mê, rượu hoặc ngộ độc thuốc',
							'Tổn thương thân não, chấn thương sọ não, đột quỵ hoặc sau co giật',
							'Hội chứng giảm thông khí do béo phì/OSA hoặc suy giáp nặng'
						]
					},
					{
						label: 'Tắc nghẽn và bệnh phổi–thành ngực',
						causes: [
							'COPD/hen nặng, nút nhầy, dị vật hoặc tắc/gập ống nội khí quản',
							'Viêm phổi/phù phổi/ARDS nặng, tràn khí màng phổi',
							'Béo phì, gù vẹo cột sống hoặc chấn thương thành ngực'
						]
					},
					{
						label: 'Thần kinh–cơ',
						causes: [
							'Nhược cơ, Guillain–Barré, ALS hoặc bệnh cơ',
							'Tổn thương tủy, liệt cơ hoành hoặc yếu cơ mắc phải tại ICU'
						]
					},
					{
						label: 'Do hỗ trợ hô hấp hoặc tải CO₂',
						causes: [
							'Thông khí phút đặt thấp, rò khí, không đồng bộ hoặc khoảng chết tăng',
							'Tái hít CO₂ hoặc lỗi hệ thống thở',
							'Tăng tạo CO₂ do sốt, co giật, overfeeding hoặc tăng chuyển hóa khi thông khí cố định'
						]
					}
				]
			);
		}

		if (processes.respiratoryAlkalosis) {
			add(
				'respiratory-alkalosis',
				'Kiềm hô hấp – tăng thông khí',
				'PaCO₂ giảm hoặc bù trừ gợi ý thành phần kiềm hô hấp.',
				[
					{
						label: 'Giảm oxy/bệnh phổi–mạch phổi',
						causes: [
							'Thuyên tắc phổi, viêm phổi, phù phổi, hen hoặc tràn khí màng phổi',
							'Bệnh phổi kẽ/rối loạn khuếch tán hoặc độ cao'
						]
					},
					{
						label: 'Toàn thân và thần kinh trung ương',
						causes: [
							'Sepsis, sốt, đau hoặc lo âu sau khi đã loại trừ nguyên nhân nguy hiểm',
							'Đột quỵ, chấn thương sọ não, viêm màng não hoặc tăng áp lực nội sọ',
							'Thai kỳ hoặc bệnh gan'
						]
					},
					{
						label: 'Thuốc và can thiệp',
						causes: [
							'Salicylat giai đoạn sớm, catecholamine hoặc progesterone',
							'Thông khí phút/hỗ trợ áp lực quá mức trên máy thở'
						]
					}
				],
				'Không quy kết tăng thông khí cho lo âu trước khi loại trừ giảm oxy, sepsis, bệnh mạch phổi và độc chất.'
			);
		}

		if (oxygenation.available && (
			(oxygenation.pfRatio !== null && oxygenation.pfRatio <= 300)
			|| input.pao2 < 60
			|| (input.sao2 !== null && input.sao2 < 90)
		)) {
			add(
				'hypoxemia',
				'Năm cơ chế giảm oxy máu',
				oxygenation.mechanism || 'Chưa đủ điều kiện phân loại A–a.',
				[
					{
						label: 'A–a thường không tăng',
						causes: [
							'FiO₂ khí hít vào thấp: độ cao, sai hỗn hợp khí hoặc môi trường kín/cháy',
							'Giảm thông khí phế nang do CNS, thần kinh–cơ hoặc thành ngực'
						]
					},
					{
						label: 'A–a tăng',
						causes: [
							'V/Q không tương xứng: COPD/hen, viêm phổi, phù/xẹp phổi hoặc thuyên tắc phổi',
							'Shunt phải–trái: phế nang ngập/xẹp nặng, ARDS nặng hoặc shunt tim',
							'Hạn chế khuếch tán: bệnh phổi kẽ hoặc phù phổi'
						]
					}
				],
				'Đáp ứng với oxy hỗ trợ phân biệt: V/Q và khuếch tán thường cải thiện; shunt lớn cải thiện kém. Không dùng phép thử này thay đánh giá cấp cứu.'
			);
		}

		if (lactateAssessment.available && lactateAssessment.state !== 'normal') {
			add(
				'hyperlactatemia',
				'Tăng lactat: rà soát theo cơ chế',
				'Lactat ' + lactateAssessment.value + ' mmol/L' + (lactateAssessment.trend
					? ', xu hướng ' + (lactateAssessment.trend.direction === 'falling' ? 'giảm' : (lactateAssessment.trend.direction === 'rising' ? 'tăng' : 'ít thay đổi'))
					: '') + '.',
				[
					{
						label: 'Tăng tạo do tưới máu/oxy hóa',
						causes: [
							'Sốc, ngừng tim, suy tim hoặc suy hô hấp nặng',
							'Thiếu máu cục bộ vùng, chấn thương hoặc bỏng'
						]
					},
					{
						label: 'Tăng đường phân/tải chuyển hóa',
						causes: [
							'Sepsis không chỉ do giảm tưới máu, co giật, gắng sức hoặc công thở',
							'Catecholamine, albuterol/theophylline và một số thuốc khác'
						]
					},
					{
						label: 'Rối loạn chuyển hóa/thanh thải',
						causes: [
							'Suy gan, thiếu thiamine, bệnh ty thể hoặc bệnh ác tính',
							'Metformin, propofol, linezolid; CO hoặc cyanide'
						]
					}
				],
				'Lactat là dấu chỉ nguy cơ và đáp ứng, không phải phép đo đặc hiệu của thiếu oxy mô.'
			);
		}

		if (hyperglycemia.available && (
			input.glucoseMmol >= 11.1
			&& ((input.ketones !== null && input.ketones >= 0.6)
				|| input.hco3 < 18
				|| (hyperglycemia.effectiveOsm !== null && hyperglycemia.effectiveOsm > 300))
		)) {
			add(
				'hyperglycemic-crisis',
				'Yếu tố khởi phát DKA/HHS cần tìm',
				'Có tăng đường huyết kèm ceton/toan hoặc ưu trương.',
				[
					{
						label: 'Thiếu insulin và thuốc',
						causes: [
							'Bỏ/thiếu insulin, lỗi bơm insulin hoặc đái tháo đường mới phát hiện',
							'SGLT2 (có thể DKA glucose không quá cao), corticoid, lợi tiểu thiazide hoặc thuốc chống loạn thần'
						]
					},
					{
						label: 'Bệnh cấp tính',
						causes: [
							'Nhiễm trùng/sepsis',
							'Nhồi máu cơ tim, đột quỵ, viêm tụy, chấn thương hoặc phẫu thuật',
							'Mất nước, nôn/tiêu chảy hoặc giảm khả năng tiếp cận nước'
						]
					},
					{
						label: 'Bối cảnh đặc biệt',
						causes: [
							'Thai kỳ, rượu/nhịn đói hoặc chế độ ăn rất ít carbohydrate',
							'Rối loạn nội tiết tăng đối kháng insulin trong bối cảnh phù hợp'
						]
					}
				],
				'Không gọi DKA/HHS chỉ từ khí máu; áp dụng đầy đủ tiêu chuẩn glucose/ceton/pH–HCO₃⁻/độ thẩm thấu và đánh giá lâm sàng.'
			);
		}

		if (dyshemoglobin.available && (
			dyshemoglobin.findings.length
			|| hasContext(input, 'smoke-fire')
			|| hasContext(input, 'oxidant-drug')
		)) {
			add(
				'dyshemoglobin',
				'Dyshemoglobin/thiếu oxy mô với PaO₂ có thể bảo tồn',
				dyshemoglobin.findings.length ? dyshemoglobin.findings[0].message : 'Có bối cảnh phơi nhiễm liên quan.',
				[
					{
						label: 'COHb',
						causes: [
							'Khói cháy, khí thải động cơ, máy phát điện hoặc đốt than trong không gian kín',
							'Methylene chloride và phơi nhiễm nghề nghiệp phù hợp'
						]
					},
					{
						label: 'MetHb',
						causes: [
							'Dapsone, benzocaine/prilocaine và các thuốc/chất oxy hóa',
							'Nitrate/nitrite, aniline, nitric oxide hoặc rasburicase trong bối cảnh nguy cơ'
						]
					}
				],
				'Xác nhận bằng co-oximetry; PaO₂ và pulse oximetry thông thường không đủ để loại trừ.'
			);
		}

		return atlas;
	}

	function buildDifferential(input, classification, anionGap, osmolalGap, oxygenation, compensation, hyperglycemia, lactateAssessment, dyshemoglobin) {
		var map = {};
		var processes = inferProcesses(classification, compensation);
		var metabolicAcidosis = processes.metabolicAcidosis;
		var metabolicAlkalosis = processes.metabolicAlkalosis;
		var respiratoryAcidosis = processes.respiratoryAcidosis;
		var respiratoryAlkalosis = processes.respiratoryAlkalosis;

		function add(id, name, priority, rationale, tests) {
			if (!map[id]) {
				map[id] = {
					id: id,
					name: name,
					priority: priority,
					rationale: [],
					tests: []
				};
			}
			if (priority > map[id].priority) {
				map[id].priority = priority;
			}
			(rationale || []).forEach(function (item) {
				if (map[id].rationale.indexOf(item) < 0) {
					map[id].rationale.push(item);
				}
			});
			(tests || []).forEach(function (item) {
				if (map[id].tests.indexOf(item) < 0) {
					map[id].tests.push(item);
				}
			});
		}

		if (input.lactate !== null && input.lactate >= 2) {
			add('lactic-acidosis', metabolicAcidosis || input.hco3 < 22
				? 'Toan lactic/tăng lactat'
				: 'Tăng lactat (chưa đồng nghĩa toan lactic)', input.lactate >= 4 ? 3 : 2,
				[
					'Lactat ' + round(input.lactate, 1) + ' mmol/L.',
					hasContext(input, 'shock') ? 'Có sốc/giảm tưới máu.' : '',
					hasContext(input, 'sepsis') ? 'Có nhiễm trùng/sepsis.' : ''
				].filter(Boolean),
				['Theo dõi lactat động học; đánh giá tưới máu, huyết động, nhiễm trùng, thiếu máu cục bộ vùng, thuốc và chức năng gan.']);
			if (!hasContext(input, 'shock') || hasContext(input, 'seizure') || hasContext(input, 'liver-disease') || hasContext(input, 'lactate-drug')) {
				add('non-hypoperfusion-lactate', 'Tăng lactat không do giảm tưới máu đơn thuần', 2,
					[
						hasContext(input, 'seizure') ? 'Có co giật gần đây.' : '',
						hasContext(input, 'liver-disease') ? 'Có bệnh gan/giảm thanh thải.' : '',
						hasContext(input, 'lactate-drug') ? 'Có thuốc liên quan tăng lactat.' : '',
						'Giảm tưới máu không phải cơ chế duy nhất của tăng lactat.'
					].filter(Boolean),
					['Rà soát co giật/công thở, catecholamine, metformin, linezolid, propofol, thiamine, bệnh gan và bệnh ty thể theo bối cảnh.']);
			}
		}

		if ((metabolicAcidosis || input.hco3 < 22) && input.ketones !== null && input.ketones >= 0.6) {
			var measuredKetoPriority = input.ketones >= 3
				&& (hasContext(input, 'diabetes') || (input.glucoseMmol !== null && input.glucoseMmol >= 11.1))
				? 3
				: 2;
			add('ketoacidosis', 'Nhiễm toan ceton', measuredKetoPriority,
				[
					'Ceton máu ' + round(input.ketones, 1) + ' mmol/L.',
					hasContext(input, 'diabetes') ? 'Có đái tháo đường/tăng đường huyết.' : '',
					hasContext(input, 'alcohol-starvation') ? 'Có rượu hoặc nhịn đói.' : '',
					hasContext(input, 'sglt2') ? 'Có dùng SGLT2; cần nghĩ DKA dù glucose không quá cao.' : ''
				].filter(Boolean),
				['β-hydroxybutyrat/ceton máu, glucose, K⁺, creatinin, độ thẩm thấu và tìm yếu tố khởi phát.']);
		}

		if (input.glucoseMmol !== null && input.glucoseMmol >= 33.3) {
			var effectiveOsm = hyperglycemia.effectiveOsm;
			var hyperosmolar = (effectiveOsm !== null && effectiveOsm > 300)
				|| (input.measuredOsm !== null && input.measuredOsm > 320);
			var overlap = (input.ketones !== null && input.ketones >= 3) || input.ph < 7.3 || input.hco3 < 15;
			add(
				'hyperglycemic-crisis',
				hyperosmolar
					? (overlap ? 'Cơn tăng đường huyết ưu trương, cân nhắc thể phối hợp DKA–HHS' : 'Hội chứng tăng áp lực thẩm thấu do tăng đường huyết (HHS)')
					: 'Tăng đường huyết nặng – cần loại trừ HHS/DKA',
				hyperosmolar ? 3 : 2,
				[
					'Glucose ' + round(input.glucoseMmol, 1) + ' mmol/L.',
					effectiveOsm !== null ? 'Độ thẩm thấu hiệu dụng ước tính ' + round(effectiveOsm, 1) + ' mOsm/kg.' : '',
					hyperglycemia.correctedSodium !== null ? 'Na⁺ hiệu chỉnh ước tính ' + round(hyperglycemia.correctedSodium, 1) + ' mmol/L.' : '',
					input.measuredOsm !== null ? 'Độ thẩm thấu đo được ' + round(input.measuredOsm, 1) + ' mOsm/kg.' : '',
					overlap ? 'Có ceton hoặc thành phần toan gợi ý khả năng thể phối hợp.' : ''
				].filter(Boolean),
				['Đánh giá tri giác, glucose, Na⁺ hiệu chỉnh, K⁺, creatinin, ceton, độ thẩm thấu hiệu dụng/toàn phần và yếu tố khởi phát.']
			);
		}

		if (input.cohb !== null && input.cohb > (hasContext(input, 'smoker') ? 9 : 2)) {
			add(
				'carbon-monoxide',
				'Phơi nhiễm/ngộ độc carbon monoxide',
				input.cohb >= 25 || hasContext(input, 'smoke-fire') ? 3 : 2,
				[
					'COHb ' + round(input.cohb, 1) + '%.',
					hasContext(input, 'smoke-fire') ? 'Có bối cảnh khói cháy/khí thải hoặc không gian kín.' : '',
					'PaO₂ hoặc SpO₂ bình thường không loại trừ thiếu oxy mô do CO.'
				].filter(Boolean),
				['Co-oximetry lặp lại theo diễn biến; khai thác nguồn phơi nhiễm, thời gian đã thở oxy, ECG/troponin và đánh giá thần kinh khi phù hợp.']
			);
		}
		if (input.methb !== null && input.methb > 1.5) {
			add(
				'methemoglobinemia',
				'Methemoglobinemia mắc phải hoặc bẩm sinh',
				input.methb >= 20 || hasContext(input, 'oxidant-drug') ? 3 : 2,
				[
					'MetHb ' + round(input.methb, 1) + '%.',
					hasContext(input, 'oxidant-drug') ? 'Có thuốc/chất oxy hóa liên quan.' : '',
					'PaO₂ có thể bảo tồn dù vận chuyển oxy bị suy giảm.'
				].filter(Boolean),
				['Co-oximetry lặp lại, rà soát dapsone/thuốc tê/nitrate–nitrite/chất oxy hóa, công thức máu và G6PD khi phù hợp.']
			);
		}

		if (oxygenation.available && (
			(oxygenation.pfRatio !== null && oxygenation.pfRatio <= 300)
			|| input.pao2 < 60
			|| (input.sao2 !== null && input.sao2 < 90)
		)) {
			var oxygenPriority = input.pao2 < 60 || (oxygenation.pfRatio !== null && oxygenation.pfRatio <= 200) ? 3 : 2;
			var mechanismName = oxygenation.aaState === 'high'
				? 'Giảm oxy máu với A–a tăng: V/Q không tương xứng, shunt hoặc rối loạn khuếch tán'
				: (oxygenation.aaState === 'not-high'
					? 'Giảm oxy máu với A–a không tăng: giảm thông khí hoặc giảm oxy hít vào'
					: 'Nguyên nhân giảm oxy máu cần định danh');
			add('hypoxemia-mechanism', mechanismName, oxygenPriority,
				[
					input.pao2 < 60 ? 'PaO₂ < 60 mmHg.' : '',
					oxygenation.pfRatio !== null ? 'P/F ' + oxygenation.pfRatio + '.' : '',
					oxygenation.aaState === 'high' ? 'A–a tăng so với ước tính theo tuổi trên khí phòng.' : '',
					oxygenation.aaState === 'not-high' ? 'A–a không tăng theo ước tính trên khí phòng.' : ''
				].filter(Boolean),
				['Khám hô hấp và huyết động; X-quang/siêu âm phổi, ECG và xét nghiệm/hình ảnh theo xác suất viêm phổi, phù phổi, xẹp phổi, tràn khí hoặc thuyên tắc phổi.']);
		}

		if (metabolicAcidosis && anionGap.available && anionGap.state === 'high') {
			if ((input.lactate !== null && input.lactate >= 2) || hasContext(input, 'sepsis') || hasContext(input, 'shock') || hasContext(input, 'seizure')) {
				add('lactic-acidosis', 'Toan lactic', input.lactate !== null && input.lactate >= 4 ? 3 : 2,
					[
						input.lactate !== null ? 'Lactat ' + round(input.lactate, 1) + ' mmol/L.' : 'Có bối cảnh làm tăng lactat.',
						hasContext(input, 'shock') ? 'Có sốc/giảm tưới máu.' : '',
						hasContext(input, 'sepsis') ? 'Có nhiễm trùng/sepsis.' : ''
					].filter(Boolean),
					['Theo dõi lactat động học; đánh giá tưới máu, huyết động, nhiễm trùng và chức năng gan.']);
			}

			if ((input.ketones !== null && input.ketones >= 0.6) || hasContext(input, 'diabetes') || hasContext(input, 'alcohol-starvation') || hasContext(input, 'sglt2')) {
				var dkaPriority = input.ketones !== null && input.ketones >= 3 && (hasContext(input, 'diabetes') || (input.glucoseMmol !== null && input.glucoseMmol >= 11.1)) ? 3 : 2;
				add('ketoacidosis', 'Nhiễm toan ceton', dkaPriority,
					[
						input.ketones !== null ? 'Ceton máu ' + round(input.ketones, 1) + ' mmol/L.' : 'Có bối cảnh nguy cơ tạo ceton.',
						hasContext(input, 'diabetes') ? 'Có đái tháo đường/tăng đường huyết.' : '',
						hasContext(input, 'alcohol-starvation') ? 'Có rượu hoặc nhịn đói.' : '',
						hasContext(input, 'sglt2') ? 'Có dùng SGLT2; không yêu cầu glucose tăng rất cao để nghi DKA.' : ''
					].filter(Boolean),
					['β-hydroxybutyrat/ceton máu, glucose, K⁺, creatinin, độ thẩm thấu và tìm yếu tố khởi phát.']);
			}

			if (hasContext(input, 'renal-failure') || (input.creatinineUmol !== null && input.creatinineUmol > 265)) {
				add('uremia', 'Toan chuyển hóa do suy thận/uremia', 2,
					['Có suy thận hoặc creatinin tăng rõ.'],
					['Creatinin/eGFR, urê, K⁺, nước tiểu và đánh giá chỉ định hội chẩn thận–lọc máu.']);
			}

			if (hasContext(input, 'toxic-alcohol') || (osmolalGap.available && osmolalGap.gap > 10)) {
				add('toxic-alcohol', 'Ngộ độc methanol/ethylene glycol hoặc chất tan ngoại sinh', osmolalGap.available && osmolalGap.gap > 20 ? 3 : 2,
					[
						hasContext(input, 'toxic-alcohol') ? 'Có bối cảnh nghi phơi nhiễm cồn độc.' : '',
						osmolalGap.available ? 'Khoảng trống thẩm thấu ' + round(osmolalGap.gap, 1) + ' mOsm/kg.' : ''
					].filter(Boolean),
					['Định lượng độc chất nếu có; độ thẩm thấu, ethanol, chức năng thận, Ca²⁺, soi tinh thể niệu và hội chẩn chống độc.']);
			}

			if (hasContext(input, 'salicylate') || (respiratoryAlkalosis && metabolicAcidosis)) {
				add('salicylate', 'Ngộ độc salicylat', hasContext(input, 'salicylate') ? 3 : 2,
					['Mẫu hình toan chuyển hóa tăng AG kèm kiềm hô hấp hoặc có tiền sử dùng salicylat.'],
					['Nồng độ salicylat lặp lại theo diễn biến, glucose, K⁺, chức năng thận và ECG.']);
			}

			add('other-hagma', 'Nguyên nhân HAGMA khác', 1,
				['Cần rà soát thuốc/độc chất và nguyên nhân ít gặp khi các nhóm chính chưa giải thích đầy đủ.'],
				['Rà soát thuốc (kể cả paracetamol kéo dài/5-oxoproline), propylene glycol, D-lactat và độc chất theo bệnh sử.']);
		}

		if (metabolicAcidosis && anionGap.available && anionGap.state !== 'high') {
			if (hasContext(input, 'diarrhea') || hasContext(input, 'gi-fistula')) {
				add('gi-loss', 'Mất HCO₃⁻ qua đường tiêu hóa', 3,
					[
						hasContext(input, 'diarrhea') ? 'Có tiêu chảy hoặc mất dịch tiêu hóa dưới.' : '',
						hasContext(input, 'gi-fistula') ? 'Có rò/dẫn lưu tụy–mật–ruột hoặc hậu môn nhân tạo.' : ''
					].filter(Boolean),
					['Đánh giá lượng mất dịch, K⁺, Mg²⁺ và chức năng thận.']);
			}
			if (hasContext(input, 'saline-load')) {
				add('hyperchloremic', 'Toan tăng Cl⁻ do truyền NaCl 0,9%', 3,
					['Có tiền sử tải chloride và AG không tăng.'],
					['Đối chiếu cân bằng dịch, chloride động học và chức năng thận.']);
			}
			add('rta', 'Toan ống thận', input.urinePh !== null && input.urinePh > 5.5 ? 2 : 1,
				[input.urinePh !== null ? 'pH niệu ' + round(input.urinePh, 1) + '; cần diễn giải cùng K⁺ và khả năng acid hóa niệu.' : 'Chưa đủ dữ liệu niệu để loại trừ.'],
				['pH niệu, Na⁺/K⁺/Cl⁻ niệu cùng thời điểm, khoảng trống anion niệu, K⁺ và đánh giá thuốc.']);
			if (hasContext(input, 'carbonic-anhydrase')) {
				add('carbonic-anhydrase', 'Mất HCO₃⁻ do ức chế carbonic anhydrase', 3,
					['Có acetazolamide/topiramate hoặc thuốc liên quan.'],
					['Rà soát thuốc, K⁺, Cl⁻, chức năng thận và chỉ định tiếp tục thuốc.']);
			}
			if (hasContext(input, 'renal-failure')) {
				add('early-renal', 'Suy thận với toan khoảng trống anion chưa tăng', 2,
					['Có suy thận.'],
					['Creatinin/eGFR, urê, K⁺ và diễn biến điện giải.']);
			}
			if (input.sodium !== null && input.potassium !== null && input.sodium < 135 && input.potassium > 5) {
				add('adrenal', 'Giảm aldosteron/suy thượng thận', 2,
					['Hạ Na⁺ kèm tăng K⁺ và toan chuyển hóa không tăng AG.'],
					['Cortisol, ACTH, renin/aldosteron và rà soát thuốc ảnh hưởng hệ RAA khi phù hợp.']);
			}
		}

		if (metabolicAcidosis && !anionGap.available) {
			add('unclassified-metabolic-acidosis', 'Toan chuyển hóa chưa phân nhóm được', 2,
				['Chưa đủ Na⁺ và Cl⁻ để tính khoảng trống anion.'],
				['Bổ sung Na⁺, Cl⁻ và albumin cùng thời điểm.']);
		}

		if (metabolicAlkalosis) {
			if (hasContext(input, 'vomiting')) {
				add('gastric-acid-loss', 'Mất HCl do nôn/hút dạ dày', 3,
					['Có nôn hoặc hút dịch dạ dày.'],
					['Đánh giá thể tích, Cl⁻ niệu, K⁺/Mg²⁺ và lượng dịch tiêu hóa mất.']);
			}
			if (hasContext(input, 'diuretic')) {
				add('diuretic-alkalosis', 'Kiềm chuyển hóa liên quan lợi tiểu', 3,
					['Đang hoặc mới dùng lợi tiểu.'],
					['Đối chiếu thời điểm liều cuối, Cl⁻ niệu, thể tích, K⁺, Mg²⁺ và chức năng thận.']);
			}
			if (hasContext(input, 'mineralocorticoid') || hasContext(input, 'hypertension')) {
				add('mineralocorticoid-excess', 'Cường mineralocorticoid', 2,
					[
						hasContext(input, 'mineralocorticoid') ? 'Có bối cảnh nghi cường mineralocorticoid.' : '',
						hasContext(input, 'hypertension') ? 'Có tăng huyết áp.' : ''
					].filter(Boolean),
					['Huyết áp, K⁺/Mg²⁺, renin–aldosteron và rà soát corticoid/cam thảo khi phù hợp.']);
			}
			if (hasContext(input, 'alkali-load')) {
				add('alkali-load', 'Tải kiềm ngoại sinh', 2,
					['Có bicarbonate/citrate/antacid hoặc tải calcium–alkali.'],
					['Rà soát dịch/thuốc, chức năng thận, Ca²⁺ và cân bằng dịch.']);
			}
			if (input.urineChloride !== null && input.urineChloride < 20) {
				add('chloride-responsive-alkalosis', 'Kiềm chuyển hóa đáp ứng chloride/giảm thể tích', 3,
					['Cl⁻ niệu < 20 mmol/L.'],
					['Đánh giá thể tích tuần hoàn, nôn/hút dạ dày, K⁺, Mg²⁺ và tiền sử lợi tiểu.']);
			} else if (input.urineChloride !== null && input.urineChloride >= 20) {
				add('chloride-resistant-alkalosis', 'Kiềm chuyển hóa Cl⁻ niệu không thấp', 3,
					['Cl⁻ niệu ≥ 20 mmol/L.'],
					['Rà soát lợi tiểu đang dùng, huyết áp, K⁺/Mg²⁺; renin/aldosteron khi nghi cường mineralocorticoid.']);
			} else {
				add('metabolic-alkalosis-causes', 'Nôn/hút dạ dày, lợi tiểu hoặc cường mineralocorticoid', 2,
					[
						hasContext(input, 'vomiting') ? 'Có nôn/hút dịch dạ dày.' : '',
						hasContext(input, 'diuretic') ? 'Đang dùng lợi tiểu.' : '',
						'Chưa có Cl⁻ niệu để phân nhóm.'
					].filter(Boolean),
					['Cl⁻ niệu, K⁺, Mg²⁺, đánh giá thể tích và huyết áp.']);
			}
		}

		if (respiratoryAcidosis) {
			if (hasContext(input, 'copd') || hasContext(input, 'airway-obstruction')) {
				add('airway-obstruction', 'Giảm thông khí do COPD/hen hoặc tắc nghẽn đường thở', 3,
					[hasContext(input, 'airway-obstruction') ? 'Có nguy cơ dị vật, nút nhầy hoặc tắc/gập ống nội khí quản.' : 'Có bệnh tắc nghẽn đường thở.'],
					['Khám đường thở, lưu lượng thở ra, X-quang/phổi và đáp ứng điều trị giãn phế quản.']);
			}
			if (hasContext(input, 'cns-depressant')) {
				add('cns-depression', 'Ức chế trung tâm hô hấp do thuốc/chất', 3,
					['Có an thần, opioid hoặc tác nhân ức chế thần kinh trung ương.'],
					['Rà soát thời điểm/liều thuốc, tri giác, nhịp thở và độc chất khi phù hợp.']);
			}
			if (hasContext(input, 'neuromuscular')) {
				add('neuromuscular-hypoventilation', 'Giảm thông khí do bệnh thần kinh–cơ', 3,
					['Có bệnh thần kinh–cơ.'],
					['Dung tích sống, áp lực hít vào, phản xạ bảo vệ đường thở và đánh giá chuyên khoa.']);
			}
			if (hasContext(input, 'cns-injury')) {
				add('cns-injury-hypoventilation', 'Giảm drive do tổn thương thần kinh trung ương', 3,
					['Có tổn thương não/thân não hoặc giảm tri giác.'],
					['GCS, đồng tử, hình ảnh thần kinh, thuốc và khả năng bảo vệ đường thở.']);
			}
			if (hasContext(input, 'chest-wall')) {
				add('chest-wall-hypoventilation', 'Hạn chế bơm hô hấp do thành ngực/phổi nặng', 2,
					['Có bệnh thành ngực, béo phì, tràn khí hoặc bệnh nhu mô nặng.'],
					['Khám cơ học hô hấp, hình ảnh ngực, dung tích sống và đánh giá công thở.']);
			}
			if (hasContext(input, 'ohs-osa')) {
				add('ohs', 'Hội chứng giảm thông khí do béo phì/OSA', 2,
					['Có OHS/OSA hoặc béo phì.'],
					['HCO₃⁻ nền, khí máu khi ổn định, đa ký hô hấp/giấc ngủ và đánh giá thông khí.']);
			}
			if (['niv', 'invasive'].indexOf(input.oxygenDevice) >= 0) {
				add('ventilator-hypoventilation', 'Thông khí phút không đủ hoặc không đồng bộ máy–người bệnh', 2,
					['Đang được hỗ trợ thông khí.'],
					['Kiểm tra Vt, tần số, thông khí phút, rò khí, đường thở và dạng sóng máy thở.']);
			}
			var respiratoryCauseIds = [
				'airway-obstruction',
				'cns-depression',
				'cns-injury-hypoventilation',
				'neuromuscular-hypoventilation',
				'chest-wall-hypoventilation',
				'ohs',
				'ventilator-hypoventilation'
			];
			if (!respiratoryCauseIds.some(function (id) { return Boolean(map[id]); })) {
				add('other-hypoventilation', 'Nguyên nhân giảm thông khí khác', 2,
					['Toan hô hấp chưa có dữ kiện nguyên nhân rõ.'],
					['Đánh giá đường thở, phổi–thành ngực, tri giác, thuốc và chức năng thần kinh–cơ.']);
			}
		}

		if (respiratoryAlkalosis) {
			if (oxygenation.available && ((oxygenation.pfRatio !== null && oxygenation.pfRatio <= 300) || input.pao2 < 60)) {
				add('hypoxemic-hyperventilation', 'Tăng thông khí do giảm oxy máu', 3,
					['Có suy giảm oxy hóa.'],
					['Đánh giá bệnh phổi, phù phổi, viêm phổi, tràn khí và bệnh mạch phổi.']);
			}
			if (hasContext(input, 'sepsis')) {
				add('sepsis-hyperventilation', 'Tăng thông khí do sepsis', 3,
					['Có nhiễm trùng/sepsis.'],
					['Đánh giá ổ nhiễm, cấy bệnh phẩm, lactat và rối loạn chức năng cơ quan.']);
			}
			if (hasContext(input, 'fever')) {
				add('fever-hyperventilation', 'Tăng thông khí liên quan sốt/tăng chuyển hóa', 2,
					['Có sốt hoặc tăng chuyển hóa.'],
					['Tìm nguyên nhân sốt, nhiễm trùng, thuốc và đánh giá huyết động.']);
			}
			if (hasContext(input, 'pulmonary-embolism')) {
				add('pulmonary-embolism', 'Thuyên tắc phổi', 3,
					['Có bối cảnh nghi thuyên tắc phổi.'],
					['Xác suất lâm sàng, ECG, D-dimer hoặc CTPA theo chỉ định.']);
			}
			if (hasContext(input, 'high-altitude')) {
				add('high-altitude', 'Giảm oxy khí hít vào do độ cao', 3,
					['Có bối cảnh độ cao/áp suất khí quyển thấp.'],
					['Xác minh độ cao, áp suất khí quyển, SpO₂/PaO₂ và loại trừ bệnh phổi kèm theo.']);
			}
			if (hasContext(input, 'cns-injury')) {
				add('cns-hyperventilation', 'Tăng thông khí do tổn thương thần kinh trung ương', 2,
					['Có chấn thương sọ não, đột quỵ hoặc bệnh lý CNS.'],
					['Đánh giá thần kinh, hình ảnh học, đau/sốt và áp lực nội sọ khi có chỉ định.']);
			}
			if (hasContext(input, 'pain-anxiety')) {
				add('pain-anxiety', 'Đau/lo âu hoặc tăng thông khí chức năng', 2,
					['Có đau, lo âu hoặc thở nhanh.'],
					['Chỉ kết luận sau khi loại trừ thiếu oxy, sepsis, bệnh phổi–mạch phổi và độc chất.']);
			}
			if (hasContext(input, 'pregnancy')) {
				add('pregnancy-alkalosis', 'Kiềm hô hấp sinh lý liên quan thai kỳ', 2,
					['Có thai kỳ.'],
					['Đối chiếu tuổi thai, HCO₃⁻ và loại trừ bệnh lý hô hấp hoặc chuyển hóa kèm theo.']);
			}
			if (hasContext(input, 'liver-disease')) {
				add('liver-alkalosis', 'Kiềm hô hấp liên quan bệnh gan', 2,
					['Có bệnh gan.'],
					['Đánh giá mức độ suy gan, nhiễm trùng, cổ trướng và biến chứng hô hấp.']);
			}
			if (['niv', 'invasive'].indexOf(input.oxygenDevice) >= 0) {
				add('ventilator-overassistance', 'Thông khí phút quá mức do máy thở', 2,
					['Đang hỗ trợ thông khí.'],
					['Kiểm tra Vt, tần số, hỗ trợ áp lực, drive hô hấp và dạng sóng máy thở.']);
			}
		}

		if (!Object.keys(map).length) {
			add('no-clear-disorder', 'Chưa có chẩn đoán phân biệt ưu thế từ bộ dữ liệu hiện tại', 1,
				['Khí máu chưa cho thấy mẫu hình rõ hoặc thiếu bối cảnh lâm sàng.'],
				['Đối chiếu triệu chứng, dấu hiệu sinh tồn, diễn biến và khoảng tham chiếu của labo.']);
		}

		return Object.keys(map).map(function (key) {
			return map[key];
		}).sort(function (a, b) {
			return b.priority - a.priority || a.name.localeCompare(b.name, 'vi');
		});
	}

	function buildAdditionalTests(input, classification, compensation, anionGap, osmolalGap, differential, sanity, sampleQuality, lactateAssessment, dyshemoglobin) {
		var items = [];
		var metabolicAcidosis = anionGap.relevant;
		function add(group, test, reason) {
			var key = group + '|' + test;
			if (!items.some(function (item) { return item.key === key; })) {
				items.push({ key: key, group: group, test: test, reason: reason });
			}
		}

		if (sanity.length || sampleQuality.issues.length || !input.caseSummary) {
			add('Xác minh ban đầu', 'Đối chiếu phiếu gốc, loại mẫu, thời điểm lấy, FiO₂/thiết bị và chất lượng mẫu', 'Loại trừ sai số trước khi mở rộng suy luận.');
		}
		if (sampleQuality.level === 'danger') {
			add('Khẩn', 'Lấy lại mẫu đúng kỹ thuật nếu kết quả có thể làm thay đổi xử trí', 'Có bọt khí, nhiễm đường truyền, vi cục hoặc chậm xử lý đáng kể.');
		}
		if (metabolicAcidosis && !anionGap.available) {
			add('Ưu tiên', 'Na⁺, Cl⁻ và albumin cùng thời điểm', 'Phân loại toan chuyển hóa và hiệu chỉnh khoảng trống anion.');
		}
		if (metabolicAcidosis && input.lactate === null) {
			add('Ưu tiên', 'Lactat máu', 'Loại trừ toan lactic.');
		}
		if (lactateAssessment.available && lactateAssessment.state !== 'normal') {
			add('Ưu tiên', 'Lactat lặp lại theo diễn biến với điều kiện lấy mẫu tương đương', 'Đánh giá xu hướng song song với tưới máu và đáp ứng điều trị.');
			add('Theo định hướng', 'Khám tưới máu, huyết động, chức năng gan và rà soát thuốc/tác nhân tăng lactat', 'Phân biệt tăng tạo, giảm thanh thải và nguyên nhân không do giảm tưới máu.');
		}
		if (metabolicAcidosis && input.ketones === null) {
			add('Ưu tiên', 'β-hydroxybutyrat/ceton máu và glucose', 'Loại trừ nhiễm toan ceton, kể cả DKA đường huyết không quá cao.');
		}
		if (metabolicAcidosis && input.creatinineUmol === null) {
			add('Ưu tiên', 'Creatinin/eGFR, urê và K⁺', 'Đánh giá suy thận và rối loạn điện giải kèm theo.');
		}
		if (anionGap.available && anionGap.state === 'high' && !osmolalGap.available) {
			add('Theo định hướng', 'Độ thẩm thấu đo được cùng Na⁺, glucose và urê/BUN', 'Tính khoảng trống thẩm thấu khi HAGMA chưa rõ nguyên nhân hoặc nghi độc chất.');
		}
		if (metabolicAcidosis && anionGap.available && anionGap.state !== 'high') {
			add('Theo định hướng', 'Na⁺, K⁺, Cl⁻ niệu và pH niệu cùng thời điểm', 'Phân biệt mất bicarbonate ngoài thận với RTA; diễn giải cùng K⁺ và chức năng thận.');
		}
		if (inferProcesses(classification, compensation).metabolicAlkalosis && input.urineChloride === null) {
			add('Ưu tiên', 'Cl⁻ niệu tại thời điểm chưa can thiệp nếu khả thi', 'Phân nhóm kiềm chuyển hóa; đối chiếu thời điểm dùng lợi tiểu.');
		}

		differential.forEach(function (diagnosis) {
			diagnosis.tests.forEach(function (test) {
				add(diagnosis.priority >= 3 ? 'Ưu tiên theo chẩn đoán' : 'Theo định hướng', test, diagnosis.name);
			});
		});

		if (input.potassium !== null && (input.potassium < 3 || input.potassium > 6)) {
			add('Khẩn', 'Điện tim và kiểm tra lại K⁺', 'K⁺ bất thường rõ.');
		}
		if (dyshemoglobin.findings.length || hasContext(input, 'smoke-fire') || hasContext(input, 'oxidant-drug')) {
			add('Khẩn', 'Co-oximetry (O₂Hb, COHb, MetHb) và đánh giá phơi nhiễm', 'PaO₂/SpO₂ thông thường không loại trừ dyshemoglobin.');
		}
		if (classification.primaryType.indexOf('respiratory') >= 0 || classification.primaryType === 'mixed_acidosis' || classification.primaryType === 'mixed_alkalosis') {
			add('Theo định hướng', 'Đánh giá nhịp thở, thông khí phút, tri giác, thuốc và hình ảnh ngực', 'Tìm nguyên nhân rối loạn hô hấp.');
		}

		return items.map(function (item) {
			delete item.key;
			return item;
		});
	}

	function buildManagement(input, classification, consistency, oxygenation, alerts, differential, sampleQuality, lactateAssessment, dyshemoglobin) {
		var items = [];
		function add(urgency, title, text) {
			if (!items.some(function (item) { return item.title === title && item.text === text; })) {
				items.push({ urgency: urgency, title: title, text: text });
			}
		}

		if (alerts.some(function (alert) { return alert.level === 'critical' || alert.level === 'danger'; })) {
			add('immediate', 'Đánh giá và ổn định ban đầu', 'Đánh giá ABC, tri giác, huyết động và nhịp thở; theo dõi liên tục và báo bác sĩ phụ trách/đơn vị hồi sức tùy mức độ.');
		}
		if (consistency.level !== 'ok') {
			add('immediate', 'Xác minh kết quả', 'Kiểm tra lại loại mẫu, bọt khí, chậm phân tích, đơn vị và phiếu gốc; cân nhắc lấy lại khí máu trước thay đổi điều trị lớn.');
		}
		if (sampleQuality.level === 'danger') {
			add('immediate', 'Ưu tiên độ tin cậy của mẫu', 'Có lỗi tiền phân tích có thể làm thay đổi quyết định. Trao đổi labo, lấy lại mẫu đúng kỹ thuật và không trì hoãn ổn định ABC nếu người bệnh nguy kịch.');
		}
		if (oxygenation.available && ((oxygenation.pfRatio !== null && oxygenation.pfRatio <= 300) || input.pao2 < 60 || (input.sao2 !== null && input.sao2 < 90))) {
			var target = hasContext(input, 'copd') ? '88–92%' : '94–98%';
			add('immediate', 'Hỗ trợ oxy và đánh giá suy hô hấp', 'Chuẩn độ oxy theo mục tiêu SpO₂ tham khảo ' + target + ', đồng thời đánh giá công thở, tri giác và nhu cầu tăng bậc hỗ trợ hô hấp theo protocol tại cơ sở.');
		}

		var types = acidBaseTypes(classification);
		if (types.indexOf('respiratory_acidosis') >= 0 || types.indexOf('mixed_acidosis') >= 0) {
			add('priority', 'Khôi phục thông khí phế nang', 'Đảm bảo đường thở; tìm và xử trí tắc nghẽn, thuốc ức chế hô hấp, yếu cơ hoặc cài đặt máy thở. Cân nhắc NIV/thông khí xâm nhập dựa trên toàn trạng, không chỉ PaCO₂.');
		}
		if (types.indexOf('respiratory_alkalosis') >= 0 || types.indexOf('mixed_alkalosis') >= 0) {
			add('cause', 'Xử trí nguyên nhân tăng thông khí', 'Ưu tiên loại trừ thiếu oxy, sepsis, bệnh phổi–mạch phổi, đau và độc chất; không dùng túi giấy hoặc ức chế hô hấp theo phản xạ.');
		}
		if (types.indexOf('metabolic_acidosis') >= 0 || types.indexOf('mixed_acidosis') >= 0) {
			add('priority', 'Điều trị nguyên nhân toan chuyển hóa', 'Khôi phục tưới máu khi giảm tưới máu, kiểm soát nguồn nhiễm, xử trí DKA/suy thận/ngộ độc theo protocol tương ứng. Không sử dụng bicarbonat thường quy chỉ dựa trên một giá trị pH.');
		}
		if (types.indexOf('metabolic_alkalosis') >= 0 || types.indexOf('mixed_alkalosis') >= 0) {
			add('cause', 'Hiệu chỉnh yếu tố duy trì kiềm chuyển hóa', 'Đánh giá thể tích tuần hoàn, chloride, K⁺ và Mg²⁺; rà soát nôn/hút dạ dày, lợi tiểu và cường mineralocorticoid trước khi lựa chọn điều trị.');
		}

		if (differential.some(function (item) { return item.id === 'ketoacidosis' && item.priority >= 3; })) {
			add('priority', 'Kích hoạt protocol nhiễm toan ceton', 'Bù dịch, insulin và kali phải theo protocol DKA, theo dõi glucose/ceton/điện giải sát và tìm yếu tố khởi phát; công cụ không thay thế bảng liều.');
		}
		if (differential.some(function (item) { return item.id === 'hyperglycemic-crisis'; })) {
			add('priority', 'Kích hoạt protocol cơn tăng đường huyết', 'Đánh giá dịch, điện giải, áp lực thẩm thấu, tri giác và yếu tố khởi phát; dịch, kali và insulin phải theo protocol DKA/HHS cùng theo dõi sát, không dựa riêng vào khí máu.');
		}
		if (differential.some(function (item) { return item.id === 'toxic-alcohol' && item.priority >= 2; })) {
			add('immediate', 'Hội chẩn chống độc', 'Liên hệ đơn vị chống độc/hồi sức, lấy mẫu độc chất sớm và đánh giá chỉ định thuốc giải độc hoặc lọc máu theo protocol chuyên khoa.');
		}
		if (differential.some(function (item) { return item.id === 'carbon-monoxide'; })) {
			add('immediate', 'Kích hoạt xử trí phơi nhiễm CO', 'Đưa người bệnh khỏi nguồn phơi nhiễm, hỗ trợ oxy và hội chẩn chống độc/hồi sức theo triệu chứng, thai kỳ, tim–thần kinh và protocol; COHb đơn độc không quyết định độ nặng.');
		}
		if (differential.some(function (item) { return item.id === 'methemoglobinemia'; })) {
			add('immediate', 'Kích hoạt protocol methemoglobinemia', 'Ngừng tác nhân oxy hóa, hỗ trợ ABC, xác nhận bằng co-oximetry và hội chẩn chống độc/hồi sức; chỉ định điều trị đặc hiệu phụ thuộc triệu chứng, mức MetHb và bệnh kèm.');
		}
		if (lactateAssessment.available && lactateAssessment.state !== 'normal') {
			add('priority', 'Điều trị cơ chế làm tăng lactat', 'Tìm và xử trí sốc/thiếu oxy/thiếu máu cục bộ khi có, đồng thời rà soát co giật, công thở, thuốc, thiamine và thanh thải gan. Không truyền dịch chỉ để “hạ lactat” khi thiếu bằng chứng đáp ứng dịch.');
		}
		if (input.potassium !== null && (input.potassium < 3 || input.potassium > 6)) {
			add('immediate', 'Ưu tiên bất thường kali', 'Xác minh K⁺, theo dõi điện tim và hiệu chỉnh theo protocol; kali có thể thay đổi nhanh khi điều trị rối loạn toan–kiềm.');
		}

		add('reassess', 'Đánh giá lại sau can thiệp', 'Theo dõi lâm sàng, điện giải và khí máu theo diễn biến; diễn giải xu hướng thường có giá trị hơn một mẫu đơn lẻ.');
		return items;
	}

	function buildProtocolPath(input, sampleQuality, classification, compensation, anionGap, oxygenation, lactateAssessment, dyshemoglobin, alerts, differential, additionalTests) {
		var steps = [];

		function add(id, title, status, finding, nextAction) {
			steps.push({
				id: id,
				title: title,
				status: status,
				finding: finding,
				nextAction: nextAction
			});
		}

		add(
			'verify',
			'Xác minh mẫu và bối cảnh',
			sampleQuality.level === 'ok' ? 'complete' : (sampleQuality.level === 'danger' ? 'urgent' : 'caution'),
			sampleQuality.message + (sampleQuality.venousNote ? ' ' + sampleQuality.venousNote : ''),
			sampleQuality.issues.length
				? 'Giải quyết các yếu tố tiền phân tích và cân nhắc lấy lại mẫu trước quyết định lớn.'
				: 'Xác nhận thời điểm lấy, loại mẫu, FiO₂/thiết bị và thay đổi điều trị gần thời điểm lấy.'
		);

		var urgentAlerts = alerts.filter(function (item) {
			return item.level === 'critical' || item.level === 'danger';
		});
		add(
			'stabilize',
			'Sàng lọc bất thường đe dọa',
			urgentAlerts.length ? 'urgent' : 'complete',
			urgentAlerts.length
				? urgentAlerts.map(function (item) { return item.message; }).join(' ')
				: 'Chưa phát hiện ngưỡng cảnh báo nguy hiểm từ các dữ liệu đã nhập.',
			urgentAlerts.length
				? 'Đánh giá ABC, tri giác, huyết động, ECG và kích hoạt hỗ trợ/hội chẩn theo tình trạng.'
				: 'Tiếp tục diễn giải theo thứ tự, không bỏ qua khám lâm sàng.'
		);

		add(
			'primary',
			'Xác định pH và quá trình nguyên phát',
			classification.primaryType === 'indeterminate' ? 'missing' : (classification.primaryType.indexOf('mixed') >= 0 ? 'caution' : 'complete'),
			classification.phLabel + '. ' + classification.title + '.',
			classification.primaryType === 'indeterminate'
				? 'Đối chiếu phiếu gốc, khoảng tham chiếu labo và lấy lại mẫu nếu cần.'
				: 'Dùng hướng pH–PaCO₂–HCO₃⁻ để kiểm tra rối loạn nguyên phát và không gọi đáp ứng bù là một rối loạn mới khi còn trong khoảng dự kiến.'
		);

		var compensationConcern = compensation.mode === 'direct-mixed' || compensation.items.some(function (item) {
			return item.comparison.status !== 'within';
		});
		if (anionGap.deltaGap !== null && Math.abs(anionGap.deltaGap) >= 5) {
			compensationConcern = true;
		}
		add(
			'mixed',
			'Kiểm tra bù trừ và rối loạn phối hợp',
			compensationConcern ? 'caution' : 'complete',
			compensation.items.length
				? compensation.items.map(function (item) { return item.comparison.message; }).join(' ')
				: compensation.message,
			compensationConcern
				? 'Giữ tất cả thành phần phối hợp trong chẩn đoán và xử trí; dùng AG/khoảng trống delta khi có toan chuyển hóa.'
				: 'Mức bù không gợi ý thêm quá trình rõ; vẫn đối chiếu diễn biến thời gian.'
		);

		var highPriority = differential.filter(function (item) { return item.priority === 3; });
		add(
			'cause',
			'Định vị cơ chế và nguyên nhân',
			highPriority.length ? 'caution' : 'complete',
			highPriority.length
				? 'Hướng ưu tiên: ' + highPriority.map(function (item) { return item.name; }).join('; ') + '.'
				: 'Chưa có nguyên nhân được dữ liệu hiện tại nâng lên mức ưu tiên cao.',
			'Đối chiếu “bản đồ nguyên nhân”, chọn xét nghiệm có khả năng thay đổi xử trí và loại trừ nguyên nhân nguy hiểm trước.'
		);

		var missingPriority = additionalTests.filter(function (item) {
			return ['Khẩn', 'Ưu tiên', 'Ưu tiên theo chẩn đoán'].indexOf(item.group) >= 0;
		});
		var reassessmentText = lactateAssessment.trend
			? lactateAssessment.trend.message
			: 'Theo dõi lâm sàng và lặp lại xét nghiệm theo diễn biến hoặc sau can thiệp.';
		if (dyshemoglobin.findings.length) {
			reassessmentText += ' Cần theo dõi co-oximetry theo biểu hiện và protocol.';
		}
		if (oxygenation.available && oxygenation.mechanism) {
			reassessmentText += ' ' + oxygenation.mechanism;
		}
		add(
			'act',
			'Bổ sung dữ liệu, xử trí và đánh giá lại',
			missingPriority.length ? 'caution' : 'complete',
			missingPriority.length
				? 'Còn ' + missingPriority.length + ' xét nghiệm/đánh giá ưu tiên được đề xuất. ' + reassessmentText
				: reassessmentText,
			'Thực hiện theo mức khẩn, xử trí nguyên nhân và so sánh xu hướng với mẫu trước trong cùng điều kiện.'
		);

		return steps;
	}

	function buildSummary(result) {
		var input = result.input;
		var pco2 = displayPressure(input.paco2, input.gasPressureUnit);
		var pao2 = displayPressure(input.pao2, input.gasPressureUnit);
		var lines = ['PHÂN TÍCH KHÍ MÁU THEO PROTOCOL – v' + VERSION];

		if (input.caseSummary) {
			lines.push('Mô tả ca bệnh: ' + input.caseSummary);
		}
		lines.push(
			'pH ' + input.ph + '; PaCO₂ ' + pco2.value + ' ' + pco2.unit + '; HCO₃⁻ ' + input.hco3 + ' mmol/L'
			+ (pao2 ? '; PaO₂ ' + pao2.value + ' ' + pao2.unit : '') + '.'
		);
		lines.push('0. Protocol theo ca: ' + result.protocolPath.map(function (step) {
			return step.title + ' [' + step.status + ']';
		}).join(' → ') + '.');
		lines.push('1. Chất lượng mẫu: ' + result.sampleQuality.message + ' ' + result.consistency.message);
		lines.push('2. pH: ' + result.classification.phLabel + '.');
		lines.push('3. Rối loạn chính: ' + result.classification.title + '. ' + result.classification.explanation);
		if (result.conclusionReasoning.length) {
			lines.push('3a. Lập luận:');
			result.conclusionReasoning.forEach(function (reason) {
				lines.push('• ' + reason);
			});
		}
		if (result.compensation.items.length) {
			result.compensation.items.forEach(function (item) {
				lines.push('4. ' + item.label + ': ' + item.comparison.message);
			});
		} else {
			lines.push('4. Bù trừ: ' + result.compensation.message);
		}
		lines.push('5. Khoảng trống anion: ' + (result.anionGap.available
			? result.anionGap.effective + ' mmol/L (' + result.anionGap.stateLabel.toLowerCase() + ')'
				+ (result.anionGap.deltaGap !== null ? '; khoảng trống delta ' + result.anionGap.deltaGap + ' mmol/L.' : '.')
			: result.anionGap.message));
		lines.push('6. Oxy hóa: ' + (result.oxygenation.available
			? (result.oxygenation.pfRatio !== null ? 'P/F ' + result.oxygenation.pfRatio + '. ' : '') + result.oxygenation.message
			: result.oxygenation.message));
		if (result.lactateAssessment.available) {
			lines.push('7. Lactat: ' + result.lactateAssessment.value + ' mmol/L – ' + result.lactateAssessment.label + '. '
				+ (result.lactateAssessment.trend ? result.lactateAssessment.trend.message : result.lactateAssessment.message));
		}
		if (result.dyshemoglobin.findings.length) {
			lines.push('8. Co-oximetry: ' + result.dyshemoglobin.findings.map(function (item) {
				return item.message;
			}).join(' '));
		}
		lines.push('9. Chẩn đoán phân biệt: ' + result.differential.slice(0, 6).map(function (item) {
			return item.name;
		}).join('; ') + '.');
		if (result.causeAtlas.length) {
			lines.push('10. Bản đồ nguyên nhân cần rà soát: ' + result.causeAtlas.map(function (section) {
				return section.title;
			}).join('; ') + '.');
		}
		if (result.additionalTests.length) {
			lines.push('11. Xét nghiệm bổ sung: ' + result.additionalTests.slice(0, 10).map(function (item) {
				return item.test;
			}).join('; ') + '.');
		}
		lines.push('12. Hướng xử trí: ' + result.management.map(function (item) {
			return item.title + ' – ' + item.text;
		}).join(' '));
		lines.push('Lưu ý: Kết quả là công cụ hỗ trợ, không thay thế thăm khám và protocol tại cơ sở.');
		return lines.join('\n');
	}

	function inspectField(rawInput, fieldName) {
		var input = normalizeInput(rawInput);
		if (input._formatErrors[fieldName]) {
			return { state: 'invalid', message: input._formatErrors[fieldName] + ' Chỉ nhập số và một dấu thập phân.' };
		}

		var validation = validate(input);
		if (validation.fieldErrors[fieldName] && validation.fieldErrors[fieldName].length) {
			return { state: 'invalid', message: validation.fieldErrors[fieldName][0] };
		}

		var checks = assessReferenceRanges(input);
		var check = checks.find(function (item) {
			return item.field === fieldName;
		});
		if (!check) {
			return { state: 'empty', message: '' };
		}
		if (check.state === 'normal') {
			return { state: 'normal', message: 'Trong khoảng tham chiếu ' + check.reference + '.' };
		}
		return {
			state: check.state,
			message: (check.state === 'low' ? 'Thấp hơn' : (check.state === 'high' ? 'Cao hơn' : 'Ngoài')) + ' khoảng tham chiếu ' + check.reference + '. ' + check.note
		};
	}

	function analyze(rawInput) {
		var input = normalizeInput(rawInput);
		var validation = validate(input);
		if (validation.errors.length) {
			return {
				ok: false,
				input: input,
				errors: validation.errors,
				fieldErrors: validation.fieldErrors,
				warnings: validation.warnings
			};
		}

		var sampleQuality = assessSampleQuality(input);
		var consistency = assessConsistency(input);
		var classification = classifyAcidBase(input);
		var compensation = assessCompensation(classification, input);
		classification = resolveCandidateClassification(classification, compensation);
		var anionGap = assessAnionGap(input, classification, compensation);
		var conclusionReasoning = buildConclusionReasoning(input, classification, compensation, anionGap, consistency);
		var osmolalGap = assessOsmolalGap(input);
		var oxygenation = assessOxygenation(input);
		var lactateAssessment = assessLactate(input);
		var dyshemoglobin = assessDyshemoglobin(input);
		var hyperglycemia = assessHyperglycemia(input);
		var referenceChecks = assessReferenceRanges(input);
		var sanity = assessSanity(input, consistency, anionGap, oxygenation, validation.warnings);
		var alerts = assessAlerts(input, consistency, oxygenation, osmolalGap, sampleQuality, dyshemoglobin);
		var differential = buildDifferential(input, classification, anionGap, osmolalGap, oxygenation, compensation, hyperglycemia, lactateAssessment, dyshemoglobin);
		var causeAtlas = buildCauseAtlas(input, classification, anionGap, oxygenation, compensation, lactateAssessment, dyshemoglobin, hyperglycemia);
		var additionalTests = buildAdditionalTests(input, classification, compensation, anionGap, osmolalGap, differential, sanity, sampleQuality, lactateAssessment, dyshemoglobin);
		var management = buildManagement(input, classification, consistency, oxygenation, alerts, differential, sampleQuality, lactateAssessment, dyshemoglobin);
		var protocolPath = buildProtocolPath(input, sampleQuality, classification, compensation, anionGap, oxygenation, lactateAssessment, dyshemoglobin, alerts, differential, additionalTests);
		var result = {
			ok: true,
			input: input,
			warnings: validation.warnings,
			sampleQuality: sampleQuality,
			consistency: consistency,
			classification: classification,
			conclusionReasoning: conclusionReasoning,
			compensation: compensation,
			anionGap: anionGap,
			osmolalGap: osmolalGap,
			oxygenation: oxygenation,
			lactateAssessment: lactateAssessment,
			dyshemoglobin: dyshemoglobin,
			hyperglycemia: hyperglycemia,
			referenceChecks: referenceChecks,
			sanity: sanity,
			alerts: alerts,
			differential: differential,
			causeAtlas: causeAtlas,
			additionalTests: additionalTests,
			management: management,
			protocolPath: protocolPath
		};
		result.summary = buildSummary(result);
		return result;
	}

	return Object.freeze({
		version: VERSION,
		NORMAL: NORMAL,
		MMHG_PER_KPA: MMHG_PER_KPA,
		analyze: analyze,
		normalizeInput: normalizeInput,
		parseNumeric: parseNumeric,
		inspectField: inspectField,
		displayPressure: displayPressure,
		round: round
	});
}));

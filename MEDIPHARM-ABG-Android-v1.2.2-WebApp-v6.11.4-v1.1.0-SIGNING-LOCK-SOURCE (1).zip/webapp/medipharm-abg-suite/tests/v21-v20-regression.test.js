const assert=require('assert');
const oldCore=require('./fixtures/nah-abg-core-v2.0-canonical.js');
const newCore=require('../assets/js/nah-abg-core.js');
const cases=[
 {ph:7.40,paco2:40,hco3:24,pao2:95,fio2:21,sodium:140,chloride:104,albumin:40,albuminUnit:'gl'},
 {ph:7.21,paco2:25,hco3:10,pao2:92,fio2:21,sodium:138,chloride:100,albumin:40,albuminUnit:'gl',lactate:6},
 {ph:7.28,paco2:60,hco3:27,pao2:58,fio2:28,sodium:139,chloride:101,albumin:35,albuminUnit:'gl',chronicity:'acute'},
 {ph:7.36,paco2:60,hco3:33,pao2:55,fio2:28,sodium:140,chloride:98,albumin:38,albuminUnit:'gl',chronicity:'chronic'},
 {ph:7.52,paco2:28,hco3:23,pao2:90,fio2:21,sodium:138,chloride:103,albumin:42,albuminUnit:'gl'},
 {ph:7.50,paco2:48,hco3:36,pao2:72,fio2:30,sodium:140,chloride:92,albumin:40,albuminUnit:'gl'},
 {ph:7.10,paco2:60,hco3:18,pao2:60,fio2:35,sodium:140,chloride:106,albumin:30,albuminUnit:'gl'},
 {ph:7.40,paco2:20,hco3:12,pao2:98,fio2:21,sodium:140,chloride:100,albumin:40,albuminUnit:'gl'},
 {sampleType:'venous',ph:7.32,paco2:48,hco3:24,pao2:35,sodium:139,chloride:103,albumin:40,albuminUnit:'gl'},
 {ph:7.30,paco2:30,hco3:15,sodium:132,chloride:90,albumin:20,albuminUnit:'gl',glucose:30,glucoseUnit:'mmol',measuredOsm:320,urea:8,ureaUnit:'urea-mmol'}
];
const additive=new Set(['advancedCompensation','mixedDisorders','deltaAnalysis','acidBaseMap','stepByStepReasoning','oxygenationAdvanced']);
function legacyProjection(result){
  const out={};
  Object.keys(result).forEach(k=>{ if(!additive.has(k)) out[k]=result[k]; });
  return out;
}
cases.forEach((input,i)=>{
 const a=oldCore.analyze(input), b=newCore.analyze(input);
 assert.deepStrictEqual(legacyProjection(b),a,`legacy output changed for case ${i+1}`);
});
console.log(`ABG Suite v2.1 vs v2.0 legacy regression PASS (${cases.length}/${cases.length})`);

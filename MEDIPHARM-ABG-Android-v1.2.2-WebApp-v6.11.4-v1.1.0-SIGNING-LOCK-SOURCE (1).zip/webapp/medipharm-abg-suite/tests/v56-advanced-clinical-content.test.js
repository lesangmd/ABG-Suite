'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
const sources=JSON.parse(fs.readFileSync(path.join(root,'ADVANCED-CONTENT-SOURCES-v5.6.json'),'utf8'));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'ADVANCED-CONTENT-MANIFEST-v5.6.json'),'utf8'));
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('object not closed '+marker);}
function optionsFor(marker){const st=mod.indexOf(marker);assert(st>=0,marker);const en=mod.indexOf('</select>',st);return [...mod.slice(st,en).matchAll(/<option value="([^"]+)">/g)].map(m=>m[1]).filter(Boolean);}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
const demos=vm.runInNewContext('('+extractObject(ui,'var DEMOS = {')+')');
const meta=vm.runInNewContext('('+extractObject(ui,'var LEARNING_CASES = {')+')');
assert.strictEqual(Object.keys(demos).length,50);assert.strictEqual(Object.keys(meta).length,50);assert.deepStrictEqual(Object.keys(demos).sort(),Object.keys(meta).sort());
const mainCases=optionsFor('data-demo-select');const classroomCases=optionsFor('data-classroom-demo-select');
assert.strictEqual(mainCases.length,50);assert.strictEqual(classroomCases.length,50);assert.deepStrictEqual([...mainCases].sort(),Object.keys(demos).sort());assert.deepStrictEqual([...classroomCases].sort(),Object.keys(demos).sort());
assert.strictEqual((mod.match(/class="nah-abg__handbook-number"/g)||[]).length,50);assert.strictEqual((mod.match(/nah-abg__lesson-objectives/g)||[]).length,50);assert.strictEqual((mod.match(/data-lesson-quiz/g)||[]).length,50);
const lessonIds=['hb-ventilator-abg','hb-ventilator-serial','hb-ards-advanced','hb-niv-advanced','hb-hfnc-advanced','hb-shock-lactate','hb-cooximetry','hb-toxic-alcohol','hb-renal-metabolic','hb-pregnancy-advanced','hb-altitude-advanced'];
for(const id of lessonIds){const st=mod.indexOf('-'+id+'">');assert(st>=0,id);const en=mod.indexOf('</article>',st);const block=mod.slice(st,en);for(const cls of ['nah-abg__lesson-objectives','nah-abg__lesson-example','nah-abg__lesson-quiz'])assert(block.includes(cls),id+' '+cls);}
const newCases=['ventilator-low-vt-ards','ventilator-autopeep-copd','ventilator-hypercapnia-adjust','ventilator-overventilation-serial','niv-copd-response','niv-copd-failure','hfnc-pneumonia-response','hfnc-worsening-hypoxemia','septic-shock-lactate-clearance','septic-shock-lactate-persistent','co-exposure-delayed-sample','methemoglobin-benzocaine','methanol-late-osm-gap','ethylene-glycol-acidosis','ckd-acidosis-hyperkalemia','renal-tubular-acidosis','pregnancy-hyperemesis','pregnancy-respiratory-deterioration','altitude-acclimatization','altitude-pulmonary-edema'];
for(const k of newCases){assert(demos[k],k);assert(meta[k],k);assert(mainCases.includes(k),k+' main');assert(classroomCases.includes(k),k+' classroom');}
// Henderson-Hasselbalch internal consistency spot gate for all 20 new cases.
for(const k of newCases){const d=demos[k];const calc=0.03*d.paco2*Math.pow(10,d.ph-6.1);assert(Math.abs(calc-d.hco3)<=2.6,`${k}: HCO3 supplied ${d.hco3}, HH ${calc.toFixed(1)}`);}
assert.strictEqual(newCases.filter(k=>demos[k].serial_abg&&meta[k].serial_abg).length,8);
assert.strictEqual(manifest.serial_oriented_new_cases,8);
assert.strictEqual(manifest.handbook_lessons,50);assert.strictEqual(manifest.handbook_new,11);assert.strictEqual(manifest.clinical_cases,50);assert.strictEqual(manifest.clinical_cases_new,20);assert.strictEqual(manifest.assessment_items,220);assert.strictEqual(manifest.question_formats,6);assert.strictEqual(manifest.mock_test_packs,6);
assert.strictEqual(sources.runtime_remote_fetch,false);assert(sources.sources.length>=8);for(const id of ['ssc-2026','aarc-pva-2024','ers-hfnc-2022','cdc-co-2024','kdigo-ckd-2024','wms-altitude-2024'])assert(sources.sources.some(s=>s.id===id),id);
for(const text of ['50 bài tương tác','50 ca thực hành','50 bài học, 50 ca lâm sàng','<b>50 ca</b>'])assert(mod.includes(text),text);
assert(ui.includes('return total||50;'));
// No v5.6 scope creep into assessment/exam/access fundamentals.
assert(ui.includes('ASSESSMENT_V53_MIXED_QUESTIONS'));assert(mod.includes('220 câu đánh giá'));assert(plugin.includes("home_url('/phan-tich-khi-mau-app/')"));
console.log('PASS v5.6 advanced clinical content gate: 50 lessons / 50 cases / 20 new HH-consistent cases');

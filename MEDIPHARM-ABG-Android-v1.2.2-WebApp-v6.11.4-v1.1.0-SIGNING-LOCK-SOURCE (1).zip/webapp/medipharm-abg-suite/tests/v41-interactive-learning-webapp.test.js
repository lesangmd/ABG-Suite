const fs=require('fs'),assert=require('assert'),crypto=require('crypto');
const main=fs.readFileSync('medipharm-abg-suite.php','utf8');
const mod=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
const ui=fs.readFileSync('assets/js/nah-abg-ui.js','utf8');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
const core=fs.readFileSync('assets/js/nah-abg-core.js');
const launcherCss=fs.readFileSync('assets/css/nah-abg-launcher.css','utf8');
const readme=fs.readFileSync('readme.txt','utf8');
assert(main.includes('Version: 6.2.4'));assert(main.includes("const VERSION='6.2.4'"));assert(main.includes("add_shortcode('medipharm_abg_launcher'"));
assert(mod.includes('data-workspace-tab="home"'));assert(mod.includes('<span>Lý thuyết</span>')&&mod.includes('<span>Ôn tập</span>'));assert(mod.includes('data-workspace-panel="home"'));assert(mod.includes('data-workspace-panel="learn"'));
assert(mod.includes('data-classroom-demo-select'));assert(mod.includes('data-classroom-load-demo'));assert(mod.includes('Nạp ca mẫu vào công cụ'));
assert(mod.includes('data-learning-hub="cards"'));assert(mod.includes('data-learning-hub="exam"'));assert(mod.includes('data-theory-map-target="-hb-mixed"'));
assert(mod.includes('render_launcher'));assert(mod.includes("wp_enqueue_style( 'medipharm-abg-suite-launcher'"));assert(!mod.slice(mod.indexOf('public function render_launcher'),mod.indexOf('public function render_analyzer')).includes('enqueue_assets'));assert(launcherCss.includes('.nah-abg-launcher__compact-card'));assert(!launcherCss.includes('.nah-abg-launcher__mosaic')); // v5.7 compact one-card launcher supersedes legacy multi-card grid
assert(ui.includes('learningTabForWorkspace')&&ui.includes('workspaceMeta')&&ui.includes("requested==='theory'"));assert(ui.includes("searchParams.get('view')"));assert(ui.includes('data-classroom-load-demo'));
assert(css.includes('v4.1 — Interactive Learning WebApp Experience'));assert(css.includes('.nah-abg__home-grid'));assert(css.includes('.nah-abg__learning-hub'));assert(css.includes('.nah-abg__knowledge-map'));assert(css.includes('.nah-abg-launcher'));
assert(readme.includes('Stable tag: 6.2'));assert(readme.includes('= 4.1 ='));
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('v4.1 interactive learning webapp: PASS');

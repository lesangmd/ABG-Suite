const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'assets/css/nah-abg.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/nah-abg-ui.js'), 'utf8');
const php = fs.readFileSync(path.join(root, 'medipharm-abg-suite.php'), 'utf8');
function ok(cond, msg){ if(!cond){ console.error('FAIL:', msg); process.exit(1); } }
ok(/Version:\s*6\.2/.test(php), 'plugin version current release');
ok(js.includes("root.classList.toggle('nah-abg--menu-open', !!open)"), 'menu open state class synchronized');
ok(css.includes('.nah-abg.nah-abg--menu-open .nah-abg__hero'), 'open menu elevates hero stacking context');
ok(css.includes('z-index: 2147483000 !important'), 'hero z-index above sticky nav');
ok(css.includes('.nah-abg.nah-abg--menu-open .nah-abg__menu'), 'menu overlay z-index rule exists');
ok(css.includes('z-index: 2147483600 !important'), 'menu is top overlay');
console.log('PASS v4.2.5 menu z-index hotfix');

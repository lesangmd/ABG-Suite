const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const php=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function ok(x,m){if(!x)throw new Error(m)}
ok(php.includes("Version: 6.3.9") && php.includes("const VERSION='6.3.9'"),'version 6.3.9');
ok(php.includes('medipharm_abg_web_login'),'web login AJAX route');
ok(mod.includes('data-abg-web-login'),'compact login form');
ok(mod.includes('Tên đăng nhập hoặc email') && mod.includes('name="password"'),'two credential fields');
ok(!mod.includes('Lưu thông tin đăng nhập'),'provider save-login field removed from ABG form source');
ok(js.includes("postAccessRequest('medipharm_abg_web_login'"),'web login runtime');
ok(css.includes('.nah-abg [hidden]{display:none!important}'),'hidden guard');
ok(css.includes('grid-template-columns:repeat(5,minmax(0,1fr))'),'five-step responsive progress');
ok(css.includes('grid-template-columns:48px minmax(0,1fr) 30px'),'mobile home card grid');
console.log('v6.3.9 mobile/login corrective checks: PASS');

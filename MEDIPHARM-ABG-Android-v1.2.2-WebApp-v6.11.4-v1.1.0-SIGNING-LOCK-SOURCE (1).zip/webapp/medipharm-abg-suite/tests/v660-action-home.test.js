const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(!php.includes('Tài nguyên nổi bật'),'featured resources removed');
ok(php.includes('Ca lâm sàng mẫu'),'sample cases present');
ok(php.includes('Hỏi đáp lâm sàng'),'clinical QA action present');
ok(php.includes('data-home-demo="dka"'),'DKA sample launcher present');
ok(php.includes('data-home-demo="acute-resp-acidosis"'),'respiratory sample launcher present');
ok(php.includes('data-home-demo="pe-hypoxemia"'),'oxygenation sample launcher present');
ok(php.includes('Từ điển học tập'),'dictionary retained');
ok(css.includes('v6.6.0 — Action-first Home'),'v660 css present');
ok(js.includes('v6.6.0 — Home sample-case launcher'),'v660 runtime present');
console.log('v6.6.0 action home PASS');

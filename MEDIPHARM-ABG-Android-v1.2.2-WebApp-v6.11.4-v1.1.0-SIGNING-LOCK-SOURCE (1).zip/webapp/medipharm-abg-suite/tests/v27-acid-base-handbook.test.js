'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
assert(main.includes('Version: 6.2.4'));
assert(main.includes("const VERSION='6.2.4'"));
[
  'Bốn rối loạn toan–kiềm nguyên phát',
  'Nguyên tắc đáp ứng bù',
  'Toan chuyển hóa: bắt đầu từ HCO₃⁻ giảm',
  'Kiềm chuyển hóa: bắt đầu từ HCO₃⁻ tăng',
  'Toan hô hấp: PaCO₂ tăng và yếu tố thời gian',
  'Kiềm hô hấp: PaCO₂ giảm do tăng thông khí',
  'Khoảng trống anion trong toan chuyển hóa',
  'Nhận diện rối loạn toan–kiềm phối hợp',
  'Tóm tắt cách tiếp cận rối loạn toan–kiềm',
  'công thức Winter',
  'Hiệu chỉnh khi albumin giảm'
].forEach(x=>assert(mod.includes(x), 'missing '+x));
assert(mod.includes('PaCO₂ ≈ 1,5 × HCO₃⁻ + 8 ± 2 mmHg'));
assert(mod.includes('Khoảng trống anion = Na⁺ − (Cl⁻ + HCO₃⁻)'));
assert(mod.includes('data-handbook-open-analysis'));
assert(css.includes('v2.7 — Rối loạn toan–kiềm và đáp ứng bù'));
assert(css.includes('.nah-abg__disorder-grid'));
assert(css.includes('.nah-abg__formula-stack'));
assert(css.includes('@media (max-width: 700px)'));
assert.equal(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('ABG Suite v2.7 acid-base handbook PASS');

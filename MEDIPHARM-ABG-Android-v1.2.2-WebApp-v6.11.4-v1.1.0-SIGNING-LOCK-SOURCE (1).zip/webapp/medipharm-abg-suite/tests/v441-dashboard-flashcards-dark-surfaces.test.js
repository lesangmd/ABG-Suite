const fs=require('fs');
const php=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
const js=fs.readFileSync('assets/js/nah-abg-ui.js','utf8');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
function ok(x,m){if(!x)throw new Error(m)}
ok(php.includes('data-home-v441-card'),'Dashboard quick flashcard markup missing');
ok(php.includes('Ôn nhanh bằng thẻ ghi nhớ'),'Quick-review single-title label missing');
ok(js.includes('renderHomeQuickCard'),'Quick flashcard renderer missing');
ok(js.includes("data-home-v441-rate=\"mastered\""),'Quick flashcard rating missing');
ok(css.includes('v4.4.1 — Dark Mode Surface Normalization & Dashboard Flashcards'),'v4.4.1 CSS gate missing');
ok(css.includes('.nah-abg[data-theme="dark"] .nah-abg__adaptive-topic'),'Adaptive dark surface normalization missing');
console.log('v4.4.1 dashboard flashcards + dark surfaces PASS');

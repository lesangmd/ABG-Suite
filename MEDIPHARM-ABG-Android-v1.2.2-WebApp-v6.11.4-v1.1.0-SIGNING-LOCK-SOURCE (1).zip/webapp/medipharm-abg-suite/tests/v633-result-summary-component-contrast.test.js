const fs=require('fs'), assert=require('assert'), crypto=require('crypto');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
const php=fs.readFileSync('medipharm-abg-suite.php','utf8');
assert(php.includes('Version: 6.3.3'));
assert(php.includes("const VERSION='6.3.3'"));
assert(css.includes('v6.3.3 — Result Summary & Component Contrast Fix'));
assert(css.includes('--abg-cf-summary-gradient:linear-gradient'));
assert(css.includes('.nah-abg .nah-abg__result-summary{'));
assert(css.includes('color:var(--abg-cf-ink)!important'));
assert(css.includes('.nah-abg .nah-abg__result-summary h3{'));
assert(css.includes('color:#11353f!important'));
assert(css.includes('.nah-abg[data-theme="dark"] .nah-abg__result-summary'));
assert(css.includes('color:#f4f9fa!important'));
assert(css.includes('.nah-abg__result-actions [data-copy-result]'));
assert(css.includes('.nah-abg .nah-abg__result-card{'));
assert(css.includes('.nah-abg .nah-abg__badge--warning'));
const locks={
 'assets/js/nah-abg-core.js':'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02',
 'CASE-BANK-v5.2.json':'494165500b10cd4eb994e5af8486995692c1305cbf0c39f8e1e7ac3b340a8e0d',
 'MIXED-FORMAT-BANK-v5.3.json':'761d1a40557fb178fc9e5b00adbf87cee5e72db520c315929921f1bebeb0fae1',
 'MOCK-TEST-PACKS-v5.9.json':'aea34dde244d4881e19168f08772586b02979ef73323870a083c648708e9fcde',
 'ASSESSMENT-SCHEMA-v5.2.json':'31022c7e3ae273dd8026e5295052de00d352afbef012edd6145ca78996e506e2'
};
for(const [f,h] of Object.entries(locks)){
 const got=crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
 assert.strictEqual(got,h,`${f} changed`);
}
console.log('v6.3.3 result summary/component contrast PASS');

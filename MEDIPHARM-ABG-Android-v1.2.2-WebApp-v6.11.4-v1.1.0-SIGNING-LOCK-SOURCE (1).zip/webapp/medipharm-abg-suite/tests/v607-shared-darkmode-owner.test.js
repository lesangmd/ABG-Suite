const fs=require('fs');const assert=require('assert');
const js=fs.readFileSync('assets/js/nah-abg-ui.js','utf8');
const plugin=fs.readFileSync('medipharm-abg-suite.php','utf8');
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
['hostThemeToggle','[data-syh-theme-toggle]','requestHostTheme','nah-sdp:theme-change','tvm-dark','yhlsm-dark'].forEach(x=>assert(js.includes(x),x));
assert(js.includes("hostToggle.click()"),'ABG toggle must invoke canonical host switch');
assert(!js.includes("medipharm:theme-toggle-request"),'obsolete private ABG theme request must be removed');
assert(js.includes("if (persist && !hasHostThemeOwner())"),'ABG local theme storage must be standalone fallback only');
console.log('PASS v6.1 shared dark-mode owner contract');

const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='[')depth++;else if(c===']'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('array not closed '+marker);}
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('object not closed '+marker);}
function countIds(arr){return (arr.match(/\{id:/g)||[]).length;}
function words(s){return new Set(s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[a-z0-9]+/g)||[]);}
function jaccard(a,b){let inter=0;for(const x of a)if(b.has(x))inter++;return inter/Math.max(1,new Set([...a,...b]).size);}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
const legacyLearning=extractArray(ui,'var LEARNING_QUESTIONS');
const legacyExtra=extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS');
const v51=JSON.parse(extractArray(ui,'var ASSESSMENT_V51_QUESTIONS'));
const legacyLessons=JSON.parse(extractObject(ui,'var LEGACY_ITEM_LESSON'));
assert.strictEqual(countIds(legacyLearning),32);assert.strictEqual(countIds(legacyExtra),16);assert.strictEqual(v51.length,72);assert.strictEqual(Object.keys(legacyLessons).length,48);
assert.strictEqual(32+16+v51.length,120);
for(const token of ['lesson','difficulty','cognitive','clinicalContext','distractorRationale','remediation'])assert(v51.every(x=>x[token]),token);
const domains=['foundation','acidbase','oxygen','clinical'];
for(const d of domains){const xs=v51.filter(x=>x.topic===d);assert.strictEqual(xs.length,18,d);}
assert.strictEqual(new Set(v51.map(x=>x.lesson)).size,39);
const ids=v51.map(x=>x.id);assert.strictEqual(new Set(ids).size,ids.length);
// Final canonical distribution uses the known preserved 48 baseline: 12/domain and difficulty counts from v5.0.1.
const legacyDifficulty={foundation:{basic:4,intermediate:5,advanced:3},acidbase:{basic:3,intermediate:4,advanced:5},oxygen:{basic:3,intermediate:4,advanced:5},clinical:{basic:3,intermediate:3,advanced:6}};
for(const d of domains){const c={...legacyDifficulty[d]};for(const x of v51.filter(q=>q.topic===d))c[x.difficulty]=(c[x.difficulty]||0)+1;assert.deepStrictEqual(c,{basic:10,intermediate:10,advanced:10},d);}
// Existing answer positions were A36/B10/C2/D0; v5.1 deliberately corrects the imbalance without altering the legacy 48.
const pos=[36,10,2,0];for(const x of v51)pos[x.a]++;assert.deepStrictEqual(pos,[36,28,28,28]);assert(Math.max(...pos)/120<=0.30);
const normalized=v51.map(x=>x.q.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim());assert.strictEqual(new Set(normalized).size,normalized.length);
for(let i=0;i<v51.length;i++)for(let j=i+1;j<v51.length;j++)assert(jaccard(words(v51[i].q),words(v51[j].q))<0.80,`near duplicate ${v51[i].id}/${v51[j].id}`);
assert(ui.includes('normalizeAssessmentItem'));assert(ui.includes('ASSESSMENT_V51_QUESTIONS.map'));
for(const text of ['Ngân hàng 220 câu','220 câu đánh giá'])assert(mod.includes(text),text);
const sha=crypto.createHash('sha256').update(core).digest('hex');assert.strictEqual(sha,'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
assert(plugin.includes("home_url('/phan-tich-khi-mau-app/')"));
console.log('PASS v5.1 question bank expansion + item taxonomy gate');

const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
const mixed=JSON.parse(fs.readFileSync(path.join(root,'MIXED-FORMAT-BANK-v5.3.json'),'utf8'));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'MIXED-FORMAT-BANK-v5.3-MANIFEST.json'),'utf8'));
const schema=JSON.parse(fs.readFileSync(path.join(root,'ASSESSMENT-SCHEMA-v5.3.json'),'utf8'));
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='[')depth++;else if(c===']'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('array not closed '+marker);}
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('object not closed '+marker);}
function sha(s){return crypto.createHash('sha256').update(s).digest('hex');}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
assert.strictEqual(manifest.baseline_package_sha256,'329f713a677f85f61c2ce10a89a65ca94a78d8e7971cd8717e8d5c9879a48de4');
assert.strictEqual(mixed.length,40);assert.strictEqual(new Set(mixed.map(x=>x.id)).size,40);for(const x of mixed){for(const k of ['domain','lesson_id','concept','difficulty','cognitive_level','error_pattern','source_scope','distractor_rationale','remediation_link','item_format','schema_version'])assert(x[k]!==undefined&&x[k]!=='' ,x.id+' '+k);assert.strictEqual(x.domain,x.topic);assert.strictEqual(x.lesson_id,x.lesson);}
const formats=['multiple_response','ordering','matching','numeric_calculation','structured_case_interpretation'];const domains=['foundation','acidbase','oxygen','clinical'];
for(const f of formats)assert.strictEqual(mixed.filter(x=>x.item_format===f).length,8,f);for(const d of domains)assert.strictEqual(mixed.filter(x=>x.topic===d).length,10,d);
assert.strictEqual(manifest.canonical_item_count,220);assert.strictEqual(manifest.baseline_items_preserved,180);assert.strictEqual(manifest.new_mixed_items,40);assert.strictEqual(manifest.scoring.partial_credit,false);assert.strictEqual(manifest.storage_migration,false);
assert.deepStrictEqual(schema.properties.item_format.enum,['single_best_answer',...formats]);assert.deepStrictEqual(schema.properties.schema_version.enum,[1,2,3]);
// v5.2 canonical data arrays must remain byte-for-byte unchanged inside the v5.3 runtime.
assert.strictEqual(sha(extractArray(ui,'var LEARNING_QUESTIONS')),'3203d1ee4331a6ffa2fe5956c6d341d58dd0a7d368ae2cae765ad1434188e027');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS')),'541ea4cc17cb562e2b932477cf1fbf17e3e9a8c04370f075fa5da181b96f5d34');
assert.strictEqual(sha(extractArray(ui,'var ASSESSMENT_V51_QUESTIONS')),'d72d797771190fdd073e2a99d2318ce4d42c2050f2d8c681e071018df9814d1b');
const v52=JSON.parse(extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS'));assert.strictEqual(v52.length,60);
const runtimeMixed=JSON.parse(extractArray(ui,'var ASSESSMENT_V53_MIXED_QUESTIONS'));assert.deepStrictEqual(runtimeMixed,mixed);
assert(ui.includes("x.item_format=x.item_format||'single_best_answer'"));assert(ui.includes("if(x.item_format!=='single_best_answer')x.schema_version=3"));assert(ui.includes("mixed:{label:'Hỗn hợp · 20 câu'"));assert(ui.includes("itemFormat:'single_best_answer'"));
for(const fn of ['assessmentAnswerComplete','assessmentItemCorrect','assessmentOrderingSequence','renderAssessmentInput','bindAssessmentInputs','assessmentAnswerText'])assert(ui.includes('function '+fn+'('),fn);
for(const token of ['data-exam-multi','data-exam-order','data-exam-match','data-exam-numeric','data-exam-structured'])assert(ui.includes(token),token);
for(const token of ['nah-abg__mixed-ordering','nah-abg__mixed-matching','nah-abg__mixed-numeric','nah-abg__mixed-structured','nah-abg__format-chip'])assert(css.includes(token),token);
for(const text of ['Ngân hàng 220 câu','220 câu đánh giá','Hỗn hợp · 20 câu'])assert(mod.includes(text),text);
// Evaluate pure scoring helpers directly.
function fnSource(name){const marker='function '+name+'(';const s=ui.indexOf(marker);assert(s>=0);const brace=ui.indexOf('{',s);let depth=0,quote='',esc=false;for(let i=brace;i<ui.length;i++){const c=ui[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return ui.slice(s,i+1);}}throw new Error(name);}
const sandbox={Set,Number,Math,String,Array,Object};vm.createContext(sandbox);for(const name of ['assessmentNumericValue','assessmentOrderingSequence','assessmentAnswerComplete','assessmentItemCorrect'])vm.runInContext(fnSource(name),sandbox);vm.runInContext(fnSource('shuffled'),sandbox);vm.runInContext(fnSource('prepareAssessmentItem'),sandbox);
assert(sandbox.assessmentItemCorrect({item_format:'multiple_response',correct_answers:[1,3]},[3,1]));assert(!sandbox.assessmentItemCorrect({item_format:'multiple_response',correct_answers:[1,3]},[1]));
assert(sandbox.assessmentItemCorrect({item_format:'ordering',o:['a','b','c'],correct_order:[1,2,0]},[2,0,1]));
assert(sandbox.assessmentItemCorrect({item_format:'matching',match_left:['a','b'],correct_matches:[1,0]},[1,0]));assert(!sandbox.assessmentAnswerComplete({item_format:'matching',match_left:['a','b']},[1,null]));assert(!sandbox.assessmentAnswerComplete({item_format:'ordering',o:['a','b','c']},[0,1,null]));
assert(sandbox.assessmentItemCorrect({item_format:'numeric_calculation',answer_value:26,tolerance:2},'27,5'));assert(!sandbox.assessmentItemCorrect({item_format:'numeric_calculation',answer_value:26,tolerance:2},'29'));
assert(sandbox.assessmentItemCorrect({item_format:'structured_case_interpretation',structured_fields:[{id:'a',correct:1},{id:'b',correct:0}]},{a:1,b:0}));
const mr={item_format:'multiple_response',o:['A','B','C'],correct_answers:[0,2]},pm=sandbox.prepareAssessmentItem(mr);assert.deepStrictEqual(pm.correct_answers.map(i=>pm.o[i]).sort(),['A','C']);
const mt={item_format:'matching',match_left:['L1','L2'],match_options:['R1','R2'],correct_matches:[1,0]},pt=sandbox.prepareAssessmentItem(mt);assert.strictEqual(pt.match_options[pt.correct_matches[0]],'R2');assert.strictEqual(pt.match_options[pt.correct_matches[1]],'R1');
const st={item_format:'structured_case_interpretation',structured_fields:[{id:'x',options:['bad','good','other'],correct:1}]},ps=sandbox.prepareAssessmentItem(st);assert.strictEqual(ps.structured_fields[0].options[ps.structured_fields[0].correct],'good');
assert.strictEqual(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
assert(plugin.includes("home_url('/phan-tich-khi-mau-app/')"));
console.log('PASS v5.3 mixed-format engine + 40-item production corpus gate');

const fs=require('fs');
const path=require('path');
const css=fs.readFileSync(path.join(__dirname,'../assets/css/nah-abg.css'),'utf8');
function ok(cond,msg){ if(!cond){ console.error('FAIL:',msg); process.exitCode=1; } else console.log('PASS:',msg); }
ok(css.includes('max-width: 1199px'),'tablet landscape breakpoint through 1199px');
ok(css.includes('.nah-abg__handbook-toc-label {\n\t\tgrid-column: 1 / -1;'),'theory TOC label spans full tablet grid');
ok(css.includes('grid-template-columns: 22px minmax(0,1fr) !important'),'review answers protect text column on tablet');
ok(css.includes('writing-mode: horizontal-tb !important'),'answer text forced horizontal');
ok(css.includes('word-break: normal !important'),'answer text avoids character-by-character wrapping');

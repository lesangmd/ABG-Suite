const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
function extractArray(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('[',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='[')depth++;else if(c===']'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('array not closed '+marker);}
function extractObject(src,marker){const m=src.indexOf(marker);assert(m>=0,marker);const start=src.indexOf('{',m);let depth=0,quote='',esc=false;for(let i=start;i<src.length;i++){const c=src[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return src.slice(start,i+1);}}throw new Error('object not closed '+marker);}
function sha(s){return crypto.createHash('sha256').update(s).digest('hex');}
function words(s){return new Set(s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[a-z0-9]+/g)||[]);}
function jaccard(a,b){let inter=0;for(const x of a)if(b.has(x))inter++;return inter/Math.max(1,new Set([...a,...b]).size);}
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"));assert(plugin.includes("const VERSION='6.2.4'"));
const legacyLearning=extractArray(ui,'var LEARNING_QUESTIONS');
const legacyExtra=extractArray(ui,'var ASSESSMENT_EXTRA_QUESTIONS');
const v51=extractArray(ui,'var ASSESSMENT_V51_QUESTIONS');
const legacyLessons=extractObject(ui,'var LEGACY_ITEM_LESSON');
assert.strictEqual(sha(legacyLearning),'3203d1ee4331a6ffa2fe5956c6d341d58dd0a7d368ae2cae765ad1434188e027');
assert.strictEqual(sha(legacyExtra),'541ea4cc17cb562e2b932477cf1fbf17e3e9a8c04370f075fa5da181b96f5d34');
assert.strictEqual(sha(v51),'d72d797771190fdd073e2a99d2318ce4d42c2050f2d8c681e071018df9814d1b');
assert.strictEqual(sha(legacyLessons),'09322e2829ad1616ed343cf81d82c9eeac8f395e4cea4400e5c217a03f4c845b');
const v52=JSON.parse(extractArray(ui,'var ASSESSMENT_V52_CASE_QUESTIONS'));
assert.strictEqual(v52.length,60);assert.strictEqual(new Set(v52.map(x=>x.id)).size,60);
const caseIds=[...new Set(v52.map(x=>x.case_id))];assert.strictEqual(caseIds.length,20);
for(const id of caseIds){const xs=v52.filter(x=>x.case_id===id);assert.strictEqual(xs.length,3,id);assert.deepStrictEqual(xs.map(x=>x.case_sequence),[1,2,3],id);assert.deepStrictEqual(xs.map(x=>x.case_stage),['initial','analysis','integration'],id);}
const domains=['foundation','acidbase','oxygen','clinical'];
const lessonIds=new Set([...mod.matchAll(/id=\"<\?php echo esc_attr\( \$instance_id \); \?>-(hb-[a-z0-9-]+)\"/g)].map(m=>m[1]));
assert(v52.every(x=>lessonIds.has(x.lesson)), 'unknown v5.2 lesson/remediation reference');
for(const d of domains){const xs=v52.filter(x=>x.topic===d);assert.strictEqual(xs.length,15,d);const c={basic:0,intermediate:0,advanced:0};xs.forEach(x=>c[x.difficulty]++);assert.deepStrictEqual(c,{basic:5,intermediate:5,advanced:5},d);}
assert.strictEqual(new Set(v52.filter(x=>x.serial_abg).map(x=>x.case_id)).size,8);
assert.strictEqual(v52.filter(x=>x.serial_abg).length,24);
for(const f of ['case_id','case_title','case_vignette','case_sequence','case_stage','serial_abg','source_scope','distractorRationale','remediation'])assert(v52.every(x=>x[f]!==undefined&&x[f]!==''),f);
const pos=[36,28,28,28];v52.forEach(x=>pos[x.a]++);assert.deepStrictEqual(pos,[51,43,43,43]);assert(Math.max(...pos)/180<0.29);
const normalized=v52.map(x=>x.q.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim());assert.strictEqual(new Set(normalized).size,60);
let maxJ=0,pair='';for(let i=0;i<v52.length;i++)for(let j=i+1;j<v52.length;j++){const z=jaccard(words(v52[i].q),words(v52[j].q));if(z>maxJ){maxJ=z;pair=v52[i].id+'/'+v52[j].id;}assert(z<0.80,`near duplicate ${v52[i].id}/${v52[j].id} ${z}`);} 
assert(ui.includes('ASSESSMENT_V52_CASE_QUESTIONS.map'));assert(ui.includes("case:{label:'Theo ca · 20 câu'"));assert(ui.includes('caseOnly||q.case_linked'));assert(ui.includes('nah-abg__case-context'));
for(const text of ['Ngân hàng 220 câu','220 câu đánh giá','Theo ca · 20 câu'])assert(mod.includes(text),text);
const shaCore=crypto.createHash('sha256').update(core).digest('hex');assert.strictEqual(shaCore,'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
assert(plugin.includes("home_url('/phan-tich-khi-mau-app/')"));
console.log('PASS v5.2 case-based question bank gate; max Jaccard',maxJ.toFixed(4),pair);

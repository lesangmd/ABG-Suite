const fs=require('fs');const assert=require('assert');
const main=fs.readFileSync('medipharm-abg-suite.php','utf8');
const ui=fs.readFileSync('assets/js/nah-abg-ui.js','utf8');
const readme=fs.readFileSync('readme.txt','utf8');
assert(main.includes('Version: 6.2.4'));assert(main.includes("const VERSION='6.2.4'"));
assert(readme.includes('Stable tag: 6.2'));assert(readme.includes('== v4.4 =='));
[
  "[/\\bDiscordance\\b/gi, 'Sự không phù hợp']",
  "[/A[–-]a gradient/gi, 'chênh áp oxy phế nang–động mạch']",
  "[/V\\/Q mismatch/gi, 'mất tương hợp thông khí/tưới máu (V/Q)']",
  "[/\\bpseudohypoxemia\\b/gi, 'giảm oxy máu giả do mẫu']",
  "[/\\brespiratory compensation\\b/gi, 'bù hô hấp']",
  "[/\\bmetabolic compensation\\b/gi, 'bù chuyển hóa']",
  "[/\\banion gap\\b/gi, 'khoảng trống anion']",
  "[/\\bdelta ratio\\b/gi, 'tỷ số delta']",
  "[/\\bpulse oximetry\\b/gi, 'đo độ bão hòa oxy ngoại vi']"
].forEach(x=>assert(ui.includes(x),x));
assert(!ui.includes('Discordance giữa dữ liệu và bệnh cảnh'));
assert(ui.includes('Sự không phù hợp giữa kết quả khí máu và bệnh cảnh lâm sàng'));
assert(ui.includes('Bù hô hấp có giới hạn sinh lý.'));
assert(ui.includes('Bù chuyển hóa trong rối loạn hô hấp cần thời gian.'));
console.log('v4.4 Vietnamese clinical language gate PASS');

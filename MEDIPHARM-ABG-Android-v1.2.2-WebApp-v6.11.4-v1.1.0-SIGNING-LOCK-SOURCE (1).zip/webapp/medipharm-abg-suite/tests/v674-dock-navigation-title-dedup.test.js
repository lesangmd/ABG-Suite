const fs=require('fs');
const plugin=fs.readFileSync('medipharm-abg-suite.php','utf8');
const mod=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
const js=fs.readFileSync('assets/js/nah-abg-ui.js','utf8');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
function assert(v,m){if(!v)throw new Error(m)}
assert(plugin.includes('Version: 6.7.4')&&plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.7.4'")&&plugin.includes("const VERSION='6.7.4'"),'version');
assert(js.includes('v6.7.4 — Mobile Dock Navigation Reliability Hotfix'),'dock router');
assert(js.includes(".nah-abg__mobile-dock [data-home-workspace]"),'dock selector');
assert(js.includes('tab.click();'),'dock target dispatch');
assert(!mod.includes('<span class="nah-abg__v670-kicker">PHÂN TÍCH KHÍ MÁU ĐỘNG MẠCH</span>'),'hero duplicate');
assert(!mod.includes('<div><span>KHÍ MÁU ĐỘNG MẠCH</span><h2>Phân tích khí máu</h2>'),'analysis duplicate');
assert(css.includes('v6.7.4 — Dock reliability + duplicate-title cleanup'),'css gate');
console.log('v6.7.4 dock navigation + title dedup PASS');

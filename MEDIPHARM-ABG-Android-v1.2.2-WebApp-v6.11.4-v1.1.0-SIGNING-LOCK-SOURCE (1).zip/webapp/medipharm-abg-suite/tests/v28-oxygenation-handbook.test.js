'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
assert(main.includes('Version: 6.2.4'));
assert(main.includes("const VERSION='6.2.4'"));
[
  'Oxy hóa máu và thông khí là hai vấn đề khác nhau',
  'Hành trình của oxy: từ khí hít vào đến mô',
  'PaO₂ và độ bão hòa oxy không thay đổi theo đường thẳng',
  'Phương trình khí phế nang',
  'Chênh áp oxy phế nang–động mạch giúp định hướng cơ chế',
  'Năm cơ chế chính gây giảm oxy máu',
  'Tỷ số PaO₂/FiO₂: đặt PaO₂ trong bối cảnh oxy hít vào',
  'Hai kiểu suy hô hấp thường gặp trên khí máu',
  'Luôn đọc khí máu cùng bối cảnh hỗ trợ oxy và thông khí',
  'Tóm tắt cách đánh giá oxy hóa máu và suy hô hấp',
  'CaO₂ (mL O₂/dL) ≈ 1,34 × Hb (g/dL) × SaO₂ (dạng 0–1) + 0,003 × PaO₂ (mmHg)',
  'PAO₂ = FiO₂ × (P<sub>B</sub> − P<sub>H₂O</sub>) − PaCO₂ / R'
].forEach(x=>assert(mod.includes(x), 'missing '+x));
[
  'Thuốc ức chế SGLT2 – nhiễm toan ceton',
  'COPD – toan hô hấp mạn có bù',
  'COPD – theo dõi khi thông khí không xâm nhập',
  'Methemoglobin – chênh lệch độ bão hòa oxy'
].forEach(x=>assert(mod.includes(x), 'missing compact case title '+x));
assert(!mod.includes('Thuốc ức chế đồng vận chuyển natri–glucose 2 – nhiễm toan ceton khi glucose không quá cao'));
assert(!mod.includes('Methemoglobin – PaO₂ và saturation gap'));
assert(!ui.includes("[/\\bCOPD\\b/g, 'bệnh phổi tắc nghẽn mạn tính']"));
assert(ui.includes('Đồng oxy kế và hemoglobin bất thường'));
assert(css.includes('v2.8 — Oxy hóa máu & suy hô hấp'));
assert(css.includes('.nah-abg__oxygen-chain'));
assert(css.includes('.nah-abg__mechanism-grid'));
assert(css.includes('@media (max-width: 700px)'));
assert.equal(crypto.createHash('sha256').update(core).digest('hex'),'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('ABG Suite v2.8 oxygenation handbook PASS');

const fs=require('fs'), path=require('path'), vm=require('vm'), assert=require('assert');
const root=path.resolve(__dirname,'..');
let src=fs.readFileSync(path.join(root,'assets/js/nah-abg-canonical-learning.js'),'utf8');
const cases=JSON.parse(fs.readFileSync(path.join(root,'assets/data/learning/cases.json'),'utf8'));
assert.strictEqual(cases.length,13,'expected 13 canonical cases');
// Expose private functions/state for deterministic runtime testing without a browser.
src=src.replace("window.MEDIPHARMABGCanonical={openTopic:function(id){roots().forEach(function(r){openTopic(r,id);});},selectTab:function(name){roots().forEach(function(r){openWorkspace(r,'theory');selectTab(r,name);});}};",
"window.MEDIPHARMABGCanonical={openTopic:function(id){roots().forEach(function(r){openTopic(r,id);});},selectTab:function(name){roots().forEach(function(r){openWorkspace(r,'theory');selectTab(r,name);});}};window.__ABG_TEST__={state:state,indexData:indexData,showCase:showCase,renderCases:renderCases,saveProgress:saveProgress};");
const ctx={
  window:{NAHABGConfig:{}},
  document:{readyState:'complete',querySelectorAll:()=>[]},
  localStorage:{setItem(){},getItem(){return null;}},
  requestAnimationFrame(fn){if(fn)fn();},
  setTimeout(fn){if(fn)fn();},
  navigator:{},
  console
};
vm.createContext(ctx); vm.runInContext(src,ctx);
const api=ctx.window.__ABG_TEST__; assert(api,'test API missing');
api.state.cases=cases; api.indexData();
for(const c of cases){
  const box={dataset:{},className:'',innerHTML:'',scrollIntoView(){}};
  const fakeRoot={querySelector(sel){return sel==='[data-canonical-cases]'?box:null;}};
  assert.doesNotThrow(()=>api.showCase(fakeRoot,c.id),'showCase threw for '+c.id);
  assert(box.innerHTML.includes(c.title_vi),'detail title missing for '+c.id);
  assert(box.innerHTML.includes('Bệnh sử'),'history section missing for '+c.id);
  assert(box.innerHTML.includes('Khám lâm sàng'),'exam section missing for '+c.id);
  assert(box.innerHTML.includes('Xét nghiệm kèm theo'),'labs section missing for '+c.id);
  assert(box.innerHTML.includes('Khí máu động mạch'),'ABG section missing for '+c.id);
  assert(box.innerHTML.includes('Lập luận chẩn đoán'),'reasoning section missing for '+c.id);
}
console.log('PASS v6.10.2: all 13 clinical cases render detail without runtime exception');

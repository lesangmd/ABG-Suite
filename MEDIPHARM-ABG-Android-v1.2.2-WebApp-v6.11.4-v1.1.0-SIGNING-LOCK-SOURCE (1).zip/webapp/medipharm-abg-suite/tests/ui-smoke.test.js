'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
let JSDOM; try { ({ JSDOM } = require('jsdom')); } catch (e) { console.log('ABG UI smoke SKIPPED - jsdom unavailable'); process.exit(0); }

function numericField(name, required) {
	return `<label class="nah-abg__field"><span>${name}${required ? ' *' : ''}</span><input type="text" name="${name}" data-numeric${required ? ' required' : ''}></label>`;
}

const html = `<!doctype html>
<html><head></head><body>
<div data-nah-abg-root data-abg-standalone="1">
	<button type="button" data-install-app hidden>Cài WebApp</button>
	<div data-install-help hidden><span data-install-help-text></span></div>
	<ol>
		<li data-progress-step="1"></li>
		<li data-progress-step="2"></li>
		<li data-progress-step="3"></li>
		<li data-progress-step="4"></li>
		<li data-progress-step="5"></li>
	</ol>
	<form data-abg-form novalidate>
		<section data-form-step="1">
			<input type="radio" name="sampleType" value="arterial" checked>
			<input type="radio" name="sampleType" value="venous">
			<input type="radio" name="unitSystem" value="si" checked>
			<input type="radio" name="unitSystem" value="us">
			<select name="gasPressureUnit" data-gas-pressure-unit>
				<option value="mmhg" selected>mmHg</option>
				<option value="kpa">kPa</option>
			</select>
			<select name="sex"><option value="unspecified" selected>Không chọn</option></select>
			<select name="chronicity"><option value="auto" selected>Tự động</option></select>
			<textarea name="caseSummary"></textarea>
			<input type="checkbox" name="clinicalContexts[]" value="sepsis">
			<input type="checkbox" name="sampleIssues[]" value="air-bubbles">
			<select data-demo-select>
				<option value=""></option>
				<option value="hagma">HAGMA</option>
			</select>
			<button type="button" data-load-demo>Nạp ca</button>
			${numericField('age', false)}
			${numericField('sampleDelayMinutes', false)}
		</section>
		<section data-form-step="2" hidden>
			${numericField('ph', true)}
			<label class="nah-abg__field"><span>PaCO₂ *</span><input type="text" name="paco2" data-numeric required><small data-paco2-reference></small></label>
			${numericField('hco3', true)}
			${numericField('pao2', false)}
			${numericField('sao2', false)}
			${numericField('spo2', false)}
			${numericField('lactate', false)}
			${numericField('priorLactate', false)}
			${numericField('lactateIntervalHours', false)}
			${numericField('cohb', false)}
			${numericField('methb', false)}
			<span data-pressure-unit-label></span>
		</section>
		<section data-form-step="3" hidden>
			${numericField('sodium', false)}
			${numericField('chloride', false)}
			${numericField('potassium', false)}
			${numericField('albumin', false)}
			<select name="albuminUnit" data-unit-role="albumin">
				<option value="gl" selected>g/L</option><option value="gdl">g/dL</option>
			</select>
			${numericField('glucose', false)}
			<select name="glucoseUnit" data-unit-role="glucose">
				<option value="mmol" selected>mmol/L</option><option value="mgdl">mg/dL</option>
			</select>
			${numericField('urea', false)}
			<select name="ureaUnit" data-unit-role="urea">
				<option value="urea-mmol" selected>Urê mmol/L</option><option value="bun-mgdl">BUN mg/dL</option>
			</select>
			${numericField('creatinine', false)}
			<select name="creatinineUnit" data-unit-role="creatinine">
				<option value="umol" selected>µmol/L</option><option value="mgdl">mg/dL</option>
			</select>
			${numericField('ketones', false)}
			${numericField('measuredOsm', false)}
			${numericField('urineChloride', false)}
			${numericField('urinePh', false)}
		</section>
		<section data-form-step="4" hidden>
			<select name="oxygenDevice"><option value="room-air" selected>Khí phòng</option></select>
			<label class="nah-abg__field"><span>FiO₂</span><input type="text" name="fio2" value="21" data-numeric></label>
			${numericField('peep', false)}
			<label class="nah-abg__field"><span>Áp suất</span><input type="text" name="atmosphericPressure" value="760" data-numeric></label>
			${numericField('hemoglobin', false)}
			<select name="hemoglobinUnit" data-unit-role="hemoglobin">
				<option value="gl" selected>g/L</option><option value="gdl">g/dL</option>
			</select>
			<div data-venous-warning hidden></div>
		</section>
		<section data-form-step="5" hidden>
			<div data-result-shell></div>
			<div data-result-actions hidden></div>
		</section>
		<div data-form-errors hidden></div>
		<button type="button" data-prev-step hidden>Quay lại</button>
		<button type="button" data-next-step>Tiếp tục</button>
		<button type="submit" data-analyze hidden>Phân tích</button>
	</form>
	<button type="button" data-copy-result>Sao chép</button>
	<button type="button" data-print-result>In</button>
	<button type="button" data-reset-form>Làm ca mới</button>
</div>
</body></html>`;

const dom = new JSDOM(html, {
	runScripts: 'dangerously',
	url: 'https://example.test/phan-tich-khi-mau/'
});

dom.window.Element.prototype.scrollIntoView = function () {};
dom.window.print = function () {};
const serviceWorkerRegistrations = [];
Object.defineProperty(dom.window.navigator, 'serviceWorker', {
	configurable: true,
	value: {
		register(url, options) {
			serviceWorkerRegistrations.push({ url, options });
			return Promise.resolve();
		}
	}
});
dom.window.NAHABGConfig = {
	manifestUrl: 'https://example.test/?nah_sdp_abg_manifest=1',
	swUrl: 'https://example.test/?nah_sdp_abg_sw=1',
	isHttps: true
};

const base = path.resolve(__dirname, '..', 'assets', 'js');
dom.window.eval(fs.readFileSync(path.join(base, 'nah-abg-core.js'), 'utf8'));
dom.window.eval(fs.readFileSync(path.join(base, 'nah-abg-ui.js'), 'utf8'));
dom.window.dispatchEvent(new dom.window.Event('beforeinstallprompt', { cancelable: true }));
dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded'));

const root = dom.window.document.querySelector('[data-nah-abg-root]');
const form = root.querySelector('[data-abg-form]');
const next = root.querySelector('[data-next-step]');

assert.ok(dom.window.document.querySelector('link[rel="manifest"]'));
assert.strictEqual(serviceWorkerRegistrations.length, 1);
assert.match(serviceWorkerRegistrations[0].url, /nah_sdp_abg_sw=1/);
assert.strictEqual(root.querySelector('[data-install-app]').hidden, false);
assert.strictEqual(form.elements.albuminUnit.value, 'gl', 'SI must be the default unit system');
assert.strictEqual(root.querySelector('[data-form-step="1"]').hidden, false);
next.click();
assert.strictEqual(root.querySelector('[data-form-step="2"]').hidden, false);

// Invalid formatting is shown inline and blocks forward navigation.
form.elements.ph.value = '7,4,0';
form.elements.paco2.value = '25';
form.elements.hco3.value = '10';
next.click();
assert.strictEqual(root.querySelector('[data-form-step="2"]').hidden, false);
assert.ok(form.elements.ph.classList.contains('is-invalid'));
assert.match(root.querySelector('[data-form-errors]').textContent, /định dạng số không hợp lệ/i);

// Corrected decimal-comma input proceeds.
form.elements.ph.value = '7,21';
form.elements.pao2.value = '92';
form.elements.sao2.value = '96';
next.click();
assert.strictEqual(root.querySelector('[data-form-step="3"]').hidden, false);

form.elements.sodium.value = '138';
form.elements.chloride.value = '100';
form.elements.albumin.value = '32';
form.elements.lactate.value = '5,1';
form.elements.priorLactate.value = '7,8';
form.elements.lactateIntervalHours.value = '2';
form.elements.caseSummary.value = 'Sốt, tụt huyết áp và thở nhanh.';
form.querySelector('[name="clinicalContexts[]"][value="sepsis"]').checked = true;

next.click();
assert.strictEqual(root.querySelector('[data-form-step="4"]').hidden, false);

form.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));

assert.strictEqual(root.querySelector('[data-form-step="5"]').hidden, false);
const resultText = root.querySelector('[data-result-shell]').textContent;
assert.match(resultText, /Toan chuyển hóa nguyên phát/);
assert.match(resultText, /Lập luận/);
assert.match(resultText, /pH 7,21 < 7,35/);
assert.match(resultText, /HCO₃⁻ 10 mmol\/L < 22 mmol\/L/);
assert.match(resultText, /PaCO₂ thực đo 25 mmHg; khoảng bù dự kiến 21–25 mmHg/);
assert.match(resultText, /Khoảng trống anion hiệu chỉnh albumin 30 mmol\/L > 14 mmol\/L/);
assert.match(resultText, /Khoảng trống anion/);
assert.match(resultText, /Chẩn đoán phân biệt có ưu tiên/);
assert.match(resultText, /Lộ trình protocol theo chính ca bệnh/);
assert.match(resultText, /Bản đồ nguyên nhân thường gặp cần rà soát/);
assert.match(resultText, /Lactat và xu hướng/);
assert.match(resultText, /Tỷ lệ giảm ước tính/);
assert.match(resultText, /Toan lactic/);
assert.match(resultText, /Xét nghiệm cần bổ sung/);
assert.match(resultText, /Hướng xử trí theo mức ưu tiên/);
assert.match(resultText, /Sốt, tụt huyết áp và thở nhanh/);
assert.strictEqual(root.querySelector('[data-result-actions]').hidden, false);

// Switching to US units updates unit selectors and converts existing values.
const usUnits = form.querySelector('[name="unitSystem"][value="us"]');
usUnits.checked = true;
usUnits.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
assert.strictEqual(form.elements.albuminUnit.value, 'gdl');
assert.strictEqual(form.elements.glucoseUnit.value, 'mgdl');
assert.strictEqual(form.elements.creatinineUnit.value, 'mgdl');
assert.ok(Math.abs(dom.window.NAHABGCore.parseNumeric(form.elements.albumin.value).value - 3.2) < 0.01);

console.log('NAH ABG UI smoke test passed.');

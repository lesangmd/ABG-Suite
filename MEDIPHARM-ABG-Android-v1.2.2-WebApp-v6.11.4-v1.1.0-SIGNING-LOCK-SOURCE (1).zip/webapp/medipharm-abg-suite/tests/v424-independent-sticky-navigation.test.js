const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const ui = fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const main = fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
function assert(v,msg){ if(!v){ throw new Error(msg); } }
assert(main.includes('Version: 6.2.4'), 'version header');
assert(css.includes('v4.2.4 — Independent Sticky Navigation Hotfix'), 'hotfix css marker');
assert(css.includes('overflow: clip !important'), 'root no longer hidden scroll container');
assert(css.includes('position: sticky !important'), 'workspace nav remains sticky');
assert(ui.includes("style.position !== 'fixed' && style.position !== 'sticky'"), 'admin bar visibility positioning');
assert(ui.includes("window.addEventListener('scroll'"), 'scroll offset sync');
assert(ui.includes('requestAnimationFrame(function ()'), 'scroll sync throttled');
console.log('PASS v4.2.4 independent sticky navigation');

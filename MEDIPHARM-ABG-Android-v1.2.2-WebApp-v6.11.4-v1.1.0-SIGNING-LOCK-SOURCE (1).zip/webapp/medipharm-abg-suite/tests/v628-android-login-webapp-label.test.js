const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const ui=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
function assert(x,m){ if(!x) throw new Error(m); }
assert(plugin.includes('Version: 6.2.8'),'version');
assert(plugin.includes("const VERSION='6.2.8'"),'version const');
assert(mod.includes("<?php if ( ! $android_shell ) : ?>") && mod.includes('Về Trang chủ'),'android home guard');
assert(mod.includes('data-install-label>Cài Webapp</span>'),'webapp label php');
assert(!mod.includes('data-install-label>Cài ứng dụng</span>'),'old standalone install label');
assert(ui.includes("'Cài Webapp'"),'webapp label js');
assert(ui.includes('window.MEDIPHARMABGOpenLogin'),'native login hook');
assert(ui.includes('trialCopy.hidden = !!showLogin'),'login hides quota copy');
console.log('v6.2.8 regression PASS');

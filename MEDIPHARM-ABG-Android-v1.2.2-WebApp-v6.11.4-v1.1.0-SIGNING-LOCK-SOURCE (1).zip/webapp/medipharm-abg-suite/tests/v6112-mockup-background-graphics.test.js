const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const php=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
function ok(x,m){if(!x)throw new Error(m)}
ok(php.includes('Version: 6.11.2')&&php.includes("MEDIPHARM_ABG_SUITE_VERSION','6.11.2"),'version 6.11.2');
ok(fs.existsSync(path.join(root,'assets/graphics/abg-hero-backdrop.svg')),'hero backdrop asset');
ok(fs.existsSync(path.join(root,'assets/graphics/abg-login-backdrop.svg')),'login backdrop asset');
ok(mod.includes('nah-abg__v6112-hero-logo')&&mod.includes('assets/icons/brand-abg.png'),'hero brand artwork');
ok(css.includes("url('../graphics/abg-hero-backdrop.svg')")&&css.includes("url('../graphics/abg-login-backdrop.svg')"),'background bindings');
ok(css.includes('v6.11.2 — Mockup Background Graphics Alignment'),'release css marker');
ok(css.includes('@media(max-width:600px)')&&css.includes('.nah-abg__v6112-hero-logo{width:86px!important'),'mobile alignment');
console.log('PASS v6.11.2 mockup background graphics alignment');

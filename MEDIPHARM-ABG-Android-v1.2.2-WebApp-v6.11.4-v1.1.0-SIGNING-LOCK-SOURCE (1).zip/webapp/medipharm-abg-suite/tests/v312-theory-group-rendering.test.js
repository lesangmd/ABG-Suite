const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const php = fs.readFileSync(path.join(root, 'class-medipharm-abg-suite-module.php'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/nah-abg.css'), 'utf8');
const main = fs.readFileSync(path.join(root, 'medipharm-abg-suite.php'), 'utf8');

assert(main.includes('Version: 6.2.4'));
assert(php.includes('Phiên bản v<?php echo esc_html( MEDIPHARM_ABG_SUITE_VERSION ); ?>'));

const requiredAcidBase = [
  'hb-language','hb-four','hb-compensation','hb-metabolic-acidosis','hb-metabolic-alkalosis',
  'hb-respiratory-acidosis','hb-respiratory-alkalosis','hb-anion-gap','hb-mixed','hb-acidbase-summary'
];
const requiredClinical = [
  'hb-case-dka','hb-case-sglt2','hb-case-sepsis','hb-case-copd','hb-case-opioid','hb-case-vomiting',
  'hb-case-diarrhea','hb-case-salicylate','hb-case-hypoxemia','hb-case-ventilator','hb-case-co','hb-case-airbubble'
];
for (const id of requiredAcidBase.concat(requiredClinical)) {
  const tocCount = (php.match(new RegExp('href="#<\\?php echo esc_attr\\( \\$instance_id \\); \\?>-' + id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"', 'g')) || []).length;
  const cardCount = (php.match(new RegExp('id="<\\?php echo esc_attr\\( \\$instance_id \\); \\?>-' + id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"', 'g')) || []).length;
  assert.strictEqual(tocCount, 1, 'TOC link missing/duplicate for ' + id);
  assert.strictEqual(cardCount, 1, 'theory card missing/duplicate for ' + id);
}
assert(css.includes('grid-auto-rows: min-content'));
assert(css.includes('align-self: start'));
console.log('v3.1.2 theory group rendering: PASS');

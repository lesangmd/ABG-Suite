const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
function ok(x,m){if(!x){console.error('FAIL',m);process.exit(1)}}
ok(main.includes('Version: 6.2.4')&&main.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2.4'"),'version 5.0');
ok(php.includes('data-home-v49-week')&&php.includes('data-home-v49-readiness'),'v5.0 insight surfaces');
ok(js.includes('function v49ActivityDays()')&&js.includes('function v49Readiness()')&&js.includes('function renderV49Insights()'),'v5.0 analytics functions');
ok(js.includes('Object.keys(state.questions||{})')&&js.includes('state.cardSchedule')&&js.includes('theoryViewed'),'analytics uses existing local timestamps');
ok(js.includes('function openLessonTargetInViewport(target)')&&js.includes("setLearnSection('lessons', false)"),'sticky-aware lesson destination helper');
ok(js.includes("if(target)openLessonTargetInViewport(target)"),'knowledge map uses viewport helper');
ok(css.includes('.nah-abg__v49-insights')&&css.includes('.nah-abg__v49-bars'),'v5.0 responsive styles');
ok(!js.includes('XMLHttpRequest'),'no XMLHttpRequest');
console.log('PASS v5.0 learning analytics + lesson viewport gate');

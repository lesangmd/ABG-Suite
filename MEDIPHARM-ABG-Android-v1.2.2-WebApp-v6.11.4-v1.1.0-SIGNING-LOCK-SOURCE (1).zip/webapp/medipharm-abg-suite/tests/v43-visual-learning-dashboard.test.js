const fs=require('fs'), path=require('path');
const root=path.resolve(__dirname,'..');
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-ui.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
function ok(x,m){if(!x)throw new Error(m)}
ok(plugin.includes('Version: 6.2.4')&&plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2"),'current release version missing');
ok(php.includes('data-home-v43-snapshot')&&php.includes('data-home-v43-mastery')&&php.includes('data-home-v43-insight'),'v4.3 dashboard regions missing');
ok(js.includes('renderV43Dashboard')&&js.includes('v43DomainRows'),'v4.3 intelligence renderer missing');
['Nền tảng khí máu','Toan–kiềm','Rối loạn phối hợp','Oxy hóa & thông khí','Chất lượng mẫu','Ứng dụng lâm sàng'].forEach(x=>ok(js.includes(x),'missing domain '+x));
['Mới','Đang học','Cần ôn','Đã vững'].forEach(x=>ok(js.includes(x),'missing status '+x));
ok(css.includes('.nah-abg__v43-ring')&&css.includes('conic-gradient'),'progress ring missing');
ok(css.includes('@media(max-width:600px)'),'mobile rules missing');
ok(!js.includes('XMLHttpRequest'),'unexpected XHR primitive');ok((js.match(/fetch\(/g)||[]).length===1&&js.includes('function requestTrialUse(actionName, onAllowed)'),'only action-driven trial request is allowed');
console.log('PASS v4.3 visual learning dashboard');

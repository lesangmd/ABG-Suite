const fs=require('fs'); const path=require('path'); const root=path.join(__dirname,'..');
function assert(x,m){if(!x){throw new Error(m||'assertion failed')}}
const php=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
assert(php.includes('ĐIỂM NHẤN LÂM SÀNG'));
assert(php.includes('ĐIỀU CẦN NHỚ'));
assert(php.includes('CÂU HỎI NHANH'));
assert(php.includes('CA 60 GIÂY'));
assert(!php.includes('Clinical Pearls'));
assert(!php.includes('CLINICAL PEARL'));
assert(!php.includes('<span>FACT</span>'));
assert(!php.includes('<span>QUIZ</span>'));
assert(css.includes('color-scheme: dark'));
assert(css.includes('select option:checked'));
assert(css.includes('.nah-abg[data-theme="dark"] .nah-abg__visual-theory'));
console.log('v4.2.5 dark-mode + Vietnamese UI static gate PASS');

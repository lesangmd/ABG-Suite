const fs=require('fs');
const php=fs.readFileSync('class-medipharm-abg-suite-module.php','utf8');
const css=fs.readFileSync('assets/css/nah-abg.css','utf8');
const main=fs.readFileSync('medipharm-abg-suite.php','utf8');
function ok(x,m){if(!x)throw new Error(m)}
ok(main.includes("Version: 6.3.6")&&main.includes("MEDIPHARM_ABG_SUITE_VERSION','6.3.6'"),'version');
ok(php.includes('nah-abg__brand-subtitle')&&php.includes('Khí máu lâm sàng'),'brand subtitle');
ok(php.includes('KHÍ MÁU ĐỘNG MẠCH')&&php.includes('<h1>Khí máu lâm sàng</h1>'),'professional hero');
ok((php.match(/data-workspace-tab=/g)||[]).length>=6,'workspace tabs');
ok(php.includes('nah-abg__home-summary--v636')&&php.includes('Tiếp tục học')&&php.includes('Tiến độ học tập'),'summary row');
ok(css.includes('v6.3.6 — Focused Clinical Home'),'css release');
ok(css.includes('grid-template-columns:repeat(5,minmax(0,1fr))'),'five card grid');
ok(css.includes('.nah-abg__app-search-box input')&&css.includes('border:0!important'),'search single control');
ok(css.includes('@media(max-width:700px)'),'mobile breakpoint');
console.log('v6.3.6 focused clinical home checks: PASS');

const fs=require('fs');const path=require('path');const assert=require('assert');
const root=path.resolve(__dirname,'..');
const cases=JSON.parse(fs.readFileSync(path.join(root,'assets/data/learning/cases.json'),'utf8'));
assert.strictEqual(cases.length,25,'expected 25 cases');
for(const c of cases){for(const g of (c.management_plan||[])){const items=g.items||[];assert(Array.isArray(items),'management items must be array');assert(!(items.length>6&&items.every(x=>typeof x==='string'&&x.length<=2)),`character-split list: ${c.id}/${g.title_vi}`);}}
const asthma=cases.find(c=>c.id==='CASE-ASTHMA');const airway=(asthma.management_plan||[]).find(g=>g.title_vi==='Đường thở');assert(airway&&airway.items.length===1&&airway.items[0].includes('PaCO₂ tăng'),'asthma airway content normalized');
const js=fs.readFileSync(path.join(root,'assets/js/nah-abg-canonical-learning.js'),'utf8');assert(js.includes("items.every(function(x){return typeof x==='string'&&x.length<=2;})"),'defensive list normalizer missing');
const php=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');assert(php.includes('android-v1-channel/releases/MEDIPHARM-ABG-v1.1.0.apk'),'Android download must point to signed v1.1.0 channel APK');assert(!php.includes('main/MEDIPHARM-ABG-latest.apk'),'obsolete main latest alias must not be used');
console.log('PASS v6.11.1 clinical case list + Android download hotfix');

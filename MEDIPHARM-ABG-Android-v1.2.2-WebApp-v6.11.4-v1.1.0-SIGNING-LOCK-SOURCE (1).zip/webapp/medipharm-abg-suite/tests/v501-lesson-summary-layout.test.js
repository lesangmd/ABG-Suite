const fs=require('fs');const path=require('path');const crypto=require('crypto');const assert=require('assert');
const root=path.resolve(__dirname,'..');
const plugin=fs.readFileSync(path.join(root,'medipharm-abg-suite.php'),'utf8');
const mod=fs.readFileSync(path.join(root,'class-medipharm-abg-suite-module.php'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/nah-abg.css'),'utf8');
const core=fs.readFileSync(path.join(root,'assets/js/nah-abg-core.js'));
assert(plugin.includes('Version: 6.2.4'));assert(plugin.includes("MEDIPHARM_ABG_SUITE_VERSION','6.2"));assert(plugin.includes("const VERSION='6.2.4'"));
for(const id of ['hb-acidbase-summary','hb-oxygen-summary']){
  const marker=`nah-abg__handbook-card--summary\" id=\"<?php echo esc_attr( $instance_id ); ?>-${id}`;
  const at=mod.indexOf(marker);assert(at>=0,id);
  const end=mod.indexOf('</article>',at);const block=mod.slice(at,end);
  const objective=block.indexOf('nah-abg__lesson-objectives');const steps=block.indexOf('nah-abg__reading-steps');
  assert(objective>=0 && steps>=0 && objective<steps,`${id}: objectives must precede numbered step grid`);
  const firstLiStart=block.indexOf('<li>',steps);const firstLiEnd=block.indexOf('</li>',firstLiStart);
  assert(!block.slice(firstLiStart,firstLiEnd).includes('nah-abg__lesson-objectives'),`${id}: objectives nested in first reading step`);
  assert(!block.slice(firstLiStart,firstLiEnd).includes('nah-abg__lesson-example'),`${id}: example nested in first reading step`);
  assert(!block.slice(firstLiStart,firstLiEnd).includes('nah-abg__lesson-quiz'),`${id}: quiz nested in first reading step`);
}
assert(css.includes('.nah-abg__reading-steps > li {'));
assert(css.includes('.nah-abg__reading-steps > li > span {'));
assert(css.includes('v5.0.1 — Lesson Summary Card Layout Hotfix'));
assert(css.includes('.nah-abg .nah-abg__lesson-objectives ul > li'));
const sha=crypto.createHash('sha256').update(core).digest('hex');assert.strictEqual(sha,'92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02');
console.log('PASS v5.0.1 lesson summary layout isolation gate');

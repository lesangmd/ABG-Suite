# MEDIPHARM ABG Suite v5.9 — Content Governance & Production Audit

- Parent: v5.8.
- Freezes the v6.0 candidate corpus at 220 assessment items, 50 lessons, 50 clinical cases and six item formats.
- Expands fixed mock-test packs from six to eight without adding assessment items.
- Adds Comprehensive B and Multi-format mock packs with deterministic seeds.
- Adds production governance artifacts and regression gates for corpus integrity, Vietnamese editorial quality, responsive/dark-mode compatibility and calculation-core integrity.
- Local-first storage, route, trial access and calculation core remain unchanged.

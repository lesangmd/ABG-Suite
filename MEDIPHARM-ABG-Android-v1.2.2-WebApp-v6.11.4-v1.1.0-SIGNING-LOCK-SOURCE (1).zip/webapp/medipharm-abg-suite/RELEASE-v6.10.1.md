# MEDIPHARM ABG Suite v6.10.1 — Case Open Reliability & Learning 2×2

- Fixes opening all 13 canonical clinical cases by binding case cards directly and adding a capture-phase fallback router.
- Learning lists render as a 2-column card grid on desktop, with 2×2 learning category cards.
- Removes “Tiến độ” from the hamburger menu and mobile “Thêm” sheet.
- Keeps canonical learning v1.2.0 and ABG calculation core unchanged.

# MEDIPHARM ABG Suite v5.7.1 — Homepage Learning Hierarchy & Compact Profile Hotfix

Parent baseline: **v5.7 – Error Pattern & Targeted Remediation**  
Parent ZIP SHA-256: `5567fc3e140fe1610a768e4640db5ee54f87e3ba3c704a482560e37f4c96a434`

## Scope

UI/UX hotfix only. No clinical-content, calculation, assessment, remediation, access, route or storage migration.

## Changes

1. Reordered the app homepage into a clearer three-level hierarchy:
   - **Tiến độ của bạn**
   - **Chọn cách bạn muốn học**
   - **Hồ sơ học tập**
2. “Chọn cách bạn muốn học” now appears immediately below the compact progress module instead of after the full learning dashboard.
3. Removed duplicated module-title pairs, including:
   - `TIẾN ĐỘ CỦA BẠN` + `Hành trình của bạn`
   - `KHÁM PHÁ` + `Chọn cách bạn muốn học`
   - `HỒ SƠ HỌC TẬP` + `Nhìn lại hành trình của bạn`
   - `ÔN NHANH HÔM NAY` + `Thẻ ghi nhớ`
   - `KẾ HOẠCH HÔM NAY` + `Ba bước vừa đủ để tiến lên`
4. Rebuilt the learning-profile surface as a compact dashboard:
   - concise five-milestone summary;
   - five compact activity KPIs;
   - 7-day learning rhythm;
   - six-domain mastery view;
   - one learning insight;
   - compact flashcard review;
   - three-step daily study plan.
5. Removed the repeated “next step” CTA inside the portfolio because the progress module already owns the primary next-step recommendation.
6. Responsive profile layout:
   - desktop: asymmetric two-column dashboard;
   - tablet: balanced two-column arrangement with the portfolio spanning full width;
   - mobile: single-column compact stack without horizontal milestone scrolling.

## Preserved invariants

- 220 assessment questions unchanged.
- 50 handbook lessons unchanged.
- 50 clinical cases unchanged.
- Error Pattern & Targeted Remediation engine unchanged.
- Mock-test packs and Blueprint generator unchanged.
- Trial gate remains 10 launches for guests.
- localStorage key remains `medipharm_abg_learning_v30`.
- Canonical route remains `/phan-tich-khi-mau-app/`.
- No `fetch`, XHR, beacon or AJAX runtime added.
- Calculation core unchanged.

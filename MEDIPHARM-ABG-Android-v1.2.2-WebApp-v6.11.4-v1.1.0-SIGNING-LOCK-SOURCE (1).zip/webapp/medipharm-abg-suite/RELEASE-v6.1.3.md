# MEDIPHARM ABG Suite v6.1.3

Responsive Learning Card & Blueprint Generator Runtime Hotfix.

- Parent: v6.1.2.
- Touch-tablet cards now use a stacked, full-width layout even when the browser reports desktop-class CSS width.
- Mobile exam/generator removes redundant nested framing and expands controls to the usable viewport width.
- Start button now exposes an immediate busy state, resets cleanly on denied/failed trial authorization, and shows a clear inline state if no questions can be generated.
- User-facing assessment copy removes residual internal wording such as “blueprint”.
- Calculation core and clinical corpus unchanged.

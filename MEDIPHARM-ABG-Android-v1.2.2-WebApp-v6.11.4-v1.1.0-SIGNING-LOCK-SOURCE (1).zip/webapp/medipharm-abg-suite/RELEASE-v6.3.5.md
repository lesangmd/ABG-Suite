# MEDIPHARM ABG Suite v6.3.5 — Responsive Home IA & Header Controls

## Phạm vi
- Đưa **Trang chủ** thành màn hình mặc định thay cho mở thẳng module Phân tích.
- Header mới theo một cấu trúc ổn định: **Logo → Tìm kiếm → Tài khoản → Menu**.
- Trên mobile, tìm kiếm chuyển thành hàng thứ hai toàn chiều rộng thay vì bị ẩn.
- Bổ sung popover Tài khoản: đăng nhập/đăng ký khi là khách; tên tài khoản/đăng xuất khi đã đăng nhập.
- Điều hướng top-level được chuẩn hóa thành 6 mục: Trang chủ, Phân tích, Học tập, Ca lâm sàng, Ôn luyện, Tiến độ.
- Bỏ rail dọc desktop để tất cả breakpoint dùng cùng một mô hình điều hướng ngang; mobile dùng picker thu gọn.
- Trang chủ rút gọn theo 5 module nghiệp vụ, tiếp tục học và điểm nhấn học tập; hồ sơ chi tiết chuyển về module Tiến độ.

## Bất biến
- Không thay đổi thuật toán ABG, công thức, clinical rules, ngân hàng nội dung, access gate hoặc dữ liệu người dùng.
- O₂/CO₂ brand system v6.3.4 được giữ nguyên.

# Chuyên đề 2. Phân tích rối loạn toan–kiềm có hệ thống

## Mục tiêu
Người học cần nhận diện bốn rối loạn acid–base nguyên phát, áp dụng các công thức bù phù hợp, phân biệt tương đối rối loạn hô hấp cấp và mạn, và phát hiện rối loạn phối hợp.

## ABG-T02-S01 — Khung phân tích năm bước
Nên xác định rối loạn sinh lý trước rồi mới tìm nguyên nhân. Năm câu hỏi thực hành là: pH đang theo hướng toan hay kiềm; PaCO₂ hay HCO₃⁻ giải thích hướng thay đổi đó; phản ứng bù có phù hợp không; có nhiều rối loạn cùng tồn tại không; và bệnh cảnh nào giải thích toàn bộ mẫu hình.

pH <7,35 là toan máu, pH >7,45 là kiềm máu. pH 7,35–7,45 chưa đủ để gọi là bình thường nếu PaCO₂ hoặc HCO₃⁻ bất thường. Bốn rối loạn nguyên phát gồm toan chuyển hóa, kiềm chuyển hóa, toan hô hấp và kiềm hô hấp.

## ABG-T02-S02 — Toan chuyển hóa và công thức Winter
Trong toan chuyển hóa, cơ thể tăng thông khí để giảm PaCO₂. Công thức Winter:

**PaCO₂ dự kiến = 1,5 × HCO₃⁻ + 8 ± 2 mmHg**

Theo SI có thể quy đổi gần đúng:

**PaCO₂ dự kiến ≈ 0,20 × HCO₃⁻ + 1,07 ± 0,27 kPa**

PaCO₂ thực tế cao hơn mức dự kiến gợi ý toan hô hấp phối hợp hoặc thông khí bù không đủ. PaCO₂ thấp hơn rõ gợi ý kiềm hô hấp phối hợp. Công thức dùng để kiểm tra mức bù chứ không xác định nguyên nhân.

## ABG-T02-S03 — Kiềm chuyển hóa và bù hô hấp
Trong kiềm chuyển hóa, cơ thể có xu hướng giảm thông khí và giữ CO₂. Một ước tính thường dùng:

**PaCO₂ dự kiến ≈ 40 + 0,7 × (HCO₃⁻ − 24) ± 5 mmHg**

Tương đương gần đúng:

**PaCO₂ dự kiến ≈ 5,3 + 0,093 × (HCO₃⁻ − 24) ± 0,67 kPa**

PaCO₂ thấp hơn nhiều mức dự kiến gợi ý kiềm hô hấp phối hợp; cao hơn nhiều gợi ý toan hô hấp phối hợp. Nôn, giảm chloride, giảm thể tích và dùng lợi tiểu là các bệnh cảnh thường gặp.

## ABG-T02-S04 — Toan hô hấp: phân biệt cấp và mạn
Trong toan hô hấp cấp, HCO₃⁻ thường tăng khoảng 1 mmol/L cho mỗi 10 mmHg PaCO₂ tăng trên 40 mmHg. Trong toan hô hấp mạn, mức tăng thường khoảng 3,5–4 mmol/L cho mỗi 10 mmHg.

Ví dụ PaCO₂ 60 mmHg. Nếu cấp, HCO₃⁻ dự kiến khoảng 26 mmol/L. Nếu mạn, HCO₃⁻ thường khoảng 31–32 mmol/L. HCO₃⁻ thấp hơn nhiều mức dự kiến ở người tăng CO₂ mạn gợi ý thêm toan chuyển hóa; cao hơn quá mức có thể gợi ý thêm kiềm chuyển hóa.

## ABG-T02-S05 — Kiềm hô hấp: phân biệt cấp và mạn
Trong kiềm hô hấp cấp, HCO₃⁻ thường giảm khoảng 2 mmol/L cho mỗi 10 mmHg PaCO₂ giảm dưới 40 mmHg. Trong kiềm hô hấp mạn, HCO₃⁻ có thể giảm khoảng 4–5 mmol/L cho mỗi 10 mmHg.

Nếu HCO₃⁻ thấp hơn nhiều mức bù dự kiến, cần nghĩ thêm toan chuyển hóa. Kiềm hô hấp có thể gặp trong đau, thiếu oxy, nhiễm khuẩn nặng, bệnh gan hoặc một số ngộ độc; khí máu phản ánh sinh lý chứ không xác định nguyên nhân.

## ABG-T02-S06 — Rối loạn phối hợp và cách kết luận
Rối loạn phối hợp nên được nghĩ đến khi phản ứng bù nằm ngoài mức dự kiến, khi pH gần bình thường nhưng PaCO₂ và HCO₃⁻ đều bất thường rõ, hoặc khi pH thay đổi nặng hơn mức một rối loạn đơn lẻ có thể giải thích.

Ví dụ pH 7,44; PaCO₂ 2,7 kPa (20 mmHg); HCO₃⁻ 13 mmol/L. PaCO₂ giảm theo hướng gây kiềm, HCO₃⁻ giảm theo hướng gây toan; đây là rối loạn phối hợp chứ không phải khí máu bình thường.

Trình tự đọc nhanh: pH → PaCO₂ → HCO₃⁻ → kiểm tra bù → tìm rối loạn phối hợp → đánh giá oxy hóa → đối chiếu bệnh cảnh. Kết luận nên mô tả sinh lý trước rồi mới liên hệ nguyên nhân.

## Tóm tắt thực hành
- Luôn kiểm tra mức bù thay vì chỉ đặt tên rối loạn nguyên phát.
- Công thức Winter dùng cho toan chuyển hóa.
- Rối loạn hô hấp cấp và mạn có mức thay đổi HCO₃⁻ khác nhau.
- pH gần bình thường có thể che lấp rối loạn phối hợp nặng.

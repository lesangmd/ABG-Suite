# Chuyên đề 3. Khoảng trống anion và rối loạn chuyển hóa

## Mục tiêu
Người học cần tính và diễn giải đúng khoảng trống anion, hiệu chỉnh khi albumin giảm, phân biệt toan chuyển hóa tăng khoảng trống anion với toan tăng chloride và sử dụng tỷ số delta có chọn lọc để phát hiện rối loạn phối hợp.

## ABG-T03-S01 — Khoảng trống anion: cơ sở và cách tính
Khoảng trống anion (anion gap, AG) ước tính phần anion không được đo trực tiếp. Công thức thường dùng:

**AG = Na⁺ − (Cl⁻ + HCO₃⁻)**

đơn vị mmol/L. Giá trị bình thường phụ thuộc phương pháp xét nghiệm; khoảng 8–12 mmol/L thường được dùng như tham khảo kinh điển khi không tính kali, nhưng nên ưu tiên khoảng tham chiếu của phòng xét nghiệm.

Trong toan chuyển hóa tăng AG, một acid không bay hơi tích tụ. H⁺ được bicarbonat đệm làm HCO₃⁻ giảm, trong khi anion đi kèm tích tụ và làm AG tăng.

## ABG-T03-S02 — Hiệu chỉnh khoảng trống anion theo albumin
Albumin là anion không đo được quan trọng. Khi albumin giảm, AG nền cũng giảm và có thể che lấp sự tích tụ acid. Công thức thường dùng:

**AG hiệu chỉnh = AG đo được + 2,5 × (4 − albumin [g/dL])**

Nếu albumin dùng g/L:

**AG hiệu chỉnh = AG + 0,25 × (40 − albumin [g/L])**

Ví dụ AG đo được 12 mmol/L với albumin 20 g/L cho AG hiệu chỉnh khoảng 17 mmol/L. Không hiệu chỉnh có thể khiến một toan chuyển hóa tăng AG bị bỏ sót.

## ABG-T03-S03 — Toan chuyển hóa tăng khoảng trống anion
Các cơ chế quan trọng gồm tăng lactat, nhiễm toan ceton, suy thận tiến triển và một số thuốc hoặc độc chất. Lactat và keton nên được đo trực tiếp khi có chỉ định; AG chỉ giúp phân loại cơ chế chứ không thay thế xét nghiệm đặc hiệu.

Trong suy thận tiến triển, phosphate, sulfate và các anion khác tích tụ. Một số độc chất tạo ra acid hữu cơ hoặc chất chuyển hóa acid; đánh giá cần kết hợp bệnh sử, khoảng trống thẩm thấu nếu phù hợp, lactat, keton và xét nghiệm độc chất chuyên biệt.

## ABG-T03-S04 — Toan chuyển hóa không tăng AG và vai trò của chloride
Trong toan chuyển hóa không tăng AG, HCO₃⁻ giảm nhưng chloride tăng tương ứng nên AG không tăng đáng kể. Vì vậy còn gọi là toan chuyển hóa tăng chloride máu.

Các nguyên nhân điển hình gồm mất bicarbonat qua tiêu hóa, toan hóa ống thận và truyền lượng lớn dịch giàu chloride. Natri chloride 0,9% chứa chloride khoảng 154 mmol/L; truyền nhiều có thể làm xuất hiện hoặc làm nặng toan tăng chloride.

Khi HCO₃⁻ giảm mà chloride tăng tương ứng, nhóm nguyên nhân không tăng AG trở nên hợp lý hơn. Sau hồi sức dịch, HCO₃⁻ thấp kéo dài không nhất thiết đồng nghĩa bệnh nguyên ban đầu còn hoạt động.

## ABG-T03-S05 — Tỷ số delta và rối loạn chuyển hóa phối hợp
Khi AG tăng, có thể so sánh mức tăng AG với mức giảm HCO₃⁻:

**ΔAG = AG hiệu chỉnh − AG bình thường**

**ΔHCO₃⁻ = 24 − HCO₃⁻ thực tế**

**Tỷ số delta = ΔAG/ΔHCO₃⁻**

Nếu HCO₃⁻ giảm ít hơn nhiều so với mức tăng AG, có thể có thêm kiềm chuyển hóa. Nếu HCO₃⁻ giảm nhiều hơn, có thể có thêm toan chuyển hóa không tăng AG. Tuy nhiên tỷ số delta chịu ảnh hưởng của AG nền, albumin, thời điểm bệnh và điều trị; vì vậy chỉ nên dùng như công cụ gợi ý.

## ABG-T03-S06 — Chiến lược thực hành
Khi HCO₃⁻ thấp, nên hỏi lần lượt: AG có tăng không; albumin có thấp không; nếu AG tăng, mức tăng có tương xứng với mức giảm HCO₃⁻ không; nếu AG không tăng, chloride có tăng không; và bệnh cảnh nào giải thích được các thay đổi này.

Một người bệnh có thể đồng thời có toan lactic tăng AG và toan tăng chloride sau hồi sức dịch. Vì vậy không nên dừng phân tích sau khi nhận ra một cơ chế đầu tiên.

## Tóm tắt thực hành
- Tính AG khi HCO₃⁻ thấp.
- Hiệu chỉnh AG theo albumin khi cần.
- Tăng chloride gợi ý toan chuyển hóa không tăng AG.
- Tỷ số delta chỉ hỗ trợ phát hiện rối loạn phối hợp.

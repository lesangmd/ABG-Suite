# Chuyên đề 1. Nền tảng sinh lý khí máu và cân bằng toan–kiềm

## Mục tiêu
Sau chuyên đề này, người học cần hiểu mối liên hệ giữa pH, PaCO₂ và HCO₃⁻; giải thích được vai trò của hệ đệm, phổi và thận; hiểu ý nghĩa sinh lý của các thông số khí máu cốt lõi; và nhận biết được một bộ kết quả không hợp lý về mặt sinh lý.

## ABG-T01-S01 — Khí máu phản ánh điều gì?
Khí máu động mạch tích hợp ba quá trình sinh lý lớn: cân bằng toan–kiềm, thông khí phế nang và trao đổi oxy. pH cho biết trạng thái acid–base tổng thể; PaCO₂ phản ánh thành phần hô hấp và mức thông khí phế nang; HCO₃⁻ phản ánh chủ yếu thành phần chuyển hóa; PaO₂ và SaO₂ phản ánh oxy hóa nhưng phải đặt trong bối cảnh FiO₂, tuổi, áp suất khí quyển và mức hỗ trợ hô hấp.

Cần phân biệt trạng thái và quá trình. Toan máu là trạng thái pH thấp, còn quá trình gây toan là cơ chế có xu hướng làm giảm pH. Kiềm máu và quá trình gây kiềm cũng tương tự. Hai quá trình đối nghịch có thể làm pH gần bình thường, vì vậy pH bình thường không loại trừ rối loạn toan–kiềm.

## ABG-T01-S02 — Hệ đệm bicarbonat và phương trình Henderson–Hasselbalch
Hệ bicarbonat là hệ đệm ngoại bào quan trọng nhất trong thực hành khí máu. Phương trình Henderson–Hasselbalch có thể viết:

**pH = 6,1 + log[HCO₃⁻/(0,03 × PaCO₂)]**

khi HCO₃⁻ tính bằng mmol/L và PaCO₂ tính bằng mmHg. Nếu dùng kPa, hệ số hòa tan CO₂ tương ứng xấp xỉ 0,225. Giá trị lâm sàng cốt lõi của phương trình là pH phụ thuộc vào tỷ lệ HCO₃⁻/PaCO₂. HCO₃⁻ đại diện chủ yếu cho thành phần chuyển hóa; PaCO₂ đại diện cho thành phần hô hấp. Khi tỷ lệ giảm, pH giảm; khi tỷ lệ tăng, pH tăng.

Ví dụ HCO₃⁻ 24 mmol/L và PaCO₂ 5,3 kPa (40 mmHg) cho pH xấp xỉ 7,40. Mục tiêu không phải tính pH bằng tay thường quy mà là dùng quan hệ này để kiểm tra tính hợp lý của dữ liệu.

## ABG-T01-S03 — Vai trò của phổi trong điều hòa acid–base
CO₂ tham gia phản ứng CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻. Giữ CO₂ làm tăng H⁺ và có xu hướng làm pH giảm; thải CO₂ làm giảm H⁺ và có xu hướng làm pH tăng. Phổi điều chỉnh PaCO₂ chủ yếu thông qua thông khí phế nang.

Khi thông khí phế nang giảm, PaCO₂ tăng và có xu hướng gây toan hô hấp. Khi thông khí tăng, PaCO₂ giảm và có xu hướng gây kiềm hô hấp. PaCO₂ thường khoảng 4,7–6,0 kPa (35–45 mmHg), nhưng phải đọc theo bệnh cảnh. Phản ứng hô hấp diễn ra nhanh, vì vậy tăng thông khí là cơ chế bù quan trọng trong toan chuyển hóa.

## ABG-T01-S04 — Vai trò của thận trong điều hòa acid–base
Thận điều chỉnh acid–base chậm hơn phổi nhưng bền vững hơn thông qua tái hấp thu bicarbonat, bài tiết H⁺ và tạo bicarbonat mới. Khi PaCO₂ tăng kéo dài, thận tăng giữ bicarbonat; khi PaCO₂ giảm kéo dài, thận tăng bài tiết bicarbonat.

Vì thích nghi qua thận cần nhiều giờ đến vài ngày, mức HCO₃⁻ giúp phân biệt tương đối rối loạn hô hấp cấp với mạn. Trong suy thận, giảm khả năng bài tiết acid cố định có thể gây toan chuyển hóa; mẫu hình cụ thể tùy mức suy thận và mức tích tụ các anion không đo được.

## ABG-T01-S05 — Các thông số cốt lõi và ý nghĩa lâm sàng
Các thông số thường gặp gồm pH, PaCO₂, HCO₃⁻, kiềm dư (base excess), PaO₂ và SaO₂. HCO₃⁻ trên nhiều máy khí máu là giá trị tính từ pH và PaCO₂ chứ không phải phép đo hoàn toàn độc lập. CO₂ toàn phần trong xét nghiệm sinh hóa chủ yếu phản ánh bicarbonat nhưng không hoàn toàn đồng nhất với HCO₃⁻ trên khí máu.

Kiềm dư phản ánh mức thiếu hoặc dư base trong điều kiện chuẩn hóa; giá trị âm gợi ý thành phần toan chuyển hóa, giá trị dương gợi ý thành phần kiềm chuyển hóa. Tuy nhiên kiềm dư không thay thế việc phân tích HCO₃⁻, khoảng trống anion và bệnh cảnh.

PaO₂ phản ánh oxy hòa tan trong huyết tương, không phải tổng lượng oxy được vận chuyển. Ở người trẻ khỏe mạnh thở khí phòng tại mực nước biển, PaO₂ thường khoảng 10,7–13,3 kPa (80–100 mmHg), nhưng giảm theo tuổi và phụ thuộc FiO₂.

## ABG-T01-S06 — Đọc tích hợp và những sai lầm nền tảng
Cùng một PaCO₂ có thể mang ý nghĩa khác nhau tùy pH và HCO₃⁻. pH 7,28; PaCO₂ 8,0 kPa (60 mmHg); HCO₃⁻ 27 mmol/L phù hợp hơn với toan hô hấp tương đối cấp. pH 7,36; PaCO₂ 8,0 kPa; HCO₃⁻ 33 mmol/L phù hợp hơn với tăng CO₂ mạn đã được thận bù.

Các sai lầm thường gặp gồm kết luận chỉ dựa vào pH; gọi mọi PaCO₂ tăng là suy hô hấp mà không xét thời gian và mức bù; đánh giá PaO₂ mà không biết FiO₂; hoặc bỏ qua chất lượng mẫu. Trước khi phân tích sâu, cần hỏi bộ kết quả có hợp lý về mặt sinh lý và có phù hợp với bệnh cảnh hay không.

## Tóm tắt thực hành
- pH được quyết định chủ yếu bởi tỷ lệ HCO₃⁻/PaCO₂.
- Phổi điều chỉnh PaCO₂ nhanh; thận điều chỉnh bicarbonat chậm hơn nhưng bền vững.
- Không diễn giải PaO₂ nếu chưa biết FiO₂.
- pH bình thường không loại trừ rối loạn phối hợp.

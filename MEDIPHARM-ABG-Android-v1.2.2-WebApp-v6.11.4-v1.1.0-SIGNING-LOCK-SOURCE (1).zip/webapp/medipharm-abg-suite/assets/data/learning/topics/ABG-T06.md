# Chuyên đề 6. Chiến lược đọc khí máu nâng cao và các bẫy thường gặp

## Mục tiêu
Người học cần đánh giá chất lượng mẫu trước khi diễn giải, nhận diện kết quả không hợp lý về sinh lý, hiểu giới hạn của khí máu tĩnh mạch và SpO₂, và áp dụng được quy trình đọc khí máu nhanh nhưng không bỏ sót rối loạn phối hợp.

## ABG-T06-S01 — Kiểm tra chất lượng mẫu trước khi diễn giải
Trước khi đọc pH, cần hỏi mẫu có đáng tin hay không: động mạch hay tĩnh mạch, khí phòng hay oxy, FiO₂ bao nhiêu, có bọt khí, chậm phân tích hoặc pha loãng bởi heparin không.

Bọt khí làm kết quả tiến về cân bằng với khí môi trường; PaCO₂ thường giảm, pH có thể tăng nhẹ, còn PaO₂ có thể tăng hoặc giảm tùy giá trị ban đầu. Chậm phân tích cho phép tế bào tiếp tục tiêu thụ oxy và tạo CO₂, có thể làm PaO₂ giảm và pH giảm. Ở người tăng bạch cầu hoặc tiểu cầu rất cao, tiêu thụ oxy trong mẫu có thể rõ hơn.

Một kết quả rất khác lâm sàng nên khiến người đọc kiểm tra mẫu trước khi xây dựng một chẩn đoán hiếm gặp.

## ABG-T06-S02 — Khí máu động mạch, khí máu tĩnh mạch và giới hạn
Khí máu tĩnh mạch có thể hữu ích trong nhiều đánh giá acid–base. pH tĩnh mạch thường thấp hơn động mạch một mức nhỏ và PvCO₂ thường cao hơn PaCO₂, nhưng chênh lệch không cố định, đặc biệt trong sốc hoặc giảm tưới máu.

PO₂ tĩnh mạch không dùng để đánh giá oxy hóa động mạch. Khi cần đánh giá mức thiếu oxy, phải dựa vào SpO₂ đáng tin cậy hoặc PaO₂ động mạch. Khí máu tĩnh mạch không thay thế hoàn toàn khí máu động mạch khi cần đánh giá chính xác thông khí hoặc oxy hóa.

## ABG-T06-S03 — Giá trị trong khoảng tham chiếu nhưng không phù hợp sinh lý
Một giá trị nằm trong khoảng tham chiếu dân số vẫn có thể bất thường với bệnh cảnh cụ thể. Ví dụ HCO₃⁻ 8 mmol/L trong toan chuyển hóa nặng có PaCO₂ dự kiến theo Winter khoảng 20 ± 2 mmHg; PaCO₂ 40 mmHg dù nằm trong khoảng tham chiếu thông thường vẫn cho thấy thông khí bù không đủ.

Tương tự, pH 7,40 với PaCO₂ 20 mmHg và HCO₃⁻ 12 mmol/L không phải khí máu bình thường mà là hai quá trình đối nghịch. Cần dựa trên quan hệ sinh lý và mức bù, không chỉ trên dấu cao/thấp của phòng xét nghiệm.

## ABG-T06-S04 — SpO₂, PaO₂ và các dạng hemoglobin bất thường
SpO₂ và PaO₂ là hai đại lượng khác nhau. Không nên quy đổi cứng SpO₂ thành PaO₂ vì đường cong phân ly oxy–hemoglobin thay đổi theo pH, nhiệt độ, PaCO₂ và 2,3-DPG.

Trong ngộ độc carbon monoxit, PaO₂ có thể bình thường trong khi khả năng vận chuyển oxy giảm. Trong tăng methemoglobin máu, SpO₂ có thể không phản ánh chính xác. Khi nghi ngờ cần đo carboxyhemoglobin hoặc methemoglobin bằng đồng oxy quang phổ (co-oximetry).

## ABG-T06-S05 — Quy trình đọc nhanh trong khoảng 60 giây
Một quy trình thực hành có thể gồm: kiểm tra mẫu, FiO₂ và bệnh cảnh; xem pH; xem PaCO₂ và HCO₃⁻ để xác định quá trình chính; kiểm tra mức bù; nếu HCO₃⁻ thấp thì tính khoảng trống anion và hiệu chỉnh albumin khi cần; đánh giá PaO₂ trong bối cảnh FiO₂; tìm rối loạn phối hợp; cuối cùng mới gắn mẫu hình với nguyên nhân lâm sàng.

Kết luận nên theo cấu trúc: rối loạn acid–base → mức bù → rối loạn phối hợp → tình trạng oxy hóa → liên hệ bệnh cảnh.

Ví dụ: “Toan chuyển hóa tăng khoảng trống anion, bù hô hấp phù hợp; trong bối cảnh tăng glucose và keton, phù hợp nhiễm toan ceton do đái tháo đường.”

## ABG-T06-S06 — Khi nào nên nghi ngờ kết quả sai?
Cần xem xét lại mẫu khi PaO₂ không phù hợp với SpO₂; pH, PaCO₂ và HCO₃⁻ không tương thích; kết quả thay đổi đột ngột nhưng lâm sàng không thay đổi; mẫu có bọt khí; lấy từ đường truyền; thể tích rất nhỏ; hoặc phân tích chậm.

Ví dụ pH 7,10; PaCO₂ 20 mmHg; HCO₃⁻ 28 mmol/L không phù hợp với quan hệ Henderson–Hasselbalch của cùng một mẫu. Cần xác minh dữ liệu hoặc lặp lại mẫu trước khi suy luận sâu.

Trong thực hành, một mẫu được lấy lại đúng kỹ thuật thường có giá trị hơn một chuỗi suy luận phức tạp dựa trên dữ liệu sai.

## Tóm tắt thực hành
- Kiểm tra chất lượng dữ liệu trước khi diễn giải.
- Giá trị trong khoảng tham chiếu chưa chắc phù hợp với sinh lý người bệnh.
- Khí máu tĩnh mạch không thay thế hoàn toàn khí máu động mạch.
- Kết luận nên mô tả sinh lý trước rồi mới gắn với bệnh cảnh.

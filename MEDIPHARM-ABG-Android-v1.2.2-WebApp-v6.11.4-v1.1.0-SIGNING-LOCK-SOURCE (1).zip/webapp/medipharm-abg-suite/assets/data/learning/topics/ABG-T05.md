# Chuyên đề 5. Diễn giải khí máu theo bệnh cảnh lâm sàng

## Mục tiêu
Người học cần nhận diện các mẫu hình khí máu thường gặp theo bệnh cảnh, phân biệt hậu quả sinh lý với chẩn đoán nguyên nhân, nhận biết dấu hiệu gợi ý diễn biến nặng và trình bày kết luận theo cấu trúc sinh lý trước, bệnh cảnh sau.

## ABG-T05-S01 — COPD, hen và suy giảm thông khí
Ở COPD có tăng CO₂ mạn, HCO₃⁻ thường tăng do bù qua thận. Nếu trong đợt cấp PaCO₂ tăng thêm, HCO₃⁻ chưa tăng tương xứng và pH giảm rõ, nghĩ đến toan hô hấp cấp trên nền toan hô hấp mạn.

Trong hen cấp, giai đoạn đầu thường tăng thông khí nên PaCO₂ thấp. Nếu bệnh cảnh vẫn nặng mà PaCO₂ từ thấp trở về “bình thường” hoặc tăng, cần nghĩ đến giảm dự trữ thông khí và mệt cơ hô hấp. Một PaCO₂ trong khoảng tham chiếu dân số không phải lúc nào cũng là dấu hiệu yên tâm.

## ABG-T05-S02 — Viêm phổi, ARDS và suy giảm oxy hóa
Viêm phổi thường gây giảm oxy do bất tương hợp thông khí/tưới máu và luồng thông tắt. PaCO₂ thường thấp do tăng thông khí. Nếu PaCO₂ tăng trong khi oxy hóa xấu và công thở tăng, cần đánh giá khả năng mệt hô hấp.

Trong hội chứng suy hô hấp cấp tiến triển (acute respiratory distress syndrome, ARDS), tỷ số PaO₂/FiO₂ giúp lượng hóa mức suy giảm oxy hóa nhưng phải đặt trong bối cảnh PEEP, hình ảnh học, thời điểm khởi phát và toàn cảnh lâm sàng. PaCO₂ có thể thấp, bình thường hoặc tăng tùy khoảng chết, cài đặt máy thở và chiến lược thông khí.

## ABG-T05-S03 — DKA, nhiễm khuẩn huyết và sốc
Nhiễm toan ceton do đái tháo đường (DKA) điển hình gây toan chuyển hóa tăng khoảng trống anion với giảm PaCO₂ do tăng thông khí bù. Nếu PaCO₂ cao hơn mức Winter, cần nghĩ đến suy hô hấp phối hợp hoặc giảm khả năng bù. Trong quá trình điều trị, khoảng trống anion có thể đóng lại trong khi HCO₃⁻ còn thấp do tăng chloride.

Nhiễm khuẩn huyết có thể gây tăng lactat đồng thời với kiềm hô hấp do tăng thông khí; vì vậy pH có thể gần bình thường dù rối loạn đáng kể. Lactat cần được đọc theo xu hướng, huyết động và toàn trạng; không nên đồng nhất mọi tăng lactat với thiếu oxy mô đơn thuần.

Trong sốc, PaCO₂ cao hơn mức bù dự kiến ở người toan chuyển hóa nặng có thể báo hiệu suy giảm khả năng thông khí và làm pH giảm nhanh hơn.

## ABG-T05-S04 — Suy thận, nôn và tiêu chảy
Suy thận tiến triển làm giảm bài tiết acid cố định. Giai đoạn sớm có thể gặp toan chuyển hóa tăng chloride; khi suy thận nặng hơn, khoảng trống anion thường tăng do tích tụ phosphate, sulfate và các anion khác.

Nôn nhiều gây mất acid dịch vị và thường dẫn đến kiềm chuyển hóa kèm giảm chloride, giảm kali và giảm thể tích tuần hoàn. Tiêu chảy kéo dài gây mất bicarbonat, điển hình tạo toan chuyển hóa tăng chloride với khoảng trống anion không tăng.

Các bệnh cảnh này phải được đọc cùng điện giải, chức năng thận, tình trạng thể tích và thuốc đang sử dụng.

## ABG-T05-S05 — Thuyên tắc phổi và ngộ độc
Thuyên tắc phổi thường gây tăng thông khí với PaCO₂ giảm và PaO₂ giảm, nhưng khí máu không đủ đặc hiệu để chẩn đoán hoặc loại trừ bệnh. Kết quả chỉ phản ánh hậu quả sinh lý.

Opioid làm giảm kích thích hô hấp trung ương và thường gây toan hô hấp cấp. Nếu chênh áp A–a tăng nhiều, cần nghĩ thêm tổn thương phổi như hít sặc.

Salicylate là ví dụ kinh điển của rối loạn phối hợp: kiềm hô hấp do kích thích trung tâm hô hấp và toan chuyển hóa tăng khoảng trống anion do các acid hữu cơ. pH có thể thấp, bình thường hoặc cao.

## ABG-T05-S06 — Thở máy và các mẫu hình cần cảnh giác
Ở người thở máy, PaCO₂ phải được đọc cùng thông khí phút, thể tích khí lưu thông, khoảng chết và khả năng có PEEP nội sinh (auto-PEEP). PaO₂ phải được đọc cùng FiO₂, PEEP và cơ chế tổn thương phổi.

Các mẫu hình đáng chú ý gồm pH giảm sâu đang tiến triển; PaCO₂ tăng nhanh ở hen hoặc COPD nặng; PaCO₂ cao hơn nhiều mức Winter trong toan chuyển hóa nặng; PaO₂ thấp dù FiO₂ cao; hoặc pH gần bình thường nhưng PaCO₂ và HCO₃⁻ đều bất thường sâu.

Những mẫu hình này không tự động xác định chẩn đoán nhưng cho thấy cần đánh giá nhanh nguyên nhân và mức độ nặng.

## Tóm tắt thực hành
- Mô tả rối loạn sinh lý trước, sau đó mới liên hệ bệnh cảnh.
- Một bệnh có thể tạo nhiều mẫu hình khí máu tùy giai đoạn.
- PaCO₂ “bình thường” không phải lúc nào cũng bình thường về sinh lý.
- Khí máu không thay thế chẩn đoán nguyên nhân.

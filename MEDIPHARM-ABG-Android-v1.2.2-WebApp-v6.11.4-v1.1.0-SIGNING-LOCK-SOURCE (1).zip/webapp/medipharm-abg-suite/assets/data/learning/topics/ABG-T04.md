# Chuyên đề 4. Thông khí, oxy hóa và trao đổi khí

## Mục tiêu
Người học cần phân biệt thông khí với oxy hóa, hiểu ý nghĩa của PaCO₂, PaO₂, SaO₂ và FiO₂, sử dụng đúng tỷ số PaO₂/FiO₂ và chênh áp oxy phế nang–động mạch, đồng thời nhận diện các cơ chế chính gây giảm oxy máu.

## ABG-T04-S01 — Thông khí phế nang và PaCO₂
Thông khí nói đến khả năng đào thải CO₂. Trong điều kiện sản xuất CO₂ tương đối ổn định, PaCO₂ tỷ lệ nghịch với thông khí phế nang. Thông khí phế nang khác thông khí phút vì phải trừ phần khoảng chết.

Do đó một người bệnh thở nhanh vẫn có thể giữ CO₂ nếu thể tích khí lưu thông nhỏ hoặc khoảng chết lớn. PaCO₂ phản ánh hiệu quả thông khí tốt hơn việc chỉ nhìn tần số thở. Tăng PaCO₂ có thể gặp khi giảm kích thích hô hấp trung ương, yếu cơ hô hấp, tắc nghẽn nặng, mệt cơ hoặc cài đặt thông khí chưa đủ.

## ABG-T04-S02 — PaO₂, SaO₂ và khả năng vận chuyển oxy
PaO₂ phản ánh oxy hòa tan trong huyết tương, trong khi phần lớn oxy gắn với hemoglobin. Hàm lượng oxy động mạch có thể ước tính:

**CaO₂ ≈ 1,34 × Hb × SaO₂ + 0,003 × PaO₂**

khi Hb dùng g/dL và PaO₂ dùng mmHg. Thành phần oxy hòa tan rất nhỏ so với oxy gắn hemoglobin.

Người bệnh thiếu máu nặng có thể có PaO₂ và SaO₂ bình thường nhưng khả năng vận chuyển oxy vẫn giảm. Cung cấp oxy mô còn phụ thuộc cung lượng tim; vì vậy PaO₂ bình thường không bảo đảm cung cấp oxy mô bình thường.

## ABG-T04-S03 — FiO₂ và tỷ số PaO₂/FiO₂
PaO₂ chỉ có ý nghĩa khi biết FiO₂. PaO₂ 10,7 kPa (80 mmHg) có thể chấp nhận khi thở khí phòng nhưng rất bất thường nếu FiO₂ là 0,80.

Tỷ số PaO₂/FiO₂ = PaO₂ chia FiO₂ dạng phân số. Ví dụ PaO₂ 80 mmHg với FiO₂ 0,40 cho tỷ số 200 mmHg. Nếu biểu diễn theo SI: 10,7 kPa/0,40 ≈ 26,7 kPa. Trong thực hành quốc tế, tỷ số này thường vẫn được báo bằng mmHg.

Tỷ số PaO₂/FiO₂ giúp lượng hóa suy giảm oxy hóa nhưng cần đọc cùng PEEP, phương thức hỗ trợ và bệnh cảnh.

## ABG-T04-S04 — Phương trình khí phế nang và chênh áp A–a
Áp suất oxy phế nang có thể ước tính:

**PAO₂ = FiO₂ × (PB − PH₂O) − PaCO₂/R**

Ở mực nước biển, PB khoảng 101,3 kPa (760 mmHg), PH₂O khoảng 6,3 kPa (47 mmHg), R thường khoảng 0,8.

Chênh áp oxy phế nang–động mạch (A–a) = PAO₂ − PaO₂. A–a hỗ trợ phân biệt giảm oxy do giảm thông khí đơn thuần với bất thường trao đổi khí trong phổi. Một ước tính lâm sàng thường dùng ở người thở khí phòng là A–a dự kiến ≈ tuổi/4 + 4 mmHg, nhưng không nên xem đây là ngưỡng tuyệt đối.

## ABG-T04-S05 — Năm cơ chế chính của giảm oxy máu
Năm cơ chế chính gồm FiO₂ thấp, giảm thông khí, bất tương hợp thông khí/tưới máu (V/Q mismatch), luồng thông tắt (shunt) và hạn chế khuếch tán.

Giảm thông khí thường đi kèm PaCO₂ tăng và A–a không tăng nhiều nếu phổi còn trao đổi khí tốt. Bất tương hợp thông khí/tưới máu thường cải thiện với oxy bổ sung. Luồng thông tắt đáp ứng kém hơn với tăng FiO₂. Hạn chế khuếch tán có thể rõ hơn khi gắng sức. FiO₂ thấp điển hình ở độ cao.

Việc xác định cơ chế có giá trị hơn chỉ ghi nhận PaO₂ thấp.

## ABG-T04-S06 — SpO₂, đồng oxy quang phổ và các giới hạn
SpO₂ là độ bão hòa oxy ước tính bằng máy đo ngoại vi. SaO₂ trên khí máu có thể là giá trị tính toán hoặc đo trực tiếp tùy thiết bị. Hai giá trị thường gần nhau nhưng không hoàn toàn tương đương.

Trong ngộ độc carbon monoxit hoặc tăng methemoglobin máu, PaO₂ có thể vẫn bình thường trong khi khả năng vận chuyển oxy bị ảnh hưởng. Khi nghi ngờ cần đo các dạng hemoglobin bằng đồng oxy quang phổ (co-oximetry). Không nên dùng SpO₂ để suy chính xác PaO₂ hoặc đánh giá thông khí.

## Tóm tắt thực hành
- PaCO₂ trả lời chủ yếu câu hỏi về thông khí.
- PaO₂/SaO₂ trả lời chủ yếu câu hỏi về oxy hóa.
- Luôn đặt PaO₂ trong bối cảnh FiO₂.
- Nhận diện cơ chế giảm oxy máu thay vì chỉ đánh dấu PaO₂ thấp.

# MEDIPHARM ABG Learning Canonical v1.5.1

Bộ dữ liệu chuẩn cho 6 chuyên đề khí máu, dùng làm nguồn nội dung duy nhất cho WebApp v6.8.0 và Android v1.2.0.

## Thành phần
- `topics.json`: cấu trúc 6 chuyên đề, 36 đoạn nội dung lớn.
- `topics/ABG-T01.md` … `ABG-T06.md`: nội dung chuyên môn đã tái tổ chức theo ít đề mục lớn hơn.
- `terms.json`: từ điển thuật ngữ cốt lõi.
- `qa.json`: 38 câu hỏi–đáp lâm sàng.
- `quizzes.json`: vị trí liên kết ngân hàng ôn luyện theo từng đoạn.
- `cases.json`: metadata các ca lâm sàng.
- `crosslinks.json` và `crosslinks.csv`: liên kết từng đoạn Chuyên đề ↔ Từ điển ↔ Hỏi đáp ↔ Ôn luyện ↔ Ca lâm sàng.
- `terminology_vi.json`: quy tắc Việt hóa.
- `unit_conventions.json`: quy ước SI ↔ đơn vị thường dùng tại Hoa Kỳ.

## Nguyên tắc
Nội dung người dùng cuối không hiển thị ngôn ngữ audit hoặc phát triển phần mềm. Tiếng Việt là ngôn ngữ chính; tiếng Anh chỉ xuất hiện trong ngoặc khi có giá trị tra cứu.


## v1.0.1
Chuẩn hóa thêm các cụm tiếng Anh còn sót trong nội dung hiển thị; giữ tiếng Anh trong ngoặc khi có giá trị tra cứu quốc tế.


## v1.2.0
- Hỏi đáp được mở rộng thành trả lời + giải thích + ý nghĩa lâm sàng.
- 25 ca lâm sàng có bệnh sử, khám, xét nghiệm, khí máu, câu hỏi tự phân tích, lập luận theo bước và điểm cần nhớ.
- Hỗ trợ điều hướng một khung đọc với nút Quay lại.
- Không gắn ca lâm sàng mẫu trực tiếp vào công cụ Phân tích.


## Ca lâm sàng v1.2
Mỗi ca gồm: Bệnh sử → Khám lâm sàng → Chẩn đoán sơ bộ → Xét nghiệm kèm theo (bao gồm khí máu) → Tự phân tích → Lập luận chẩn đoán → Chẩn đoán phân biệt → Hướng xử trí và điều trị → Điểm cần nhớ.


## v1.4.0 — Ca lâm sàng theo bối cảnh đầy đủ
- 25/25 ca có hồ sơ người bệnh giả định, lý do vào viện, bệnh sử hiện tại, tiền sử, thuốc đang dùng, dấu hiệu sinh tồn, khám theo cơ quan, cận lâm sàng và khí máu.
- Câu hỏi học tập chuyển thành từng cặp Câu hỏi → Đáp án → Thảo luận, cho phép người học tự trả lời trước khi mở giải thích.
- Giữ chẩn đoán sơ bộ, lập luận tổng hợp, chẩn đoán phân biệt, hướng xử trí và điểm cần nhớ.
- Ca bệnh được xác định rõ là tình huống giả định phục vụ học tập.


## Mở rộng Từ điển Khí máu v1.4.0
- Nhập 300 thuật ngữ/công thức từ `Tu dien khi mau.docx`; tổng sau hợp nhất: 306.
- Công thức Office Math được đọc theo cấu trúc phân số, ngoặc, chỉ số trên/dưới thay vì ghép phẳng ký tự.
- Giữ `source_definition_vi` nguyên bản; `definition_vi` chỉ chuẩn hóa ký hiệu hiển thị.
- Các ID canonical cũ được giữ để bảo toàn liên kết từ Chuyên đề.
- Chưa thực hiện vòng kiểm chứng học thuật ngoài tài liệu nguồn.


## v1.5.0 — Mở rộng Ca lâm sàng
- Bổ sung 12 ca mới; tổng số 25 ca contextual.
- Ca mới bao phủ phù phổi cấp do tim, toan lactic liên quan metformin, methanol, ethylene glycol, carbon monoxide, methemoglobinemia, giảm thông khí do béo phì, cơn nhược cơ, kiềm sau tăng CO₂ mạn, RTA týp 1, RTA týp 4 và rối loạn acid–base ba thành phần.
- Tất cả ca tiếp tục dùng bệnh sử đầy đủ, khám, xét nghiệm, ABG, câu hỏi–đáp án–thảo luận, lập luận, phân biệt, xử trí và điểm cần nhớ.

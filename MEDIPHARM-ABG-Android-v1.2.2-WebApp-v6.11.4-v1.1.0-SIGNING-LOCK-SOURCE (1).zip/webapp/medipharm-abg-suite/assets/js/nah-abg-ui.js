(function () {
	'use strict';

	var Core = window.NAHABGCore;
	var Config = window.NAHABGConfig || {};
	var Access = window.NAHABGAccess || {};
	var deferredInstallPrompt = null;

	if (!Core) {
		return;
	}

	window.addEventListener('beforeinstallprompt', function (event) {
		event.preventDefault();
		deferredInstallPrompt = event;
		document.dispatchEvent(new CustomEvent('nah-abg-install-ready'));
	});

	window.addEventListener('appinstalled', function () {
		deferredInstallPrompt = null;
		document.querySelectorAll('[data-install-app]').forEach(function (button) {
			button.hidden = true;
		});
	});

	var DEMOS = {
		normal: {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			age: 35,
			sex: 'male',
			ph: 7.40,
			paco2: 40,
			hco3: 24,
			pao2: 95,
			sao2: 98,
			fio2: 21,
			oxygenDevice: 'room-air',
			sodium: 140,
			clorid: 104,
			potassium: 4,
			albumin: 40,
			albuminUnit: 'gl',
			caseSummary: 'Người bệnh ổn định, lấy khí máu động mạch khi thở khí phòng.'
		},
		hagma: {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			age: 52,
			sex: 'female',
			ph: 7.21,
			paco2: 25,
			hco3: 10,
			pao2: 92,
			sao2: 96,
			fio2: 21,
			oxygenDevice: 'room-air',
			sodium: 138,
			clorid: 100,
			potassium: 4.8,
			albumin: 32,
			albuminUnit: 'gl',
			lactate: 5.1,
			priorLactate: 7.8,
			lactateIntervalHours: 2,
			glucose: 16,
			glucoseUnit: 'mmol',
			urea: 9,
			ureaUnit: 'urea-mmol',
			creatinine: 130,
			creatinineUnit: 'umol',
			measuredOsm: 310,
			clinicalContexts: ['sepsis', 'shock'],
			caseSummary: 'Sốt, tụt huyết áp, thở nhanh; nghi nhiễm trùng huyết có giảm tưới máu.'
		},
		dka: {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			age: 28,
			sex: 'female',
			ph: 7.12,
			paco2: 22,
			hco3: 7,
			pao2: 106,
			sao2: 98,
			fio2: 21,
			oxygenDevice: 'room-air',
			sodium: 132,
			clorid: 96,
			potassium: 5.4,
			albumin: 38,
			albuminUnit: 'gl',
			glucose: 24,
			glucoseUnit: 'mmol',
			ketones: 5.6,
			creatinine: 115,
			creatinineUnit: 'umol',
			clinicalContexts: ['diabetes'],
			caseSummary: 'Đái tháo đường, nôn, đau bụng, khát nhiều, thở nhanh sâu.'
		},
		'acute-resp-acidosis': {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			chronicity: 'acute',
			age: 68,
			sex: 'male',
			ph: 7.24,
			paco2: 68,
			hco3: 28,
			pao2: 58,
			sao2: 87,
			fio2: 28,
			oxygenDevice: 'conventional',
			sodium: 140,
			clorid: 103,
			potassium: 4.7,
			albumin: 36,
			albuminUnit: 'gl',
			hemoglobin: 135,
			hemoglobinUnit: 'gl',
			clinicalContexts: ['copd'],
			caseSummary: 'COPD đợt cấp, khó thở tăng, co kéo cơ hô hấp, đang thở oxy gọng kính.'
		},
		mixed: {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			age: 60,
			sex: 'male',
			ph: 7.05,
			paco2: 58,
			hco3: 16,
			pao2: 54,
			sao2: 84,
			fio2: 40,
			oxygenDevice: 'conventional',
			sodium: 136,
			clorid: 106,
			potassium: 6.1,
			albumin: 28,
			albuminUnit: 'gl',
			lactate: 6.2,
			clinicalContexts: ['shock', 'cns-depressant'],
			caseSummary: 'Sốc kèm giảm tri giác và giảm thông khí; đang được hỗ trợ oxy.'
		},
		'smoke-exposure': {
			sampleType: 'arterial',
			unitSystem: 'si',
			gasPressureUnit: 'mmhg',
			age: 42,
			sex: 'male',
			ph: 7.32,
			paco2: 34,
			hco3: 17,
			pao2: 112,
			sao2: 72,
			spo2: 98,
			cohb: 27,
			methb: 0.8,
			lactate: 3.4,
			fio2: 100,
			oxygenDevice: 'conventional',
			sodium: 139,
			clorid: 104,
			potassium: 4.1,
			albumin: 39,
			albuminUnit: 'gl',
			hemoglobin: 148,
			hemoglobinUnit: 'gl',
			clinicalContexts: ['smoke-fire'],
			caseSummary: 'Được đưa ra khỏi đám cháy trong không gian kín; đau đầu, lú lẫn, SpO₂ hiển thị cao.'
		},
		'resp-alkalosis': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 34, sex: 'female',
			ph: 7.52, paco2: 25, hco3: 20, pao2: 104, sao2: 99, fio2: 21, oxygenDevice: 'room-air',
			sodium: 139, clorid: 104, potassium: 3.6, albumin: 40, albuminUnit: 'gl',
			clinicalContexts: ['pain-anxiety'], caseSummary: 'Khởi phát khó thở, tê quanh miệng và co quắp bàn tay sau căng thẳng; phổi không ran, SpO₂ bình thường.'
		},
		'metabolic-alkalosis': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 61, sex: 'female',
			ph: 7.50, paco2: 48, hco3: 36, pao2: 82, sao2: 96, fio2: 21, oxygenDevice: 'room-air',
			sodium: 138, clorid: 88, potassium: 2.9, albumin: 37, albuminUnit: 'gl',
			clinicalContexts: ['vomiting','diuretic'], caseSummary: 'Nôn kéo dài và đang dùng lợi tiểu; khát, yếu cơ, hạ kali máu và hạ clo máu.'
		},
		'copd-chronic': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', chronicity: 'chronic', age: 72, sex: 'male',
			ph: 7.36, paco2: 60, hco3: 33, pao2: 61, sao2: 89, fio2: 28, oxygenDevice: 'conventional',
			sodium: 141, clorid: 101, potassium: 4.2, albumin: 35, albuminUnit: 'gl',
			clinicalContexts: ['copd'], caseSummary: 'COPD nặng, giai đoạn ổn định, tăng CO₂ mạn đã biết; lấy mẫu khi đang thở oxy lưu lượng thấp.'
		},
		'salicylate-mixed': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 24, sex: 'female',
			ph: 7.46, paco2: 20, hco3: 14, pao2: 108, sao2: 99, fio2: 21, oxygenDevice: 'room-air',
			sodium: 140, clorid: 104, potassium: 3.8, albumin: 41, albuminUnit: 'gl', lactate: 2.1,
			clinicalContexts: ['salicylate'], caseSummary: 'Ù tai, buồn nôn, thở nhanh sau dùng salicylat liều cao; gợi ý rối loạn hỗn hợp kiềm hô hấp và toan chuyển hóa.'
		},
		'nagma-diarrhea': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 47, sex: 'male',
			ph: 7.27, paco2: 30, hco3: 14, pao2: 96, sao2: 97, fio2: 21, oxygenDevice: 'room-air',
			sodium: 137, clorid: 113, potassium: 3.2, albumin: 39, albuminUnit: 'gl',
			clinicalContexts: ['diarrhea'], caseSummary: 'Tiêu chảy nhiều ngày, mất nước và hạ kali; clo tăng tương đối, khoảng trống anion dự kiến không tăng.'
		},
		'pe-hypoxemia': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 56, sex: 'female',
			ph: 7.48, paco2: 29, hco3: 21, pao2: 58, sao2: 89, fio2: 21, oxygenDevice: 'room-air',
			sodium: 140, clorid: 105, potassium: 4.0, albumin: 38, albuminUnit: 'gl',
			clinicalContexts: ['pulmonary-embolism'], caseSummary: 'Khó thở đột ngột và đau ngực kiểu màng phổi; nhịp tim nhanh, giảm oxy máu khi thở khí phòng.'
		},
		'ards-oxygenation': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 63, sex: 'male',
			ph: 7.33, paco2: 46, hco3: 24, pao2: 62, sao2: 90, fio2: 60, oxygenDevice: 'ventilator', peep: 10,
			sodium: 138, clorid: 104, potassium: 4.4, albumin: 27, albuminUnit: 'gl', lactate: 2.4,
			clinicalContexts: ['sepsis'], caseSummary: 'Viêm phổi nặng kèm nhiễm trùng huyết, đang thở máy; FiO₂ 0,60 và áp lực dương cuối thì thở ra 10 cmH₂O, cần tập trung đánh giá oxy hóa.'
		},
		'sample-air-bubble': {
			sampleType: 'arterial', unitSystem: 'si', gasPressureUnit: 'mmhg', age: 50, sex: 'male',
			ph: 7.43, paco2: 34, hco3: 22, pao2: 142, sao2: 99, fio2: 21, oxygenDevice: 'room-air',
			sodium: 139, clorid: 104, potassium: 4.1, albumin: 40, albuminUnit: 'gl', sampleIssues: ['air-bubbles'],
			caseSummary: 'Mẫu lấy khi thở khí phòng nhưng PaO₂ cao bất thường; quan sát thấy bọt khí trong bơm tiêm. Ca dùng để học nhận diện sai số tiền phân tích.'
		}
,
		'pregnancy-resp-alk': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:30,sex:'female',ph:7.46,paco2:30,hco3:21,pao2:108,sao2:99,fio2:21,oxygenDevice:'room-air',sodium:137,clorid:104,potassium:3.7,albumin:34,albuminUnit:'gl',clinicalContexts:['pregnancy'],caseSummary:'Thai 30 tuần, không khó thở, khí máu được lấy khi thở khí phòng; mục tiêu là nhận biết thay đổi sinh lý hô hấp trong thai kỳ.'},
		'opioid-hypoventilation': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:39,sex:'male',ph:7.18,paco2:72,hco3:26,pao2:55,sao2:84,fio2:21,oxygenDevice:'room-air',sodium:140,clorid:104,potassium:4.3,albumin:39,albuminUnit:'gl',clinicalContexts:['cns-depressant'],caseSummary:'Giảm tri giác và thở chậm sau dùng opioid; giảm thông khí phế nang rõ.'},
		'renal-failure-hagma': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:66,sex:'male',ph:7.22,paco2:29,hco3:12,pao2:90,sao2:96,fio2:21,oxygenDevice:'room-air',sodium:139,clorid:102,potassium:5.8,albumin:35,albuminUnit:'gl',creatinine:720,creatinineUnit:'umol',clinicalContexts:['renal-failure'],caseSummary:'Bệnh thận mạn tiến triển, mệt nhiều, tăng kali và giảm bicarbonat; đánh giá toan chuyển hóa do suy thận.'},
		'vomiting-plus-resp-alk': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:44,sex:'female',ph:7.58,paco2:32,hco3:29,pao2:103,sao2:98,fio2:21,oxygenDevice:'room-air',sodium:137,clorid:91,potassium:3.0,albumin:40,albuminUnit:'gl',clinicalContexts:['vomiting','pain-anxiety'],caseSummary:'Nôn nhiều kèm đau và tăng thông khí; pH tăng cao gợi ý hơn một cơ chế kiềm hóa.'},
		'saline-nagma': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:58,sex:'male',ph:7.30,paco2:32,hco3:16,pao2:94,sao2:97,fio2:21,oxygenDevice:'room-air',sodium:142,clorid:116,potassium:4.0,albumin:33,albuminUnit:'gl',clinicalContexts:['saline-load'],caseSummary:'Sau hồi sức dịch NaCl 0,9% lượng lớn; clo tăng, bicarbonat giảm, khoảng trống anion không tăng đáng kể.'},
		'ketoacidosis-sglt2': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:53,sex:'female',ph:7.19,paco2:24,hco3:9,pao2:97,sao2:98,fio2:21,oxygenDevice:'room-air',sodium:136,clorid:101,potassium:4.9,albumin:38,albuminUnit:'gl',glucose:9.8,glucoseUnit:'mmol',ketones:5.2,clinicalContexts:['diabetes','sglt2'],caseSummary:'Đái tháo đường đang dùng thuốc ức chế SGLT2, buồn nôn và thở nhanh; glucose chỉ tăng vừa nhưng ceton tăng rõ.'},
		'methanol-pattern': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:37,sex:'male',ph:6.98,paco2:18,hco3:4,pao2:110,sao2:99,fio2:21,oxygenDevice:'room-air',sodium:142,clorid:102,potassium:4.6,albumin:40,albuminUnit:'gl',measuredOsm:340,glucose:5.5,glucoseUnit:'mmol',urea:5,ureaUnit:'urea-mmol',clinicalContexts:['toxic-alcohol'],caseSummary:'Rối loạn thị giác và toan chuyển hóa nặng sau phơi nhiễm dung môi; đánh giá khoảng trống anion và thẩm thấu.'},
		'seizure-lactate': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:29,sex:'male',ph:7.16,paco2:30,hco3:10,pao2:101,sao2:98,fio2:21,oxygenDevice:'room-air',sodium:140,clorid:103,potassium:4.2,albumin:41,albuminUnit:'gl',lactate:9.0,clinicalContexts:['seizure'],caseSummary:'Lấy khí máu ngay sau cơn co giật toàn thể; lactat tăng cao, cần chú ý diễn biến theo thời gian.'},
		'neuromuscular-hypercapnia': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:51,sex:'female',ph:7.29,paco2:58,hco3:27,pao2:64,sao2:90,fio2:21,oxygenDevice:'room-air',sodium:138,clorid:103,potassium:4.1,albumin:39,albuminUnit:'gl',clinicalContexts:['neuromuscular'],caseSummary:'Yếu cơ hô hấp tiến triển, thở nông; tăng CO₂ và giảm oxy do giảm thông khí.'},
		'high-altitude': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:32,sex:'male',ph:7.48,paco2:28,hco3:20,pao2:58,sao2:89,fio2:21,oxygenDevice:'room-air',atmosphericPressure:560,sodium:140,clorid:104,potassium:3.8,albumin:42,albuminUnit:'gl',clinicalContexts:['high-altitude'],caseSummary:'Mới lên vùng cao; giảm áp suất khí quyển, giảm PaO₂ và tăng thông khí.'},
		'hfnc-hypoxemia': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:70,sex:'male',ph:7.42,paco2:37,hco3:24,pao2:68,sao2:93,spo2:94,fio2:50,oxygenDevice:'hfnc',peep:4,sodium:139,clorid:104,potassium:4.0,albumin:31,albuminUnit:'gl',caseSummary:'Viêm phổi nặng đang được hỗ trợ oxy dòng cao qua gọng mũi với FiO₂ 0,50; đánh giá mức giảm oxy và độ tin cậy của các chỉ số theo FiO₂.'},
		'niv-copd': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:73,sex:'male',ph:7.26,paco2:70,hco3:31,pao2:67,sao2:91,fio2:35,oxygenDevice:'niv',peep:6,sodium:140,clorid:100,potassium:4.4,albumin:35,albuminUnit:'gl',clinicalContexts:['copd'],caseSummary:'COPD đợt cấp đang được thông khí không xâm nhập, còn toan hô hấp và tăng CO₂; theo dõi đáp ứng cần dựa trên nhiều lần khí máu.'},
		'vbg-dka': {sampleType:'venous',unitSystem:'si',gasPressureUnit:'mmhg',age:26,sex:'female',ph:7.17,paco2:30,hco3:11,pao2:38,sao2:70,fio2:21,oxygenDevice:'room-air',sodium:134,clorid:98,potassium:5.1,albumin:39,albuminUnit:'gl',glucose:22,glucoseUnit:'mmol',ketones:5.0,clinicalContexts:['diabetes'],caseSummary:'Mẫu tĩnh mạch ở người bệnh nghi nhiễm toan ceton do đái tháo đường; dùng để học giới hạn của PO₂ tĩnh mạch trong đánh giá oxy hóa.'},
		'methemoglobinemia': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:45,sex:'male',ph:7.39,paco2:39,hco3:23,pao2:96,sao2:86,spo2:85,methb:12,fio2:21,oxygenDevice:'room-air',sodium:139,clorid:104,potassium:4.0,albumin:40,albuminUnit:'gl',clinicalContexts:['oxidant-drug'],caseSummary:'Tím tái sau thuốc/chất oxy hóa; PaO₂ bình thường nhưng độ bão hòa thấp và MetHb tăng.'},
		'mixed-hagma-alkalosis': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:57,sex:'female',ph:7.41,paco2:31,hco3:19,pao2:94,sao2:97,fio2:21,oxygenDevice:'room-air',sodium:140,clorid:96,potassium:3.4,albumin:36,albuminUnit:'gl',lactate:4.8,clinicalContexts:['vomiting','sepsis'],caseSummary:'Nôn nhiều kèm nhiễm trùng; pH gần bình thường không loại trừ rối loạn toan–kiềm phối hợp.'},
		'post-intubation-hyperventilation': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:62,sex:'male',ph:7.55,paco2:24,hco3:20,pao2:145,sao2:99,fio2:40,oxygenDevice:'ventilator',peep:5,sodium:140,clorid:104,potassium:3.7,albumin:37,albuminUnit:'gl',caseSummary:'Sau đặt nội khí quản, thông khí phút cao; khí máu cho thấy kiềm hô hấp do tăng thông khí.'}

	
,
		'ventilator-low-vt-ards': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:64,sex:'male',ph:7.31,paco2:48,hco3:24,pao2:62,sao2:90,fio2:60,oxygenDevice:'ventilator',peep:10,sodium:138,clorid:104,potassium:4.3,albumin:28,albuminUnit:'gl',lactate:2.2,clinicalContexts:['ards','mechanical-ventilation'],caseSummary:'ARDS do viêm phổi, đang thở máy bảo vệ phổi; PaO₂ 62 mmHg khi FiO₂ 0,60 và PEEP 10 cmH₂O. Đọc khí máu cùng cài đặt máy thở, không tách P/F khỏi bối cảnh.'},
		'ventilator-autopeep-copd': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:71,sex:'male',ph:7.25,paco2:74,hco3:32,pao2:70,sao2:92,fio2:35,oxygenDevice:'ventilator',peep:5,sodium:141,clorid:101,potassium:4.5,albumin:34,albuminUnit:'gl',clinicalContexts:['copd','mechanical-ventilation'],caseSummary:'COPD đợt cấp sau đặt nội khí quản, còn tăng CO₂ rõ. Máy thở ghi nhận thời gian thở ra ngắn và nghi áp lực dương cuối thì thở ra nội sinh; khí máu phải được đọc cùng cơ học hô hấp.'},
		'ventilator-hypercapnia-adjust': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:59,sex:'female',ph:7.28,paco2:61,hco3:28,pao2:93,sao2:97,fio2:40,oxygenDevice:'ventilator',peep:6,sodium:139,clorid:103,potassium:4.0,albumin:36,albuminUnit:'gl',clinicalContexts:['mechanical-ventilation'],caseSummary:'Sau điều chỉnh thông khí phút có kiểm soát, PaCO₂ giảm từ 72 xuống 61 mmHg trong khi pH tăng từ 7,22 lên 7,28. Ca dùng để đọc đáp ứng theo chuỗi thay vì một lần đo.'},
		'ventilator-overventilation-serial': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:62,sex:'male',ph:7.52,paco2:27,hco3:22,pao2:142,sao2:99,fio2:40,oxygenDevice:'ventilator',peep:5,sodium:140,clorid:104,potassium:3.8,albumin:37,albuminUnit:'gl',clinicalContexts:['mechanical-ventilation'],caseSummary:'Sau tăng thông khí phút, PaCO₂ giảm từ 40 xuống 27 mmHg và pH tăng rõ. Cần nhận diện quá thông khí do máy và đối chiếu mục tiêu điều trị thay vì coi PaCO₂ càng thấp càng tốt.'},
		'niv-copd-response': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:74,sex:'male',ph:7.32,paco2:58,hco3:29,pao2:72,sao2:93,fio2:30,oxygenDevice:'niv',peep:6,sodium:140,clorid:101,potassium:4.2,albumin:34,albuminUnit:'gl',clinicalContexts:['copd','niv'],caseSummary:'COPD tăng CO₂ được hỗ trợ thông khí không xâm nhập; sau 90 phút pH tăng từ 7,25 lên 7,32 và PaCO₂ giảm từ 72 xuống 58 mmHg, công thở giảm.'},
		'niv-copd-failure': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',chronicity:'acute',age:76,sex:'female',ph:7.18,paco2:82,hco3:30,pao2:59,sao2:86,fio2:40,oxygenDevice:'niv',peep:7,sodium:139,clorid:102,potassium:4.6,albumin:33,albuminUnit:'gl',clinicalContexts:['copd','niv'],caseSummary:'Sau thử thông khí không xâm nhập, pH tiếp tục giảm, PaCO₂ tăng và người bệnh mệt hơn. Ca nhấn mạnh khí máu nối tiếp phải được tích hợp với tri giác, công thở và huyết động để nhận diện thất bại hỗ trợ.'},
		'hfnc-pneumonia-response': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:68,sex:'male',ph:7.43,paco2:35,hco3:23,pao2:78,sao2:95,spo2:95,fio2:45,oxygenDevice:'hfnc',peep:4,sodium:138,clorid:104,potassium:4.0,albumin:30,albuminUnit:'gl',clinicalContexts:['pneumonia','hfnc'],caseSummary:'Viêm phổi giảm oxy máu đang dùng oxy dòng cao; FiO₂ giảm từ 0,60 xuống 0,45 trong khi PaO₂ tăng từ 64 lên 78 mmHg và tần số thở giảm.'},
		'hfnc-worsening-hypoxemia': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:65,sex:'female',ph:7.47,paco2:30,hco3:21,pao2:55,sao2:87,spo2:88,fio2:70,oxygenDevice:'hfnc',peep:4,sodium:137,clorid:103,potassium:3.9,albumin:29,albuminUnit:'gl',clinicalContexts:['pneumonia','hfnc'],caseSummary:'Dù FiO₂ oxy dòng cao đã tăng lên 0,70, PaO₂ giảm còn 55 mmHg và công thở tăng. Ca dùng để nhận diện xu hướng xấu đi và nguy cơ trì hoãn hỗ trợ hô hấp thích hợp.'},
		'septic-shock-lactate-clearance': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:57,sex:'male',ph:7.33,paco2:31,hco3:16,pao2:90,sao2:96,fio2:30,oxygenDevice:'conventional',sodium:138,clorid:103,potassium:4.2,albumin:28,albuminUnit:'gl',lactate:3.2,priorLactate:6.4,lactateIntervalHours:3,clinicalContexts:['sepsis','shock'],caseSummary:'Sốc nhiễm trùng sau hồi sức ban đầu; lactat giảm 6,4 → 3,2 mmol/L trong 3 giờ nhưng vẫn tăng. Cần đọc xu hướng cùng huyết áp, tưới máu ngoại vi và lượng nước tiểu.'},
		'septic-shock-lactate-persistent': {serial_abg:true,sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:61,sex:'female',ph:7.29,paco2:29,hco3:14,pao2:84,sao2:95,fio2:35,oxygenDevice:'conventional',sodium:137,clorid:101,potassium:4.5,albumin:26,albuminUnit:'gl',lactate:6.1,priorLactate:6.4,lactateIntervalHours:3,clinicalContexts:['sepsis','shock'],caseSummary:'Sốc nhiễm trùng, lactat hầu như không giảm sau 3 giờ và dấu tưới máu còn kém. Không nên tiếp tục truyền dịch chỉ để “chuẩn hóa” lactat mà không đánh giá lại toàn trạng.'},
		'co-exposure-delayed-sample': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:40,sex:'female',ph:7.39,paco2:36,hco3:22,pao2:118,sao2:88,spo2:99,cohb:10,fio2:100,oxygenDevice:'conventional',sodium:139,clorid:104,potassium:4.0,albumin:38,albuminUnit:'gl',clinicalContexts:['smoke-fire'],caseSummary:'Nghi ngộ độc carbon monoxit, mẫu được lấy sau khi đã thở oxy 100% một thời gian. COHb vẫn tăng nhưng thấp hơn mức có thể có lúc rời nguồn phơi nhiễm; thời điểm lấy mẫu rất quan trọng.'},
		'methemoglobin-benzocaine': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:46,sex:'male',ph:7.40,paco2:38,hco3:23,pao2:180,sao2:84,spo2:85,methb:22,fio2:60,oxygenDevice:'conventional',sodium:140,clorid:104,potassium:4.1,albumin:39,albuminUnit:'gl',clinicalContexts:['oxidant-drug'],caseSummary:'Tím tái sau dùng thuốc gây oxy hóa; SpO₂ quanh 85% dù PaO₂ cao trên oxy bổ sung. Đồng oxy kế cho MetHb 22%, minh họa khoảng cách giữa PaO₂ và oxyhemoglobin.'},
		'methanol-late-osm-gap': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:38,sex:'male',ph:7.03,paco2:19,hco3:5,pao2:108,sao2:99,fio2:21,oxygenDevice:'room-air',sodium:141,clorid:102,potassium:4.5,albumin:40,albuminUnit:'gl',measuredOsm:298,glucose:5.8,glucoseUnit:'mmol',urea:5.5,ureaUnit:'urea-mmol',clinicalContexts:['toxic-alcohol'],caseSummary:'Đến muộn sau phơi nhiễm nghi methanol; toan chuyển hóa tăng khoảng trống anion rất nặng nhưng khoảng trống thẩm thấu không còn tăng rõ. Khoảng trống thẩm thấu bình thường không loại trừ phơi nhiễm muộn.'},
		'ethylene-glycol-acidosis': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:43,sex:'female',ph:7.10,paco2:22,hco3:7,pao2:104,sao2:98,fio2:21,oxygenDevice:'room-air',sodium:139,clorid:100,potassium:4.8,albumin:38,albuminUnit:'gl',measuredOsm:326,glucose:6.2,glucoseUnit:'mmol',urea:6.0,ureaUnit:'urea-mmol',creatinine:180,creatinineUnit:'umol',clinicalContexts:['toxic-alcohol'],caseSummary:'Nghi phơi nhiễm ethylene glycol với toan chuyển hóa tăng khoảng trống anion, khoảng trống thẩm thấu và tổn thương thận. Khí máu giúp mô tả rối loạn nhưng không xác định chất độc đơn độc.'},
		'ckd-acidosis-hyperkalemia': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:69,sex:'male',ph:7.24,paco2:30,hco3:13,pao2:89,sao2:96,fio2:21,oxygenDevice:'room-air',sodium:137,clorid:106,potassium:6.2,albumin:34,albuminUnit:'gl',creatinine:690,creatinineUnit:'umol',clinicalContexts:['renal-failure'],caseSummary:'Bệnh thận mạn tiến triển với toan chuyển hóa và tăng kali. Cần đọc bicarbonat, khoảng trống anion, kali và chức năng thận cùng nhau.'},
		'renal-tubular-acidosis': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:35,sex:'female',ph:7.29,paco2:32,hco3:15,pao2:96,sao2:97,fio2:21,oxygenDevice:'room-air',sodium:140,clorid:115,potassium:3.0,albumin:40,albuminUnit:'gl',creatinine:80,creatinineUnit:'umol',clinicalContexts:['renal-tubular'],caseSummary:'Toan chuyển hóa tăng clo với chức năng lọc cầu thận không suy nặng và hạ kali; ca định hướng cơ chế mất bicarbonat/giảm bài tiết acid tại ống thận, cần xét nghiệm nước tiểu để phân loại.'},
		'pregnancy-hyperemesis': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:29,sex:'female',ph:7.53,paco2:31,hco3:25,pao2:110,sao2:99,fio2:21,oxygenDevice:'room-air',sodium:134,clorid:91,potassium:2.9,albumin:32,albuminUnit:'gl',clinicalContexts:['pregnancy','vomiting'],caseSummary:'Thai 18 tuần, nôn kéo dài, giảm clo và kali. PaCO₂ thấp có thể là sinh lý thai kỳ nhưng HCO₃⁻ không giảm tương ứng và pH cao gợi thêm kiềm chuyển hóa.'},
		'pregnancy-respiratory-deterioration': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:31,sex:'female',ph:7.34,paco2:41,hco3:22,pao2:68,sao2:92,fio2:35,oxygenDevice:'conventional',sodium:136,clorid:103,potassium:4.0,albumin:31,albuminUnit:'gl',clinicalContexts:['pregnancy','pneumonia'],caseSummary:'Thai 32 tuần bị viêm phổi; PaCO₂ 41 mmHg tuy “bình thường” ngoài thai kỳ nhưng cao bất thường so với sinh lý thai kỳ và đi kèm giảm oxy máu, gợi suy thông khí tiến triển.'},
		'altitude-acclimatization': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:30,sex:'male',ph:7.44,paco2:25,hco3:17,pao2:62,sao2:91,fio2:21,oxygenDevice:'room-air',atmosphericPressure:560,sodium:140,clorid:106,potassium:3.8,albumin:42,albuminUnit:'gl',clinicalContexts:['high-altitude'],caseSummary:'Sau vài ngày ở độ cao khoảng 4.000 m, PaCO₂ còn thấp nhưng bicarbonat đã giảm do bù thận; pH tiến gần hơn về bình thường trong quá trình thích nghi.'},
		'altitude-pulmonary-edema': {sampleType:'arterial',unitSystem:'si',gasPressureUnit:'mmhg',age:27,sex:'male',ph:7.48,paco2:26,hco3:19,pao2:43,sao2:78,fio2:21,oxygenDevice:'room-air',atmosphericPressure:560,sodium:140,clorid:105,potassium:3.9,albumin:41,albuminUnit:'gl',clinicalContexts:['high-altitude','pulmonary-edema'],caseSummary:'Sau lên cao nhanh xuất hiện khó thở khi nghỉ và ran phổi; PaO₂ thấp hơn nhiều so với mức dự kiến ở cùng độ cao. Không được quy toàn bộ giảm oxy cho áp suất khí quyển.'}

	};


	var LEARNING_CASES = {
		normal:{topic:'Sinh lý bình thường',level:'Cơ bản',expected:'normal',objectives:['Xác nhận pH, PaCO₂ và HCO₃⁻ trong giới hạn thường dùng.','Nhận biết khi không cần gán rối loạn toan–kiềm.'],pitfall:'Không diễn giải quá mức một khí máu bình thường khi thiếu bất thường lâm sàng.'},
		hagma:{topic:'Toan chuyển hóa tăng khoảng trống anion',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Nhận diện toan chuyển hóa.','Đối chiếu bù hô hấp và lactat.'],pitfall:'Không chỉ nhìn pH; cần kiểm tra bù và nguyên nhân tăng khoảng trống anion.'},
		dka:{topic:'Nhiễm toan ceton',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Liên hệ thể ceton với toan chuyển hóa tăng khoảng trống anion.','Đánh giá đáp ứng hô hấp theo PaCO₂ dự kiến.'],pitfall:'Glucose không phản ánh đầy đủ mức độ nhiễm toan ceton, đặc biệt khi dùng thuốc ức chế SGLT2.'},
		'acute-resp-acidosis':{topic:'Toan hô hấp cấp',level:'Cơ bản',expected:'respiratory-acidosis',objectives:['Nhận diện tăng PaCO₂ là rối loạn nguyên phát.','Phân biệt bù cấp với mạn.'],pitfall:'HCO₃⁻ hơi tăng trong toan hô hấp cấp không đồng nghĩa có kiềm chuyển hóa.'},
		mixed:{topic:'Rối loạn phối hợp',level:'Nâng cao',expected:'mixed',objectives:['Nhận diện toan chuyển hóa và toan hô hấp cùng tồn tại.','Ưu tiên phát hiện tình trạng nguy kịch.'],pitfall:'pH rất thấp có thể là hậu quả của nhiều cơ chế cộng gộp.'},
		'smoke-exposure':{topic:'Ngộ độc carbon monoxit',level:'Nâng cao',expected:'dyshemoglobinemia',objectives:['Nhận biết PaO₂ có thể bình thường khi COHb tăng.','Không dùng độ bão hòa oxy ngoại vi (SpO₂) đơn độc để loại trừ ngộ độc carbon monoxit.'],pitfall:'PaO₂ phản ánh oxy hòa tan, không phản ánh trực tiếp khả năng mang oxy của hemoglobin.'},
		'resp-alkalosis':{topic:'Kiềm hô hấp',level:'Cơ bản',expected:'respiratory-alkalosis',objectives:['Nhận diện giảm PaCO₂ nguyên phát.','Liên hệ tăng thông khí với triệu chứng.'],pitfall:'Cần tìm nguyên nhân tăng thông khí thay vì chỉ quy cho lo âu.'},
		'metabolic-alkalosis':{topic:'Kiềm chuyển hóa',level:'Trung bình',expected:'metabolic-alkalosis',objectives:['Nhận diện HCO₃⁻ tăng nguyên phát.','Liên hệ clo và kali thấp với nôn/lợi tiểu.'],pitfall:'Đánh giá thể tích tuần hoàn và clorid giúp định hướng nguyên nhân.'},
		'copd-chronic':{topic:'Tăng CO₂ mạn',level:'Trung bình',expected:'respiratory-acidosis',objectives:['Nhận diện bù thận mạn.','Không coi PaCO₂ tăng mạn là rối loạn cấp nếu pH gần bình thường.'],pitfall:'Luôn so sánh với khí máu nền nếu có.'},
		'salicylate-mixed':{topic:'Salicylat',level:'Nâng cao',expected:'mixed',objectives:['Nhận diện kiềm hô hấp phối hợp toan chuyển hóa.','Không bị đánh lừa bởi pH kiềm nhẹ.'],pitfall:'pH gần bình thường hoặc kiềm không loại trừ toan chuyển hóa đáng kể.'},
		'nagma-diarrhea':{topic:'Toan tăng clo',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Phân biệt toan chuyển hóa không tăng khoảng trống anion.','Liên hệ mất bicarbonat qua tiêu hóa.'],pitfall:'Tính khoảng trống anion cần xét albumin khi phù hợp.'},
		'pe-hypoxemia':{topic:'Giảm oxy máu',level:'Nâng cao',expected:'respiratory-alkalosis',objectives:['Nhận diện giảm oxy kèm tăng thông khí.','Diễn giải chênh áp oxy phế nang–động mạch trong bối cảnh lâm sàng.'],pitfall:'Khí máu không tự xác lập chẩn đoán thuyên tắc phổi.'},
		'ards-oxygenation':{topic:'Oxy hóa khi thở máy',level:'Nâng cao',expected:'oxygenation',objectives:['Tính và diễn giải tỷ số PaO₂/FiO₂ theo nồng độ oxy hít vào.','Luôn đọc cùng áp lực dương cuối thì thở ra và bối cảnh hỗ trợ hô hấp.'],pitfall:'Tỷ số PaO₂/FiO₂ đơn độc không đủ để xác lập hội chứng suy hô hấp cấp tiến triển.'},
		'sample-air-bubble':{topic:'Tiền phân tích',level:'Cơ bản',expected:'preanalytic',objectives:['Nhận biết PaO₂ bất thường do bọt khí.','Ưu tiên kiểm tra chất lượng mẫu trước khi suy luận sinh lý.'],pitfall:'Một kết quả không phù hợp lâm sàng cần nghĩ tới sai số mẫu.'},
		'pregnancy-resp-alk':{topic:'Thai kỳ',level:'Trung bình',expected:'respiratory-alkalosis',objectives:['Nhận biết PaCO₂ thấp sinh lý trong thai kỳ.','Tránh áp ngưỡng người không mang thai một cách máy móc.'],pitfall:'Thai kỳ có thay đổi sinh lý toan–kiềm đặc thù.'},
		'opioid-hypoventilation':{topic:'Giảm thông khí',level:'Cơ bản',expected:'respiratory-acidosis',objectives:['Liên hệ giảm thông khí với tăng PaCO₂.','Nhận diện giảm oxy đồng thời.'],pitfall:'Mức độ nguy hiểm phụ thuộc toàn trạng, không chỉ pH.'},
		'renal-failure-hagma':{topic:'Suy thận',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Nhận diện toan chuyển hóa trong suy thận.','Chú ý tăng kali đi kèm.'],pitfall:'Khoảng trống anion có thể thay đổi theo giai đoạn và albumin.'},
		'vomiting-plus-resp-alk':{topic:'Kiềm phối hợp',level:'Nâng cao',expected:'mixed',objectives:['Nhận diện kiềm chuyển hóa và kiềm hô hấp cùng tồn tại.','Đánh giá mức bù không phù hợp.'],pitfall:'pH rất kiềm cần tìm rối loạn phối hợp.'},
		'saline-nagma':{topic:'Toan do clorid',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Liên hệ truyền NaCl với tăng clorid.','Nhận diện toan không tăng khoảng trống anion.'],pitfall:'Diễn giải luôn cần bối cảnh dịch truyền.'},
		'ketoacidosis-sglt2':{topic:'Thuốc ức chế SGLT2 và nhiễm toan ceton',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Nhận diện thể ceton tăng dù glucose không rất cao.','Liên hệ thuốc ức chế SGLT2 với kiểu biểu hiện này.'],pitfall:'Không loại trừ nhiễm toan ceton do đái tháo đường chỉ vì glucose chưa rất cao.'},
		'methanol-pattern':{topic:'Khoảng trống thẩm thấu',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Nhận diện toan nặng tăng khoảng trống anion.','Kết hợp khoảng trống thẩm thấu khi nghi cồn độc.'],pitfall:'Khoảng trống thẩm thấu thay đổi theo thời điểm phơi nhiễm.'},
		'seizure-lactate':{topic:'Lactat sau co giật',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Nhận diện tăng lactat sau co giật.','Hiểu giá trị của đo lặp lại theo thời gian.'],pitfall:'Lactat đơn lẻ ngay sau co giật không luôn có cùng ý nghĩa với nhiễm trùng huyết.'},
		'neuromuscular-hypercapnia':{topic:'Suy bơm hô hấp',level:'Trung bình',expected:'respiratory-acidosis',objectives:['Nhận diện tăng CO₂ do yếu cơ hô hấp.','Phân biệt vấn đề thông khí với trao đổi khí.'],pitfall:'SpO₂ có thể chưa phản ánh sớm mức tăng CO₂.'},
		'high-altitude':{topic:'Độ cao',level:'Trung bình',expected:'respiratory-alkalosis',objectives:['Hiểu ảnh hưởng áp suất khí quyển lên PAO₂.','Nhận diện tăng thông khí thích nghi.'],pitfall:'chênh áp oxy phế nang–động mạch phải tính với áp suất khí quyển phù hợp.'},
		'hfnc-hypoxemia':{topic:'Oxy dòng cao qua gọng mũi',level:'Nâng cao',expected:'oxygenation',objectives:['Đánh giá tỷ số PaO₂/FiO₂ và SpO₂/FiO₂ trong bối cảnh hỗ trợ oxy.','Hiểu hạn chế ước tính FiO₂.'],pitfall:'Chỉ số oxy hóa cần đọc cùng hỗ trợ hô hấp và diễn biến.'},
		'niv-copd':{topic:'COPD và thông khí không xâm nhập',level:'Nâng cao',expected:'respiratory-acidosis',objectives:['Theo dõi pH và PaCO₂ khi hỗ trợ thông khí không xâm nhập.','Nhận diện nhu cầu so sánh chuỗi khí máu.'],pitfall:'Một lần đo không cho biết xu hướng đáp ứng.'},
		'vbg-dka':{topic:'Khí máu tĩnh mạch',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Sử dụng pH và HCO₃⁻ tĩnh mạch đúng bối cảnh.','Không dùng PvO₂ thay PaO₂ để đánh giá oxy hóa máu.'],pitfall:'PO₂ tĩnh mạch không đại diện cho oxy hóa máu động mạch.'},
		'methemoglobinemia':{topic:'Methemoglobin',level:'Nâng cao',expected:'dyshemoglobinemia',objectives:['Nhận biết chênh lệch bất thường giữa các cách đo độ bão hòa oxy.','Liên hệ đồng oxy kế với MetHb.'],pitfall:'PaO₂ bình thường không loại trừ rối loạn hemoglobin.'},
		'mixed-hagma-alkalosis':{topic:'pH gần bình thường',level:'Nâng cao',expected:'mixed',objectives:['Không dừng ở pH gần bình thường.','Dùng AG và bù trừ để phát hiện rối loạn phối hợp.'],pitfall:'Hai rối loạn đối nghịch có thể làm pH trông gần bình thường.'},
		'post-intubation-hyperventilation':{topic:'Thông khí cơ học',level:'Trung bình',expected:'respiratory-alkalosis',objectives:['Nhận diện kiềm hô hấp do thông khí phút cao.','Liên hệ khí máu với cài đặt máy thở và người bệnh.'],pitfall:'Không điều chỉnh máy thở chỉ dựa trên một chỉ số mà thiếu toàn cảnh.'}
	
,
		'ventilator-low-vt-ards':{topic:'Thở máy bảo vệ phổi trong ARDS',level:'Nâng cao',expected:'oxygenation',objectives:['Đọc PaO₂/FiO₂ cùng PEEP và FiO₂.','Liên hệ khí máu với chiến lược thể tích khí lưu thông theo cân nặng dự đoán.'],pitfall:'Không dùng P/F đơn độc để quyết định cài đặt máy thở hoặc gọi tên toàn bộ hội chứng.'},
		'ventilator-autopeep-copd':{topic:'COPD thở máy và áp lực dương nội sinh',level:'Nâng cao',expected:'respiratory-acidosis',objectives:['Nhận diện tăng CO₂ trên nền COPD.','Đặt ABG cạnh thời gian thở ra và nghi bẫy khí.'],pitfall:'Tăng tần số máy thở để hạ PaCO₂ có thể làm ngắn thì thở ra và tăng bẫy khí ở người bệnh tắc nghẽn.'},
		'ventilator-hypercapnia-adjust':{serial_abg:true,topic:'Theo dõi PaCO₂ sau chỉnh thông khí phút',level:'Nâng cao',expected:'respiratory-acidosis',objectives:['Dùng khí máu nối tiếp để đánh giá hướng thay đổi PaCO₂/pH.','Không suy ra đáp ứng chỉ từ một lần đo.'],pitfall:'Mục tiêu PaCO₂ phụ thuộc bệnh cảnh; không mặc định phải đưa mọi PaCO₂ về 40 mmHg ngay lập tức.'},
		'ventilator-overventilation-serial':{serial_abg:true,topic:'Quá thông khí sau đặt nội khí quản',level:'Trung bình',expected:'respiratory-alkalosis',objectives:['Nhận diện kiềm hô hấp do thông khí phút quá cao.','So sánh trước–sau điều chỉnh máy thở.'],pitfall:'PaCO₂ càng thấp không đồng nghĩa thông khí càng “tốt”.'},
		'niv-copd-response':{serial_abg:true,topic:'COPD đáp ứng với thông khí không xâm nhập',level:'Trung bình',expected:'respiratory-acidosis',objectives:['Đánh giá cải thiện pH và PaCO₂ theo thời gian.','Ghép ABG với công thở và tri giác.'],pitfall:'Một con số PaCO₂ vẫn cao có thể đi cùng đáp ứng tốt nếu pH và lâm sàng đang cải thiện.'},
		'niv-copd-failure':{serial_abg:true,topic:'Nhận diện thất bại thông khí không xâm nhập',level:'Nâng cao',expected:'respiratory-acidosis',objectives:['Nhận diện xu hướng pH xấu và PaCO₂ tăng.','Không trì hoãn đánh giá lại khi lâm sàng xấu đi.'],pitfall:'ABG chỉ là một phần; tri giác, công thở, huyết động và khả năng bảo vệ đường thở quyết định mức độ khẩn cấp.'},
		'hfnc-pneumonia-response':{serial_abg:true,topic:'Oxy dòng cao – xu hướng cải thiện',level:'Trung bình',expected:'oxygenation',objectives:['Đọc PaO₂ theo FiO₂ thực tế.','Nhận diện cải thiện khi nhu cầu FiO₂ giảm và oxy hóa tốt hơn.'],pitfall:'Không đánh giá HFNC chỉ từ một SpO₂ tại một thời điểm.'},
		'hfnc-worsening-hypoxemia':{serial_abg:true,topic:'Oxy dòng cao – xu hướng xấu đi',level:'Nâng cao',expected:'oxygenation',objectives:['Nhận diện giảm P/F dù FiO₂ tăng.','Ghép xu hướng khí máu với công thở.'],pitfall:'Kéo dài hỗ trợ không xâm nhập khi thất bại có thể làm chậm bước hỗ trợ hô hấp cần thiết.'},
		'septic-shock-lactate-clearance':{serial_abg:true,topic:'Sốc và lactat giảm theo chuỗi',level:'Trung bình',expected:'metabolic-acidosis',objectives:['Đọc lactat nối tiếp thay vì một giá trị đơn lẻ.','Không đồng nhất giảm lactat với hồi phục hoàn toàn tưới máu.'],pitfall:'Mục tiêu là đánh giá tưới máu toàn thể, không chỉ làm lactat trở về bình thường bằng truyền dịch.'},
		'septic-shock-lactate-persistent':{serial_abg:true,topic:'Lactat dai dẳng trong sốc',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Nhận diện xu hướng lactat không cải thiện.','Đánh giá lại nguyên nhân, tưới máu và chiến lược hồi sức.'],pitfall:'Lactat tăng không chỉ do thiếu oxy mô và không chỉ định lượng dịch cần truyền.'},
		'co-exposure-delayed-sample':{topic:'COHb sau khi đã thở oxy',level:'Nâng cao',expected:'dyshemoglobinemia',objectives:['Hiểu COHb phụ thuộc thời gian từ phơi nhiễm đến lấy mẫu.','Không dùng mức COHb muộn để suy ngược chính xác mức đỉnh.'],pitfall:'COHb không tương quan chặt với mức độ nặng; triệu chứng và bối cảnh vẫn quan trọng.'},
		'methemoglobin-benzocaine':{topic:'Methemoglobin và khoảng cách độ bão hòa',level:'Nâng cao',expected:'dyshemoglobinemia',objectives:['Nhận diện PaO₂ cao nhưng oxyhemoglobin giảm.','Hiểu vai trò của đồng oxy kế.'],pitfall:'SaO₂ tính toán từ PaO₂ không đáng tin để loại trừ dyshemoglobin.'},
		'methanol-late-osm-gap':{topic:'Cồn độc đến muộn',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Nhận diện toan tăng khoảng trống anion nặng.','Hiểu khoảng trống thẩm thấu có thể giảm khi chất mẹ đã chuyển hóa.'],pitfall:'Khoảng trống thẩm thấu bình thường không loại trừ cồn độc ở người đến muộn.'},
		'ethylene-glycol-acidosis':{topic:'Ethylene glycol và hai khoảng trống',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Kết hợp khoảng trống anion và thẩm thấu.','Đặt khí máu cạnh chức năng thận và bệnh sử phơi nhiễm.'],pitfall:'Khoảng trống anion/thẩm thấu hỗ trợ nhận diện mẫu hình nhưng không xác định độc chất một cách độc lập.'},
		'ckd-acidosis-hyperkalemia':{topic:'Bệnh thận mạn, toan và tăng kali',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Đọc toan chuyển hóa trong bối cảnh giảm chức năng thận.','Nhận diện tăng kali là dữ kiện an toàn quan trọng đi kèm.'],pitfall:'Không suy ra toàn bộ cơ chế từ bicarbonat thấp mà bỏ qua khoảng trống anion, kali và mức lọc cầu thận.'},
		'renal-tubular-acidosis':{topic:'Toan chuyển hóa tăng clo do cơ chế ống thận',level:'Nâng cao',expected:'metabolic-acidosis',objectives:['Nhận diện toan không tăng khoảng trống anion.','Biết khi nào cần dữ liệu nước tiểu để phân loại.'],pitfall:'Khí máu không tự phân biệt các thể toan ống thận nếu thiếu điện giải và chỉ số nước tiểu.'},
		'pregnancy-hyperemesis':{topic:'Thai kỳ và kiềm phối hợp do nôn',level:'Nâng cao',expected:'mixed',objectives:['Nhận diện PaCO₂ thấp sinh lý thai kỳ.','Phát hiện kiềm chuyển hóa phối hợp khi HCO₃⁻ không giảm như dự kiến.'],pitfall:'Áp khoảng tham chiếu người không mang thai có thể che khuất rối loạn thực sự.'},
		'pregnancy-respiratory-deterioration':{topic:'Suy hô hấp trong thai kỳ',level:'Nâng cao',expected:'respiratory-acidosis',objectives:['Nhận biết PaCO₂ khoảng 40 mmHg có thể bất thường trong thai kỳ.','Đặt khí máu trong thay đổi sinh lý thai kỳ.'],pitfall:'Một PaCO₂ “bình thường” ngoài thai kỳ không nhất thiết bình thường ở thai phụ.'},
		'altitude-acclimatization':{topic:'Thích nghi thông khí ở độ cao',level:'Nâng cao',expected:'respiratory-alkalosis',objectives:['Hiểu giảm áp suất khí quyển làm giảm oxy hít vào.','Nhận diện bù thận cho kiềm hô hấp khi thích nghi.'],pitfall:'Không so PaO₂ ở độ cao với giá trị mực nước biển mà bỏ qua áp suất khí quyển.'},
		'altitude-pulmonary-edema':{topic:'Giảm oxy quá mức ở độ cao',level:'Nâng cao',expected:'oxygenation',objectives:['Phân biệt giảm oxy dự kiến do độ cao với giảm oxy vượt mức dự kiến.','Ghép ABG với triệu chứng và dấu phù phổi độ cao.'],pitfall:'Không quy mọi giảm PaO₂ ở độ cao cho “sinh lý bình thường”.'}

	};


	var CASE_REVIEW_KEYS = {
		dka:true, 'ketoacidosis-sglt2':true, hagma:true, 'acute-resp-acidosis':true,
		'opioid-hypoventilation':true, 'metabolic-alkalosis':true, 'nagma-diarrhea':true,
		'salicylate-mixed':true, 'pe-hypoxemia':true, 'ards-oxygenation':true,
		'smoke-exposure':true, 'sample-air-bubble':true
	};
	function learningReviewLinkHtml(key) {
		if (!CASE_REVIEW_KEYS[key]) return '';
		return '<button type="button" class="nah-abg__button nah-abg__button--ghost nah-abg__learning-review-link" data-learning-review="'+key+'">Xem lại tình huống này trong phần Lý thuyết</button>';
	}

	function learningMeta(key) { return key && LEARNING_CASES[key] ? LEARNING_CASES[key] : null; }
	function learningCardHtml(key, mode, userAnswer, analyzed) {
		var meta=learningMeta(key); if(!meta) return '';
		var head='<section class="nah-abg__learning-feedback"><div class="nah-abg__learning-kicker">Phòng học ca lâm sàng</div><h4>'+escapeHtml(meta.topic)+' <small>· '+escapeHtml(meta.level)+(meta.serial_abg?' · Khí máu nối tiếp':'')+'</small></h4>';
		if(mode==='guided') return head+'<h5>Mục tiêu học tập</h5><ul>'+meta.objectives.map(function(x){return '<li>'+publicHtml(x)+'</li>';}).join('')+'</ul>'+(analyzed?'<h5>Điểm dễ nhầm</h5><p>'+escapeHtml(meta.pitfall)+'</p>'+learningReviewLinkHtml(key):'<p>Phân tích khí máu để xem phần giải thích và điểm dễ nhầm.</p>')+'</section>';
		if(!analyzed) return head+'<p>Hãy tự phân tích trước khi mở phần giải thích.</p></section>';
		var answerText = userAnswer ? '<p><strong>Nhận định đã chọn:</strong> '+escapeHtml(userAnswer)+'</p>' : '';
		return head+answerText+'<h5>Gợi ý đối chiếu</h5><ul>'+meta.objectives.map(function(x){return '<li>'+publicHtml(x)+'</li>';}).join('')+'</ul><h5>Điểm dễ nhầm</h5><p>'+escapeHtml(meta.pitfall)+'</p>'+learningReviewLinkHtml(key)+'</section>';
	}

	var UNIT_DEFINITIONS = {
		albumin: { field: 'albumin', si: 'gl', us: 'gdl', toUs: function (value) { return value / 10; }, toSi: function (value) { return value * 10; } },
		glucose: { field: 'glucose', si: 'mmol', us: 'mgdl', toUs: function (value) { return value * 18; }, toSi: function (value) { return value / 18; } },
		urea: { field: 'urea', si: 'urea-mmol', us: 'bun-mgdl', toUs: function (value) { return value * 2.8; }, toSi: function (value) { return value / 2.8; } },
		creatinine: { field: 'creatinine', si: 'umol', us: 'mgdl', toUs: function (value) { return value / 88.4; }, toSi: function (value) { return value * 88.4; } },
		hemoglobin: { field: 'hemoglobin', si: 'gl', us: 'gdl', toUs: function (value) { return value / 10; }, toSi: function (value) { return value * 10; } }
	};

	function publicCopy(value) {
		var text = String(value === null || value === undefined ? '' : value);
		var replacements = [
			[/Oxygenation Intelligence/gi, 'Phân tích oxy hóa nâng cao'],
			[/Acid[–-]Base Map/gi, 'Bản đồ toan–kiềm'],
			[/Corrected AG & Delta analysis/gi, 'Khoảng trống anion hiệu chỉnh và phân tích delta'],
			[/Reasoning từng bước/gi, 'Diễn giải từng bước'],
			[/\breasoning\b/gi, 'diễn giải'],
			[/\bprotocol\b/gi, 'quy trình'],
			[/\bchecklist\b/gi, 'danh sách kiểm tra'],
			[/\bHAGMA\b/g, 'toan chuyển hóa tăng khoảng trống anion'],
			[/\bP\/F\b/g, 'tỷ số PaO₂/FiO₂'],
			[/\bS\/F\b/g, 'tỷ số SpO₂/FiO₂'],
			[/A[–-]a(?:\s+gradient)?/gi, 'chênh áp oxy phế nang–động mạch'],
			[/\bV\/Q mismatch\b/gi, 'mất tương hợp thông khí/tưới máu'],
			[/\bV\/Q\b/g, 'thông khí/tưới máu (V/Q)'],
			[/\bshunt\b/gi, 'luồng thông phải–trái'],
			[/\bco-oximetry\b/gi, 'đồng oxy kế'],
			[/FiO₂ context/gi, 'Độ tin cậy của FiO₂'],
			[/\bARDS\b/g, 'hội chứng suy hô hấp cấp tiến triển'],
			[/\bDKA\b/g, 'nhiễm toan ceton do đái tháo đường'],
			[/\bHFNC\b/g, 'oxy dòng cao qua gọng mũi'],
			[/\bNIV\b/g, 'thông khí không xâm nhập'],
			[/\bVBG\b/g, 'khí máu tĩnh mạch'],
			[/\bsepsis\b/gi, 'nhiễm trùng huyết'],
			[/\bdyshemoglobinemia\b/gi, 'rối loạn hemoglobin'],
			[/\bdyshemoglobin\b/gi, 'hemoglobin bất thường'],
			[/\bpulse oximetry\b/gi, 'đo độ bão hòa oxy ngoại vi'],
			[/\bmethemoglobinemia\b/gi, 'tăng methemoglobin'],
			[/\bHHS\b/g, 'hội chứng tăng áp lực thẩm thấu do tăng đường huyết'],
			[/\bCOHb\b/g, 'carboxyhemoglobin'],
			[/\bMetHb\b/g, 'methemoglobin'],
			[/carbon monoxit/gi, 'carbon monoxit'],
			[/\bclorid\b/gi, 'clorid'],
			[/\bcồn độc\b/gi, 'cồn độc'],
			[/Kích hoạt quy trình/gi, 'Áp dụng quy trình'],
			[/\bProtocol theo ca\b/gi, 'Lộ trình đánh giá theo ca bệnh'],
			[/\bDiscordance\b/gi, 'Sự không phù hợp'],
			[/\bdelta ratio\b/gi, 'tỷ lệ delta'],
			[/\bAG\b/g, 'khoảng trống anion'],
			[/\bketone\b/gi, 'ceton'],
			[/\bsaturation\b/gi, 'độ bão hòa oxy'],
			[/A[–-]a gradient/gi, 'chênh áp oxy phế nang–động mạch'],
			[/\bgradient\b/gi, 'chênh áp'],
			[/V\/Q mismatch/gi, 'mất tương hợp thông khí/tưới máu (V/Q)'],
			[/\bmismatch\b/gi, 'không tương hợp'],
			[/\bpseudohypoxemia\b/gi, 'giảm oxy máu giả do mẫu'],
			[/\brespiratory compensation\b/gi, 'bù hô hấp'],
			[/\bmetabolic compensation\b/gi, 'bù chuyển hóa'],
			[/\bcompensation\b/gi, 'bù trừ'],
			[/\banion gap\b/gi, 'khoảng trống anion'],
			[/\bdelta ratio\b/gi, 'tỷ số delta'],
			[/\bketones?\b/gi, 'ceton'],
			[/\bsaturation\b/gi, 'độ bão hòa oxy'],
			[/\broom air\b/gi, 'khí phòng'],
			[/\bhigh[- ]flow nasal cannula\b/gi, 'oxy dòng cao qua gọng mũi'],
			[/\bfollow[- ]up\b/gi, 'theo dõi'],
			[/\bscreening\b/gi, 'sàng lọc'],
			[/\bmonitoring\b/gi, 'theo dõi'],
			[/\btrend\b/gi, 'xu hướng'],
			[/\bclinical context\b/gi, 'bối cảnh lâm sàng'],
			[/\bclinical\b/gi, 'lâm sàng'],
			[/\bassessment\b/gi, 'đánh giá'],
			[/\breview\b/gi, 'ôn lại'],
			[/\blearning\b/gi, 'học tập'],
			[/\bchallenge\b/gi, 'thử thách'],
			[/\bmastery\b/gi, 'mức độ nắm vững'],
			[/\binsight\b/gi, 'nhận định'],
			[/\bacute\b/gi, 'cấp'],
			[/\bchronic\b/gi, 'mạn'],
			[/\bmixed\b/gi, 'phối hợp'],
			[/\bnormal\b/gi, 'trong giới hạn'],
			[/\bprimary\b/gi, 'nguyên phát'],
			[/\bsecondary\b/gi, 'thứ phát'],
			[/bicarbonate\/total CO₂/gi, 'bicarbonat/toàn phần CO₂'],
			[/\bbicarbonate\b/gi, 'bicarbonat'],
			[/\blactate\b/gi, 'lactat'],
			[/\bglucose\b/gi, 'glucose'],
			[/\bco-oximeter\b/gi, 'máy đồng oxy kế']
		];
		replacements.forEach(function (item) { text = text.replace(item[0], item[1]); });
		return text;
	}

	function publicHtml(value) { return escapeHtml(publicCopy(value)); }

	function escapeHtml(value) {
		return publicCopy(value)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function formatNumber(value, digits) {
		if (value === null || value === undefined || Number.isNaN(value)) {
			return '—';
		}
		return Number(value).toLocaleString('vi-VN', {
			minimumFractionDigits: 0,
			maximumFractionDigits: typeof digits === 'number' ? digits : 1
		});
	}

	function compactNumber(value, digits) {
		return String(Core.round(value, typeof digits === 'number' ? digits : 2)).replace('.', ',');
	}

	function statusClass(status) {
		var map = {
			ok: 'success',
			within: 'success',
			normal: 'success',
			'not-high': 'success',
			warning: 'warning',
			caution: 'warning',
			elevated: 'warning',
			high: 'warning',
			low: 'warning',
			danger: 'danger',
			critical: 'danger',
			urgent: 'danger',
			severe: 'danger',
			moderate: 'warning',
			mild: 'warning',
			'above-300': 'success',
			complete: 'success',
			missing: 'neutral',
			invalid: 'danger',
			immediate: 'danger',
			priority: 'warning',
			cause: 'neutral',
			reassess: 'success'
		};
		return map[status] || 'neutral';
	}

	function readForm(form) {
		var data = {};
		var formData = new FormData(form);
		formData.forEach(function (value, key) {
			if (Object.prototype.hasOwnProperty.call(data, key)) {
				if (!Array.isArray(data[key])) {
					data[key] = [data[key]];
				}
				data[key].push(value);
			} else {
				data[key] = value;
			}
		});
		return data;
	}

	function setFormValues(form, values) {
		Object.keys(values).forEach(function (name) {
			var selectors = ['[name="' + name + '"]', '[name="' + name + '[]"]'];
			var fields = form.querySelectorAll(selectors.join(','));
			if (!fields.length) {
				return;
			}

			fields.forEach(function (field) {
				if (field.type === 'radio') {
					field.checked = field.value === String(values[name]);
				} else if (field.type === 'checkbox') {
					var selected = Array.isArray(values[name]) ? values[name] : [values[name]];
					field.checked = selected.indexOf(field.value) >= 0;
				} else {
					field.value = values[name];
				}
				field.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	function resultCard(number, title, badge, badgeStatus, body, formula) {
		return [
			'<article class="nah-abg__result-card">',
			'<div class="nah-abg__result-index">', number, '</div>',
			'<div class="nah-abg__result-content">',
			'<div class="nah-abg__result-title-row">',
			'<h4>', escapeHtml(title), '</h4>',
			badge ? '<span class="nah-abg__badge nah-abg__badge--' + statusClass(badgeStatus) + '">' + escapeHtml(badge) + '</span>' : '',
			'</div>',
			body,
			formula ? '<details class="nah-abg__formula"><summary>Xem công thức</summary><p>' + escapeHtml(formula) + '</p></details>' : '',
			'</div>',
			'</article>'
		].join('');
	}

	function renderAlerts(result) {
		var combined = [];
		result.alerts.forEach(function (item) {
			combined.push(item);
		});
		result.sanity.forEach(function (item) {
			if (!combined.some(function (existing) { return existing.message === item.message; })) {
				combined.push(item);
			}
		});

		if (!combined.length) {
			return '';
		}

		return '<div class="nah-abg__alert-block"><h4>Cảnh báo cần chú ý</h4><ul>' +
			combined.map(function (alert) {
				return '<li class="nah-abg__alert-item nah-abg__alert-item--' + statusClass(alert.level) + '">' + publicHtml(alert.message) + '</li>';
			}).join('') +
			'</ul></div>';
	}

	function renderReferenceWarnings(result) {
		var abnormal = result.referenceChecks.filter(function (check) {
			return check.state !== 'normal';
		});
		if (!abnormal.length) {
			return '<div class="nah-abg__reference-strip nah-abg__reference-strip--ok"><strong>Đối chiếu khoảng tham chiếu:</strong> Các thông số đã nhập không có cảnh báo ngoài khoảng thường dùng.</div>';
		}

		return [
			'<div class="nah-abg__reference-strip">',
			'<strong>Giá trị ngoài khoảng tham chiếu/tham khảo</strong>',
			'<div class="nah-abg__reference-chips">',
			abnormal.map(function (check) {
				return '<span class="nah-abg__reference-chip nah-abg__reference-chip--' + statusClass(check.state) + '">' +
					'<b>' + escapeHtml(check.label) + ': ' + escapeHtml(formatNumber(check.value, 2)) + (check.unit ? ' ' + escapeHtml(check.unit) : '') + '</b>' +
					'<small>Tham chiếu ' + escapeHtml(check.reference) + (check.note ? ' • ' + publicHtml(check.note) : '') + '</small>' +
					'</span>';
			}).join(''),
			'</div>',
			'</div>'
		].join('');
	}

	function pressureText(value, unit) {
		var displayed = Core.displayPressure(value, unit);
		return displayed ? formatNumber(displayed.value, unit === 'kpa' ? 2 : 1) + ' ' + displayed.unit : '—';
	}

	function renderConclusionReasoning(result) {
		var reasons = result.conclusionReasoning || [];
		if (!reasons.length) {
			return '';
		}

		return [
			'<section class="nah-abg__reasoning" aria-label="Lập luận cho kết luận">',
			'<h4>Lập luận</h4>',
			'<ul>',
			reasons.map(function (reason) {
				return '<li>' + publicHtml(reason) + '</li>';
			}).join(''),
			'</ul>',
			'</section>'
		].join('');
	}

	function renderHeader(result) {
		var input = result.input;
		var values = [
			['pH', formatNumber(input.ph, 3), result.classification.phState === 'normal' ? 'normal' : 'warning'],
			['PaCO₂', pressureText(input.paco2, input.gasPressureUnit), input.paco2 >= 35 && input.paco2 <= 45 ? 'normal' : 'warning'],
			['HCO₃⁻', formatNumber(input.hco3, 1) + ' mmol/L', input.hco3 >= 22 && input.hco3 <= 26 ? 'normal' : 'warning']
		];
		if (input.pao2 !== null) {
			values.push(['PaO₂', pressureText(input.pao2, input.gasPressureUnit), input.sampleType === 'arterial' && input.pao2 < 60 ? 'danger' : 'normal']);
		}

		return [
			'<div class="nah-abg__result-summary">',
			'<p class="nah-abg__result-kicker">KẾT LUẬN TỔNG HỢP</p>',
			'<h3>', publicHtml(result.classification.title), '</h3>',
			'<p>', publicHtml(result.classification.explanation), '</p>',
			renderConclusionReasoning(result),
			input.caseSummary ? '<div class="nah-abg__case-summary"><small>Mô tả ca bệnh</small><p>' + escapeHtml(input.caseSummary).replace(/\n/g, '<br>') + '</p></div>' : '',
			'<div class="nah-abg__vitals">',
			values.map(function (item) {
				return '<div><small>' + escapeHtml(item[0]) + '</small><strong class="is-' + statusClass(item[2]) + '">' + escapeHtml(item[1]) + '</strong></div>';
			}).join(''),
			'</div>',
			'</div>'
		].join('');
	}

	function renderProtocolPath(result) {
		var labels = {
			complete: 'Đã kiểm tra',
			caution: 'Cần đối chiếu',
			urgent: 'Ưu tiên ngay',
			missing: 'Thiếu dữ liệu'
		};
		var body = '<div class="nah-abg__protocol-path">' + result.protocolPath.map(function (step, index) {
			return [
				'<section class="nah-abg__protocol-step nah-abg__protocol-step--', statusClass(step.status), '">',
				'<div class="nah-abg__protocol-marker">', index + 1, '</div>',
				'<div>',
				'<div class="nah-abg__protocol-heading"><h5>', publicHtml(step.title), '</h5>',
				'<span class="nah-abg__badge nah-abg__badge--', statusClass(step.status), '">', escapeHtml(labels[step.status] || step.status), '</span></div>',
				'<p>', publicHtml(step.finding), '</p>',
				'<p class="nah-abg__protocol-action"><strong>Bước tiếp:</strong> ', publicHtml(step.nextAction), '</p>',
				'</div>',
				'</section>'
			].join('');
		}).join('') + '</div>';
		var urgent = result.protocolPath.filter(function (step) { return step.status === 'urgent'; }).length;
		return resultCard('P', 'Các bước cần rà soát theo ca bệnh', urgent ? urgent + ' bước ưu tiên' : '6 bước', urgent ? 'danger' : 'success', body, '');
	}

	function renderConsistency(result) {
		var c = result.consistency;
		var quality = result.sampleQuality;
		var body = '<p><strong>Tiền phân tích:</strong> ' + publicHtml(quality.message) + '</p>';
		if (quality.issues.length) {
			body += '<div class="nah-abg__sample-issues">' + quality.issues.map(function (issue) {
				return [
					'<div class="nah-abg__sample-issue nah-abg__sample-issue--', statusClass(issue.level), '">',
					'<h5>', publicHtml(issue.title), '</h5>',
					'<p>', publicHtml(issue.effect), '</p>',
					'<small><strong>Thao tác:</strong> ', publicHtml(issue.action), '</small>',
					'</div>'
				].join('');
			}).join('') + '</div>';
		}
		if (quality.venousNote) {
			body += '<p class="nah-abg__hint">' + publicHtml(quality.venousNote) + '</p>';
		}
		body += '<div class="nah-abg__subresult"><h5>Tính nhất quán Henderson–Hasselbalch</h5><p>' + publicHtml(c.message) + '</p>' +
			'<p class="nah-abg__metric">HCO₃⁻ ước tính: <strong>' + formatNumber(c.calculatedHco3, 1) +
			' mmol/L</strong> • Sai khác: <strong>' + formatNumber(c.difference, 1) + ' mmol/L</strong></p></div>';
		if (!result.sanity.length && !quality.issues.length) {
			body += '<p class="nah-abg__quality-ok">Không phát hiện mâu thuẫn dữ liệu rõ trong các kiểm tra tự động.</p>';
		}
		var qualityLevel = quality.level === 'danger' || c.level === 'danger'
			? 'danger'
			: (quality.level === 'warning' || c.level === 'warning' || result.sanity.length ? 'warning' : 'ok');
		return resultCard('01', 'Kiểm tra mẫu, chất lượng và tính hợp lý', qualityLevel === 'ok' ? 'Phù hợp' : 'Cần đối chiếu', qualityLevel, body, c.formula);
	}

	function renderPh(result) {
		var body = '<p>pH = <strong>' + formatNumber(result.input.ph, 3) + '</strong>. ' +
			(result.classification.phState === 'normal'
				? 'pH trong giới hạn không loại trừ rối loạn đã bù hoặc rối loạn phối hợp.'
				: 'Hướng thay đổi của pH giúp định vị quá trình nguyên phát, nhưng vẫn phải kiểm tra bù trừ.') +
			'</p>';
		return resultCard('02', 'Đánh giá pH', result.classification.phLabel, result.classification.phState === 'normal' ? 'normal' : 'warning', body, '');
	}

	function renderPrimary(result) {
		return resultCard(
			'03',
			'Xác định rối loạn nguyên phát',
			result.classification.title,
			result.classification.primaryType.indexOf('mixed') >= 0 ? 'danger' : 'warning',
			'<p>' + publicHtml(result.classification.explanation) + '</p>',
			'Trong rối loạn hô hấp nguyên phát, pH và PaCO₂ thay đổi ngược hướng; trong rối loạn chuyển hóa, pH và PaCO₂ thường thay đổi cùng hướng do bù trừ.'
		);
	}

	function renderCompensation(result) {
		var comp = result.compensation;
		var body = '';
		var badge = '';
		var badgeStatus = 'neutral';
		var formula = '';

		if (comp.items.length) {
			body = comp.items.map(function (item) {
				var comparison = item.comparison;
				var expectedText = comparison.expected !== null
					? 'Giá trị dự kiến: ' + formatNumber(comparison.expected, 1)
					: 'Khoảng đối chiếu';
				return [
					'<div class="nah-abg__subresult">',
					'<h5>', publicHtml(item.label), '</h5>',
					'<p>', escapeHtml(comparison.message), '</p>',
					'<p class="nah-abg__metric">', expectedText, ' • Khoảng: ',
					formatNumber(comparison.low, 1), '–', formatNumber(comparison.high, 1),
					' • Thực tế: <strong>', formatNumber(comparison.actual, 1), '</strong></p>',
					'</div>'
				].join('');
			}).join('');
			var worst = comp.items.some(function (item) { return item.comparison.status !== 'within'; });
			badge = comp.mode === 'candidates' ? 'Đối chiếu các khả năng' : (worst ? 'Gợi ý phối hợp' : 'Bù phù hợp');
			badgeStatus = worst ? 'warning' : 'success';
			formula = comp.items.map(function (item) { return item.formula; }).join(' | ');
		} else {
			body = '<p>' + escapeHtml(comp.message) + '</p>';
			badge = comp.mode === 'direct-mixed' ? 'Rối loạn phối hợp' : 'Không áp dụng';
			badgeStatus = comp.mode === 'direct-mixed' ? 'danger' : 'neutral';
		}
		return resultCard('04', 'Đánh giá bù trừ', badge, badgeStatus, body, formula);
	}


	function renderAdvancedReasoning(result) {
		var advanced = result.advancedCompensation;
		var mixed = result.mixedDisorders;
		var delta = result.deltaAnalysis;
		var reasoning = result.stepByStepReasoning;
		var body = '<div class="nah-abg__advanced-reasoning">';

		if (advanced.items.length) {
			body += '<div class="nah-abg__advanced-block"><h5>Bù trừ định lượng</h5>' + advanced.items.map(function (item) {
				var expected = item.expected !== null && item.expected !== undefined
					? formatNumber(item.expected, 1)
					: formatNumber(item.expectedLow, 1) + '–' + formatNumber(item.expectedHigh, 1);
				return '<p><strong>' + publicHtml(item.label) + ':</strong> ' + escapeHtml(item.observedLabel) +
					' thực đo <b>' + formatNumber(item.observed, 1) + '</b> ' + escapeHtml(item.unit) +
					'; dự kiến ' + expected + '. ' + publicHtml(item.message) + '</p>';
			}).join('') + '</div>';
		}

		body += '<div class="nah-abg__advanced-block"><h5>Rối loạn phối hợp</h5><p>' + publicHtml(mixed.message) + '</p>';
		if (mixed.findings.length) {
			body += '<ul>' + mixed.findings.map(function (item) {
				return '<li><strong>' + publicHtml(item.label) + '</strong><span>' + publicHtml(item.evidence) + '</span></li>';
			}).join('') + '</ul>';
		}
		body += '</div>';

		if (delta.available || delta.agCorrected !== null) {
			body += '<div class="nah-abg__advanced-block"><h5>Khoảng trống anion hiệu chỉnh và phân tích delta</h5><div class="nah-abg__metric-grid">' +
				'<span><small>AG sử dụng</small><strong>' + formatNumber(delta.agEffective, 1) + ' mmol/L</strong></span>' +
				(delta.agCorrected !== null ? '<span><small>Hiệu chỉnh albumin</small><strong>+' + formatNumber(delta.albuminCorrection, 1) + ' mmol/L</strong></span>' : '') +
				(delta.available ? '<span><small>ΔAG</small><strong>' + formatNumber(delta.deltaAG, 1) + '</strong></span>' : '') +
				(delta.available ? '<span><small>ΔHCO₃⁻</small><strong>' + formatNumber(delta.deltaHco3, 1) + '</strong></span>' : '') +
				(delta.available ? '<span><small>ΔAG/ΔHCO₃⁻</small><strong>' + formatNumber(delta.deltaRatio, 2) + '</strong></span>' : '') +
				'</div><p class="nah-abg__hint">' + publicHtml(delta.interpretation || delta.message) + '</p></div>';
		}

		body += '<div class="nah-abg__advanced-block"><h5>Diễn giải từng bước</h5><ol class="nah-abg__reasoning-steps">' +
			reasoning.steps.map(function (step) { return '<li class="is-' + statusClass(step.status) + '">' + publicHtml(step.text) + '</li>'; }).join('') +
			'</ol><p class="nah-abg__hint">' + publicHtml(reasoning.caution) + '</p></div>';
		body += '</div>';

		return resultCard('A1', 'Phân tích toan–kiềm nâng cao', mixed.findings.length ? 'Cần rà soát rối loạn phối hợp' : 'Đã phân tích', mixed.findings.length ? 'warning' : 'success', body, 'Các phép tính bù trừ, khoảng trống anion và rối loạn phối hợp cần được đối chiếu với diễn biến lâm sàng.');
	}

	function renderAcidBaseMap(result) {
		var map = result.acidBaseMap;
		var W = 640, H = 360, left = 62, right = 22, top = 22, bottom = 48;
		var plotW = W - left - right, plotH = H - top - bottom;
		function sx(x) { return left + ((x - map.x.min) / (map.x.max - map.x.min)) * plotW; }
		function sy(y) { return top + plotH - ((y - map.y.min) / (map.y.max - map.y.min)) * plotH; }
		function path(points) {
			return points.map(function (p, i) { return (i ? 'L' : 'M') + sx(p.paco2).toFixed(1) + ',' + sy(p.hco3).toFixed(1); }).join(' ');
		}
		var grid = '';
		[20,30,40,50,60,70,80].forEach(function (x) { grid += '<line x1="' + sx(x) + '" y1="' + top + '" x2="' + sx(x) + '" y2="' + (top+plotH) + '" class="map-grid"/><text x="' + sx(x) + '" y="' + (H-22) + '" text-anchor="middle">' + x + '</text>'; });
		[10,15,20,25,30,35,40].forEach(function (y) { grid += '<line x1="' + left + '" y1="' + sy(y) + '" x2="' + (left+plotW) + '" y2="' + sy(y) + '" class="map-grid"/><text x="' + (left-10) + '" y="' + (sy(y)+4) + '" text-anchor="end">' + y + '</text>'; });
		var curves = map.isopleths.map(function (iso) {
			if (!iso.points.length) return '';
			var last = iso.points[iso.points.length-1];
			return '<path d="' + path(iso.points) + '" class="map-isopleth ' + (iso.ph === 7.4 ? 'is-reference' : '') + '"/><text x="' + Math.min(left+plotW-24,sx(last.paco2)+4) + '" y="' + (sy(last.hco3)-4) + '" class="map-ph">pH ' + iso.ph.toFixed(2) + '</text>';
		}).join('');
		var normalX = sx(map.normal.paco2Low), normalY = sy(map.normal.hco3High);
		var normalW = sx(map.normal.paco2High)-normalX, normalH = sy(map.normal.hco3Low)-normalY;
		var px = Math.max(left, Math.min(left+plotW, sx(map.patient.paco2)));
		var py = Math.max(top, Math.min(top+plotH, sy(map.patient.hco3)));
		var svg = '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Bản đồ toan–kiềm theo PaCO₂ và HCO₃⁻">' +
			'<rect x="'+left+'" y="'+top+'" width="'+plotW+'" height="'+plotH+'" class="map-bg"/>' + grid +
			'<rect x="'+normalX+'" y="'+normalY+'" width="'+normalW+'" height="'+normalH+'" class="map-normal"/><text x="'+(normalX+normalW/2)+'" y="'+(normalY-6)+'" text-anchor="middle" class="map-normal-label">Vùng tham chiếu</text>' +
			curves +
			'<circle cx="'+px+'" cy="'+py+'" r="8" class="map-patient"/><circle cx="'+px+'" cy="'+py+'" r="14" class="map-patient-ring"/>' +
			'<text x="'+Math.min(left+plotW-120,px+14)+'" y="'+Math.max(top+16,py-12)+'" class="map-patient-label">Ca bệnh: pH '+formatNumber(map.patient.ph,3)+'</text>' +
			'<text x="'+(left+plotW/2)+'" y="'+(H-4)+'" text-anchor="middle" class="map-axis-label">PaCO₂ (mmHg)</text>' +
			'<text transform="translate(16 '+(top+plotH/2)+') rotate(-90)" text-anchor="middle" class="map-axis-label">HCO₃⁻ (mmol/L)</text></svg>';
		var body = '<div class="nah-abg__acid-map">'+svg+'</div><div class="nah-abg__map-legend"><span><i class="is-patient"></i>Ca bệnh</span><span><i class="is-normal"></i>Vùng tham chiếu</span><span><i class="is-line"></i>Đường đẳng pH</span></div><p class="nah-abg__hint">'+escapeHtml(map.note)+'</p>';
		return resultCard('A2', 'Bản đồ toan–kiềm', 'Trực quan hóa pH–PaCO₂–HCO₃⁻', 'neutral', body, 'Các đường đẳng pH được dựng từ Henderson–Hasselbalch: HCO₃⁻ = 0,03 × PaCO₂ × 10^(pH − 6,1).');
	}

	function renderAnionGap(result) {
		var ag = result.anionGap;
		var body;
		var badge;
		var status;
		var formula = '';

		if (!ag.available) {
			body = '<p>' + escapeHtml(ag.message) + '</p>';
			badge = 'Chưa tính';
			status = ag.relevant ? 'warning' : 'neutral';
		} else {
			body = [
				'<p class="nah-abg__metric-grid">',
				'<span><small>AG chưa hiệu chỉnh</small><strong>', formatNumber(ag.raw, 1), ' mmol/L</strong></span>',
				'<span><small>AG sử dụng</small><strong>', formatNumber(ag.effective, 1), ' mmol/L</strong></span>',
				ag.deltaRatio !== null ? '<span><small>ΔAG/ΔHCO₃⁻</small><strong>' + formatNumber(ag.deltaRatio, 2) + '</strong></span>' : '',
				ag.deltaGap !== null ? '<span><small>Khoảng trống delta</small><strong>' + formatNumber(ag.deltaGap, 1) + ' mmol/L</strong></span>' : '',
				'</p>',
				ag.albuminMissing ? '<p class="nah-abg__hint">Chưa hiệu chỉnh theo albumin; giảm albumin có thể che lấp AG tăng.</p>' : '',
				ag.deltaInterpretation ? '<p>' + escapeHtml(ag.deltaInterpretation) + '</p>' : ''
			].join('');
			badge = ag.stateLabel;
			status = ag.state;
			formula = ag.formula;
		}

		if (result.osmolalGap.available) {
			body += '<div class="nah-abg__subresult"><h5>Khoảng trống thẩm thấu</h5><p>' +
				escapeHtml(result.osmolalGap.message) + '</p><p class="nah-abg__metric">Osm tính: <strong>' +
				formatNumber(result.osmolalGap.calculated, 1) + '</strong> • Khoảng trống: <strong>' +
				formatNumber(result.osmolalGap.gap, 1) + ' mOsm/kg</strong></p></div>';
			formula += ' ' + result.osmolalGap.formula;
		}
		if (result.hyperglycemia.available && result.hyperglycemia.correctedSodium !== null && result.input.glucoseMmol >= 11.1) {
			body += '<div class="nah-abg__subresult"><h5>Tăng đường huyết</h5><p class="nah-abg__metric-grid">' +
				'<span><small>Na⁺ hiệu chỉnh ước tính</small><strong>' + formatNumber(result.hyperglycemia.correctedSodium, 1) + ' mmol/L</strong></span>' +
				'<span><small>Osm hiệu dụng</small><strong>' + formatNumber(result.hyperglycemia.effectiveOsm, 1) + ' mOsm/kg</strong></span>' +
				(result.hyperglycemia.totalCalculatedOsm !== null
					? '<span><small>Osm toàn phần tính</small><strong>' + formatNumber(result.hyperglycemia.totalCalculatedOsm, 1) + ' mOsm/kg</strong></span>'
					: '') +
				'</p><p class="nah-abg__hint">' + escapeHtml(result.hyperglycemia.message) + '</p></div>';
			formula += ' ' + result.hyperglycemia.formula;
		}
		return resultCard('05', 'Khoảng trống anion và thẩm thấu', badge, status, body, formula);
	}

	function renderOxygenation(result) {
		var o2 = result.oxygenation;
		var body;
		var badge = 'Chưa đánh giá';
		var status = 'neutral';
		var formula = '';

		if (!o2.available) {
			body = '<p>' + publicHtml(o2.message) + '</p>';
			status = o2.reason === 'venous' ? 'warning' : 'neutral';
		} else {
			var metrics = [];
			if (o2.pfRatio !== null) {
				metrics.push('<span><small>Tỷ số PaO₂/FiO₂</small><strong>' + formatNumber(o2.pfRatio, 0) + '</strong></span>');
				badge = o2.pfLabel;
				status = o2.pfState;
			}
			if (o2.aaGradient !== null) {
				metrics.push('<span><small>Chênh áp O₂ phế nang–động mạch</small><strong>' + formatNumber(o2.aaGradient, 1) + ' mmHg</strong></span>');
			}
			if (o2.arterialO2Content !== null) {
				metrics.push('<span><small>Hàm lượng oxy động mạch (CaO₂)</small><strong>' + formatNumber(o2.arterialO2Content, 1) + ' mL/dL</strong></span>');
			}
			body = '<p class="nah-abg__metric-grid">' + metrics.join('') + '</p>';
			if (o2.expectedAa !== null) {
				body += '<p>Giới hạn A–a ước tính theo tuổi: <strong>' + formatNumber(o2.expectedAa, 1) +
					' mmHg</strong>; kết quả ' + (o2.aaState === 'high' ? 'tăng' : 'không tăng') + ' trên khí phòng.</p>';
			} else if (o2.aaCaution) {
				body += '<p class="nah-abg__hint">A–a đã được tính nhưng không phân loại tự động khi FiO₂ cao hoặc áp suất khí quyển thấp.</p>';
			}
			if (o2.mechanism) {
				body += '<p><strong>Định hướng cơ chế:</strong> ' + publicHtml(o2.mechanism) + '</p>';
			}
			if (o2.contentCaution) {
				body += '<p class="nah-abg__hint">' + publicHtml(o2.contentCaution) + '</p>';
			}
			body += '<p>' + publicHtml(o2.message) + '</p>';
			formula = o2.formula;
		}

		if (result.dyshemoglobin.available) {
			var dys = result.dyshemoglobin;
			var dysMetrics = [];
			if (result.input.spo2 !== null) {
				dysMetrics.push('<span><small>SpO₂</small><strong>' + formatNumber(result.input.spo2, 1) + '%</strong></span>');
			}
			if (result.input.cohb !== null) {
				dysMetrics.push('<span><small>COHb</small><strong>' + formatNumber(result.input.cohb, 1) + '%</strong></span>');
			}
			if (result.input.methb !== null) {
				dysMetrics.push('<span><small>MetHb</small><strong>' + formatNumber(result.input.methb, 1) + '%</strong></span>');
			}
			body += '<div class="nah-abg__subresult"><h5>Đồng oxy kế và hemoglobin bất thường</h5>' +
				(dysMetrics.length ? '<p class="nah-abg__metric-grid">' + dysMetrics.join('') + '</p>' : '') +
				dys.findings.map(function (finding) {
					return '<p class="nah-abg__finding nah-abg__finding--' + statusClass(finding.level) + '">' + publicHtml(finding.message) + '</p>';
				}).join('') +
				'<p class="nah-abg__hint">' + publicHtml(dys.message) + '</p></div>';
		}
		return resultCard('06', 'Đánh giá oxy hóa máu', badge, status, body, formula);
	}


	function renderAdvancedOxygenation(result) {
		var a = result.oxygenationAdvanced;
		if (!a || !a.available) {
			return resultCard('O2', 'Đánh giá oxy hóa mở rộng', 'Chưa đủ dữ liệu', 'neutral', '<p>' + publicHtml(a && a.message ? a.message : 'Chưa đủ dữ liệu.') + '</p>', 'Cần diễn giải cùng phương thức hỗ trợ hô hấp, FiO₂ và tình trạng người bệnh.');
		}
		var metrics = [];
		if (a.pfRatio !== null) metrics.push('<span><small>Tỷ số PaO₂/FiO₂</small><strong>' + formatNumber(a.pfRatio, 0) + '</strong></span>');
		if (a.sfRatio !== null) metrics.push('<span><small>Tỷ số SpO₂/FiO₂</small><strong>' + formatNumber(a.sfRatio, 0) + '</strong></span>');
		metrics.push('<span><small>Độ tin cậy của FiO₂</small><strong>' + escapeHtml(a.fio2Reliability === 'high' ? 'Tin cậy cao' : (a.fio2Reliability === 'moderate' ? 'Khá tin cậy' : (a.fio2Reliability === 'low' ? 'Ước tính' : 'Chưa rõ'))) + '</strong></span>');
		var body = '<p class="nah-abg__metric-grid">' + metrics.join('') + '</p>' +
			'<div class="nah-abg__subresult"><h5>Kiểu suy hô hấp / thông khí</h5><p><strong>' + publicHtml(a.respiratoryLabel) + '</strong></p></div>' +
			'<div class="nah-abg__subresult"><h5>Bối cảnh FiO₂ và hỗ trợ hô hấp</h5><p>' + publicHtml(a.fio2Context) + '</p>' + (a.peepContext ? '<p>' + publicHtml(a.peepContext) + '</p>' : '') + '</div>';
		if (a.sfRatio !== null && !a.sfReliable) body += '<p class="nah-abg__hint">Tỷ số SpO₂/FiO₂ có độ tin cậy hạn chế khi SpO₂ ở vùng bão hòa cao hoặc quá thấp; ưu tiên PaO₂ khi đã có khí máu động mạch.</p>';
		if (a.interpretation && a.interpretation.length) body += '<div class="nah-abg__subresult"><h5>Diễn giải tích hợp</h5><ol class="nah-abg__reasoning-list">' + a.interpretation.map(function(x){ return '<li>' + publicHtml(x) + '</li>'; }).join('') + '</ol></div>';
		body += '<p class="nah-abg__hint"><strong>An toàn:</strong> ' + publicHtml(a.safety) + '</p>';
		var status = a.respiratoryPattern === 'no-threshold-pattern' ? 'success' : (a.pfSeverity === 'severe' ? 'danger' : 'warning');
		return resultCard('O2', 'Phân tích oxy hóa nâng cao', 'Đánh giá tích hợp', status, body, 'Tỷ số PaO₂/FiO₂ = PaO₂ chia FiO₂; tỷ số SpO₂/FiO₂ = SpO₂ chia FiO₂. Tỷ số SpO₂/FiO₂ chỉ là chỉ số bổ trợ và không thay thế PaO₂ khi đã có khí máu động mạch.');
	}

	function renderLactate(result) {
		var lactate = result.lactateAssessment;
		if (!lactate.available) {
			return resultCard('07', 'Lactat và xu hướng', 'Chưa nhập', 'neutral', '<p>' + publicHtml(lactate.message) + '</p>', '');
		}

		var body = '<p><strong>Lactat hiện tại ' + formatNumber(lactate.value, 1) + ' mmol/L.</strong> ' +
			publicHtml(lactate.message) + '</p>';
		if (lactate.trend) {
			var directionLabel = lactate.trend.direction === 'falling'
				? 'Đang giảm'
				: (lactate.trend.direction === 'rising' ? 'Đang tăng' : 'Ít thay đổi');
			body += '<div class="nah-abg__lactate-trend">' +
				'<div><small>Lần trước</small><strong>' + formatNumber(lactate.trend.previous, 1) + '</strong></div>' +
				'<div><small>Hiện tại</small><strong>' + formatNumber(lactate.trend.current, 1) + '</strong></div>' +
				'<div><small>Thay đổi</small><strong>' + formatNumber(lactate.trend.change, 1) + ' mmol/L</strong></div>' +
				'<div><small>Tỷ lệ giảm ước tính</small><strong>' + formatNumber(lactate.trend.clearancePercent, 1) + '%</strong></div>' +
				'</div><p><strong>' + escapeHtml(directionLabel) + '</strong>' +
				(lactate.trend.intervalHours !== null ? ' sau ' + formatNumber(lactate.trend.intervalHours, 1) + ' giờ. ' : '. ') +
				escapeHtml(lactate.trend.message) + '</p>';
		}
		body += '<p class="nah-abg__hint">' + publicHtml(lactate.caution) + '</p>';
		return resultCard('07', 'Lactat và xu hướng', lactate.label, lactate.state, body, '');
	}

	function renderDifferential(result) {
		var priorityLabels = { 3: 'Ưu tiên cao', 2: 'Cần đánh giá', 1: 'Cân nhắc' };
		var body = '<div class="nah-abg__differential-list">' + result.differential.map(function (item) {
			return [
				'<div class="nah-abg__diagnosis nah-abg__diagnosis--', item.priority, '">',
				'<div><h5>', publicHtml(item.name), '</h5>',
				'<span class="nah-abg__priority nah-abg__priority--', item.priority, '">', priorityLabels[item.priority], '</span></div>',
				'<ul>', item.rationale.map(function (reason) { return '<li>' + publicHtml(reason) + '</li>'; }).join(''), '</ul>',
				'</div>'
			].join('');
		}).join('') + '</div>';
		return resultCard('08', 'Chẩn đoán phân biệt có ưu tiên', result.differential.length + ' hướng', result.differential[0].priority === 3 ? 'danger' : 'warning', body, '');
	}

	function renderCauseAtlas(result) {
		if (!result.causeAtlas.length) {
			return resultCard(
				'09',
				'Bản đồ nguyên nhân thường gặp',
				'Chưa kích hoạt nhóm',
				'neutral',
				'<p>Chưa có mẫu hình đủ rõ để mở một nhóm nguyên nhân cụ thể. Đối chiếu lại ca bệnh, diễn biến và dữ liệu còn thiếu.</p>',
				''
			);
		}

		var body = '<div class="nah-abg__cause-atlas">' + result.causeAtlas.map(function (section, index) {
			return [
				'<details ', index === 0 ? 'open' : '', '>',
				'<summary><span>', publicHtml(section.title), '</span><small>', publicHtml(section.trigger), '</small></summary>',
				'<div class="nah-abg__cause-groups">',
				section.groups.map(function (group) {
					return '<section><h5>' + publicHtml(group.label) + '</h5><ul>' +
						group.causes.map(function (cause) { return '<li>' + publicHtml(cause) + '</li>'; }).join('') +
						'</ul></section>';
				}).join(''),
				section.note ? '<p class="nah-abg__hint">' + publicHtml(section.note) + '</p>' : '',
				'</div>',
				'</details>'
			].join('');
		}).join('') + '</div>';
		return resultCard('09', 'Bản đồ nguyên nhân thường gặp cần rà soát', result.causeAtlas.length + ' nhóm phù hợp', 'neutral', body, '');
	}

	function renderAdditionalTests(result) {
		var groupOrder = ['Khẩn', 'Xác minh ban đầu', 'Ưu tiên', 'Ưu tiên theo chẩn đoán', 'Theo định hướng'];
		var body = groupOrder.map(function (group) {
			var items = result.additionalTests.filter(function (item) { return item.group === group; });
			if (!items.length) {
				return '';
			}
			return '<div class="nah-abg__test-group"><h5>' + escapeHtml(group) + '</h5><ul>' +
				items.map(function (item) {
					return '<li><strong>' + publicHtml(item.test) + '</strong><small>' + publicHtml(item.reason) + '</small></li>';
				}).join('') +
				'</ul></div>';
		}).join('');
		return resultCard('10', 'Xét nghiệm cần bổ sung', result.additionalTests.length + ' mục', 'neutral', body || '<p>Chưa có đề xuất bổ sung từ dữ liệu hiện tại.</p>', '');
	}

	function renderManagement(result) {
		var urgencyLabels = {
			immediate: 'Ngay',
			priority: 'Ưu tiên',
			cause: 'Theo nguyên nhân',
			reassess: 'Đánh giá lại'
		};
		var body = '<div class="nah-abg__management-list">' + result.management.map(function (item) {
			return [
				'<div class="nah-abg__management-item nah-abg__management-item--', escapeHtml(item.urgency), '">',
				'<span>', escapeHtml(urgencyLabels[item.urgency] || 'Lưu ý'), '</span>',
				'<div><h5>', publicHtml(item.title), '</h5><p>', publicHtml(item.text), '</p></div>',
				'</div>'
			].join('');
		}).join('') + '</div>' +
			'<p class="nah-abg__hint"><strong>Không tự động kê đơn hoặc đưa liều.</strong> Xử trí phải dựa trên thăm khám, nguyên nhân, diễn biến và hướng dẫn chuyên môn tại cơ sở.</p>';
		return resultCard('11', 'Hướng xử trí theo mức ưu tiên', 'Không gồm liều thuốc', result.alerts.length ? 'warning' : 'neutral', body, '');
	}

	/* v3.9 — Tích hợp kết quả khí máu với bối cảnh lâm sàng. */
	var CLINICAL_SETTING_LABELS = {
		'unspecified':'Chưa chọn bối cảnh chăm sóc','emergency':'Cấp cứu','critical-care':'Hồi sức tích cực','inpatient':'Nội trú','outpatient':'Ngoại trú','peri-procedure':'Quanh thủ thuật hoặc phẫu thuật','follow-up':'Theo dõi diễn biến'
	};
	var CLINICAL_FOCUS_LABELS = {
		'general':'Diễn giải tổng thể','acidbase':'Rối loạn toan–kiềm','oxygenation':'Oxy hóa máu','ventilation':'Thông khí','mixed':'Rối loạn phối hợp','sample':'Độ tin cậy của mẫu','trend':'Theo dõi thay đổi theo thời gian'
	};
	var CLINICAL_CONTEXT_LABELS = {
		'sepsis':'Nhiễm trùng huyết','shock':'Sốc/giảm tưới máu','diabetes':'Đái tháo đường/tăng đường huyết','renal-failure':'Suy thận','vomiting':'Nôn/hút dịch dạ dày','diarrhea':'Tiêu chảy/mất HCO₃⁻','copd':'COPD/hen/tắc nghẽn','cns-depressant':'An thần/opioid/ức chế thần kinh','neuromuscular':'Bệnh thần kinh–cơ','ohs-osa':'Giảm thông khí do béo phì/ngưng thở khi ngủ','pulmonary-embolism':'Nghi thuyên tắc phổi','pain-anxiety':'Đau/lo âu/tăng thông khí','liver-disease':'Bệnh gan','pregnancy':'Thai kỳ','salicylate':'Dùng/ngộ độc salicylat','alcohol-starvation':'Rượu/nhịn đói','toxic-alcohol':'Nghi methanol/ethylene glycol','diuretic':'Đang dùng lợi tiểu','saline-load':'Truyền nhiều NaCl 0,9%','seizure':'Co giật gần đây','sglt2':'Đang dùng thuốc ức chế SGLT2','gi-fistula':'Rò/dẫn lưu tụy–mật–ruột','carbonic-anhydrase':'Acetazolamide/topiramate','mineralocorticoid':'Nghi cường mineralocorticoid','hypertension':'Tăng huyết áp','alkali-load':'Tải bicarbonat/citrate/antacid','airway-obstruction':'Dị vật/nút nhầy/tắc ống nội khí quản','cns-injury':'Tổn thương thần kinh trung ương','chest-wall':'Bệnh thành ngực/hạn chế nặng','fever':'Sốt/tăng chuyển hóa','high-altitude':'Độ cao/oxy khí hít vào thấp','lactate-drug':'Thuốc có thể tăng lactat','smoke-fire':'Khói cháy/khí thải/không gian kín','oxidant-drug':'Thuốc/chất oxy hóa gây methemoglobin','smoker':'Có hút thuốc'
	};
	function uniqueText(items){var seen={};return (items||[]).filter(function(item){var key=String(item||'').trim();if(!key||seen[key])return false;seen[key]=1;return true;});}
	function hasClinicalContext(result,name){return result&&result.input&&Array.isArray(result.input.clinicalContexts)&&result.input.clinicalContexts.indexOf(name)>=0;}
	function clinicalIntegrationTopic(result){
		var focus=result.integrationContext&&result.integrationContext.focus?result.integrationContext.focus:'general';
		if(focus==='acidbase'||focus==='mixed')return 'acidbase';
		if(focus==='oxygenation'||focus==='ventilation')return 'oxygen';
		if(focus==='sample')return 'foundation';
		if(result.sampleQuality&&result.sampleQuality.issues&&result.sampleQuality.issues.length)return 'foundation';
		if(result.mixedDisorders&&result.mixedDisorders.findings&&result.mixedDisorders.findings.length)return 'acidbase';
		if(result.oxygenation&&result.oxygenation.available&&result.oxygenation.pfRatio!==null&&result.oxygenation.pfRatio<=300)return 'oxygen';
		return 'clinical';
	}
	function buildClinicalIntegrationData(result){
		var input=result.input||{}, ctx=result.integrationContext||{}, contexts=Array.isArray(input.clinicalContexts)?input.clinicalContexts:[];
		var findings=[], gaps=[], checks=[], tags=[];
		var setting=CLINICAL_SETTING_LABELS[ctx.setting||'unspecified']||'Chưa chọn bối cảnh chăm sóc';
		var focus=CLINICAL_FOCUS_LABELS[ctx.focus||'general']||'Diễn giải tổng thể';
		tags.push(setting);tags.push(focus);
		contexts.slice(0,6).forEach(function(name){tags.push(CLINICAL_CONTEXT_LABELS[name]||name);});
		findings.push('Toan–kiềm: '+publicCopy(result.classification.title)+'.');
		if(result.mixedDisorders&&result.mixedDisorders.findings&&result.mixedDisorders.findings.length) findings.push('Có dấu hiệu cần xem xét rối loạn phối hợp: '+publicCopy(result.mixedDisorders.message));
		if(result.anionGap&&result.anionGap.available&&result.anionGap.relevant){
			var ag='Khoảng trống anion '+formatNumber(result.anionGap.effective,1)+' mmol/L · '+publicCopy(result.anionGap.stateLabel)+'.';
			if(result.anionGap.corrected!==null)ag+=' Đã tính với hiệu chỉnh albumin.';
			findings.push(ag);
		}
		if(result.oxygenation){
			if(result.oxygenation.available){
				var ox='Oxy hóa: PaO₂ '+pressureText(input.pao2,input.gasPressureUnit);
				if(result.oxygenation.pfRatio!==null)ox+=' · PaO₂/FiO₂ '+formatNumber(result.oxygenation.pfRatio,0);
				if(result.oxygenation.aaState==='high')ox+=' · chênh áp oxy phế nang–động mạch tăng';
				findings.push(ox+'.');
			}else findings.push('Oxy hóa: '+publicCopy(result.oxygenation.message));
		}
		if(result.lactateAssessment&&result.lactateAssessment.available)findings.push('Lactat '+formatNumber(result.lactateAssessment.value,1)+' mmol/L · '+publicCopy(result.lactateAssessment.label)+'.');

		if(result.sampleQuality&&result.sampleQuality.issues&&result.sampleQuality.issues.length)gaps.push('Có vấn đề chất lượng mẫu/tiền phân tích cần xác minh trước khi dựa vào kết quả để suy luận sâu.');
		if((ctx.focus==='oxygenation'||ctx.focus==='general')&&input.sampleType==='venous')gaps.push('Mẫu tĩnh mạch không dùng để định lượng oxy hóa động mạch bằng PO₂.');
		if((ctx.focus==='oxygenation'||ctx.focus==='general')&&input.sampleType==='arterial'&&input.pao2===null)gaps.push('Chưa có PaO₂ để đánh giá oxy hóa động mạch.');
		if((ctx.focus==='oxygenation'||ctx.focus==='general')&&input.sampleType==='arterial'&&input.pao2!==null&&input.fio2===null)gaps.push('Chưa có FiO₂ nên chưa thể đặt PaO₂ vào đúng mức hỗ trợ oxy.');
		if(result.anionGap&&result.anionGap.relevant&&!result.anionGap.available)gaps.push('Có thành phần toan chuyển hóa nhưng chưa đủ Na⁺ và Cl⁻ để tính khoảng trống anion.');
		if(result.anionGap&&result.anionGap.available&&result.anionGap.relevant&&result.anionGap.albuminMissing)gaps.push('Chưa có albumin; khoảng trống anion chưa được hiệu chỉnh khi albumin thấp.');
		if((hasClinicalContext(result,'sepsis')||hasClinicalContext(result,'shock'))&&!(result.lactateAssessment&&result.lactateAssessment.available))gaps.push('Bệnh cảnh nhiễm trùng huyết/sốc đã được chọn nhưng chưa có lactat để đối chiếu tưới máu và xu hướng.');
		if((hasClinicalContext(result,'diabetes')||hasClinicalContext(result,'sglt2'))&&input.ketones===null)gaps.push('Bệnh cảnh đái tháo đường/thuốc ức chế SGLT2 đã được chọn nhưng chưa có ceton để đối chiếu khi nghi nhiễm toan ceton.');
		if(hasClinicalContext(result,'smoke-fire')&&input.cohb===null)gaps.push('Phơi nhiễm khói/khí thải đã được chọn nhưng chưa có carboxyhemoglobin từ đồng oxy kế.');
		if(hasClinicalContext(result,'oxidant-drug')&&input.methb===null)gaps.push('Phơi nhiễm chất oxy hóa đã được chọn nhưng chưa có methemoglobin từ đồng oxy kế.');

		if(hasClinicalContext(result,'sepsis')||hasClinicalContext(result,'shock'))checks.push('Đặt khí máu cùng huyết động, tưới máu ngoại vi, lượng nước tiểu, lactat và diễn biến sau can thiệp.');
		if(hasClinicalContext(result,'diabetes')||hasClinicalContext(result,'sglt2'))checks.push('Đối chiếu glucose, ceton, khoảng trống anion, điện giải và diễn biến lâm sàng; glucose không quá cao không tự loại trừ nhiễm toan ceton.');
		if(hasClinicalContext(result,'renal-failure'))checks.push('Đối chiếu chức năng thận, kali, khoảng trống anion, tình trạng dịch và khí máu nền nếu có.');
		if(hasClinicalContext(result,'vomiting')||hasClinicalContext(result,'diuretic'))checks.push('Đối chiếu clorid, kali, tình trạng thể tích và thuốc đang dùng khi đánh giá kiềm chuyển hóa.');
		if(hasClinicalContext(result,'diarrhea')||hasClinicalContext(result,'gi-fistula'))checks.push('Đối chiếu mất bicarbonat qua tiêu hóa, clorid, kali và chức năng thận.');
		if(hasClinicalContext(result,'copd')||hasClinicalContext(result,'cns-depressant')||hasClinicalContext(result,'neuromuscular')||hasClinicalContext(result,'ohs-osa')||hasClinicalContext(result,'airway-obstruction')||hasClinicalContext(result,'chest-wall'))checks.push('Đọc PaCO₂ cùng nhịp thở, tri giác, công hô hấp, hỗ trợ thông khí và khí máu nền để phân biệt cấp–mạn.');
		if(hasClinicalContext(result,'pulmonary-embolism'))checks.push('Khí máu có thể hỗ trợ mô tả trao đổi khí nhưng không xác lập thuyên tắc phổi; cần ghép xác suất lâm sàng và thăm dò chẩn đoán phù hợp.');
		if(hasClinicalContext(result,'salicylate'))checks.push('Tìm mẫu hình kiềm hô hấp phối hợp toan chuyển hóa và đối chiếu nồng độ salicylat, thời điểm phơi nhiễm cùng các dữ kiện độc chất học.');
		if(hasClinicalContext(result,'toxic-alcohol'))checks.push('Khi bệnh cảnh phù hợp, đọc khoảng trống anion cùng khoảng trống thẩm thấu và dữ liệu độc chất học; không suy ra tác nhân chỉ từ một phép tính.');
		if(hasClinicalContext(result,'smoke-fire')||hasClinicalContext(result,'oxidant-drug'))checks.push('PaO₂ có thể bình thường dù vận chuyển oxy qua hemoglobin bất thường; đối chiếu đồng oxy kế và bệnh cảnh phơi nhiễm.');
		if(ctx.focus==='trend')checks.push('So sánh chuỗi khí máu chỉ sau khi xác nhận điều kiện lấy mẫu, FiO₂/hỗ trợ hô hấp và can thiệp giữa các thời điểm.');
		(result.additionalTests||[]).slice(0,4).forEach(function(item){if(item&&item.test)checks.push('Cân nhắc đối chiếu: '+publicCopy(item.test)+'.');});
		checks=uniqueText(checks).slice(0,7);gaps=uniqueText(gaps);findings=uniqueText(findings);
		var status='Đủ dữ kiện cơ bản',level='success';
		if(result.sampleQuality&&result.sampleQuality.issues&&result.sampleQuality.issues.length){status='Ưu tiên xác minh mẫu';level='danger';}
		else if(gaps.length){status='Cần bổ sung dữ kiện';level='warning';}
		return {setting:setting,focus:focus,tags:uniqueText(tags),findings:findings,gaps:gaps,checks:checks,status:status,level:level,topic:clinicalIntegrationTopic(result)};
	}
	function renderClinicalIntegration(result){
		var x=buildClinicalIntegrationData(result);
		var body='<div class="nah-abg__clinical-integration-result">'+
			'<div class="nah-abg__clinical-integration-meta">'+x.tags.map(function(tag){return '<span>'+escapeHtml(tag)+'</span>';}).join('')+'</div>'+
			'<div class="nah-abg__clinical-integration-columns"><section><h5>Khí máu đang cho thấy</h5><ul>'+x.findings.map(function(item){return '<li>'+escapeHtml(item)+'</li>';}).join('')+'</ul></section>'+
			'<section><h5>Điểm cần bổ sung hoặc xác minh</h5>'+(x.gaps.length?'<ul>'+x.gaps.map(function(item){return '<li>'+escapeHtml(item)+'</li>';}).join('')+'</ul>':'<p>Chưa phát hiện khoảng trống dữ liệu lớn theo câu hỏi đã chọn. Vẫn cần đối chiếu với diễn biến thực tế.</p>')+'</section></div>'+
			'<section class="nah-abg__clinical-integration-checks"><h5>Các điểm nên đối chiếu với bệnh cảnh</h5>'+(x.checks.length?'<ol>'+x.checks.map(function(item){return '<li>'+escapeHtml(item)+'</li>';}).join('')+'</ol>':'<p>Chọn thêm dữ kiện lâm sàng ở bước Ca bệnh để nhận gợi ý đối chiếu cụ thể hơn.</p>')+'</section>'+
			'<div class="nah-abg__clinical-integration-actions"><button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="'+escapeHtml(x.topic)+'">Xem lý thuyết liên quan</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-integration-open-review="'+escapeHtml(x.topic)+'">Ôn câu hỏi liên quan</button></div>'+
			'<p class="nah-abg__clinical-integration-disclaimer">Phần này cấu trúc hóa việc đối chiếu dữ kiện; không tự xác lập chẩn đoán hoặc quyết định điều trị.</p></div>';
		return resultCard('L', 'Tích hợp với bối cảnh lâm sàng', x.status, x.level, body, '');
	}

	function buildClinicalSummaryText(result, records) {
		var lines = [];
		lines.push('TÓM TẮT PHÂN TÍCH KHÍ MÁU');
		lines.push('Rối loạn chính: ' + publicCopy(result.classification.title) + '.');
		if (result.integrationContext) { var ix=buildClinicalIntegrationData(result); lines.push('Bối cảnh: ' + ix.setting + ' · Câu hỏi ưu tiên: ' + ix.focus + '.'); }
		if (result.compensation && result.compensation.items && result.compensation.items.length) {
			lines.push('Bù trừ: ' + result.compensation.items.map(function (item) { return publicCopy(item.comparison.message); }).join(' '));
		} else if (result.compensation && result.compensation.message) {
			lines.push('Bù trừ: ' + publicCopy(result.compensation.message));
		}
		if (result.mixedDisorders && result.mixedDisorders.findings && result.mixedDisorders.findings.length) {
			lines.push('Rối loạn phối hợp: ' + publicCopy(result.mixedDisorders.message));
		}
		if (result.anionGap) {
			lines.push('Khoảng trống anion: ' + (result.anionGap.available ? formatNumber(result.anionGap.effective, 1) + ' mmol/L · ' + publicCopy(result.anionGap.stateLabel) : publicCopy(result.anionGap.message)));
		}
		if (result.oxygenation) {
			var ox = result.oxygenation;
			var oxText = publicCopy(ox.message || 'Chưa đủ dữ liệu.');
			if (ox.available && ox.pfRatio !== null) oxText = 'Tỷ số PaO₂/FiO₂ ' + formatNumber(ox.pfRatio, 0) + '. ' + oxText;
			lines.push('Oxy hóa: ' + oxText);
		}
		if (result.lactateAssessment && result.lactateAssessment.available) {
			lines.push('Lactat: ' + formatNumber(result.lactateAssessment.value, 1) + ' mmol/L · ' + publicCopy(result.lactateAssessment.label) + '.');
		}
		if (records && records.length) {
			lines.push('Theo dõi chuỗi: đã lưu ' + records.length + ' mốc trong phiên làm việc; cần so sánh các lần đo trong cùng điều kiện lâm sàng và hỗ trợ hô hấp.');
		}
		if (result.additionalTests && result.additionalTests.length) {
			lines.push('Cần bổ sung/đối chiếu: ' + result.additionalTests.slice(0, 5).map(function (item) { return publicCopy(item.test); }).join('; ') + '.');
		}
		lines.push('Lưu ý: Kết quả hỗ trợ diễn giải, không thay thế thăm khám, chẩn đoán và quyết định điều trị theo bối cảnh thực tế.');
		return lines.join('\n');
	}

	function renderClinicalSummaryAndTeaching(result, records) {
		var summaryText = buildClinicalSummaryText(result, records);
		var summaryLines = summaryText.split('\n').filter(Boolean);
		var teaching = result.stepByStepReasoning && result.stepByStepReasoning.steps ? result.stepByStepReasoning.steps : [];
		var body = '<div class="nah-abg__summary-toolbar" role="tablist" aria-label="Chế độ xem kết quả">' +
			'<button type="button" class="is-active" data-summary-mode="clinical" role="tab" aria-selected="true">Tóm tắt lâm sàng</button>' +
			'<button type="button" data-summary-mode="teaching" role="tab" aria-selected="false">Giải thích học tập</button>' +
			'</div>' +
			'<div class="nah-abg__summary-pane" data-summary-pane="clinical">' +
			'<ul class="nah-abg__clinical-summary-list">' + summaryLines.slice(1).map(function(line){ return '<li>' + escapeHtml(line) + '</li>'; }).join('') + '</ul>' +
			'<button type="button" class="nah-abg__button nah-abg__button--ghost nah-abg__button--small" data-copy-clinical-summary>Sao chép tóm tắt</button>' +
			'</div>' +
			'<div class="nah-abg__summary-pane" data-summary-pane="teaching" hidden>' +
			'<p class="nah-abg__teaching-intro">Các bước dưới đây giải thích cách đi từ dữ liệu khí máu đến nhận định. Đây là nội dung học tập, không phải chỉ định điều trị.</p>' +
			'<ol class="nah-abg__teaching-steps">' + teaching.map(function(step){ return '<li><span>Bước ' + step.index + '</span><p>' + publicHtml(step.text) + '</p></li>'; }).join('') + '</ol>' +
			(result.deltaAnalysis && result.deltaAnalysis.available ? '<p class="nah-abg__hint"><strong>Phân tích delta:</strong> ' + escapeHtml(result.deltaAnalysis.interpretation || result.deltaAnalysis.message) + '</p>' : '') +
			'<p class="nah-abg__hint">Nên đối chiếu loại mẫu, thời điểm lấy, hỗ trợ hô hấp, diễn biến và các xét nghiệm liên quan trước khi kết luận.</p></div>';
		return resultCard('T', 'Tóm tắt lâm sàng và giải thích học tập', 'Hai chế độ xem', 'success', body, '');
	}

	function renderResult(result, serialRecords) {
		return [
			renderHeader(result),
			renderAlerts(result),
			renderReferenceWarnings(result),
			'<div class="nah-abg__result-list">',
			renderClinicalSummaryAndTeaching(result, serialRecords || []),
			renderClinicalIntegration(result),
			renderProtocolPath(result),
			renderConsistency(result),
			renderPh(result),
			renderPrimary(result),
			renderCompensation(result),
			renderAdvancedReasoning(result),
			renderAnionGap(result),
			renderAcidBaseMap(result),
			renderOxygenation(result),
			renderAdvancedOxygenation(result),
			renderLactate(result),
			renderDifferential(result),
			renderCauseAtlas(result),
			renderAdditionalTests(result),
			renderManagement(result),
			'</div>'
		].join('');
	}

	function setFieldFeedback(field, feedback) {
		var container = field.closest('.nah-abg__field');
		if (!container) {
			return;
		}
		var existing = container.querySelector('[data-field-feedback="' + field.name + '"]');
		if (!existing) {
			existing = document.createElement('small');
			existing.setAttribute('data-field-feedback', field.name);
			existing.className = 'nah-abg__field-feedback';
			container.appendChild(existing);
		}

		field.classList.remove('is-invalid', 'is-warning', 'is-valid');
		existing.classList.remove('is-invalid', 'is-warning', 'is-valid');
		if (!feedback || feedback.state === 'empty') {
			existing.textContent = '';
			return;
		}

		existing.textContent = feedback.message;
		if (feedback.state === 'invalid' || feedback.state === 'critical') {
			field.classList.add('is-invalid');
			existing.classList.add('is-invalid');
		} else if (feedback.state === 'high' || feedback.state === 'low') {
			field.classList.add('is-warning');
			existing.classList.add('is-warning');
		} else if (feedback.state === 'normal') {
			field.classList.add('is-valid');
			existing.classList.add('is-valid');
		}
	}

	function validateNumericField(form, field) {
		if (!field.value.trim()) {
			setFieldFeedback(field, { state: 'empty', message: '' });
			return field.required ? { state: 'invalid', message: 'Vui lòng nhập ' + field.name + '.' } : { state: 'empty', message: '' };
		}
		var feedback = Core.inspectField(readForm(form), field.name);
		setFieldFeedback(field, feedback);
		return feedback;
	}

	function convertUnitValue(field, convert) {
		if (!field || !field.value.trim()) {
			return;
		}
		var parsed = Core.parseNumeric(field.value);
		if (!parsed.valid || parsed.value === null) {
			return;
		}
		field.value = compactNumber(convert(parsed.value), 2);
	}

	function applyUnitSystem(form, system, convertExisting) {
		Object.keys(UNIT_DEFINITIONS).forEach(function (role) {
			var definition = UNIT_DEFINITIONS[role];
			var select = form.querySelector('[data-unit-role="' + role + '"]');
			var field = form.elements[definition.field];
			if (!select) {
				return;
			}
			var target = system === 'us' ? definition.us : definition.si;
			var previous = select.value;
			if (convertExisting && previous !== target) {
				convertUnitValue(field, system === 'us' ? definition.toUs : definition.toSi);
			}
			select.value = target;
		});
	}

	function updatePressureUnit(form, previousUnit, nextUnit) {
		if (previousUnit && previousUnit !== nextUnit) {
			['paco2', 'pao2'].forEach(function (name) {
				var field = form.elements[name];
				convertUnitValue(field, nextUnit === 'kpa'
					? function (value) { return value / Core.MMHG_PER_KPA; }
					: function (value) { return value * Core.MMHG_PER_KPA; });
			});
		}

		form.closest('[data-nah-abg-root]').querySelectorAll('[data-pressure-unit-label]').forEach(function (label) {
			label.textContent = nextUnit === 'kpa' ? 'kPa' : 'mmHg';
		});
		var reference = form.closest('[data-nah-abg-root]').querySelector('[data-paco2-reference]');
		if (reference) {
			reference.textContent = nextUnit === 'kpa' ? 'Tham chiếu: 4,7–6,0 kPa' : 'Tham chiếu: 35–45 mmHg';
		}
		form.elements.paco2.placeholder = nextUnit === 'kpa' ? '5,3' : '40';
		form.elements.pao2.placeholder = nextUnit === 'kpa' ? '12,0' : '90';
	}

	function setupAppMenu(root) {
		if (!root) { return; }
		var toggle = root.querySelector('[data-abg-menu-toggle]');
		var menu = root.querySelector('[data-abg-menu]');
		var accountToggle = root.querySelector('[data-abg-account-toggle]');
		var accountPopover = root.querySelector('[data-abg-account-popover]');
		var overlay = root.querySelector('[data-abg-info-overlay]');
		var close = root.querySelector('[data-abg-info-close]');
		if (!toggle || !menu) { return; }

		function setAccount(open) {
			if (!accountToggle || !accountPopover) return;
			accountPopover.hidden = !open;
			accountToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			root.classList.toggle('nah-abg--account-open', !!open);
		}
		function setMenu(open) {
			if (open) setAccount(false);
			menu.hidden = !open;
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			root.classList.toggle('nah-abg--menu-open', !!open);
		}
		function closeInfo() {
			if (!overlay) { return; }
			overlay.hidden = true;
			root.querySelectorAll('[data-abg-info-panel]').forEach(function (panel) { panel.hidden = true; });
		}
		function openInfo(name) {
			if (!overlay) { return; }
			var panel = root.querySelector('[data-abg-info-panel="' + name + '"]');
			if (!panel) { return; }
			root.querySelectorAll('[data-abg-info-panel]').forEach(function (item) { item.hidden = true; });
			panel.hidden = false;
			overlay.hidden = false;
			setMenu(false);
			if (close) { close.focus(); }
		}

		if (accountToggle && accountPopover) {
			accountToggle.addEventListener('click', function (event) {
				event.stopPropagation();
				setMenu(false);
				setAccount(accountPopover.hidden);
			});
			accountPopover.addEventListener('click', function (event) {
				if (event.target.closest('a,button')) setAccount(false);
			});
		}
		toggle.addEventListener('click', function (event) {
			event.stopPropagation();
			setMenu(menu.hidden);
		});
		menu.addEventListener('click', function (event) {
			var info = event.target.closest('[data-abg-info]');
			if (info) { openInfo(info.getAttribute('data-abg-info')); return; }
			var update = event.target.closest('[data-abg-check-update]');
			if (update) {
				event.preventDefault();
				setMenu(false);
				var label = update.querySelector('[data-abg-check-update-label]');
				if (label) { label.textContent = 'Đang kiểm tra…'; }
				update.disabled = true;
				var finish = function () { window.location.reload(); };
				if (navigator.serviceWorker && navigator.serviceWorker.getRegistration) {
					navigator.serviceWorker.getRegistration().then(function (registration) {
						return registration ? registration.update() : null;
					}).then(finish).catch(finish);
				} else {
					finish();
				}
				return;
			}
			if (event.target.closest('a,button')) { setMenu(false); }
		});
		if (close) { close.addEventListener('click', closeInfo); }
		if (overlay) {
			overlay.addEventListener('click', function (event) { if (event.target === overlay) { closeInfo(); } });
		}
		document.addEventListener('click', function (event) {
			if (!menu.hidden && !menu.contains(event.target) && !toggle.contains(event.target)) { setMenu(false); }
			if (accountPopover && !accountPopover.hidden && !accountPopover.contains(event.target) && accountToggle && !accountToggle.contains(event.target)) { setAccount(false); }
		});
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') { setMenu(false); setAccount(false); closeInfo(); }
		});
	}

	function setupTheme(root) {
		if (!root) { return; }
		var button = root.querySelector('[data-theme-toggle]');
		if (!button) { return; }
		var label = button.querySelector('[data-theme-label]');
		var storageKey = 'nah_abg_theme_v640';
		var savedTheme = null;
		try { savedTheme = window.localStorage.getItem(storageKey); } catch (error) { savedTheme = null; }
		function applyTheme(theme, persist) {
			var isDark = theme === 'dark';
			root.classList.toggle('nah-abg--dark', isDark);
			root.classList.toggle('nah-abg--light', !isDark);
			root.setAttribute('data-theme', isDark ? 'dark' : 'light');
			root.setAttribute('data-theme-source', 'abg');
			button.setAttribute('aria-pressed', isDark ? 'true' : 'false');
			button.setAttribute('aria-label', isDark ? 'Bật chế độ sáng' : 'Bật chế độ tối');
			if (label) label.textContent = isDark ? 'Chế độ sáng' : 'Chế độ tối';
			var themeMeta = document.querySelector('meta[name="theme-color"]');
			if (themeMeta && root.getAttribute('data-abg-standalone') === '1') themeMeta.setAttribute('content', isDark ? '#101b28' : '#ffffff');
			if (persist) {
				try { window.localStorage.setItem(storageKey, isDark ? 'dark' : 'light'); } catch (error) {}
			}
		}
		/* v6.4.0: ABG owns its visual theme. Do not inherit a dark host/site/OS theme,
		   because the clinical home and login surfaces are designed as a white medical app. */
		applyTheme(savedTheme === 'dark' ? 'dark' : 'light', false);
		button.addEventListener('click', function () {
			applyTheme(root.classList.contains('nah-abg--dark') ? 'light' : 'dark', true);
		});
	}
	function setupPwa(root) {
		if (!root || root.getAttribute('data-abg-standalone') !== '1') {
			return;
		}

		var installButton = root.querySelector('[data-install-app]');
		var installHelp = root.querySelector('[data-install-help]');
		var helpText = root.querySelector('[data-install-help-text]');
		var installLabel = root.querySelector('[data-install-label]');
		var standalone = window.matchMedia && window.matchMedia('(display-mode: standalone)').matches;
		var isIos = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
		var start = window.location.pathname + window.location.search;

		if (!document.querySelector('link[rel="manifest"]') && Config.manifestUrl) {
			var manifest = document.createElement('link');
			manifest.rel = 'manifest';
			manifest.href = Config.manifestUrl + '&start=' + encodeURIComponent(start);
			document.head.appendChild(manifest);
		}

		if ('serviceWorker' in navigator && Config.swUrl && (Config.isHttps || window.location.hostname === 'localhost')) {
			var scope = '/phan-tich-khi-mau-app/';
			navigator.serviceWorker.register(Config.swUrl + '&start=' + encodeURIComponent(start), { scope: scope }).catch(function () {
				// Installation remains optional; calculation must continue to work.
			});
		}

		if (!installButton || !installHelp || !helpText) {
			return;
		}

		function refreshInstallButton() {
			if (standalone) {
				installButton.hidden = true;
				return;
			}
			installButton.hidden = false;
			if (installLabel) {
				installLabel.textContent = isIos && !deferredInstallPrompt ? 'Thêm vào Màn hình chính' : 'Cài Webapp';
			}
		}

		installButton.addEventListener('click', function () {
			if (deferredInstallPrompt) {
				deferredInstallPrompt.prompt().then(function () {
					deferredInstallPrompt = null;
					refreshInstallButton();
				});
				return;
			}
			if (isIos) {
				helpText.textContent = 'Trên Safari: chọn nút Chia sẻ, sau đó chọn “Thêm vào Màn hình chính”.';
			} else if (!Config.isHttps && window.location.hostname !== 'localhost') {
				helpText.textContent = 'Ứng dụng cần kết nối HTTPS để cài đặt. Vẫn có thể sử dụng đầy đủ công cụ khi mở trên trình duyệt.';
			}
			installHelp.hidden = false;
			installHelp.scrollIntoView({ behavior: 'smooth', block: 'center' });
		});

		document.addEventListener('nah-abg-install-ready', refreshInstallButton);
		refreshInstallButton();
	}



	/* v3.0 — Hệ thống học tập khí máu. Dữ liệu và tiến độ chỉ được xử lý tại thiết bị. */
	var LEARNING_QUESTIONS = [
		{id:'f01',topic:'foundation',q:'Ba thông số nào nên được đọc cùng nhau khi bắt đầu phân tích toan–kiềm?',o:['pH, PaCO₂ và HCO₃⁻','PaO₂, hemoglobin và lactat','Natri, kali và clorid','Glucose, ceton và creatinine'],a:0,e:'pH cho biết trạng thái toan hay kiềm; PaCO₂ đại diện thành phần hô hấp; HCO₃⁻ đại diện thành phần chuyển hóa.'},
		{id:'f02',topic:'foundation',q:'Cơ quan nào điều chỉnh PaCO₂ trực tiếp thông qua thông khí phế nang?',o:['Gan','Phổi','Thận','Tủy xương'],a:1,e:'Phổi thay đổi thông khí phế nang để điều chỉnh PaCO₂ trong thời gian ngắn.'},
		{id:'f03',topic:'foundation',q:'Một pH gần khoảng tham chiếu có loại trừ rối loạn toan–kiềm phối hợp không?',o:['Có, luôn loại trừ','Không','Chỉ khi PaO₂ bình thường','Chỉ khi lactat bình thường'],a:1,e:'Hai quá trình nguyên phát đối nghịch có thể kéo pH về gần khoảng tham chiếu. Vì vậy vẫn phải đọc PaCO₂ và HCO₃⁻.'},
		{id:'f04',topic:'foundation',q:'Bọt khí trong mẫu khí máu có thể gây hậu quả nào?',o:['Không ảnh hưởng kết quả','Làm các khí trong mẫu trao đổi với không khí môi trường','Chỉ làm thay đổi natri','Chỉ làm thay đổi glucose'],a:1,e:'Bọt khí tạo điều kiện trao đổi oxy và CO₂ giữa mẫu với không khí, làm sai kết quả khí máu.'},
		{id:'f05',topic:'foundation',q:'Trong phương trình Henderson–Hasselbalch, pH phụ thuộc chủ yếu vào mối tương quan giữa yếu tố nào?',o:['Bicarbonate và CO₂ hòa tan','Natri và kali','Glucose và lactat','Hemoglobin và albumin'],a:0,e:'Hệ bicarbonat–CO₂ là nền tảng để liên hệ thành phần chuyển hóa và hô hấp với pH.'},
		{id:'f06',topic:'foundation',q:'Khi kết quả khí máu rất khác với toàn cảnh lâm sàng, bước nào nên được nghĩ đến sớm?',o:['Tìm ngay một bệnh hiếm','Kiểm tra chất lượng mẫu và bối cảnh lấy mẫu','Bỏ qua kết quả PaCO₂','Chỉ tính khoảng trống anion'],a:1,e:'Chất lượng mẫu, thời điểm lấy và hỗ trợ hô hấp tại lúc lấy mẫu phải được xác nhận trước khi diễn giải sâu.'},
		{id:'f07',topic:'foundation',q:'HCO₃⁻ trong phân tích khí máu chủ yếu đại diện cho thành phần nào của cân bằng toan–kiềm?',o:['Hô hấp','Chuyển hóa','Oxy hóa','Đông máu'],a:1,e:'HCO₃⁻ là biến số chính của thành phần chuyển hóa trong cách tiếp cận khí máu cơ bản.'},
		{id:'f08',topic:'foundation',q:'Phản ứng điều hòa của thận đối với rối loạn hô hấp thường cần khoảng thời gian nào để phát triển đầy đủ?',o:['Vài giây','Vài phút','Nhiều giờ đến vài ngày','Luôn xảy ra tức thì'],a:2,e:'Đáp ứng thận chậm hơn nhiều so với đáp ứng thông khí của phổi và cần thời gian để phát triển.'},

		{id:'a01',topic:'acidbase',q:'pH 7,25; HCO₃⁻ 12 mmol/L và PaCO₂ giảm. Rối loạn nguyên phát phù hợp nhất là gì?',o:['Toan chuyển hóa','Kiềm chuyển hóa','Toan hô hấp','Kiềm hô hấp'],a:0,e:'pH thấp và HCO₃⁻ giảm cùng chiều xác định toan chuyển hóa; PaCO₂ giảm có thể là đáp ứng hô hấp.'},
		{id:'a02',topic:'acidbase',q:'Công thức Winter được dùng chủ yếu để làm gì?',o:['Ước tính PaCO₂ dự kiến trong toan chuyển hóa','Tính PaO₂ phế nang','Tính hàm lượng oxy động mạch','Hiệu chỉnh natri theo glucose'],a:0,e:'Công thức Winter ước tính PaCO₂ dự kiến trong toan chuyển hóa để đánh giá đáp ứng hô hấp và gợi ý rối loạn phối hợp.'},
		{id:'a03',topic:'acidbase',q:'Trong toan chuyển hóa, PaCO₂ thực đo cao hơn rõ so với mức dự kiến theo công thức Winter gợi ý điều gì?',o:['Có thêm toan hô hấp','Có thêm kiềm hô hấp','Bù hoàn toàn bình thường','Không thể có rối loạn phối hợp'],a:0,e:'PaCO₂ cao hơn dự kiến cho thấy thông khí thấp hơn mức bù phù hợp, gợi ý thêm một quá trình toan hô hấp.'},
		{id:'a04',topic:'acidbase',q:'Khoảng trống anion nên được hiệu chỉnh theo yếu tố nào khi yếu tố này giảm rõ?',o:['Albumin','Hemoglobin','Tiểu cầu','Ure'],a:0,e:'Albumin là anion không đo được quan trọng; albumin thấp có thể làm khoảng trống anion thấp giả và che mức tăng thật sự.'},
		{id:'a05',topic:'acidbase',q:'pH 7,50; PaCO₂ 48 mmHg; HCO₃⁻ 36 mmol/L phù hợp nhất với rối loạn nguyên phát nào?',o:['Kiềm chuyển hóa','Toan chuyển hóa','Kiềm hô hấp','Toan hô hấp'],a:0,e:'pH tăng và HCO₃⁻ tăng cùng chiều xác định kiềm chuyển hóa; PaCO₂ tăng theo hướng đáp ứng hô hấp.'},
		{id:'a06',topic:'acidbase',q:'Trong toan hô hấp mạn, HCO₃⁻ thường thay đổi theo hướng nào?',o:['Tăng do đáp ứng của thận','Giảm nhanh do phổi','Không thay đổi','Giảm do tăng thông khí'],a:0,e:'Khi PaCO₂ tăng kéo dài, thận tăng giữ và tái tạo bicarbonat, vì vậy HCO₃⁻ tăng nhiều hơn so với tình trạng cấp.'},
		{id:'a07',topic:'acidbase',q:'pH hơi kiềm, PaCO₂ rất thấp và HCO₃⁻ thấp sâu hơn mức bù dự kiến nên nghĩ tới điều gì?',o:['Kiềm hô hấp đơn thuần','Kiềm hô hấp phối hợp toan chuyển hóa','Toan hô hấp đơn thuần','Kiềm chuyển hóa đơn thuần'],a:1,e:'HCO₃⁻ thấp hơn mức có thể giải thích bởi kiềm hô hấp đơn thuần gợi ý thêm toan chuyển hóa.'},
		{id:'a08',topic:'acidbase',q:'Khi độ tăng khoảng trống anion lớn hơn rõ so với độ giảm HCO₃⁻, nên cân nhắc rối loạn phối hợp nào?',o:['Kiềm chuyển hóa đi kèm','Toan hô hấp đi kèm','Kiềm hô hấp đi kèm','Không có rối loạn phối hợp'],a:0,e:'Khoảng trống anion tăng nhiều hơn mức giảm bicarbonat có thể gợi ý thêm một quá trình làm HCO₃⁻ tăng, thường là kiềm chuyển hóa.'},

		{id:'o01',topic:'oxygen',q:'PaCO₂ phản ánh trực tiếp nhất quá trình nào?',o:['Thông khí phế nang','Hàm lượng hemoglobin','Tưới máu thận','Nồng độ lactat'],a:0,e:'PaCO₂ chủ yếu phản ánh mức thông khí phế nang tương đối so với lượng CO₂ cơ thể tạo ra.'},
		{id:'o02',topic:'oxygen',q:'Tại sao cùng một PaO₂ nhưng ý nghĩa có thể rất khác nhau giữa hai người bệnh?',o:['Vì phải biết FiO₂ và hình thức hỗ trợ oxy tại lúc lấy mẫu','Vì PaO₂ chỉ phụ thuộc vào giới tính','Vì PaO₂ không liên quan đến phổi','Vì PaO₂ luôn bằng SpO₂'],a:0,e:'PaO₂ cần được đặt trong bối cảnh FiO₂, áp suất khí quyển và hỗ trợ hô hấp để đánh giá mức suy giảm oxy hóa.'},
		{id:'o03',topic:'oxygen',q:'Chênh áp oxy phế nang–động mạch tăng gợi ý nhiều hơn nhóm cơ chế nào?',o:['Bất tương xứng thông khí/tưới máu, hạn chế khuếch tán hoặc luồng thông','Chỉ giảm FiO₂ đơn thuần','Chỉ giảm thông khí đơn thuần','Chỉ thiếu máu'],a:0,e:'Chênh áp tăng thường phản ánh vấn đề trao đổi khí giữa phế nang và máu, thay vì chỉ giảm oxy hít vào hoặc giảm thông khí thuần túy.'},
		{id:'o04',topic:'oxygen',q:'Tỷ số PaO₂/FiO₂ nên được hiểu như thế nào?',o:['Chỉ số mô tả mức oxy hóa cần đặt trong bối cảnh lâm sàng','Một chẩn đoán độc lập','Một chỉ số chức năng thận','Thước đo trực tiếp thông khí phế nang'],a:0,e:'Tỷ số PaO₂/FiO₂ hữu ích để mô tả và theo dõi oxy hóa nhưng không nên dùng đơn độc để xác lập chẩn đoán.'},
		{id:'o05',topic:'oxygen',q:'PaO₂ bình thường có đảm bảo hàm lượng oxy động mạch luôn bình thường không?',o:['Có','Không, còn phụ thuộc hemoglobin và độ bão hòa oxy','Chỉ phụ thuộc natri','Chỉ phụ thuộc pH'],a:1,e:'Phần lớn oxy được vận chuyển gắn với hemoglobin. Thiếu máu nặng hoặc rối loạn hemoglobin có thể làm vận chuyển oxy bất thường dù PaO₂ bình thường.'},
		{id:'o06',topic:'oxygen',q:'Giảm thông khí phế nang thường làm PaCO₂ thay đổi theo hướng nào?',o:['Tăng','Giảm','Luôn bằng 40 mmHg','Không liên quan'],a:0,e:'Khi thải CO₂ không đủ so với lượng tạo ra, PaCO₂ tăng.'},
		{id:'o07',topic:'oxygen',q:'Khi nghi ngộ độc carbon monoxit, xét nghiệm nào giúp đánh giá trực tiếp carboxyhemoglobin?',o:['Đồng oxy kế','Chỉ PaO₂','Chỉ SpO₂','Chỉ HCO₃⁻'],a:0,e:'Đồng oxy kế có thể phân biệt các dạng hemoglobin và định lượng carboxyhemoglobin; PaO₂ chỉ phản ánh oxy hòa tan.'},
		{id:'o08',topic:'oxygen',q:'Trong người bệnh đang thở máy, dữ kiện nào cần đọc cùng PaO₂?',o:['FiO₂ và mức áp lực dương cuối thì thở ra','Chỉ nhiệt độ cơ thể','Chỉ natri máu','Chỉ nhịp tim'],a:0,e:'Mức oxy hóa trên thở máy phải được đọc cùng FiO₂ và hỗ trợ áp lực dương để hiểu mức độ rối loạn trao đổi khí.'},

		{id:'c01',topic:'clinical',q:'Người bệnh dùng thuốc ức chế SGLT2 có buồn nôn, thở nhanh, ceton tăng, HCO₃⁻ thấp nhưng glucose chỉ tăng vừa. Điều nào đúng nhất?',o:['Glucose không quá cao không loại trừ nhiễm toan ceton','Có thể bỏ qua ceton','Chỉ cần đọc glucose','Không cần phân tích toan–kiềm'],a:0,e:'Nhiễm toan ceton liên quan thuốc ức chế SGLT2 có thể xảy ra khi glucose không tăng rất cao; cần đánh giá trực tiếp ceton và trạng thái toan–kiềm.'},
		{id:'c02',topic:'clinical',q:'Người bệnh COPD đợt cấp có pH thấp và PaCO₂ tăng rõ. Bước quan trọng tiếp theo là gì?',o:['Đánh giá HCO₃⁻ và khí máu nền nếu có để ước tính thành phần cấp/mạn','Chỉ nhìn PaO₂','Bỏ qua pH','Chỉ tính khoảng trống anion'],a:0,e:'HCO₃⁻ và kết quả nền giúp phân biệt tăng CO₂ cấp với tình trạng tăng mạn có bù hoặc cấp trên nền mạn.'},
		{id:'c03',topic:'clinical',q:'Người bệnh dùng opioid giảm tri giác, pH thấp và PaCO₂ tăng. Cơ chế khí máu phù hợp nhất là gì?',o:['Giảm thông khí gây toan hô hấp','Tăng thông khí gây kiềm hô hấp','Mất bicarbonat qua ruột','Kiềm chuyển hóa do nôn'],a:0,e:'Ức chế trung tâm hô hấp làm giảm thông khí phế nang, giữ CO₂ và gây toan hô hấp.'},
		{id:'c04',topic:'clinical',q:'Trong sốc nhiễm trùng có lactat tăng, cách đọc lactat phù hợp nhất là gì?',o:['Đặt trong bối cảnh tưới máu và theo dõi xu hướng theo thời gian','Dùng một giá trị để xác định toàn bộ mức độ nặng','Bỏ qua khí máu','Luôn đồng nghĩa với một nguyên nhân duy nhất'],a:0,e:'Lactat có nhiều cơ chế tăng; giá trị và xu hướng cần được đặt cùng huyết động, bệnh cảnh và các chỉ số khác.'},
		{id:'c05',topic:'clinical',q:'Nôn kéo dài thường gợi ý kiểu rối loạn toan–kiềm nào?',o:['Kiềm chuyển hóa','Toan chuyển hóa tăng khoảng trống anion','Toan hô hấp','Kiềm hô hấp nguyên phát'],a:0,e:'Mất acid dạ dày và clorid có thể gây kiềm chuyển hóa, thường kèm hạ clorid và hạ kali.'},
		{id:'c06',topic:'clinical',q:'Tiêu chảy nhiều ngày thường gây kiểu toan chuyển hóa nào?',o:['Toan chuyển hóa không tăng khoảng trống anion','Toan chuyển hóa tăng khoảng trống anion bắt buộc','Kiềm chuyển hóa','Toan hô hấp'],a:0,e:'Mất bicarbonat qua đường tiêu hóa thường gây toan chuyển hóa tăng clorid với khoảng trống anion không tăng.'},
		{id:'c07',topic:'clinical',q:'Người bệnh phơi nhiễm khói trong không gian kín có PaO₂ bình thường nhưng triệu chứng thần kinh. Điều gì cần được nhớ?',o:['PaO₂ bình thường không loại trừ ngộ độc carbon monoxit','PaO₂ bình thường loại trừ mọi vấn đề oxy','Chỉ cần SpO₂','Không cần hỏi bệnh sử phơi nhiễm'],a:0,e:'Carbon monoxit làm giảm khả năng vận chuyển oxy của hemoglobin trong khi PaO₂ hòa tan có thể vẫn bình thường.'},
		{id:'c08',topic:'clinical',q:'Khi một kết quả PaO₂ rất bất thường nhưng không phù hợp với SpO₂ và tình trạng người bệnh, bước đầu tiên nên là gì?',o:['Kiểm tra chất lượng mẫu, bọt khí và bối cảnh lấy mẫu','Chẩn đoán ngay luồng thông hiếm gặp','Bỏ qua tất cả dữ liệu còn lại','Chỉ lặp lại công thức Winter'],a:0,e:'Sự không phù hợp giữa kết quả và lâm sàng là dấu hiệu phải xem xét sai số tiền phân tích trước khi suy luận bệnh lý phức tạp.'}
	];

	var LEARNING_CARDS = [
		{id:'fc01',topic:'foundation',front:'Ba thông số mở đầu khi đọc toan–kiềm?',back:'pH, PaCO₂ và HCO₃⁻.'},
		{id:'fc02',topic:'foundation',front:'Phổi điều chỉnh biến số nào trực tiếp?',back:'PaCO₂ thông qua thông khí phế nang.'},
		{id:'fc03',topic:'foundation',front:'Thận đáp ứng nhanh hay chậm hơn phổi?',back:'Chậm hơn; đáp ứng đầy đủ thường cần nhiều giờ đến vài ngày.'},
		{id:'fc04',topic:'foundation',front:'Một pH gần bình thường có loại trừ rối loạn phối hợp?',back:'Không. Hai quá trình đối nghịch có thể kéo pH về gần khoảng tham chiếu.'},
		{id:'fc05',topic:'foundation',front:'Khi khí máu không phù hợp lâm sàng, nhớ kiểm tra gì trước?',back:'Chất lượng mẫu, thời điểm lấy, FiO₂ và hình thức hỗ trợ hô hấp.'},
		{id:'fc06',topic:'acidbase',front:'Công thức Winter',back:'PaCO₂ dự kiến ≈ 1,5 × HCO₃⁻ + 8 ± 2 mmHg.'},
		{id:'fc07',topic:'acidbase',front:'PaCO₂ cao hơn mức Winter dự kiến gợi ý gì?',back:'Có thêm toan hô hấp.'},
		{id:'fc08',topic:'acidbase',front:'PaCO₂ thấp hơn mức Winter dự kiến gợi ý gì?',back:'Có thêm kiềm hô hấp.'},
		{id:'fc09',topic:'acidbase',front:'Albumin thấp ảnh hưởng khoảng trống anion ra sao?',back:'Có thể làm khoảng trống anion thấp giả và che mức tăng thật sự; cần cân nhắc hiệu chỉnh.'},
		{id:'fc10',topic:'acidbase',front:'HCO₃⁻ tăng nhiều trong tăng PaCO₂ kéo dài gợi ý gì?',back:'Đáp ứng thận của toan hô hấp mạn hoặc thành phần mạn.'},
		{id:'fc11',topic:'oxygen',front:'PaCO₂ phản ánh trục nào?',back:'Thông khí phế nang, không phải trực tiếp oxy hóa máu.'},
		{id:'fc12',topic:'oxygen',front:'PaO₂ phải luôn đọc cùng dữ kiện nào?',back:'FiO₂ và bối cảnh hỗ trợ oxy/thông khí tại thời điểm lấy mẫu.'},
		{id:'fc13',topic:'oxygen',front:'Tỷ số PaO₂/FiO₂ là chẩn đoán hay chỉ số mô tả?',back:'Là chỉ số mô tả mức oxy hóa; không phải chẩn đoán độc lập.'},
		{id:'fc14',topic:'oxygen',front:'PaO₂ bình thường có bảo đảm vận chuyển oxy bình thường?',back:'Không. Hemoglobin, độ bão hòa oxy và dạng hemoglobin cũng quyết định hàm lượng oxy.'},
		{id:'fc15',topic:'oxygen',front:'Đồng oxy kế hữu ích khi nghi gì?',back:'Rối loạn dạng hemoglobin như carboxyhemoglobin hoặc methemoglobin.'},
		{id:'fc16',topic:'clinical',front:'Thuốc ức chế SGLT2 và ceton tăng nhưng glucose không quá cao?',back:'Vẫn phải nghĩ đến nhiễm toan ceton và đánh giá trực tiếp trạng thái toan–kiềm.'},
		{id:'fc17',topic:'clinical',front:'COPD đợt cấp + PaCO₂ tăng: cần thêm dữ kiện nào để đánh giá cấp/mạn?',back:'pH, HCO₃⁻ và khí máu nền nếu có.'},
		{id:'fc18',topic:'clinical',front:'Nôn kéo dài thường gây rối loạn nào?',back:'Kiềm chuyển hóa, thường kèm giảm clorid và kali.'},
		{id:'fc19',topic:'clinical',front:'Tiêu chảy thường gây rối loạn nào?',back:'Toan chuyển hóa không tăng khoảng trống anion do mất bicarbonat.'},
		{id:'fc20',topic:'clinical',front:'PaO₂ bình thường sau phơi nhiễm khói có loại trừ ngộ độc carbon monoxit?',back:'Không. Cần bối cảnh phơi nhiễm và đồng oxy kế khi phù hợp.'}
	];

	function learningTopicName(topic) {
		return {foundation:'Nền tảng',acidbase:'Rối loạn toan–kiềm',oxygen:'Oxy hóa máu',clinical:'Tình huống lâm sàng'}[topic] || 'Ôn tập';
	}

	/* v3.1 — Tab Lý thuyết: một bài mở, các bài còn lại ở dạng tiêu đề accordion. */
	function setupHandbookAccordion(root, stickyScroll) {
		var theory = root.querySelector('[data-workspace-panel="theory"]');
		if (!theory || theory.dataset.handbookAccordionReady === '1') return null;
		theory.dataset.handbookAccordionReady = '1';

		var content = theory.querySelector('.nah-abg__handbook-content');
		var toc = theory.querySelector('.nah-abg__handbook-toc');
		if (!content) return null;

		/* Mục lục chỉ mở một nhóm mặc định để không kéo chiều cao trang. */
		if (toc && toc.dataset.compactReady !== '1') {
			toc.dataset.compactReady = '1';
			var rawChildren = Array.prototype.slice.call(toc.children);
			toc.innerHTML = '';
			var tocLabel = document.createElement('div');
			tocLabel.className = 'nah-abg__handbook-toc-label';
			tocLabel.textContent = 'Mục lục sổ tay';
			toc.appendChild(tocLabel);
			var currentBody = null;
			var groupCount = 0;
			rawChildren.forEach(function (node) {
				if (node.tagName === 'STRONG') {
					var group = document.createElement('details');
					group.className = 'nah-abg__toc-accordion';
					group.open = groupCount === 0;
					var summary = document.createElement('summary');
					summary.textContent = node.textContent.trim();
					var body = document.createElement('div');
					body.className = 'nah-abg__toc-links';
					group.appendChild(summary);
					group.appendChild(body);
					toc.appendChild(group);
					currentBody = body;
					groupCount++;
					return;
				}
				if (node.tagName === 'A') {
					if (!currentBody) {
						var fallback = document.createElement('div');
						fallback.className = 'nah-abg__toc-links';
						toc.appendChild(fallback);
						currentBody = fallback;
					}
					currentBody.appendChild(node);
				}
			});
		}

		var sourceCards = Array.prototype.slice.call(content.children).filter(function (node) {
			return node.classList && node.classList.contains('nah-abg__handbook-card');
		});
		var items = [];

		sourceCards.forEach(function (card, index) {
			var number = card.querySelector('.nah-abg__handbook-number');
			var heading = card.querySelector('h3');
			if (!heading) return;

			var details = document.createElement('details');
			Array.prototype.slice.call(card.attributes).forEach(function (attr) {
				details.setAttribute(attr.name, attr.value);
			});
			details.classList.add('nah-abg__handbook-accordion');
			details.open = index === 0;

			var summary = document.createElement('summary');
			summary.className = 'nah-abg__handbook-accordion-summary';
			var numberSpan = document.createElement('span');
			numberSpan.className = 'nah-abg__handbook-number';
			numberSpan.textContent = number ? number.textContent.trim() : String(index + 1);
			var titleSpan = document.createElement('span');
			titleSpan.className = 'nah-abg__handbook-accordion-title';
			titleSpan.textContent = heading.textContent.trim();
			var chevron = document.createElement('span');
			chevron.className = 'nah-abg__handbook-accordion-chevron';
			chevron.setAttribute('aria-hidden', 'true');
			summary.appendChild(numberSpan);
			summary.appendChild(titleSpan);
			summary.appendChild(chevron);

			var body = document.createElement('div');
			body.className = 'nah-abg__handbook-accordion-body';
			Array.prototype.slice.call(card.children).forEach(function (child) {
				if (child === number || child === heading) return;
				body.appendChild(child);
			});

			details.appendChild(summary);
			details.appendChild(body);
			card.parentNode.replaceChild(details, card);
			items.push(details);
		});

		items.forEach(function (item) {
			item.addEventListener('toggle', function () {
				if (!item.open) return;
				items.forEach(function (other) {
					if (other !== item && other.open) other.open = false;
				});
				if (item.id && typeof window.CustomEvent === 'function') {
					var titleNode=item.querySelector('.nah-abg__handbook-accordion-title');
					root.dispatchEvent(new CustomEvent('medipharm-abg-theory-open',{detail:{id:item.id,title:titleNode?titleNode.textContent:''}}));
				}
			});
		});

		function openTarget(target, shouldScroll) {
			if (!target) return;
			var item = target.classList && target.classList.contains('nah-abg__handbook-accordion') ? target : target.closest('.nah-abg__handbook-accordion');
			if (!item) return;
			items.forEach(function (other) { if (other !== item) other.open = false; });
			item.open = true;

			if (toc && item.id) {
				var links = Array.prototype.slice.call(toc.querySelectorAll('a[href]'));
				var link = links.find(function (candidate) { return candidate.getAttribute('href') === '#' + item.id; });
				var tocGroup = link ? link.closest('.nah-abg__toc-accordion') : null;
				if (tocGroup) tocGroup.open = true;
			}
			if (shouldScroll !== false) {
				window.requestAnimationFrame(function () {
					if (typeof stickyScroll === 'function') stickyScroll(item);
					else item.scrollIntoView({ behavior: 'smooth', block: 'start' });
				});
			}
		}

		if (toc) {
			toc.querySelectorAll('a[href^="#"]').forEach(function (link) {
				link.addEventListener('click', function (event) {
					var selector = link.getAttribute('href');
					if (!selector || selector.length < 2) return;
					var target = root.querySelector(selector);
					if (!target) return;
					event.preventDefault();
					openTarget(target, true);
					if (window.history && window.history.replaceState) {
						window.history.replaceState(null, '', selector);
					}
				});
			});
		}

		function openHash() {
			var hash = window.location.hash;
			if (!hash || hash.length < 2) return;
			var target = null;
			try { target = root.querySelector(hash); } catch (error) {}
			if (target) openTarget(target, false);
		}
		openHash();
		window.addEventListener('hashchange', openHash);

		return { open: openTarget, items: items };
	}

	/* v3.3 — Thử thách ca lâm sàng. */
	var CASE_CHALLENGES = [
		{id:'ch-dka',level:'basic',title:'Nhiễm toan ceton do đái tháo đường',topic:'acidbase',intro:'pH 7,20; PaCO₂ 24 mmHg; HCO₃⁻ 10 mmol/L; Na⁺ 138 mmol/L; Cl⁻ 102 mmol/L.',steps:[
			{q:'Bước 1 · Trạng thái pH là gì?',o:['Toan máu','Kiềm máu','Trong khoảng tham chiếu'],a:0,e:'pH 7,20 cho thấy toan máu.'},
			{q:'Bước 2 · Rối loạn nguyên phát?',o:['Toan chuyển hóa','Toan hô hấp','Kiềm chuyển hóa','Kiềm hô hấp'],a:0,e:'HCO₃⁻ giảm cùng chiều với pH, phù hợp toan chuyển hóa nguyên phát.'},
			{q:'Bước 3 · PaCO₂ 24 mmHg có phù hợp đáp ứng hô hấp?',o:['Có, gần mức dự kiến theo công thức Winter','Không, gợi ý thêm toan hô hấp','Không thể đánh giá'],a:0,e:'PaCO₂ dự kiến ≈ 1,5 × 10 + 8 = 23 ± 2 mmHg.'},
			{q:'Bước 4 · Khoảng trống anion có tăng?',o:['Có','Không','Không thể tính'],a:0,e:'Khoảng trống anion = 138 − (102 + 10) = 26 mmol/L, tăng rõ.'}]},
		{id:'ch-copd',level:'basic',title:'COPD đợt cấp và tăng CO₂',topic:'acidbase',intro:'pH 7,28; PaCO₂ 68 mmHg; HCO₃⁻ 31 mmol/L.',steps:[
			{q:'Bước 1 · Trạng thái pH?',o:['Toan máu','Kiềm máu','Bình thường'],a:0,e:'pH 7,28 cho thấy toan máu.'},
			{q:'Bước 2 · Rối loạn nguyên phát?',o:['Toan hô hấp','Toan chuyển hóa','Kiềm hô hấp','Kiềm chuyển hóa'],a:0,e:'PaCO₂ tăng theo hướng làm giảm pH, phù hợp toan hô hấp.'},
			{q:'Bước 3 · HCO₃⁻ tăng gợi ý điều gì?',o:['Có đáp ứng của thận; cần nghĩ tăng CO₂ mạn hoặc cấp trên nền mạn','Chắc chắn kiềm chuyển hóa nguyên phát','Không có ý nghĩa'],a:0,e:'HCO₃⁻ tăng cho thấy đã có đáp ứng chuyển hóa.'},
			{q:'Bước 4 · Dữ kiện nào hữu ích để phân biệt cấp và mạn?',o:['Khí máu nền trước đó và diễn biến lâm sàng','Chỉ PaO₂ hiện tại','Chỉ natri máu'],a:0,e:'Kết quả nền và diễn biến giúp đánh giá mức thích nghi trước đó.'}]},
		{id:'ch-opioid',level:'basic',title:'Opioid và giảm thông khí',topic:'oxygen',intro:'pH 7,24; PaCO₂ 64 mmHg; HCO₃⁻ 27 mmol/L; PaO₂ 58 mmHg khi thở khí phòng.',steps:[
			{q:'Bước 1 · Rối loạn chính?',o:['Toan hô hấp','Toan chuyển hóa','Kiềm hô hấp'],a:0,e:'pH thấp kèm PaCO₂ tăng xác định toan hô hấp.'},
			{q:'Bước 2 · Cơ chế phù hợp nhất?',o:['Giảm thông khí phế nang','Tăng thông khí phế nang','Mất bicarbonat'],a:0,e:'Opioid có thể làm giảm thông khí và giữ CO₂.'},
			{q:'Bước 3 · PaO₂ giảm có thể liên quan trực tiếp tới?',o:['Giảm thông khí','Tăng hemoglobin','Kiềm chuyển hóa'],a:0,e:'Giảm thông khí làm giảm oxy phế nang và PaO₂.'},
			{q:'Bước 4 · Cần xác nhận thêm khi đọc PaO₂?',o:['FiO₂ hoặc hỗ trợ oxy lúc lấy mẫu','Chỉ glucose','Chỉ kali'],a:0,e:'PaO₂ phải được đặt trong bối cảnh FiO₂ và hỗ trợ hô hấp.'}]},
		{id:'ch-vomit',level:'intermediate',title:'Nôn kéo dài và kiềm chuyển hóa',topic:'acidbase',intro:'pH 7,51; PaCO₂ 48 mmHg; HCO₃⁻ 37 mmol/L; clorid giảm.',steps:[
			{q:'Bước 1 · Rối loạn nguyên phát?',o:['Kiềm chuyển hóa','Kiềm hô hấp','Toan chuyển hóa'],a:0,e:'pH tăng và HCO₃⁻ tăng phù hợp kiềm chuyển hóa.'},
			{q:'Bước 2 · PaCO₂ tăng có thể là gì?',o:['Đáp ứng hô hấp theo hướng giảm thông khí','Kiềm hô hấp phối hợp','Không liên quan'],a:0,e:'Trong kiềm chuyển hóa, PaCO₂ thường tăng theo hướng bù.'},
			{q:'Bước 3 · Nôn kéo dài hỗ trợ cơ chế nào?',o:['Mất acid dạ dày và clorid','Mất bicarbonat qua ruột','Ức chế hô hấp'],a:0,e:'Mất acid dạ dày và clorid là cơ chế thường gặp.'},
			{q:'Bước 4 · Điểm dễ nhầm?',o:['Không gọi PaCO₂ tăng là toan hô hấp nếu vẫn phù hợp mức đáp ứng dự kiến','Bỏ qua pH'],a:0,e:'Cần so với mức đáp ứng dự kiến trước khi kết luận rối loạn phối hợp.'}]},
		{id:'ch-salicylate',level:'intermediate',title:'Salicylat và rối loạn phối hợp',topic:'acidbase',intro:'pH 7,46; PaCO₂ 21 mmHg; HCO₃⁻ 15 mmol/L.',steps:[
			{q:'Bước 1 · pH hơi kiềm có loại trừ toan chuyển hóa?',o:['Không','Có'],a:0,e:'Rối loạn phối hợp có thể làm pH gần bình thường hoặc hơi kiềm.'},
			{q:'Bước 2 · PaCO₂ rất thấp gợi ý?',o:['Kiềm hô hấp','Toan hô hấp','Kiềm chuyển hóa'],a:0,e:'PaCO₂ thấp mạnh phù hợp kiềm hô hấp.'},
			{q:'Bước 3 · HCO₃⁻ thấp sâu nên làm gì?',o:['So với mức dự kiến; có thể gợi ý thêm toan chuyển hóa','Luôn coi là bù bình thường'],a:0,e:'HCO₃⁻ thấp hơn dự kiến gợi ý thêm toan chuyển hóa.'},
			{q:'Bước 4 · Mẫu hình kinh điển?',o:['Kiềm hô hấp phối hợp toan chuyển hóa','Toan hô hấp đơn thuần'],a:0,e:'Salicylat có thể gây đồng thời hai quá trình này.'}]},
		{id:'ch-hypox',level:'intermediate',title:'Giảm oxy máu và tăng thông khí',topic:'oxygen',intro:'Thở khí phòng: pH 7,48; PaCO₂ 31 mmHg; PaO₂ 55 mmHg; HCO₃⁻ 23 mmol/L.',steps:[
			{q:'Bước 1 · Rối loạn toan–kiềm chính?',o:['Kiềm hô hấp','Kiềm chuyển hóa','Toan hô hấp'],a:0,e:'pH tăng kèm PaCO₂ giảm phù hợp kiềm hô hấp.'},
			{q:'Bước 2 · PaO₂ 55 mmHg cho biết?',o:['Có giảm oxy máu','Oxy hóa bình thường','Không thể đánh giá'],a:0,e:'PaO₂ giảm rõ khi thở khí phòng.'},
			{q:'Bước 3 · Chênh áp oxy phế nang–động mạch giúp định hướng?',o:['Cơ chế giảm oxy máu','Loại toan chuyển hóa','Tình trạng thiếu máu'],a:0,e:'Chênh áp giúp định hướng giảm thông khí/FiO₂ thấp so với bất thường trao đổi khí.'},
			{q:'Bước 4 · Kết luận tích hợp?',o:['Kiềm hô hấp kèm giảm oxy máu cần tìm cơ chế trao đổi khí','Chỉ có kiềm hô hấp'],a:0,e:'Phân tích toan–kiềm và oxy hóa cần được tích hợp.'}]},
		{id:'ch-mixed',level:'advanced',title:'Toan chuyển hóa tăng khoảng trống anion kèm kiềm chuyển hóa',topic:'acidbase',intro:'pH 7,32; PaCO₂ 34 mmHg; HCO₃⁻ 17 mmol/L; Na⁺ 140 mmol/L; Cl⁻ 96 mmol/L.',steps:[
			{q:'Bước 1 · Rối loạn nguyên phát?',o:['Toan chuyển hóa','Toan hô hấp','Kiềm chuyển hóa'],a:0,e:'pH thấp và HCO₃⁻ thấp xác định toan chuyển hóa.'},
			{q:'Bước 2 · Khoảng trống anion?',o:['27 mmol/L','17 mmol/L','10 mmol/L'],a:0,e:'140 − (96 + 17) = 27 mmol/L.'},
			{q:'Bước 3 · Độ tăng khoảng trống anion lớn hơn độ giảm HCO₃⁻ gợi ý?',o:['Có thể thêm kiềm chuyển hóa','Có thêm toan hô hấp','Không phối hợp'],a:0,e:'Mẫu hình này có thể gợi ý thêm kiềm chuyển hóa.'},
			{q:'Bước 4 · Vì sao không chỉ nhìn pH?',o:['pH là kết quả tổng hợp và có thể che nhiều quá trình','pH không liên quan'],a:0,e:'Rối loạn phối hợp có thể kéo pH về gần khoảng tham chiếu.'}]},
		{id:'ch-vent',level:'advanced',title:'Giảm oxy máu khi thở máy',topic:'oxygen',intro:'FiO₂ 0,60; PaO₂ 72 mmHg; PaCO₂ 40 mmHg; áp lực dương cuối thì thở ra 10 cmH₂O.',steps:[
			{q:'Bước 1 · Tỷ số PaO₂/FiO₂ xấp xỉ?',o:['120','72','432'],a:0,e:'72 / 0,60 ≈ 120.'},
			{q:'Bước 2 · PaO₂ 72 mmHg có thể coi gần bình thường?',o:['Không, vì đang cần FiO₂ 0,60','Có'],a:0,e:'PaO₂ cần được đọc cùng FiO₂.'},
			{q:'Bước 3 · Áp lực dương cuối thì thở ra có vai trò?',o:['Cho biết mức hỗ trợ đi kèm chỉ số oxy hóa','Không liên quan'],a:0,e:'Mức hỗ trợ áp lực dương là một phần của bối cảnh oxy hóa.'},
			{q:'Bước 4 · Tỷ số PaO₂/FiO₂ tự xác lập chẩn đoán?',o:['Không, phải tích hợp bệnh cảnh và tiêu chuẩn khác','Có'],a:0,e:'Tỷ số này mô tả mức oxy hóa nhưng không nên dùng đơn độc.'}]},
		{id:'ch-co',level:'advanced',title:'Ngộ độc carbon monoxit',topic:'oxygen',intro:'Đau đầu sau phơi nhiễm khói. SpO₂ 98%, PaO₂ 96 mmHg nhưng bệnh cảnh vẫn gợi ý ngộ độc carbon monoxit.',steps:[
			{q:'Bước 1 · PaO₂ bình thường có loại trừ?',o:['Không','Có'],a:0,e:'PaO₂ phản ánh oxy hòa tan, không đo hemoglobin bị carbon monoxit chiếm chỗ.'},
			{q:'Bước 2 · SpO₂ bình thường có đủ loại trừ?',o:['Không','Có'],a:0,e:'Máy đo thông thường có thể không phân biệt chính xác carboxyhemoglobin.'},
			{q:'Bước 3 · Xét nghiệm hữu ích?',o:['Đồng oxy kế','Chỉ bicarbonat','Chỉ natri'],a:0,e:'Đồng oxy kế giúp định lượng carboxyhemoglobin.'},
			{q:'Bước 4 · Bài học chính?',o:['Không đồng nhất PaO₂ với khả năng vận chuyển oxy của hemoglobin','PaO₂ phản ánh đầy đủ vận chuyển oxy'],a:0,e:'Vận chuyển oxy phụ thuộc hemoglobin và dạng hemoglobin, không chỉ PaO₂.'}]}
	];


	/* v3.4 — Rối loạn phối hợp chuyên sâu. */
	var MIXED_DISORDER_CASES = [
		{id:'mx01',title:'Toan chuyển hóa kèm kiềm hô hấp',intro:'pH 7,37; PaCO₂ 20 mmHg; HCO₃⁻ 12 mmol/L.',steps:[
			{q:'Rối loạn nguyên phát nổi bật là gì?',o:['Toan chuyển hóa','Toan hô hấp','Kiềm chuyển hóa'],a:0,e:'HCO₃⁻ giảm rõ và pH không kiềm mạnh, phù hợp một quá trình toan chuyển hóa.'},
			{q:'PaCO₂ dự kiến theo công thức Winter xấp xỉ bao nhiêu?',o:['26 ± 2 mmHg','40 ± 2 mmHg','12 ± 2 mmHg'],a:0,e:'1,5 × 12 + 8 = 26 mmHg, khoảng dự kiến 24–28 mmHg.'},
			{q:'PaCO₂ thực đo 20 mmHg gợi ý điều gì?',o:['Có thêm kiềm hô hấp','Có thêm toan hô hấp','Đáp ứng bù phù hợp'],a:0,e:'PaCO₂ thấp hơn rõ mức dự kiến, gợi ý thêm một quá trình kiềm hô hấp.'}]},
		{id:'mx02',title:'Toan chuyển hóa kèm toan hô hấp',intro:'pH 7,10; PaCO₂ 34 mmHg; HCO₃⁻ 12 mmol/L.',steps:[
			{q:'Rối loạn chuyển hóa nào đang hiện diện?',o:['Toan chuyển hóa','Kiềm chuyển hóa','Không có rối loạn chuyển hóa'],a:0,e:'HCO₃⁻ giảm sâu trong bối cảnh toan máu phù hợp toan chuyển hóa.'},
			{q:'PaCO₂ dự kiến theo công thức Winter?',o:['26 ± 2 mmHg','34 ± 2 mmHg','46 ± 2 mmHg'],a:0,e:'PaCO₂ dự kiến khoảng 26 ± 2 mmHg.'},
			{q:'PaCO₂ 34 mmHg cao hơn dự kiến cho thấy?',o:['Có thêm toan hô hấp','Có thêm kiềm hô hấp','Bù hoàn toàn bình thường'],a:0,e:'PaCO₂ cao hơn mức đáp ứng dự kiến nghĩa là thông khí không giảm CO₂ đủ, gợi ý thêm toan hô hấp.'}]},
		{id:'mx03',title:'Toan tăng khoảng trống anion kèm kiềm chuyển hóa',intro:'pH 7,32; Na⁺ 140; Cl⁻ 96; HCO₃⁻ 17 mmol/L. Giả định khoảng trống anion tham chiếu 12 mmol/L để minh họa.',steps:[
			{q:'Khoảng trống anion là bao nhiêu?',o:['27 mmol/L','17 mmol/L','10 mmol/L'],a:0,e:'140 − (96 + 17) = 27 mmol/L.'},
			{q:'Độ tăng khoảng trống anion và độ giảm HCO₃⁻ lần lượt xấp xỉ?',o:['15 và 7 mmol/L','7 và 15 mmol/L','15 và 15 mmol/L'],a:0,e:'Δ khoảng trống anion ≈ 27 − 12 = 15; Δ HCO₃⁻ ≈ 24 − 17 = 7 mmol/L.'},
			{q:'Khoảng trống anion tăng nhiều hơn mức giảm HCO₃⁻ gợi ý?',o:['Có thể thêm kiềm chuyển hóa','Có thể thêm toan tăng clo','Chỉ có toan hô hấp'],a:0,e:'HCO₃⁻ cao hơn mức dự kiến nếu chỉ có toan tăng khoảng trống anion, vì vậy cần nghĩ thêm một quá trình làm HCO₃⁻ tăng, thường là kiềm chuyển hóa.'}]},
		{id:'mx04',title:'Toan tăng khoảng trống anion kèm toan tăng clo',intro:'pH 7,22; Na⁺ 138; Cl⁻ 108; HCO₃⁻ 12 mmol/L. Giả định khoảng trống anion tham chiếu 12 mmol/L để minh họa.',steps:[
			{q:'Khoảng trống anion là bao nhiêu?',o:['18 mmol/L','30 mmol/L','12 mmol/L'],a:0,e:'138 − (108 + 12) = 18 mmol/L.'},
			{q:'Δ khoảng trống anion so với Δ HCO₃⁻?',o:['6 so với 12 mmol/L','12 so với 6 mmol/L','6 so với 6 mmol/L'],a:0,e:'Δ khoảng trống anion ≈ 6 trong khi HCO₃⁻ giảm khoảng 12 mmol/L.'},
			{q:'HCO₃⁻ giảm nhiều hơn mức tăng khoảng trống anion gợi ý?',o:['Có thể thêm toan chuyển hóa không tăng khoảng trống anion','Có thể thêm kiềm chuyển hóa','Chỉ có kiềm hô hấp'],a:0,e:'Mức giảm HCO₃⁻ lớn hơn phần tăng khoảng trống anion có thể phản ánh thêm một quá trình toan chuyển hóa tăng clo.'}]},
		{id:'mx05',title:'Kiềm chuyển hóa kèm kiềm hô hấp',intro:'pH 7,58; PaCO₂ 30 mmHg; HCO₃⁻ 34 mmol/L.',steps:[
			{q:'Biến đổi chuyển hóa chính?',o:['Kiềm chuyển hóa','Toan chuyển hóa','Không có'],a:0,e:'HCO₃⁻ tăng và pH kiềm cho thấy kiềm chuyển hóa.'},
			{q:'Trong kiềm chuyển hóa đơn thuần, PaCO₂ thường thay đổi theo hướng nào?',o:['Tăng theo hướng giảm thông khí','Giảm mạnh','Không thay đổi'],a:0,e:'Đáp ứng hô hấp của kiềm chuyển hóa thường làm PaCO₂ tăng, không giảm.'},
			{q:'PaCO₂ 30 mmHg trong trường hợp này gợi ý?',o:['Có thêm kiềm hô hấp','Có thêm toan hô hấp','Chỉ là đáp ứng bù'],a:0,e:'PaCO₂ giảm ngược hướng đáp ứng dự kiến, vì vậy có thêm một quá trình kiềm hô hấp.'}]},
		{id:'mx06',title:'Kiềm chuyển hóa kèm toan hô hấp',intro:'pH 7,44; PaCO₂ 62 mmHg; HCO₃⁻ 41 mmol/L.',steps:[
			{q:'HCO₃⁻ 41 mmol/L cho thấy?',o:['Có thành phần kiềm chuyển hóa','Có thành phần toan chuyển hóa','Không liên quan pH'],a:0,e:'HCO₃⁻ tăng mạnh theo hướng kiềm.'},
			{q:'PaCO₂ 62 mmHg cho thấy?',o:['Có thành phần toan hô hấp','Có thành phần kiềm hô hấp','Thông khí bình thường'],a:0,e:'PaCO₂ tăng theo hướng toan hô hấp.'},
			{q:'pH gần khoảng tham chiếu trong bối cảnh cả HCO₃⁻ và PaCO₂ đều tăng mạnh nên được hiểu thế nào?',o:['Có thể là hai quá trình nguyên phát đối nghịch','Loại trừ rối loạn toan–kiềm','Chắc chắn chỉ là bù'],a:0,e:'Hai quá trình đối nghịch có thể kéo pH về gần bình thường; cần đối chiếu mức đáp ứng dự kiến và bệnh cảnh.'}]},
		{id:'mx07',title:'Kiềm hô hấp kèm toan chuyển hóa',intro:'pH 7,45; PaCO₂ 20 mmHg; HCO₃⁻ 13 mmol/L.',steps:[
			{q:'PaCO₂ 20 mmHg gợi ý quá trình nào?',o:['Kiềm hô hấp','Toan hô hấp','Kiềm chuyển hóa'],a:0,e:'PaCO₂ giảm mạnh theo hướng kiềm hô hấp.'},
			{q:'HCO₃⁻ 13 mmol/L có thể chỉ được giải thích bằng thay đổi hô hấp cấp?',o:['Không, thấp sâu và cần nghĩ thêm toan chuyển hóa','Có, luôn là đáp ứng bình thường'],a:0,e:'HCO₃⁻ thấp sâu hơn mức thường gặp trong một kiềm hô hấp cấp đơn thuần.'},
			{q:'Kết luận phù hợp nhất?',o:['Kiềm hô hấp phối hợp toan chuyển hóa','Kiềm hô hấp đơn thuần','Toan hô hấp phối hợp kiềm chuyển hóa'],a:0,e:'Hai biến đổi nguyên phát theo hai hướng đối nghịch giải thích pH gần khoảng tham chiếu.'}]},
		{id:'mx08',title:'Tăng CO₂ mạn kèm kiềm chuyển hóa',intro:'Người bệnh COPD ổn định trước đây có PaCO₂ khoảng 60 mmHg và HCO₃⁻ khoảng 32 mmol/L. Hiện pH 7,47; PaCO₂ 60 mmHg; HCO₃⁻ 42 mmol/L sau nhiều ngày dùng lợi tiểu.',steps:[
			{q:'PaCO₂ 60 mmHg có thể phản ánh điều gì trong bối cảnh này?',o:['Tăng CO₂ mạn đã biết','Kiềm hô hấp cấp','Thông khí hoàn toàn bình thường'],a:0,e:'Dữ liệu nền cho thấy người bệnh vốn đã có tăng CO₂ mạn.'},
			{q:'HCO₃⁻ hiện tại 42 mmol/L cao hơn rõ giá trị nền 32 mmol/L gợi ý?',o:['Có thêm kiềm chuyển hóa','Chỉ là bù hô hấp mạn','Có thêm toan chuyển hóa'],a:0,e:'So sánh với giá trị nền cho thấy bicarbonat tăng thêm ngoài mức thích nghi mạn trước đó.'},
			{q:'Dữ kiện dùng lợi tiểu giúp củng cố nhận định nào?',o:['Kiềm chuyển hóa phối hợp trên nền tăng CO₂ mạn','Toan chuyển hóa tăng khoảng trống anion','Kiềm hô hấp đơn thuần'],a:0,e:'Bệnh cảnh và thay đổi HCO₃⁻ so với nền hỗ trợ một quá trình kiềm chuyển hóa phối hợp.'}]}
	];


	/* v3.5 — Oxy hóa máu và thông khí chuyên sâu. */
	var OXYGEN_VENT_CASES = [
		{id:'ox01',title:'Giảm thông khí do opioid',intro:'Thở khí phòng. FiO₂ 0,21; PaCO₂ 68 mmHg; PaO₂ 58 mmHg. Giả định áp suất khí quyển 760 mmHg và hệ số hô hấp 0,8 để minh họa.',steps:[
			{q:'PaCO₂ 68 mmHg cho thấy điều gì?',o:['Giảm thông khí phế nang rõ','Tăng thông khí phế nang','Không cung cấp thông tin về thông khí'],a:0,e:'PaCO₂ tăng rõ cho thấy thông khí phế nang không đủ so với lượng CO₂ cơ thể sinh ra.'},
			{q:'PAO₂ ước tính gần nhất là bao nhiêu?',o:['Khoảng 65 mmHg','Khoảng 115 mmHg','Khoảng 150 mmHg'],a:0,e:'PAO₂ ≈ 0,21 × 713 − 68/0,8 ≈ 65 mmHg.'},
			{q:'Chênh áp A–a xấp xỉ 7 mmHg gợi ý gì?',o:['Giảm thông khí là cơ chế chính có thể giải thích giảm oxy máu','Có luồng thông trong phổi rất lớn','Bắt buộc có thuyên tắc phổi'],a:0,e:'PAO₂ và PaO₂ cùng giảm, trong khi chênh áp A–a không tăng rõ; mẫu hình phù hợp giảm thông khí đơn thuần hơn là rối loạn trao đổi khí tại phổi.'}]},
		{id:'ox02',title:'Thuyên tắc phổi và mất tương hợp thông khí–tưới máu',intro:'Thở khí phòng. FiO₂ 0,21; PaCO₂ 28 mmHg; PaO₂ 58 mmHg; khó thở đột ngột.',steps:[
			{q:'PaCO₂ thấp trong bối cảnh này phù hợp nhất với?',o:['Tăng thông khí','Giảm thông khí','Ứ CO₂ mạn'],a:0,e:'PaCO₂ 28 mmHg phản ánh tăng thông khí tương đối.'},
			{q:'PAO₂ ước tính gần nhất?',o:['Khoảng 115 mmHg','Khoảng 60 mmHg','Khoảng 40 mmHg'],a:0,e:'PAO₂ ≈ 0,21 × 713 − 28/0,8 ≈ 115 mmHg.'},
			{q:'Chênh áp A–a khoảng 57 mmHg hướng tới cơ chế nào?',o:['Bất thường trao đổi khí, thường là mất tương hợp thông khí–tưới máu trong bệnh cảnh này','Giảm oxy hít vào đơn thuần','Giảm thông khí đơn thuần'],a:0,e:'Chênh áp tăng rõ cho thấy PaO₂ thấp hơn nhiều so với oxy phế nang; với khó thở đột ngột, mất tương hợp thông khí–tưới máu là cơ chế quan trọng cần nghĩ tới.'}]},
		{id:'ox03',title:'Viêm phổi nặng và luồng thông trong phổi',intro:'Đang nhận FiO₂ 0,50. PaCO₂ 32 mmHg; PaO₂ 60 mmHg. Hình ảnh phổi có đông đặc nhiều vùng.',steps:[
			{q:'PaO₂ 60 mmHg khi FiO₂ 0,50 nên được hiểu thế nào?',o:['Giảm oxy máu đáng kể dù đang nhận oxy bổ sung','Oxy hóa bình thường','Không thể diễn giải vì FiO₂ đã biết'],a:0,e:'PaO₂ thấp trong khi FiO₂ cao cho thấy suy giảm trao đổi oxy đáng kể.'},
			{q:'Tỷ số PaO₂/FiO₂ xấp xỉ bao nhiêu?',o:['120','300','600'],a:0,e:'60/0,50 = 120. Cần diễn giải cùng thiết bị hỗ trợ, áp lực đường thở và bệnh cảnh.'},
			{q:'Đông đặc nhiều vùng làm giảm oxy máu chủ yếu theo cơ chế nào?',o:['Luồng thông trong phổi hoặc vùng có thông khí rất thấp so với tưới máu','Giảm oxy hít vào','Giảm thông khí đơn thuần'],a:0,e:'Máu tưới qua các đơn vị phổi không được thông khí hiệu quả tạo mẫu hình giống luồng thông, thường làm giảm oxy máu nặng và đáp ứng với oxy kém hơn.'}]},
		{id:'ox04',title:'COPD đợt cấp: vừa tăng CO₂ vừa giảm oxy máu',intro:'Đang nhận FiO₂ 0,28. pH 7,28; PaCO₂ 64 mmHg; PaO₂ 58 mmHg.',steps:[
			{q:'PaCO₂ 64 mmHg cho thấy?',o:['Có giảm thông khí phế nang','Có tăng thông khí','Không liên quan thông khí'],a:0,e:'PaCO₂ tăng là bằng chứng của thông khí phế nang không đủ so với lượng CO₂ sinh ra.'},
			{q:'Nếu PAO₂ ước tính khoảng 120 mmHg, chênh áp A–a khoảng 62 mmHg gợi ý gì?',o:['Ngoài giảm thông khí còn có bất thường trao đổi khí tại phổi','Giảm thông khí đơn thuần giải thích toàn bộ','PaO₂ chắc chắn sai'],a:0,e:'Chênh áp A–a tăng cho thấy giảm thông khí không phải cơ chế duy nhất; COPD thường có thêm mất tương hợp thông khí–tưới máu.'},
			{q:'Cách kết luận phù hợp nhất?',o:['Đọc đồng thời thông khí và oxy hóa, không quy mọi bất thường cho một cơ chế','Chỉ cần nhìn PaCO₂','Chỉ cần nhìn PaO₂'],a:0,e:'Một người bệnh có thể đồng thời giảm thông khí và rối loạn trao đổi khí, vì vậy PaCO₂ và PaO₂ cần được phân tích theo hai trục.'}]},
		{id:'ox05',title:'Bệnh phổi kẽ và hạn chế khuếch tán',intro:'Thở khí phòng. PaCO₂ 33 mmHg; PaO₂ 63 mmHg lúc nghỉ, giảm thêm khi đi bộ; bệnh phổi kẽ đã được xác định.',steps:[
			{q:'PaCO₂ 33 mmHg có gợi ý giảm thông khí là cơ chế chính không?',o:['Không','Có'],a:0,e:'PaCO₂ không tăng; người bệnh còn có xu hướng tăng thông khí, nên giảm thông khí không phải lời giải chính.'},
			{q:'Giảm oxy rõ hơn khi gắng sức phù hợp với cơ chế nào?',o:['Hạn chế khuếch tán có thể góp phần','Giảm oxy hít vào','Tăng CO₂ do giảm thông khí'],a:0,e:'Khi gắng sức, thời gian tiếp xúc của máu với mao mạch phổi ngắn lại, làm hạn chế khuếch tán biểu hiện rõ hơn.'},
			{q:'Có nên xem hạn chế khuếch tán là cơ chế duy nhất trong mọi bệnh phổi kẽ?',o:['Không, mất tương hợp thông khí–tưới máu cũng có thể góp phần','Có, luôn luôn duy nhất'],a:0,e:'Các cơ chế có thể cùng tồn tại; khí máu định hướng sinh lý nhưng không thay thế đánh giá bệnh phổi toàn diện.'}]},
		{id:'ox06',title:'Suy hô hấp giảm oxy máu nặng khi thở FiO₂ cao',intro:'Đang thông khí hỗ trợ với FiO₂ 0,80. PaO₂ 60 mmHg; PaCO₂ 38 mmHg.',steps:[
			{q:'Tỷ số PaO₂/FiO₂ là bao nhiêu?',o:['75','160','480'],a:0,e:'60/0,80 = 75, cho thấy suy giảm oxy hóa rất nặng trong bối cảnh FiO₂ đã biết.'},
			{q:'PaCO₂ 38 mmHg có loại trừ suy hô hấp nặng không?',o:['Không','Có'],a:0,e:'Thông khí CO₂ và oxy hóa là hai trục khác nhau. PaCO₂ bình thường không loại trừ giảm oxy máu nặng.'},
			{q:'Cơ chế nên ưu tiên nghĩ tới khi PaO₂ vẫn thấp dù FiO₂ cao?',o:['Luồng thông trong phổi hoặc mất tương hợp thông khí–tưới máu rất nặng','Giảm oxy hít vào','Giảm thông khí đơn thuần'],a:0,e:'Khi oxy hít vào đã cao mà PaO₂ vẫn thấp, cần nghĩ tới rối loạn trao đổi khí nặng, đặc biệt vùng phổi không được thông khí hiệu quả.'}]},
		{id:'ox07',title:'Ngộ độc carbon monoxit với PaO₂ bình thường',intro:'Sau phơi nhiễm khói kín, đau đầu và lú lẫn. PaO₂ 98 mmHg; SpO₂ 99% trên máy đo thông thường.',steps:[
			{q:'PaO₂ 98 mmHg có loại trừ rối loạn vận chuyển oxy do carbon monoxit không?',o:['Không','Có'],a:0,e:'PaO₂ phản ánh oxy hòa tan trong huyết tương chứ không đo lượng hemoglobin bị carbon monoxit chiếm chỗ.'},
			{q:'SpO₂ thông thường có thể gây yên tâm giả trong tình huống này không?',o:['Có','Không'],a:0,e:'Máy đo độ bão hòa thông thường không định lượng chính xác carboxyhemoglobin.'},
			{q:'Xét nghiệm thích hợp để đánh giá các dạng hemoglobin bất thường?',o:['Đồng oxy kế','Chỉ đo PaO₂ lặp lại','Chỉ tính chênh áp A–a'],a:0,e:'Đồng oxy kế giúp phân biệt và định lượng các dạng hemoglobin như carboxyhemoglobin.'}]},
		{id:'ox08',title:'Methemoglobin và chênh lệch độ bão hòa oxy',intro:'Tím tái sau dùng thuốc oxy hóa. SpO₂ khoảng 85% dai dẳng; PaO₂ 100 mmHg.',steps:[
			{q:'PaO₂ bình thường nhưng SpO₂ thấp dai dẳng nên gợi ý gì?',o:['Cần nghĩ tới hemoglobin bất thường khi bệnh cảnh phù hợp','Chắc chắn giảm thông khí','Chắc chắn FiO₂ thấp'],a:0,e:'PaO₂ bình thường cho thấy oxy hòa tan vẫn đủ, trong khi độ bão hòa bất thường gợi ý vấn đề ở hemoglobin hoặc phép đo.'},
			{q:'Công cụ nào hữu ích để xác định methemoglobin?',o:['Đồng oxy kế','Chỉ phương trình khí phế nang','Chỉ tỷ số PaO₂/FiO₂'],a:0,e:'Đồng oxy kế có thể định lượng methemoglobin và các dạng hemoglobin khác.'},
			{q:'Bài học chính của ca này?',o:['Không đồng nhất PaO₂ với khả năng vận chuyển oxy của hemoglobin','PaO₂ luôn phản ánh đầy đủ oxy mô'],a:0,e:'Khả năng vận chuyển oxy phụ thuộc hemoglobin, độ bão hòa thực và cung lượng tim, không chỉ oxy hòa tan.'}]}
	];


	/* v3.6 — Chất lượng mẫu và an toàn tiền phân tích. */
	var SAMPLING_SAFETY_CASES = [
		{id:'ps01',title:'Bọt khí trong bơm tiêm',intro:'Mẫu động mạch có bọt khí nhìn thấy. SpO₂ 88% nhưng PaO₂ trả về 112 mmHg; PaCO₂ thấp hơn dự kiến.',steps:[
			{q:'Việc cần làm trước tiên là gì?',o:['Đánh giá độ tin cậy của mẫu trước khi diễn giải sinh lý bệnh','Kết luận oxy hóa đã cải thiện','Tính ngay chênh áp A–a'],a:0,e:'Không khí tiếp xúc với máu có thể làm thay đổi PaO₂ và PaCO₂. Khi mẫu có bọt khí đáng kể, độ tin cậy của phép đo phải được đặt câu hỏi trước.'},
			{q:'Bọt khí có thể làm PaO₂ thay đổi theo hướng nào?',o:['Dịch về áp suất oxy của khí phòng, nên có thể tăng hoặc giảm tùy PaO₂ ban đầu','Luôn giảm','Luôn tăng'],a:0,e:'Hướng sai lệch của PaO₂ phụ thuộc giá trị ban đầu và mức trao đổi với không khí; vì vậy không thể áp dụng một hiệu chỉnh cố định.'},
			{q:'Cách xử trí dữ liệu phù hợp nhất?',o:['Nếu chất lượng mẫu không bảo đảm, lấy lại mẫu đúng kỹ thuật','Tự trừ một lượng PaO₂ ước tính','Chấp nhận nếu pH gần bình thường'],a:0,e:'Không nên sửa kết quả bằng suy đoán. Một mẫu mới, không bọt khí và được xử lý đúng thường đáng tin cậy hơn.'}]},
		{id:'ps02',title:'Heparin lỏng dư và mẫu thể tích nhỏ',intro:'Mẫu lấy được rất ít máu trong bơm tiêm có sẵn một lượng heparin lỏng tương đối lớn. Nhiều thông số thấp bất thường so với xét nghiệm đồng thời.',steps:[
			{q:'Sai số chính cần nghĩ tới?',o:['Pha loãng và ảnh hưởng của chất chống đông không phù hợp','Bắt buộc là suy đa cơ quan','Bọt khí là nguyên nhân duy nhất'],a:0,e:'Khi tỷ lệ chất chống đông so với thể tích máu quá lớn, pha loãng và thành phần heparin có thể làm sai nhiều phép đo.'},
			{q:'Biện pháp phòng ngừa phù hợp?',o:['Dùng dụng cụ lấy khí máu và chất chống đông phù hợp với máy phân tích, đủ thể tích mẫu','Tăng heparin để chắc chắn không đông','Lắc mạnh bơm tiêm trong thời gian dài'],a:0,e:'Dụng cụ chuyên dụng và tỷ lệ mẫu–chất chống đông phù hợp giúp hạn chế pha loãng; mẫu cần được trộn nhẹ nhưng đầy đủ theo hướng dẫn.'},
			{q:'Có nên diễn giải sâu các bất thường nhỏ trong mẫu này không?',o:['Không, cần giải quyết vấn đề chất lượng mẫu trước','Có, mọi con số đều đáng tin như nhau'],a:0,e:'Khi tiền phân tích không bảo đảm, các chênh lệch nhỏ có thể phản ánh sai số hơn là sinh lý bệnh.'}]},
		{id:'ps03',title:'Mẫu phân tích chậm',intro:'Mẫu được để ở nhiệt độ phòng khá lâu trước khi phân tích. Kết quả cho PaO₂ thấp hơn và PaCO₂/lactat cao hơn so với mẫu lấy lại ngay sau đó.',steps:[
			{q:'Cơ chế tiền phân tích phù hợp nhất?',o:['Chuyển hóa tế bào tiếp diễn sau khi lấy mẫu','FiO₂ tự tăng trong bơm tiêm','HCO₃⁻ tự tăng do tiếp xúc ánh sáng'],a:0,e:'Tế bào máu tiếp tục tiêu thụ oxy và tạo CO₂/acid sau khi lấy, nên trì hoãn có thể làm thay đổi khí máu và một số chất chuyển hóa.'},
			{q:'Nhóm người bệnh nào đặc biệt dễ có PaO₂ giảm nhanh trong mẫu chậm?',o:['Người có bạch cầu hoặc tiểu cầu rất cao','Người thiếu máu nhẹ đơn thuần','Người tăng huyết áp'],a:0,e:'Hoạt động chuyển hóa của lượng tế bào rất lớn có thể tiêu thụ oxy trong mẫu nhanh hơn và tạo hình ảnh giảm oxy giả.'},
			{q:'Nguyên tắc an toàn?',o:['Phân tích càng sớm càng tốt theo quy trình đã thẩm định và ghi nhận bất kỳ trì hoãn đáng kể nào','Mọi mẫu đều ổn định như nhau trong nhiều giờ'],a:0,e:'Thời gian chấp nhận phụ thuộc vật liệu, loại mẫu và quy trình cơ sở; trì hoãn không cần thiết nên được tránh.'}]},
		{id:'ps04',title:'Lấy nhầm máu tĩnh mạch',intro:'Người bệnh tỉnh, SpO₂ 97% khí phòng. “Khí máu động mạch” trả về PO₂ 38 mmHg, PCO₂ 48 mmHg, màu mẫu sẫm; thao tác lấy máu khó.',steps:[
			{q:'Mâu thuẫn nào cần được kiểm tra trước?',o:['PO₂ rất thấp không phù hợp với SpO₂ và tình trạng lâm sàng','PCO₂ 48 luôn chứng minh suy hô hấp','Màu mẫu không bao giờ có ý nghĩa'],a:0,e:'PaO₂ rất thấp nhưng SpO₂ bình thường là bất tương hợp lớn, cần kiểm tra nguồn mẫu, thiết bị đo và chất lượng lấy mẫu.'},
			{q:'Khả năng tiền phân tích quan trọng?',o:['Mẫu tĩnh mạch bị ghi nhận như mẫu động mạch','Bắt buộc có luồng thông trong tim','PaO₂ động mạch luôn thấp hơn PO₂ tĩnh mạch'],a:0,e:'Lấy nhầm máu tĩnh mạch có thể tạo PO₂ thấp hơn rõ và PCO₂ cao hơn so với động mạch.'},
			{q:'PO₂ tĩnh mạch có dùng thay PaO₂ để đánh giá oxy hóa động mạch không?',o:['Không','Có, nếu pH gần nhau'],a:0,e:'Một số thông số toan–kiềm tĩnh mạch có thể hữu ích trong bối cảnh chọn lọc, nhưng PO₂ tĩnh mạch không thay thế PaO₂.'}]},
		{id:'ps05',title:'Nhiễm dịch từ đường động mạch',intro:'Mẫu lấy qua đường động mạch đang có dung dịch rửa. Khí máu và điện giải đồng thời bị pha loãng, khác hẳn kết quả vài phút trước.',steps:[
			{q:'Sai số cần nghĩ tới?',o:['Nhiễm dung dịch trong đường lấy mẫu','Đột biến sinh lý xảy ra đồng thời ở mọi thông số','Bọt khí luôn giải thích được điện giải pha loãng'],a:0,e:'Nếu phần dịch trong catheter hoặc hệ thống lấy mẫu chưa được loại bỏ đúng quy trình, mẫu có thể bị pha loãng hoặc nhiễm thành phần của dịch rửa.'},
			{q:'Dấu hiệu nào củng cố nghi ngờ?',o:['Nhiều thông số thay đổi đồng thời theo kiểu pha loãng và không phù hợp lâm sàng','Chỉ pH thay đổi 0,01','SpO₂ ổn định đơn độc'],a:0,e:'Mẫu nhiễm dịch thường tạo một cụm bất thường không hợp lý giữa khí máu, điện giải, glucose hoặc hemoglobin.'},
			{q:'Hành động phù hợp?',o:['Kiểm tra quy trình lấy qua đường động mạch và lấy lại mẫu nếu cần','Sửa từng giá trị bằng một hệ số cố định'],a:0,e:'Không có hệ số hiệu chỉnh chung cho mức nhiễm dịch không biết. Cần phục hồi quy trình lấy mẫu đúng và lấy lại mẫu đáng tin cậy.'}]},
		{id:'ps06',title:'Thay đổi oxy ngay quanh thời điểm lấy mẫu',intro:'PaO₂ tăng mạnh so với mẫu trước nhưng hồ sơ không ghi rõ FiO₂. Điều dưỡng cho biết oxy vừa được tăng lưu lượng ngay trước lúc lấy mẫu.',steps:[
			{q:'Thiếu dữ kiện nào làm giảm khả năng diễn giải?',o:['Mức hỗ trợ oxy và thời điểm thay đổi so với lúc lấy mẫu','Nhóm máu ABO','Chiều cao người bệnh'],a:0,e:'PaO₂ phải được đọc trong bối cảnh FiO₂/lưu lượng oxy và kiểu hỗ trợ đang dùng tại đúng thời điểm lấy mẫu.'},
			{q:'Có thể so trực tiếp PaO₂ này với mẫu trước không?',o:['Không nên nếu điều kiện oxy khác hoặc chưa được ghi nhận rõ','Có, PaO₂ luôn so sánh trực tiếp được'],a:0,e:'Hai PaO₂ đo trong điều kiện FiO₂ khác nhau không phản ánh cùng một trạng thái oxy hóa.'},
			{q:'Bài học an toàn?',o:['Ghi rõ FiO₂ hoặc lưu lượng oxy, thiết bị hỗ trợ và thời điểm lấy mẫu','Chỉ cần ghi SpO₂ sau khi có kết quả'],a:0,e:'Thông tin điều kiện hô hấp là một phần của chất lượng tiền phân tích và cần đi cùng mẫu.'}]},
		{id:'ps07',title:'Cục máu và trộn mẫu không đầy đủ',intro:'Bơm tiêm khí máu có một cục máu nhỏ. Kết quả lặp lại trên cùng mẫu biến thiên; máy phân tích có lúc báo lỗi hút mẫu.',steps:[
			{q:'Vấn đề chính?',o:['Mẫu không đồng nhất và có nguy cơ gây sai phép đo hoặc ảnh hưởng hệ thống hút mẫu','Một cục máu nhỏ không bao giờ ảnh hưởng','Chỉ PaO₂ mới bị ảnh hưởng'],a:0,e:'Chống đông và trộn mẫu không đầy đủ có thể gây cục máu, làm mẫu không đồng nhất và gây vấn đề cho phép đo.'},
			{q:'Có nên cố lấy phần máu “không có cục” để diễn giải không?',o:['Không nên coi đó là cách khắc phục đáng tin cậy','Có, kết quả sẽ chắc chắn đúng'],a:0,e:'Khi tính toàn vẹn mẫu đã mất, lựa chọn an toàn thường là lấy lại mẫu đúng kỹ thuật theo quy trình cơ sở.'},
			{q:'Phòng ngừa?',o:['Chống đông đúng, đủ thể tích và trộn nhẹ ngay sau lấy theo hướng dẫn','Để mẫu đứng yên lâu trước khi trộn'],a:0,e:'Mục tiêu là phân bố chất chống đông đồng đều mà không tạo thêm bọt khí hay tổn thương mẫu.'}]},
		{id:'ps08',title:'Giảm oxy giả ở người tăng bạch cầu rất cao',intro:'Người bệnh có bạch cầu tăng rất cao, SpO₂ 95% nhưng PaO₂ từ mẫu bị trì hoãn thấp bất ngờ. Mẫu lấy lại và phân tích ngay cho PaO₂ cao hơn rõ.',steps:[
			{q:'Giải thích tiền phân tích phù hợp?',o:['Tế bào trong mẫu tiếp tục tiêu thụ oxy, tạo giảm PaO₂ giả khi phân tích chậm','SpO₂ luôn sai trong tăng bạch cầu','FiO₂ trong cơ thể giảm sau khi lấy máu'],a:0,e:'Với số lượng tế bào rất cao, tiêu thụ oxy trong ống/bơm tiêm có thể nhanh và làm PaO₂ giảm sau lấy mẫu.'},
			{q:'Dấu hiệu nào giúp nhận ra?',o:['Bất tương hợp giữa lâm sàng/SpO₂ với PaO₂ và sự cải thiện khi mẫu được phân tích ngay','PaCO₂ luôn bằng 40 mmHg'],a:0,e:'Sự không phù hợp giữa các nguồn dữ liệu và phụ thuộc rõ vào thời gian xử lý là manh mối quan trọng.'},
			{q:'Nguyên tắc?',o:['Đối chiếu kết quả với lâm sàng và ưu tiên xử lý mẫu nhanh trong nhóm nguy cơ','Tin tuyệt đối một PaO₂ đơn lẻ'],a:0,e:'Kết quả khí máu phải xác nhận hoặc ít nhất có thể giải thích được tình trạng lâm sàng; khi không phù hợp cần kiểm tra mẫu trước.'}]}
	];


	/* v3.8 — Ngân hàng thi và đánh giá có cấu trúc. */
	var ASSESSMENT_DIFFICULTY = {
		f01:'basic',f02:'basic',f03:'intermediate',f04:'intermediate',f05:'basic',f06:'advanced',f07:'basic',f08:'intermediate',
		a01:'basic',a02:'basic',a03:'intermediate',a04:'intermediate',a05:'basic',a06:'intermediate',a07:'advanced',a08:'advanced',
		o01:'basic',o02:'basic',o03:'intermediate',o04:'intermediate',o05:'intermediate',o06:'basic',o07:'advanced',o08:'advanced',
		c01:'intermediate',c02:'intermediate',c03:'basic',c04:'intermediate',c05:'basic',c06:'basic',c07:'advanced',c08:'advanced'
	};
	var ASSESSMENT_EXTRA_QUESTIONS = [
		{id:'f09',topic:'foundation',difficulty:'intermediate',q:'pH 7,40 nhưng PaCO₂ và HCO₃⁻ đều bất thường rõ. Nhận định nào phù hợp nhất?',o:['pH bình thường luôn loại trừ rối loạn toan–kiềm','Cần nghĩ đến đáp ứng bù hoặc rối loạn phối hợp và tiếp tục phân tích','Chỉ cần đọc PaO₂','Không cần xem HCO₃⁻'],a:1,e:'pH gần khoảng tham chiếu có thể là kết quả của bù hoặc nhiều quá trình đối nghịch; cần đọc đồng thời PaCO₂ và HCO₃⁻.'},
		{id:'f10',topic:'foundation',difficulty:'advanced',q:'Khi cần đánh giá mức oxy hóa động mạch, vì sao PO₂ của mẫu tĩnh mạch không thể thay trực tiếp PaO₂?',o:['Vì PO₂ tĩnh mạch chịu ảnh hưởng của chiết xuất oxy ở mô và không đại diện oxy hóa động mạch','Vì mẫu tĩnh mạch không đo được pH','Vì PaO₂ luôn bằng SpO₂','Vì máu tĩnh mạch không có CO₂'],a:0,e:'PO₂ tĩnh mạch phản ánh máu sau trao đổi oxy ở mô, nên không dùng thay PaO₂ để định lượng oxy hóa động mạch.'},
		{id:'f11',topic:'foundation',difficulty:'intermediate',q:'Khái niệm “bù” trong rối loạn toan–kiềm nên được hiểu như thế nào?',o:['Là quá trình đưa pH về đúng 7,40 trong mọi trường hợp','Là đáp ứng sinh lý làm giảm mức thay đổi pH nhưng không tạo ra một rối loạn nguyên phát mới','Là dấu hiệu bệnh đã khỏi','Là thay đổi không thể dự đoán'],a:1,e:'Đáp ứng bù có hướng và khoảng dự kiến; nó làm giảm biến đổi pH nhưng không đồng nghĩa với bình thường hóa hoàn toàn.'},
		{id:'f12',topic:'foundation',difficulty:'advanced',q:'Một kết quả khí máu bất ngờ xuất hiện ngay sau khi thay đổi lưu lượng oxy. Dữ kiện nào cần được xác nhận trước khi so sánh với mẫu trước?',o:['FiO₂ hoặc thiết bị oxy và thời điểm lấy mẫu so với thay đổi hỗ trợ','Chỉ cân nặng người bệnh','Chỉ kali máu','Chỉ số lượng tiểu cầu'],a:0,e:'Thay đổi hỗ trợ oxy ngay quanh thời điểm lấy có thể làm hai mẫu không còn tương đương về điều kiện đo.'},
		{id:'a09',topic:'acidbase',difficulty:'advanced',q:'Khoảng trống anion đo được là 14 mmol/L, albumin 20 g/L. Nếu dùng hiệu chỉnh xấp xỉ 2,5 mmol/L cho mỗi 1 g/dL albumin thấp hơn 4 g/dL, khoảng trống anion hiệu chỉnh gần nhất là bao nhiêu?',o:['14 mmol/L','16,5 mmol/L','19 mmol/L','24 mmol/L'],a:2,e:'Albumin 20 g/L = 2 g/dL, thấp hơn 4 g/dL là 2 g/dL; cộng khoảng 5 mmol/L, được khoảng 19 mmol/L.'},
		{id:'a10',topic:'acidbase',difficulty:'intermediate',q:'Trong toan chuyển hóa với HCO₃⁻ 8 mmol/L, PaCO₂ dự kiến theo công thức Winter xấp xỉ bao nhiêu?',o:['20 ± 2 mmHg','32 ± 2 mmHg','40 ± 2 mmHg','52 ± 2 mmHg'],a:0,e:'1,5 × 8 + 8 = 20 mmHg, với khoảng thường dùng ±2 mmHg.'},
		{id:'a11',topic:'acidbase',difficulty:'advanced',q:'Người bệnh có PaCO₂ tăng kéo dài và HCO₃⁻ tăng rõ. Dữ kiện nào giúp nhất để nhận diện đợt toan hô hấp cấp trên nền mạn?',o:['Khí máu nền trước đó và mức thay đổi pH/HCO₃⁻ hiện tại','Chỉ PaO₂','Chỉ glucose','Chỉ natri'],a:0,e:'So sánh với khí máu nền và mức thích nghi HCO₃⁻ giúp tách thành phần mạn khỏi thay đổi cấp.'},
		{id:'a12',topic:'acidbase',difficulty:'advanced',q:'Trong toan chuyển hóa tăng khoảng trống anion, khoảng trống anion tăng nhiều hơn rõ so với mức HCO₃⁻ giảm. Điều này gợi ý gì?',o:['Có thể phối hợp kiềm chuyển hóa','Chắc chắn có toan hô hấp','Loại trừ rối loạn phối hợp','Chắc chắn là mẫu tĩnh mạch'],a:0,e:'Mức tăng khoảng trống anion lớn hơn mức giảm HCO₃⁻ có thể cho thấy một quá trình làm HCO₃⁻ cao hơn dự kiến, thường gợi ý kiềm chuyển hóa đi kèm.'},
		{id:'o09',topic:'oxygen',difficulty:'advanced',q:'Giảm oxy máu do giảm thông khí đơn thuần thường có đặc điểm nào khi không có bệnh phổi kèm theo?',o:['PaCO₂ tăng và chênh áp oxy phế nang–động mạch thường không tăng nhiều','PaCO₂ luôn giảm sâu','Chênh áp oxy phế nang–động mạch luôn tăng rất cao','PaO₂ luôn bình thường'],a:0,e:'Giảm thông khí làm giảm PAO₂ và tăng PaCO₂; nếu trao đổi khí trong phổi còn bảo tồn, chênh áp A–a thường không tăng nhiều.'},
		{id:'o10',topic:'oxygen',difficulty:'intermediate',q:'PaO₂ 80 mmHg khi FiO₂ 0,50 cho tỷ số PaO₂/FiO₂ xấp xỉ bao nhiêu?',o:['80','160','250','400'],a:1,e:'80 / 0,50 = 160.'},
		{id:'o11',topic:'oxygen',difficulty:'advanced',q:'Trong ngộ độc carbon monoxit, vì sao PaO₂ có thể vẫn bình thường dù vận chuyển oxy bị ảnh hưởng?',o:['PaO₂ đo oxy hòa tan trong huyết tương, không phản ánh trực tiếp hemoglobin bị carbon monoxit chiếm chỗ','PaO₂ đo trực tiếp carboxyhemoglobin','Carbon monoxit luôn làm PaCO₂ bằng 0','SpO₂ luôn giảm về 50%'],a:0,e:'PaO₂ không đo phần oxy gắn hemoglobin; vì vậy cần đánh giá dạng hemoglobin bằng đồng oxy kế khi bệnh cảnh phù hợp.'},
		{id:'o12',topic:'oxygen',difficulty:'advanced',q:'Giảm oxy máu do luồng thông trong phổi thường có đặc điểm nào so với bất tương xứng thông khí–tưới máu?',o:['Có thể đáp ứng kém hơn với tăng FiO₂','Luôn làm PaCO₂ tăng rất cao','Luôn có chênh áp A–a bình thường','Không ảnh hưởng PaO₂'],a:0,e:'Máu đi qua vùng không được thông khí có thể làm giảm oxy máu khó sửa hoàn toàn chỉ bằng tăng FiO₂.'},
		{id:'c09',topic:'clinical',difficulty:'advanced',q:'Người bệnh sốc nhiễm trùng có lactat 5,2 mmol/L, sau hồi sức giảm còn 3,1 mmol/L. Cách diễn giải phù hợp nhất?',o:['Xu hướng giảm là dữ kiện hữu ích nhưng vẫn phải tích hợp huyết động và bệnh cảnh','Lactat đã bình thường hoàn toàn','Một giá trị lactat xác định duy nhất nguyên nhân','Không cần theo dõi thêm'],a:0,e:'Xu hướng lactat có giá trị theo dõi nhưng không thay thế đánh giá tưới máu, huyết động và nguyên nhân nền.'},
		{id:'c10',topic:'clinical',difficulty:'advanced',q:'Người bệnh COPD có PaCO₂ 70 mmHg, HCO₃⁻ 36 mmol/L và pH 7,31; khí máu nền gần đây có PaCO₂ 55 mmHg. Mẫu hình nào đáng cân nhắc?',o:['Tăng CO₂ cấp trên nền tăng CO₂ mạn','Kiềm hô hấp đơn thuần','Toan chuyển hóa đơn thuần','Khí máu hoàn toàn bình thường'],a:0,e:'Khí máu nền cho thấy tăng CO₂ mạn; PaCO₂ hiện tại tăng thêm cùng pH giảm gợi ý một thành phần cấp trên nền mạn.'},
		{id:'c11',topic:'clinical',difficulty:'advanced',q:'pH 7,47; PaCO₂ 20 mmHg; HCO₃⁻ 14 mmol/L ở người bệnh nghi ngộ độc salicylat. Nhận định nào phù hợp nhất?',o:['Kiềm hô hấp phối hợp toan chuyển hóa','Kiềm hô hấp đơn thuần chắc chắn','Toan hô hấp phối hợp kiềm chuyển hóa','Khí máu bình thường'],a:0,e:'PaCO₂ rất thấp theo hướng kiềm hô hấp trong khi HCO₃⁻ thấp hơn mức bù đơn thuần, phù hợp mẫu hình phối hợp kinh điển.'},
		{id:'c12',topic:'clinical',difficulty:'advanced',q:'Người bệnh tăng bạch cầu rất cao có SpO₂ 96% nhưng PaO₂ của mẫu bị chậm xử lý thấp bất ngờ. Bước nào hợp lý nhất?',o:['Kiểm tra khả năng tiêu thụ oxy trong mẫu và lặp lại mẫu với xử lý nhanh nếu cần','Chẩn đoán ngay suy hô hấp nặng chỉ từ một PaO₂','Bỏ qua SpO₂ hoàn toàn','Tăng FiO₂ mà không kiểm tra mẫu'],a:0,e:'Tế bào rất nhiều có thể tiếp tục tiêu thụ oxy sau lấy mẫu và gây giảm PaO₂ giả khi xử lý chậm.'}
	];
	var LEGACY_ITEM_LESSON = {"f01":"hb-core","f02":"hb-core","f03":"hb-balance","f04":"hb-sampling","f05":"hb-equation","f06":"hb-reading","f07":"hb-core","f08":"hb-compensation","f09":"hb-mixed","f10":"hb-oxygen-ventilation","f11":"hb-compensation","f12":"hb-oxygen-support","a01":"hb-metabolic-acidosis","a02":"hb-metabolic-acidosis","a03":"hb-mixed","a04":"hb-anion-gap","a05":"hb-metabolic-alkalosis","a06":"hb-respiratory-acidosis","a07":"hb-respiratory-alkalosis","a08":"hb-mixed","a09":"hb-anion-gap","a10":"hb-metabolic-acidosis","a11":"hb-respiratory-acidosis","a12":"hb-mixed","o01":"hb-oxygen-ventilation","o02":"hb-oxygen-support","o03":"hb-aa-gradient","o04":"hb-pf","o05":"hb-oxygen-path","o06":"hb-oxygen-ventilation","o07":"hb-oxygen-path","o08":"hb-oxygen-support","o09":"hb-hypoxemia","o10":"hb-pf","o11":"hb-oxygen-path","o12":"hb-hypoxemia","c01":"hb-case-sglt2","c02":"hb-case-copd","c03":"hb-case-opioid","c04":"hb-case-sepsis","c05":"hb-case-airbubble","c06":"hb-case-diarrhea","c07":"hb-case-salicylate","c08":"hb-case-ventilator","c09":"hb-case-sepsis","c10":"hb-case-copd","c11":"hb-case-salicylate","c12":"hb-case-airbubble"};
	var ASSESSMENT_V51_QUESTIONS = [
		{"id":"f13","topic":"foundation","difficulty":"basic","lesson":"hb-balance","cognitive":"remember","clinicalContext":"general","q":"pH 7,28 được mô tả chính xác nhất là gì?","e":"pH dưới khoảng tham chiếu biểu thị toan máu; đây là mô tả trạng thái pH, chưa tự xác định cơ chế nguyên phát.","distractorRationale":"Các phương án nhiễu nhầm trạng thái pH với cơ chế hoặc đưa PaO₂ vào một câu hỏi không cần PaO₂.","remediation":"hb-balance","o":["Kiềm máu","Toan máu","pH trong khoảng tham chiếu","Không thể mô tả nếu chưa biết PaO₂"],"a":1},
		{"id":"f14","topic":"foundation","difficulty":"basic","lesson":"hb-core","cognitive":"remember","clinicalContext":"general","q":"Thông số nào đại diện trực tiếp nhất cho thành phần hô hấp trong bộ ba pH–PaCO₂–HCO₃⁻?","e":"PaCO₂ phản ánh cân bằng giữa tạo CO₂ và thông khí phế nang, nên là biến hô hấp chính.","distractorRationale":"Các phương án nhiễu lần lượt là biến chuyển hóa, biến kết quả tổng hợp và điện giải.","remediation":"hb-core","o":["HCO₃⁻","pH","PaCO₂","Na⁺"],"a":2},
		{"id":"f15","topic":"foundation","difficulty":"basic","lesson":"hb-equation","cognitive":"understand","clinicalContext":"general","q":"Trong cách đọc Henderson–Hasselbalch, pH thay đổi theo tỷ lệ giữa yếu tố nào?","e":"pH của hệ bicarbonat phụ thuộc tương quan giữa HCO₃⁻ và CO₂ hòa tan.","distractorRationale":"Các cặp còn lại hữu ích trong những mục tiêu khác nhưng không tạo tỷ lệ nền tảng của phương trình này.","remediation":"hb-equation","o":["PaO₂ và FiO₂","Na⁺ và Cl⁻","Lactat và glucose","HCO₃⁻ và CO₂ hòa tan"],"a":3},
		{"id":"f16","topic":"foundation","difficulty":"basic","lesson":"hb-reference","cognitive":"remember","clinicalContext":"adult","q":"Khoảng pH động mạch thường dùng làm tham chiếu ở người lớn là khoảng nào?","e":"Khoảng tham chiếu thường dùng cho pH động mạch người lớn là 7,35–7,45; cần đối chiếu phòng xét nghiệm khi có quy định riêng.","distractorRationale":"Các khoảng còn lại biểu thị bất thường rõ hoặc không phù hợp với khoảng tham chiếu thông dụng.","remediation":"hb-reference","o":["7,15–7,25","7,50–7,60","7,35–7,45","6,80–7,00"],"a":2},
		{"id":"f17","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"understand","clinicalContext":"preanalytical","q":"Mục tiêu chính của việc loại bỏ bọt khí đáng kể khỏi bơm tiêm khí máu là gì?","e":"Bọt khí tạo bề mặt trao đổi khiến PO₂/PCO₂ của mẫu dịch chuyển về cân bằng với không khí.","distractorRationale":"Các phương án nhiễu gán cho bọt khí những tác động không thuộc cơ chế tiền phân tích này.","remediation":"hb-sampling","o":["Tăng hemoglobin trong mẫu","Làm tăng natri","Ngăn mọi thay đổi pH do thận","Giảm trao đổi khí giữa mẫu và không khí môi trường"],"a":3},
		{"id":"f18","topic":"foundation","difficulty":"basic","lesson":"hb-reading","cognitive":"apply","clinicalContext":"general","q":"Sau khi xác nhận mẫu phù hợp, bước mở đầu hợp lý nhất khi đọc toan–kiềm là gì?","e":"Ba biến pH–PaCO₂–HCO₃⁻ phải được đặt cùng nhau để xác định hướng rối loạn và thành phần nguyên phát.","distractorRationale":"Các lựa chọn nhiễu tách một biến khỏi hệ hoặc ưu tiên oxy hóa trước câu hỏi toan–kiềm.","remediation":"hb-reading","o":["Tính PaO₂/FiO₂ trước mọi trường hợp","Đọc pH cùng PaCO₂ và HCO₃⁻","Chỉ nhìn HCO₃⁻","Chỉ nhìn PaCO₂"],"a":1},
		{"id":"f19","topic":"foundation","difficulty":"intermediate","lesson":"hb-remember","cognitive":"apply","clinicalContext":"general","q":"Một kết quả pH 7,40; PaCO₂ 60 mmHg; HCO₃⁻ 36 mmol/L cho thấy nguyên tắc ghi nhớ nào quan trọng nhất?","e":"PaCO₂ và HCO₃⁻ đều bất thường rõ dù pH gần 7,40; bù hoặc rối loạn phối hợp có thể kéo pH về gần khoảng tham chiếu.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa pH hoặc bỏ qua mối quan hệ giữa các biến.","remediation":"hb-remember","o":["pH 7,40 luôn đồng nghĩa khí máu bình thường","Chỉ cần đọc PaO₂","Không cần xem mức bù","pH gần bình thường không loại trừ rối loạn đáng kể"],"a":3},
		{"id":"f20","topic":"foundation","difficulty":"intermediate","lesson":"hb-language","cognitive":"understand","clinicalContext":"general","q":"Câu nào phân biệt đúng “toan máu” và “quá trình gây toan”?","e":"Một quá trình gây toan có thể tồn tại dù pH chưa thấp nếu có quá trình kiềm hóa đi kèm; vì vậy cần tách trạng thái pH khỏi cơ chế.","distractorRationale":"Các phương án nhiễu đồng nhất hai khái niệm hoặc đặt ngưỡng/loại rối loạn không đúng.","remediation":"hb-language","o":["Hai khái niệm hoàn toàn đồng nghĩa","Toan máu chỉ dùng cho toan chuyển hóa","Toan máu mô tả pH thấp; quá trình gây toan là cơ chế làm pH có xu hướng giảm","Quá trình gây toan chỉ xảy ra khi pH < 7,00"],"a":2},
		{"id":"f21","topic":"foundation","difficulty":"intermediate","lesson":"hb-sampling","cognitive":"apply","clinicalContext":"preanalytical","q":"Mẫu lấy qua đường động mạch đang truyền dịch nhưng không loại bỏ đủ dịch trong đường trước khi lấy. Kết quả bất thường nên được xử lý thế nào trước tiên?","e":"Dịch tồn trong đường có thể pha loãng và làm sai đồng thời khí máu, điện giải hoặc glucose; độ tin cậy mẫu phải được giải quyết trước.","distractorRationale":"Các phương án nhiễu bỏ qua nguyên nhân tiền phân tích hoặc giả định chỉ một thông số bị ảnh hưởng.","remediation":"hb-sampling","o":["Giải thích ngay là rối loạn chuyển hóa thật","Nghi nhiễm dịch đường truyền và đánh giá lại quy trình lấy mẫu","Chỉ bỏ qua natri, còn khí máu chắc chắn đúng","Không cần lặp lại vì pH không bao giờ bị ảnh hưởng"],"a":1},
		{"id":"f22","topic":"foundation","difficulty":"intermediate","lesson":"hb-reference","cognitive":"apply","clinicalContext":"general","q":"FiO₂ 40% khi đưa vào phép tính PaO₂/FiO₂ nên được biểu diễn dưới dạng nào?","e":"FiO₂ dùng trong tỷ số PaO₂/FiO₂ được biểu diễn dưới dạng phân số, nên 40% = 0,40.","distractorRationale":"Các phương án nhiễu là lỗi chuyển đổi phần trăm sang phân số.","remediation":"hb-reference","o":["40","4,0","0,04","0,40"],"a":3},
		{"id":"f23","topic":"foundation","difficulty":"intermediate","lesson":"hb-reading","cognitive":"analyze","clinicalContext":"general","q":"Kết quả ABG có pH và PaCO₂ phù hợp với nhau nhưng HCO₃⁻ khác xa mức có thể kỳ vọng. Cách tiếp cận tốt nhất là gì?","e":"Sự không khớp giữa các biến là tín hiệu để kiểm tra bù, rối loạn phối hợp và chất lượng dữ liệu.","distractorRationale":"Các phương án nhiễu đơn giản hóa quá mức hoặc kết luận lỗi máy không có bằng chứng.","remediation":"hb-reading","o":["Chọn chẩn đoán chỉ theo pH","Bỏ HCO₃⁻ vì không quan trọng","Xem xét rối loạn phối hợp, bù và độ tin cậy dữ liệu thay vì ép vào một rối loạn đơn thuần","Giả định máy xét nghiệm sai mà không kiểm tra gì thêm"],"a":2},
		{"id":"f24","topic":"foundation","difficulty":"advanced","lesson":"hb-equation","cognitive":"analyze","clinicalContext":"general","q":"Vì sao thay đổi PaCO₂ có thể làm pH thay đổi nhanh hơn so với đáp ứng HCO₃⁻ của thận?","e":"Thành phần hô hấp có thể thay đổi rất nhanh; đáp ứng thận cần thời gian để tăng tái hấp thu/tạo bicarbonat hoặc bài tiết acid.","distractorRationale":"Các phương án nhiễu phủ nhận sinh lý thận hoặc gán sai cơ quan điều hòa.","remediation":"hb-equation","o":["Thận không bao giờ điều chỉnh HCO₃⁻","PaCO₂ do gan điều chỉnh","HCO₃⁻ chỉ tồn tại trong phổi","Thông khí có thể thay đổi trong phút, trong khi điều chỉnh HCO₃⁻ của thận cần nhiều giờ đến ngày"],"a":3},
		{"id":"f25","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","clinicalContext":"preanalytical","q":"Một mẫu khí máu bị trì hoãn xử lý trong khi tế bào vẫn chuyển hóa. Xu hướng nào có thể xuất hiện?","e":"Chuyển hóa tế bào tiếp tục tiêu thụ O₂ và tạo CO₂/acid, đặc biệt đáng kể khi trì hoãn hoặc số lượng tế bào rất cao.","distractorRationale":"Các phương án nhiễu mô tả thay đổi không phù hợp với chuyển hóa trong mẫu.","remediation":"hb-sampling","o":["PO₂ tăng vô hạn và PCO₂ về 0","PO₂ giảm, PCO₂ tăng và pH giảm theo thời gian","Natri bốc hơi hoàn toàn","Albumin tăng nhanh do tế bào tạo mới"],"a":1},
		{"id":"f26","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","clinicalContext":"preanalytical","q":"SpO₂ 98% ổn định nhưng mẫu ghi PaO₂ 35 mmHg sau một lần lấy khó. Bước suy luận ưu tiên là gì?","e":"Bất tương hợp rất lớn giữa SpO₂ và PaO₂ trong bối cảnh lấy khó đòi hỏi kiểm tra nguồn mẫu và tiền phân tích.","distractorRationale":"Các phương án nhiễu nhảy thẳng tới cơ chế bệnh hoặc bỏ dữ kiện kiểm chứng quan trọng.","remediation":"hb-sampling","o":["Chẩn đoán ngay luồng thông nặng","Bỏ qua SpO₂ trong mọi trường hợp","Kiểm tra nguồn mẫu, chất lượng lấy và khả năng lấy nhầm máu tĩnh mạch trước khi gán suy hô hấp nặng","Chỉ tính khoảng trống anion"],"a":2},
		{"id":"f27","topic":"foundation","difficulty":"advanced","lesson":"hb-reading","cognitive":"analyze","clinicalContext":"serial","q":"Khi so sánh hai ABG liên tiếp, điều kiện nào cần tương đương hoặc được ghi rõ để diễn giải xu hướng?","e":"Xu hướng chỉ có ý nghĩa khi biết điều kiện hô hấp/oxy tại mỗi lần lấy; thay đổi hỗ trợ có thể giải thích phần lớn biến thiên.","distractorRationale":"Các phương án nhiễu không liên quan trực tiếp đến tính so sánh của hai mẫu.","remediation":"hb-reading","o":["Màu mắt người bệnh","Nhóm máu ABO","Chiều cao người lấy mẫu","Thiết bị/FiO₂, hỗ trợ thông khí và thời điểm lấy so với thay đổi điều trị"],"a":3},
		{"id":"f28","topic":"foundation","difficulty":"advanced","lesson":"hb-balance","cognitive":"analyze","clinicalContext":"general","q":"pH 7,37 với PaCO₂ 25 mmHg và HCO₃⁻ 14 mmol/L nên được hiểu thế nào ở bước đầu?","e":"PaCO₂ thấp theo hướng kiềm hóa và HCO₃⁻ thấp theo hướng toan hóa; pH gần tham chiếu không loại trừ hai quá trình đồng thời.","distractorRationale":"Các phương án nhiễu coi pH gần bình thường là đủ để dừng phân tích.","remediation":"hb-balance","o":["Khí máu bình thường","pH gần tham chiếu nhưng cả hai thành phần bất thường, cần đánh giá rối loạn phối hợp","Chỉ có giảm oxy máu","Không có quá trình toan–kiềm"],"a":1},
		{"id":"f29","topic":"foundation","difficulty":"advanced","lesson":"hb-reference","cognitive":"analyze","clinicalContext":"altitude","q":"Tại độ cao đáng kể, vì sao không nên dùng máy móc áp suất khí quyển 760 mmHg trong phương trình khí phế nang?","e":"Phương trình khí phế nang phụ thuộc áp suất khí quyển; dùng 760 mmHg ở độ cao có thể đánh giá sai PAO₂ và chênh áp A–a.","distractorRationale":"Các phương án nhiễu mô tả những thay đổi không phải cơ sở của hiệu chỉnh áp suất khí quyển.","remediation":"hb-reference","o":["FiO₂ khí phòng luôn tăng theo độ cao","PaCO₂ không còn đo được","Áp suất khí quyển giảm theo độ cao và làm thay đổi PAO₂ dự kiến","HCO₃⁻ luôn bằng 24 mmol/L"],"a":2},
		{"id":"f30","topic":"foundation","difficulty":"advanced","lesson":"hb-remember","cognitive":"analyze","clinicalContext":"general","q":"Nguyên tắc nào an toàn nhất khi một con số khí máu “không hợp” với toàn cảnh người bệnh?","e":"Khí máu cần được kiểm tra tính hợp lý nội tại và đối chiếu bệnh cảnh; bất tương hợp là tín hiệu kiểm tra chứ không phải lý do suy đoán.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa một nguồn dữ liệu hoặc khuyến khích thay số không có căn cứ.","remediation":"hb-remember","o":["Luôn tin một con số bất thường hơn mọi dữ kiện khác","Luôn bỏ kết quả xét nghiệm","Tự suy đoán giá trị đúng rồi thay số","Xác nhận mẫu, bối cảnh và các biến liên quan trước khi kết luận từ một giá trị đơn lẻ"],"a":3},
		{"id":"a13","topic":"acidbase","difficulty":"basic","lesson":"hb-four","cognitive":"remember","clinicalContext":"general","q":"pH thấp và PaCO₂ tăng theo hướng làm pH giảm phù hợp nhất với rối loạn nguyên phát nào?","e":"PaCO₂ tăng là thay đổi hô hấp theo hướng gây toan; khi pH thấp, toan hô hấp là quá trình nguyên phát phù hợp.","distractorRationale":"Các phương án nhiễu chọn sai hướng PaCO₂ hoặc nhầm thành phần chuyển hóa.","remediation":"hb-four","o":["Kiềm hô hấp","Toan chuyển hóa","Toan hô hấp","Kiềm chuyển hóa"],"a":2},
		{"id":"a14","topic":"acidbase","difficulty":"basic","lesson":"hb-four","cognitive":"remember","clinicalContext":"general","q":"pH tăng và PaCO₂ giảm phù hợp nhất với rối loạn nguyên phát nào?","e":"Giảm PaCO₂ làm giảm acid carbonic và tăng pH, phù hợp kiềm hô hấp.","distractorRationale":"Các phương án nhiễu đảo hướng hoặc nhầm thành phần chuyển hóa.","remediation":"hb-four","o":["Toan hô hấp","Toan chuyển hóa","Kiềm chuyển hóa","Kiềm hô hấp"],"a":3},
		{"id":"a15","topic":"acidbase","difficulty":"basic","lesson":"hb-metabolic-acidosis","cognitive":"apply","clinicalContext":"general","q":"pH 7,22; HCO₃⁻ 11 mmol/L. Quá trình nguyên phát cần nghĩ trước là gì?","e":"pH thấp đi cùng HCO₃⁻ thấp xác định hướng toan chuyển hóa; sau đó mới đánh giá PaCO₂ dự kiến.","distractorRationale":"Các phương án nhiễu không phù hợp với hướng biến đổi HCO₃⁻ và pH.","remediation":"hb-metabolic-acidosis","o":["Kiềm chuyển hóa","Toan chuyển hóa","Toan hô hấp","Kiềm hô hấp"],"a":1},
		{"id":"a16","topic":"acidbase","difficulty":"basic","lesson":"hb-metabolic-alkalosis","cognitive":"apply","clinicalContext":"general","q":"pH 7,52; HCO₃⁻ 38 mmol/L. Rối loạn nguyên phát phù hợp nhất là gì?","e":"pH tăng đi cùng HCO₃⁻ tăng phù hợp kiềm chuyển hóa; PaCO₂ dùng để đánh giá đáp ứng hô hấp.","distractorRationale":"Các phương án nhiễu đảo hướng pH/HCO₃⁻ hoặc chọn rối loạn hô hấp chưa có dữ kiện.","remediation":"hb-metabolic-alkalosis","o":["Toan chuyển hóa","Kiềm hô hấp","Kiềm chuyển hóa","Toan hô hấp"],"a":2},
		{"id":"a17","topic":"acidbase","difficulty":"basic","lesson":"hb-respiratory-acidosis","cognitive":"apply","clinicalContext":"general","q":"pH 7,25; PaCO₂ 65 mmHg. Quá trình nguyên phát phù hợp nhất ở bước đầu là gì?","e":"PaCO₂ tăng theo hướng gây toan và pH thấp, phù hợp toan hô hấp; HCO₃⁻ giúp đánh giá cấp/mạn và phối hợp.","distractorRationale":"Các phương án nhiễu không phù hợp hướng PaCO₂ hoặc dừng phân tích quá sớm.","remediation":"hb-respiratory-acidosis","o":["Kiềm hô hấp","Kiềm chuyển hóa","Không có rối loạn","Toan hô hấp"],"a":3},
		{"id":"a18","topic":"acidbase","difficulty":"basic","lesson":"hb-respiratory-alkalosis","cognitive":"apply","clinicalContext":"general","q":"pH 7,50; PaCO₂ 25 mmHg. Quá trình nguyên phát phù hợp nhất là gì?","e":"PaCO₂ giảm làm pH tăng, phù hợp kiềm hô hấp; HCO₃⁻ giúp đánh giá thời gian và phối hợp.","distractorRationale":"Các phương án nhiễu đảo hướng PaCO₂ hoặc chọn thành phần chuyển hóa.","remediation":"hb-respiratory-alkalosis","o":["Toan hô hấp","Toan chuyển hóa","Kiềm hô hấp","Kiềm chuyển hóa"],"a":2},
		{"id":"a19","topic":"acidbase","difficulty":"basic","lesson":"hb-anion-gap","cognitive":"apply","clinicalContext":"general","q":"Với Na⁺ 140, Cl⁻ 104 và HCO₃⁻ 20 mmol/L, khoảng trống anion không tính K⁺ xấp xỉ bao nhiêu?","e":"Khoảng trống anion = Na⁺ − (Cl⁻ + HCO₃⁻) = 140 − 124 = 16 mmol/L.","distractorRationale":"Các phương án nhiễu thường do cộng sai hoặc bỏ một thành phần của công thức.","remediation":"hb-anion-gap","o":["8 mmol/L","16 mmol/L","24 mmol/L","36 mmol/L"],"a":1},
		{"id":"a20","topic":"acidbase","difficulty":"intermediate","lesson":"hb-compensation","cognitive":"understand","clinicalContext":"general","q":"Điều nào mô tả đúng đáp ứng bù trong một rối loạn toan–kiềm đơn thuần?","e":"Đáp ứng sinh lý có hướng và biên độ dự kiến; lệch rõ khỏi khoảng này gợi ý thêm rối loạn.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa bình thường hóa pH hoặc hiểu bù như một rối loạn nguyên phát mới.","remediation":"hb-compensation","o":["Bù luôn đưa pH chính xác về 7,40","Bù tạo ra một rối loạn nguyên phát thứ hai","Bù không có khoảng dự kiến","Đáp ứng bù làm giảm biến đổi pH nhưng không “bù quá mức” thành rối loạn đối nghịch nguyên phát"],"a":3},
		{"id":"a21","topic":"acidbase","difficulty":"intermediate","lesson":"hb-metabolic-acidosis","cognitive":"apply","clinicalContext":"general","q":"Trong toan chuyển hóa với HCO₃⁻ 16 mmol/L, PaCO₂ dự kiến theo Winter gần nhất là bao nhiêu?","e":"1,5 × 16 + 8 = 32 mmHg, thường dùng khoảng ±2 mmHg.","distractorRationale":"Các phương án nhiễu phản ánh tính sai hoặc dùng mốc PaCO₂ bình thường thay vì công thức Winter.","remediation":"hb-metabolic-acidosis","o":["20 ± 2 mmHg","40 ± 2 mmHg","32 ± 2 mmHg","50 ± 2 mmHg"],"a":2},
		{"id":"a22","topic":"acidbase","difficulty":"intermediate","lesson":"hb-metabolic-acidosis","cognitive":"analyze","clinicalContext":"general","q":"HCO₃⁻ 16 mmol/L nhưng PaCO₂ thực đo 45 mmHg. So với Winter, điều này gợi ý gì?","e":"PaCO₂ dự kiến khoảng 32 ± 2; giá trị 45 cao hơn rõ, cho thấy thông khí thấp hơn mức bù và gợi ý toan hô hấp phối hợp.","distractorRationale":"Các phương án nhiễu đảo hướng sai lệch hoặc bỏ qua khoảng PaCO₂ dự kiến.","remediation":"hb-metabolic-acidosis","o":["Có thêm kiềm hô hấp","Có thêm toan hô hấp","Đáp ứng bù hoàn toàn phù hợp","Không thể đánh giá"],"a":1},
		{"id":"a23","topic":"acidbase","difficulty":"intermediate","lesson":"hb-metabolic-alkalosis","cognitive":"analyze","clinicalContext":"general","q":"Trong kiềm chuyển hóa, PaCO₂ tăng vừa phải thường được hiểu thế nào?","e":"Giảm thông khí là đáp ứng hô hấp với kiềm chuyển hóa; mức tăng PaCO₂ phải được so với khoảng dự kiến và bệnh cảnh.","distractorRationale":"Các phương án nhiễu coi mọi tăng PaCO₂ là một bệnh riêng hoặc tách khỏi rối loạn chuyển hóa.","remediation":"hb-metabolic-alkalosis","o":["Luôn là toan hô hấp nguyên phát","Luôn chứng minh bệnh phổi tắc nghẽn","Không liên quan đến HCO₃⁻","Là đáp ứng giảm thông khí nếu nằm trong khoảng dự kiến, nhưng phải kiểm tra nếu tăng quá mức"],"a":3},
		{"id":"a24","topic":"acidbase","difficulty":"intermediate","lesson":"hb-respiratory-acidosis","cognitive":"analyze","clinicalContext":"serial","q":"Ở hai người cùng PaCO₂ 60 mmHg, người có HCO₃⁻ tăng nhiều hơn thường gợi ý điều gì?","e":"Thận cần thời gian để tăng HCO₃⁻; mức tăng HCO₃⁻ lớn hơn thường hướng tới tình trạng mạn hơn, dù vẫn cần khí máu nền/bối cảnh.","distractorRationale":"Các phương án nhiễu đảo ý nghĩa thời gian hoặc bỏ qua vai trò đáp ứng thận.","remediation":"hb-respiratory-acidosis","o":["Toan hô hấp chắc chắn mới xảy ra vài phút","PaCO₂ không có ý nghĩa","Thành phần tăng CO₂ đã kéo dài hơn và có đáp ứng thận rõ hơn","Chỉ có kiềm chuyển hóa"],"a":2},
		{"id":"a25","topic":"acidbase","difficulty":"intermediate","lesson":"hb-respiratory-alkalosis","cognitive":"analyze","clinicalContext":"general","q":"PaCO₂ thấp kéo dài đi kèm HCO₃⁻ giảm nhiều hơn so với vài giờ đầu thường phản ánh điều gì?","e":"Trong kiềm hô hấp kéo dài, thận giảm HCO₃⁻ nhiều hơn so với giai đoạn cấp.","distractorRationale":"Các phương án nhiễu chọn sai hướng hoặc phủ nhận tác động của thời gian.","remediation":"hb-respiratory-alkalosis","o":["Toan hô hấp cấp","Đáp ứng thận của kiềm hô hấp mạn rõ hơn","Kiềm chuyển hóa nguyên phát chắc chắn","Không có thích nghi theo thời gian"],"a":1},
		{"id":"a26","topic":"acidbase","difficulty":"advanced","lesson":"hb-anion-gap","cognitive":"analyze","clinicalContext":"general","q":"Khoảng trống anion đo được 12 mmol/L với albumin 2 g/dL. Sau hiệu chỉnh xấp xỉ +2,5 mmol/L cho mỗi 1 g/dL albumin thấp hơn 4, giá trị gần nhất là gì?","e":"Albumin thấp 2 g/dL so với mốc 4 g/dL: cộng khoảng 5 mmol/L, được khoảng 17 mmol/L.","distractorRationale":"Các phương án nhiễu không hiệu chỉnh, hiệu chỉnh thiếu hoặc cộng quá mức.","remediation":"hb-anion-gap","o":["12 mmol/L","14,5 mmol/L","22 mmol/L","17 mmol/L"],"a":3},
		{"id":"a27","topic":"acidbase","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","clinicalContext":"general","q":"Trong toan chuyển hóa tăng khoảng trống anion, ΔAG lớn hơn rõ ΔHCO₃⁻ gợi ý thêm quá trình nào?","e":"Nếu HCO₃⁻ giảm ít hơn mức tăng khoảng trống anion, có thể có một quá trình làm HCO₃⁻ cao hơn dự kiến, thường là kiềm chuyển hóa.","distractorRationale":"Các phương án nhiễu không phù hợp với quan hệ delta hoặc suy ra rối loạn hô hấp từ dữ kiện chuyển hóa.","remediation":"hb-mixed","o":["Toan chuyển hóa không tăng khoảng trống anion","Toan hô hấp chắc chắn","Kiềm chuyển hóa phối hợp","Kiềm hô hấp chắc chắn"],"a":2},
		{"id":"a28","topic":"acidbase","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","clinicalContext":"general","q":"pH 7,45; PaCO₂ 20 mmHg; HCO₃⁻ 13 mmol/L. Vì sao không nên gọi đơn giản là kiềm hô hấp?","e":"Độ giảm HCO₃⁻ phải được so với thời gian/đáp ứng dự kiến; giảm quá mức gợi ý rối loạn chuyển hóa phối hợp.","distractorRationale":"Các phương án nhiễu bỏ qua HCO₃⁻ hoặc coi PaCO₂ thấp là lỗi mẫu không có căn cứ.","remediation":"hb-mixed","o":["pH không tăng nên không có rối loạn","HCO₃⁻ thấp sâu có thể vượt mức bù dự kiến và gợi ý thêm toan chuyển hóa","PaCO₂ thấp luôn do sai số mẫu","HCO₃⁻ không dùng trong rối loạn hô hấp"],"a":1},
		{"id":"a29","topic":"acidbase","difficulty":"advanced","lesson":"hb-acidbase-summary","cognitive":"analyze","clinicalContext":"general","q":"Trình tự nào phù hợp nhất để tóm tắt một ABG toan–kiềm phức tạp?","e":"Cách tiếp cận có cấu trúc giảm nguy cơ bỏ sót rối loạn phối hợp và buộc đối chiếu đáp ứng bù.","distractorRationale":"Các phương án nhiễu bỏ các bước cốt lõi hoặc ưu tiên biến không trả lời câu hỏi toan–kiềm.","remediation":"hb-acidbase-summary","o":["PaO₂ → glucose → tuổi → pH","Chỉ pH rồi kết luận","pH → quá trình nguyên phát → bù dự kiến → khoảng trống anion/delta khi phù hợp → rối loạn phối hợp","Chỉ khoảng trống anion rồi kết luận"],"a":2},
		{"id":"a30","topic":"acidbase","difficulty":"advanced","lesson":"hb-language","cognitive":"analyze","clinicalContext":"general","q":"Một người có toan chuyển hóa và kiềm hô hấp đồng thời có thể có pH trong khoảng tham chiếu. Kết luận đúng nhất là gì?","e":"Các quá trình đối nghịch có thể kéo pH về gần tham chiếu; phân tích PaCO₂/HCO₃⁻ và bù vẫn nhận diện được phối hợp.","distractorRationale":"Các phương án nhiễu đồng nhất pH hiện tại với số lượng cơ chế đang hoạt động.","remediation":"hb-language","o":["Hai quá trình triệt tiêu nên không còn rối loạn","Chỉ quá trình làm pH lệch nhiều hơn mới tồn tại","Không thể có hai rối loạn nguyên phát cùng lúc","Trạng thái pH gần bình thường không xóa sự tồn tại của hai quá trình nguyên phát"],"a":3},
		{"id":"o13","topic":"oxygen","difficulty":"basic","lesson":"hb-oxygen-ventilation","cognitive":"understand","clinicalContext":"general","q":"Thông số nào phản ánh trực tiếp hơn vấn đề thông khí phế nang?","e":"PaCO₂ thay đổi theo thông khí phế nang tương đối với lượng CO₂ tạo ra; PaO₂/SaO₂ chủ yếu thuộc oxy hóa.","distractorRationale":"Các phương án nhiễu thuộc oxy hóa hoặc khả năng vận chuyển oxy, không phải biến thông khí trực tiếp.","remediation":"hb-oxygen-ventilation","o":["PaO₂","SaO₂","Hemoglobin","PaCO₂"],"a":3},
		{"id":"o14","topic":"oxygen","difficulty":"basic","lesson":"hb-oxygen-path","cognitive":"understand","clinicalContext":"general","q":"PaO₂ mô tả thành phần oxy nào?","e":"PaO₂ là áp suất riêng phần oxy hòa tan, không phải tổng hàm lượng oxy động mạch.","distractorRationale":"Các phương án nhiễu nhầm PaO₂ với hàm lượng oxy, oxy mô hoặc FiO₂.","remediation":"hb-oxygen-path","o":["Tổng lượng oxy gắn hemoglobin và hòa tan","Oxy trong mô trực tiếp","Oxy hòa tan trong huyết tương động mạch","FiO₂ của khí hít vào"],"a":2},
		{"id":"o15","topic":"oxygen","difficulty":"basic","lesson":"hb-saturation","cognitive":"understand","clinicalContext":"general","q":"Vì sao PaO₂ và SaO₂ không có quan hệ tuyến tính trên toàn bộ dải giá trị?","e":"Quan hệ sigmoid khiến cùng một thay đổi PaO₂ có thể gây mức thay đổi SaO₂ khác nhau tùy vùng của đường cong.","distractorRationale":"Các phương án nhiễu phủ nhận quan hệ sinh lý hoặc gán sai yếu tố quyết định.","remediation":"hb-saturation","o":["Vì PaO₂ luôn bằng SaO₂","Do đường cong phân ly oxy–hemoglobin có dạng sigmoid","Vì SaO₂ chỉ phụ thuộc natri","Vì hemoglobin không gắn oxy"],"a":1},
		{"id":"o16","topic":"oxygen","difficulty":"basic","lesson":"hb-alveolar-equation","cognitive":"remember","clinicalContext":"general","q":"Trong phương trình khí phế nang ở mức biển, yếu tố nào được trừ đi sau khi tính oxy hít vào?","e":"Dạng thường dùng: PAO₂ ≈ FiO₂ × (PB − PH₂O) − PaCO₂/R.","distractorRationale":"Các phương án nhiễu không thuộc phương trình khí phế nang.","remediation":"hb-alveolar-equation","o":["HCO₃⁻ nhân Na⁺","SaO₂ nhân hemoglobin","Lactat chia glucose","PaCO₂ chia cho hệ số hô hấp R"],"a":3},
		{"id":"o17","topic":"oxygen","difficulty":"basic","lesson":"hb-aa-gradient","cognitive":"understand","clinicalContext":"general","q":"Chênh áp A–a được tính theo biểu thức nào?","e":"Chênh áp oxy phế nang–động mạch là PAO₂ ước tính trừ PaO₂ động mạch.","distractorRationale":"Các phương án nhiễu đảo dấu hoặc dùng các đại lượng khác.","remediation":"hb-aa-gradient","o":["PaO₂ − PAO₂","PaCO₂ − HCO₃⁻","PAO₂ − PaO₂","SaO₂ − SpO₂"],"a":2},
		{"id":"o18","topic":"oxygen","difficulty":"basic","lesson":"hb-pf","cognitive":"apply","clinicalContext":"general","q":"PaO₂ 90 mmHg ở FiO₂ 0,30 cho tỷ số PaO₂/FiO₂ gần nhất là bao nhiêu?","e":"90/0,30 = 300.","distractorRationale":"Các phương án nhiễu là lỗi chia hoặc không chuyển FiO₂ sang phân số.","remediation":"hb-pf","o":["90","120","600","300"],"a":3},
		{"id":"o19","topic":"oxygen","difficulty":"basic","lesson":"hb-respiratory-failure","cognitive":"understand","clinicalContext":"general","q":"Tăng PaCO₂ rõ trong suy hô hấp chủ yếu phản ánh thất bại của quá trình nào?","e":"PaCO₂ tăng khi thông khí phế nang không đủ tương đối với lượng CO₂ tạo ra.","distractorRationale":"Các phương án nhiễu không trực tiếp quyết định thải CO₂ qua phổi.","remediation":"hb-respiratory-failure","o":["Khuếch tán hemoglobin","Thông khí","Sản xuất albumin","Đông máu"],"a":1},
		{"id":"o20","topic":"oxygen","difficulty":"intermediate","lesson":"hb-oxygen-support","cognitive":"apply","clinicalContext":"oxygen-therapy","q":"Hai PaO₂ cùng 70 mmHg, một người thở khí phòng và một người FiO₂ 0,60. Vì sao ý nghĩa khác nhau?","e":"PaO₂ phải được đặt trong bối cảnh FiO₂ và hỗ trợ hô hấp; cùng PaO₂ trên FiO₂ cao cho thấy trao đổi khí kém hơn.","distractorRationale":"Các phương án nhiễu tách PaO₂ khỏi điều kiện oxy hoặc đảo mức độ suy giảm.","remediation":"hb-oxygen-support","o":["FiO₂ không ảnh hưởng diễn giải PaO₂","Người thở khí phòng luôn nặng hơn","Người FiO₂ 0,60 có mức suy giảm oxy hóa lớn hơn vì cần nhiều oxy hít vào để đạt cùng PaO₂","Chỉ PaCO₂ mới có ý nghĩa khi dùng oxy"],"a":2},
		{"id":"o21","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"analyze","clinicalContext":"general","q":"Giảm oxy máu với PaCO₂ tăng và chênh áp A–a không tăng nhiều hướng nhiều hơn tới cơ chế nào?","e":"Giảm thông khí làm giảm PAO₂ và tăng PaCO₂; nếu phổi không có thêm bất thường trao đổi khí, A–a có thể không tăng nhiều.","distractorRationale":"Các phương án nhiễu thường làm A–a tăng do vấn đề trao đổi khí trong phổi.","remediation":"hb-hypoxemia","o":["Luồng thông trong phổi lớn","Bất tương xứng thông khí–tưới máu nặng","Hạn chế khuếch tán đơn thuần","Giảm thông khí phế nang"],"a":3},
		{"id":"o22","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"analyze","clinicalContext":"altitude","q":"Người vừa lên vùng cao có PaO₂ giảm, PaCO₂ giảm và chênh áp A–a không tăng nhiều. Cơ chế hợp lý nhất là gì?","e":"Ở độ cao, áp suất khí quyển thấp làm giảm PIO₂/PAO₂; tăng thông khí thường làm PaCO₂ giảm.","distractorRationale":"Các phương án nhiễu không giải thích đồng thời độ cao, PaCO₂ thấp và A–a không tăng nhiều.","remediation":"hb-hypoxemia","o":["Luồng thông lớn chắc chắn","Ngộ độc carbon monoxit chắc chắn","Giảm oxy hít vào do áp suất khí quyển thấp kèm tăng thông khí","Tăng FiO₂"],"a":2},
		{"id":"o23","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"analyze","clinicalContext":"pulmonary","q":"Giảm oxy máu với chênh áp A–a tăng thường hướng tới nhóm cơ chế nào?","e":"A–a tăng cho thấy PAO₂ và PaO₂ tách xa nhau, gợi ý trở ngại trao đổi oxy từ phế nang vào máu.","distractorRationale":"Các phương án nhiễu chủ yếu không làm tăng chênh áp A–a theo cùng cơ chế.","remediation":"hb-hypoxemia","o":["Chỉ giảm thông khí đơn thuần","Chỉ giảm áp suất khí quyển","Chỉ thiếu máu","Bất tương xứng thông khí–tưới máu, luồng thông hoặc hạn chế khuếch tán"],"a":3},
		{"id":"o24","topic":"oxygen","difficulty":"intermediate","lesson":"hb-pf","cognitive":"apply","clinicalContext":"critical-care","q":"PaO₂ 60 mmHg ở FiO₂ 0,80 cho tỷ số P/F bao nhiêu?","e":"60/0,80 = 75.","distractorRationale":"Các phương án nhiễu là kết quả của chia sai hoặc dùng phần trăm thay phân số.","remediation":"hb-pf","o":["133","75","240","480"],"a":1},
		{"id":"o25","topic":"oxygen","difficulty":"intermediate","lesson":"hb-oxygen-support","cognitive":"analyze","clinicalContext":"ventilation","q":"Khi theo dõi PaO₂ ở người thở máy, ngoài FiO₂ còn nên ghi nhận yếu tố nào để so sánh xu hướng có ý nghĩa?","e":"PEEP và các thay đổi hỗ trợ có thể cải thiện/biến đổi oxy hóa; hai PaO₂ không tương đương nếu điều kiện máy khác nhau.","distractorRationale":"Các phương án nhiễu không trực tiếp mô tả điều kiện hỗ trợ hô hấp tại thời điểm lấy ABG.","remediation":"hb-oxygen-support","o":["Chỉ cân nặng","Chỉ kali","Mức hỗ trợ áp lực dương như PEEP và thay đổi cài đặt thông khí","Chỉ creatinine"],"a":2},
		{"id":"o26","topic":"oxygen","difficulty":"advanced","lesson":"hb-alveolar-equation","cognitive":"apply","clinicalContext":"general","q":"Ở mức biển, FiO₂ 0,21, PaCO₂ 40 mmHg, R≈0,8. PAO₂ ước tính gần nhất là bao nhiêu?","e":"0,21×(760−47) ≈150; trừ 40/0,8=50, nên PAO₂ ≈100 mmHg.","distractorRationale":"Các phương án nhiễu bỏ một thành phần của phương trình hoặc dùng trực tiếp PaCO₂/PIO₂.","remediation":"hb-alveolar-equation","o":["Khoảng 40 mmHg","Khoảng 150 mmHg","Khoảng 250 mmHg","Khoảng 100 mmHg"],"a":3},
		{"id":"o27","topic":"oxygen","difficulty":"advanced","lesson":"hb-aa-gradient","cognitive":"apply","clinicalContext":"general","q":"Nếu PAO₂ 100 mmHg và PaO₂ 60 mmHg, chênh áp A–a là bao nhiêu?","e":"A–a = 100 − 60 = 40 mmHg.","distractorRationale":"Các phương án nhiễu cộng hai giá trị, chọn PaO₂ hoặc chọn PAO₂ thay vì hiệu số.","remediation":"hb-aa-gradient","o":["160 mmHg","60 mmHg","40 mmHg","100 mmHg"],"a":2},
		{"id":"o28","topic":"oxygen","difficulty":"advanced","lesson":"hb-saturation","cognitive":"analyze","clinicalContext":"dyshemoglobinemia","q":"Trong ngộ độc carbon monoxit, nhận định nào đúng nhất về PaO₂?","e":"CO chủ yếu ảnh hưởng hemoglobin; PaO₂ không phản ánh trực tiếp tỷ lệ carboxyhemoglobin.","distractorRationale":"Các phương án nhiễu nhầm áp suất oxy hòa tan với dạng hemoglobin hoặc tuyệt đối hóa PaO₂.","remediation":"hb-saturation","o":["PaO₂ trực tiếp đo carboxyhemoglobin","PaO₂ luôn bằng 0","PaO₂ bình thường chứng minh không có ngộ độc carbon monoxit","PaO₂ có thể bình thường vì đo oxy hòa tan, nên không loại trừ giảm khả năng vận chuyển oxy do carboxyhemoglobin"],"a":3},
		{"id":"o29","topic":"oxygen","difficulty":"advanced","lesson":"hb-respiratory-failure","cognitive":"analyze","clinicalContext":"critical-care","q":"Người bệnh có PaO₂ thấp và PaCO₂ bình thường/thấp. Kết luận nào an toàn nhất?","e":"Oxy hóa và thông khí là hai trục khác nhau; PaCO₂ bình thường/thấp không loại trừ suy giảm oxy hóa nặng.","distractorRationale":"Các phương án nhiễu đồng nhất suy hô hấp với tăng CO₂ hoặc suy ra cơ chế duy nhất từ một biến.","remediation":"hb-respiratory-failure","o":["PaCO₂ không tăng nên không có suy hô hấp","Có suy giảm oxy hóa nhưng không thể quy nguyên nhân chỉ từ PaCO₂; cần FiO₂, A–a và bệnh cảnh","Chắc chắn chỉ do giảm thông khí","Chắc chắn do luồng thông"],"a":1},
		{"id":"o30","topic":"oxygen","difficulty":"advanced","lesson":"hb-oxygen-summary","cognitive":"analyze","clinicalContext":"general","q":"Chuỗi đánh giá nào phù hợp nhất khi gặp PaO₂ thấp?","e":"Cách tiếp cận có cấu trúc tách thông khí khỏi oxy hóa và đặt PaO₂ trong điều kiện đo trước khi suy luận cơ chế.","distractorRationale":"Các phương án nhiễu dùng một chỉ số đơn lẻ hoặc chuyển sang xử trí mà chưa đánh giá dữ liệu.","remediation":"hb-oxygen-summary","o":["Chỉ nhìn SpO₂ rồi kết luận cơ chế","Chỉ tính P/F rồi chẩn đoán nguyên nhân","Xác nhận FiO₂/hỗ trợ → xem PaCO₂ → ước tính PAO₂/A–a khi phù hợp → đặt P/F và bệnh cảnh → cân nhắc cơ chế","Chỉ tăng FiO₂ trong mọi trường hợp mà không kiểm tra dữ liệu"],"a":2},
		{"id":"c13","topic":"clinical","difficulty":"basic","lesson":"hb-case-dka","cognitive":"apply","clinicalContext":"diabetes","q":"Đái tháo đường, pH 7,18, HCO₃⁻ 9 mmol/L, ceton tăng. Mẫu hình toan–kiềm chính cần nhận diện là gì?","e":"HCO₃⁻ giảm rõ cùng pH thấp phù hợp toan chuyển hóa; tiếp theo đánh giá khoảng trống anion và bù hô hấp.","distractorRationale":"Các phương án nhiễu không phù hợp hướng HCO₃⁻/pH hoặc chọn rối loạn hô hấp chưa có dữ kiện.","remediation":"hb-case-dka","o":["Kiềm chuyển hóa","Toan hô hấp","Kiềm hô hấp","Toan chuyển hóa"],"a":3},
		{"id":"c14","topic":"clinical","difficulty":"basic","lesson":"hb-case-sglt2","cognitive":"understand","clinicalContext":"diabetes","q":"Người dùng thuốc ức chế SGLT2 có buồn nôn, thở nhanh và HCO₃⁻ thấp nhưng glucose không rất cao. Dữ kiện nào vẫn cần kiểm tra trực tiếp?","e":"Nhiễm toan ceton liên quan SGLT2 có thể xuất hiện với glucose không quá cao; ceton và toan chuyển hóa phải được đánh giá trực tiếp.","distractorRationale":"Các phương án nhiễu là xét nghiệm không trả lời câu hỏi cấp tính về nhiễm toan ceton.","remediation":"hb-case-sglt2","o":["Chỉ HbA1c","Chỉ cholesterol","Ceton và khoảng trống anion","Chỉ số lượng tiểu cầu"],"a":2},
		{"id":"c15","topic":"clinical","difficulty":"basic","lesson":"hb-case-sepsis","cognitive":"understand","clinicalContext":"sepsis","q":"Trong sốc nhiễm trùng có lactat tăng, vì sao một giá trị lactat đơn lẻ không đủ xác định cơ chế cuối cùng?","e":"Lactat là chỉ dấu quan trọng nhưng có nhiều cơ chế; xu hướng và toàn cảnh lâm sàng quyết định cách diễn giải.","distractorRationale":"Các phương án nhiễu phủ nhận giá trị lactat hoặc quy mọi tăng lactat về một cơ chế duy nhất.","remediation":"hb-case-sepsis","o":["Lactat không bao giờ có ý nghĩa","Lactat chỉ phản ánh chức năng thận","Lactat luôn do thiếu oxy mô tuyệt đối","Lactat phải được đặt cùng huyết động, tưới máu, xu hướng và bệnh cảnh"],"a":3},
		{"id":"c16","topic":"clinical","difficulty":"basic","lesson":"hb-case-copd","cognitive":"apply","clinicalContext":"copd","q":"COPD có PaCO₂ 70 mmHg và pH 7,28. Dữ kiện nào giúp nhất để phân biệt cấp với cấp trên nền mạn?","e":"Mức HCO₃⁻ và PaCO₂ nền phản ánh đáp ứng thận theo thời gian, giúp nhận diện thành phần mạn.","distractorRationale":"Các phương án nhiễu không đánh giá thời gian của tăng CO₂.","remediation":"hb-case-copd","o":["Chỉ glucose","HCO₃⁻ và ABG nền trước đó nếu có","Chỉ PaO₂","Chỉ natri"],"a":1},
		{"id":"c17","topic":"clinical","difficulty":"basic","lesson":"hb-case-opioid","cognitive":"apply","clinicalContext":"toxicology","q":"Giảm tri giác sau opioid, thở chậm, pH thấp và PaCO₂ tăng phù hợp nhất với cơ chế nào?","e":"Ức chế hô hấp làm giảm thải CO₂, tăng PaCO₂ và gây toan hô hấp.","distractorRationale":"Các phương án nhiễu chọn cơ chế ngược hoặc rối loạn chuyển hóa không phù hợp bệnh cảnh.","remediation":"hb-case-opioid","o":["Tăng thông khí gây kiềm hô hấp","Mất HCO₃⁻ qua ruột","Kiềm chuyển hóa do nôn","Giảm thông khí phế nang gây toan hô hấp"],"a":3},
		{"id":"c18","topic":"clinical","difficulty":"basic","lesson":"hb-case-vomiting","cognitive":"apply","clinicalContext":"gastrointestinal","q":"Nôn kéo dài, pH 7,51 và HCO₃⁻ 38 mmol/L phù hợp nhất với mẫu hình nào?","e":"Mất acid dạ dày và giảm clo thường đi cùng kiềm chuyển hóa; PaCO₂ giúp đánh giá bù hô hấp.","distractorRationale":"Các phương án nhiễu không phù hợp hướng HCO₃⁻/pH hoặc bỏ bối cảnh nôn.","remediation":"hb-case-vomiting","o":["Toan chuyển hóa","Kiềm hô hấp đơn thuần","Kiềm chuyển hóa","Toan hô hấp"],"a":2},
		{"id":"c19","topic":"clinical","difficulty":"basic","lesson":"hb-case-diarrhea","cognitive":"apply","clinicalContext":"gastrointestinal","q":"Tiêu chảy nhiều ngày, HCO₃⁻ thấp và khoảng trống anion không tăng rõ. Cơ chế chuyển hóa phù hợp nhất là gì?","e":"Mất HCO₃⁻ qua phân thường gây toan chuyển hóa tăng clo, không tăng khoảng trống anion.","distractorRationale":"Các phương án nhiễu chọn hướng chuyển hóa ngược hoặc cơ chế hô hấp không giải thích mất bicarbonat.","remediation":"hb-case-diarrhea","o":["Kiềm chuyển hóa do giữ bicarbonat","Toan hô hấp do giữ CO₂","Kiềm hô hấp do tăng thông khí là nguyên nhân duy nhất","Mất bicarbonat qua đường tiêu hóa gây toan chuyển hóa không tăng khoảng trống anion"],"a":3},
		{"id":"c20","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-salicylate","cognitive":"analyze","clinicalContext":"toxicology","q":"pH 7,46; PaCO₂ 21 mmHg; HCO₃⁻ 14 mmol/L trong bối cảnh nghi salicylat. Mẫu hình phù hợp nhất là gì?","e":"PaCO₂ rất thấp tạo kiềm hô hấp trong khi HCO₃⁻ thấp hơn mức bù đơn thuần, gợi ý thêm toan chuyển hóa.","distractorRationale":"Các phương án nhiễu bỏ thành phần phối hợp hoặc chọn hướng trái ngược.","remediation":"hb-case-salicylate","o":["Kiềm hô hấp đơn thuần","Kiềm hô hấp phối hợp toan chuyển hóa","Toan hô hấp phối hợp kiềm chuyển hóa","Khí máu bình thường"],"a":1},
		{"id":"c21","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-hypoxemia","cognitive":"analyze","clinicalContext":"pulmonary","q":"Khó thở cấp, PaO₂ thấp, PaCO₂ thấp và A–a tăng. Khí máu cho phép kết luận nào?","e":"ABG định hướng cơ chế nhưng không tự xác lập nguyên nhân; A–a tăng cho thấy vấn đề trao đổi khí trong phổi.","distractorRationale":"Các phương án nhiễu biến mẫu hình sinh lý thành chẩn đoán nguyên nhân chắc chắn hoặc bỏ qua PaO₂.","remediation":"hb-case-hypoxemia","o":["Chắc chắn thuyên tắc phổi","Chắc chắn viêm phổi","Có rối loạn oxy hóa kèm tăng thông khí; nguyên nhân cụ thể vẫn cần bệnh cảnh và dữ liệu khác","Không có suy giảm oxy hóa vì PaCO₂ thấp"],"a":2},
		{"id":"c22","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-ventilator","cognitive":"apply","clinicalContext":"ventilation","q":"Người thở máy có PaO₂ 65 mmHg. Thông tin nào bắt buộc để đặt giá trị này vào bối cảnh?","e":"PaO₂ trên thở máy chỉ có ý nghĩa khi biết điều kiện oxy và hỗ trợ áp lực tại lúc lấy mẫu.","distractorRationale":"Các phương án nhiễu không mô tả điều kiện hô hấp ảnh hưởng trực tiếp tới oxy hóa.","remediation":"hb-case-ventilator","o":["Chỉ tuổi","Chỉ glucose","Chỉ cân nặng","FiO₂ và mức hỗ trợ áp lực dương/cài đặt liên quan tại thời điểm lấy mẫu"],"a":3},
		{"id":"c23","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-co","cognitive":"analyze","clinicalContext":"toxicology","q":"Sau hít khói, đau đầu và lú lẫn, PaO₂ 98 mmHg. Dữ kiện nào vẫn cần nếu nghi ngộ độc carbon monoxit?","e":"PaO₂ bình thường không loại trừ CO vì đo oxy hòa tan; cần định lượng dạng hemoglobin khi bệnh cảnh phù hợp.","distractorRationale":"Các phương án nhiễu không đo trực tiếp carboxyhemoglobin.","remediation":"hb-case-co","o":["Chỉ HCO₃⁻","Chỉ natri","Carboxyhemoglobin bằng đồng oxy kế","Chỉ PaCO₂"],"a":2},
		{"id":"c24","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-airbubble","cognitive":"analyze","clinicalContext":"preanalytical","q":"Mẫu có bọt khí đáng kể và PaO₂ thay đổi bất ngờ so với lâm sàng. Cách xử lý suy luận phù hợp nhất là gì?","e":"Bọt khí có thể làm khí hòa tan dịch chuyển; không có một công thức sửa số đơn giản đáng tin cậy cho mẫu bị nhiễm khí đáng kể.","distractorRationale":"Các phương án nhiễu khuyến khích hiệu chỉnh tùy ý hoặc bỏ qua lỗi tiền phân tích.","remediation":"hb-case-airbubble","o":["Hiệu chỉnh PaO₂ bằng cách cộng 20 mmHg","Giả định PaO₂ thật bằng SpO₂","Bỏ qua bọt khí nếu pH bình thường","Đánh dấu độ tin cậy thấp và xem xét lấy lại mẫu đúng kỹ thuật trước khi diễn giải sâu"],"a":3},
		{"id":"c25","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-sepsis","cognitive":"analyze","clinicalContext":"serial","q":"Lactat giảm từ 5,0 xuống 3,0 mmol/L nhưng huyết động vẫn không ổn định. Kết luận nào hợp lý nhất?","e":"Xu hướng tốt không đủ để kết luận toàn bộ tình trạng đã ổn; phải tích hợp với huyết động và bệnh cảnh.","distractorRationale":"Các phương án nhiễu biến một chỉ dấu cải thiện thành kết luận tuyệt đối.","remediation":"hb-case-sepsis","o":["Người bệnh đã hồi phục hoàn toàn","Xu hướng lactat cải thiện là dữ kiện có ích nhưng không thay thế đánh giá huyết động và tưới máu hiện tại","Lactat còn 3,0 chứng minh không còn sốc","Không cần theo dõi thêm"],"a":1},
		{"id":"c26","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-copd","cognitive":"analyze","clinicalContext":"serial","q":"COPD có PaCO₂ nền 55 mmHg; hiện 75 mmHg, pH giảm rõ. Nhận định nào phù hợp nhất?","e":"So sánh với nền cho thấy PaCO₂ tăng thêm và pH xấu đi, phù hợp thành phần cấp chồng lên trạng thái mạn.","distractorRationale":"Các phương án nhiễu chọn sai hướng hoặc bỏ dữ liệu dọc có giá trị.","remediation":"hb-case-copd","o":["Chỉ là kiềm hô hấp","ABG hoàn toàn bình thường","PaCO₂ nền không có giá trị","Có thành phần tăng CO₂ cấp trên nền tăng CO₂ mạn cần được cân nhắc"],"a":3},
		{"id":"c27","topic":"clinical","difficulty":"advanced","lesson":"hb-case-dka","cognitive":"analyze","clinicalContext":"diabetes","q":"DKA có HCO₃⁻ 10 mmol/L. PaCO₂ thực đo 40 mmHg. So với Winter, điều gì đáng chú ý?","e":"Winter dự kiến khoảng 23 ± 2 mmHg; PaCO₂ 40 cao hơn rõ, cho thấy giảm thông khí tương đối và thêm toan hô hấp.","distractorRationale":"Các phương án nhiễu tính sai mức bù hoặc đảo hướng sai lệch.","remediation":"hb-case-dka","o":["PaCO₂ hoàn toàn phù hợp bù","Có kiềm hô hấp phối hợp","PaCO₂ cao hơn nhiều so với mức bù dự kiến, gợi ý toan hô hấp phối hợp","Không thể dùng Winter trong toan chuyển hóa"],"a":2},
		{"id":"c28","topic":"clinical","difficulty":"advanced","lesson":"hb-case-sglt2","cognitive":"analyze","clinicalContext":"diabetes","q":"Người dùng SGLT2 có glucose 11 mmol/L, ceton tăng, pH 7,24, HCO₃⁻ 12 mmol/L. Điểm nào quan trọng nhất?","e":"SGLT2 có thể liên quan nhiễm toan ceton với glucose chỉ tăng vừa; dữ liệu acid–base và ceton là then chốt.","distractorRationale":"Các phương án nhiễu dùng ngưỡng glucose tuyệt đối hoặc bỏ qua ceton/toan chuyển hóa.","remediation":"hb-case-sglt2","o":["Glucose dưới 20 mmol/L loại trừ hoàn toàn nhiễm toan ceton","Chỉ cần đánh giá PaO₂","Ceton tăng không liên quan nếu glucose không rất cao","Mức glucose không quá cao không loại trừ nhiễm toan ceton; cần đọc ceton và toan–kiềm cùng nhau"],"a":3},
		{"id":"c29","topic":"clinical","difficulty":"advanced","lesson":"hb-case-ventilator","cognitive":"analyze","clinicalContext":"critical-care","q":"Hai ABG có PaO₂ lần lượt 70 và 80 mmHg, nhưng FiO₂ giảm từ 0,80 xuống 0,40. Diễn giải nào hợp lý nhất?","e":"PaO₂ phải được đọc cùng FiO₂; đạt PaO₂ cao hơn trên FiO₂ thấp hơn cho thấy hiệu quả oxy hóa tốt hơn đáng kể.","distractorRationale":"Các phương án nhiễu so sánh PaO₂ tách khỏi điều kiện oxy hoặc đảo chiều cải thiện.","remediation":"hb-case-ventilator","o":["PaO₂ chỉ tăng 10 mmHg nên gần như không thay đổi","Oxy hóa đã cải thiện đáng kể hơn mức thay đổi PaO₂ đơn thuần gợi ý vì PaO₂ tăng dù FiO₂ giảm","FiO₂ không cần xem khi so sánh","Mẫu thứ hai chắc chắn xấu hơn"],"a":1},
		{"id":"c30","topic":"clinical","difficulty":"advanced","lesson":"hb-case-hypoxemia","cognitive":"analyze","clinicalContext":"pulmonary","q":"Người bệnh thiếu máu nặng có PaO₂ và SaO₂ tương đối bảo tồn nhưng biểu hiện thiếu oxy mô. Nguyên tắc nào giải thích tốt nhất?","e":"Phần lớn oxy được vận chuyển gắn hemoglobin; hàm lượng oxy có thể thấp khi Hb thấp dù PaO₂ bình thường.","distractorRationale":"Các phương án nhiễu đồng nhất áp suất oxy với tổng khả năng vận chuyển oxy.","remediation":"hb-case-hypoxemia","o":["PaO₂ bình thường luôn bảo đảm cung cấp oxy mô đầy đủ","Hemoglobin không tham gia vận chuyển oxy","PaO₂ không phản ánh đầy đủ hàm lượng oxy; khả năng vận chuyển còn phụ thuộc hemoglobin","SaO₂ và PaO₂ là cùng một đại lượng"],"a":2}
	];
	/* v5.2 — 20 ca lâm sàng × 3 câu; metadata progressive/serial-ready. */
	var ASSESSMENT_V52_CASE_QUESTIONS = [{"id":"f31","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"understand","clinicalContext":"case-based","q":"Dữ kiện nào cần được ưu tiên xem xét trước khi diễn giải PaO₂ 148 mmHg?","o":["Chất lượng mẫu bị nghi ngờ do bọt khí có thể làm thay đổi các khí hòa tan","PaO₂ 148 mmHg chứng minh oxy hóa hoàn toàn bình thường","Chỉ cần bỏ qua PaCO₂ vì bọt khí không ảnh hưởng CO₂","SpO₂ 92% chắc chắn sai vì PaO₂ cao"],"a":0,"e":"Không khí trong bơm tiêm có thể làm PO₂ của mẫu dịch chuyển về áp suất oxy của không khí xung quanh và làm thay đổi PaCO₂/pH; cần đánh giá độ tin cậy mẫu trước.","distractorRationale":"Các phương án nhiễu coi kết quả là tuyệt đối hoặc bỏ qua lỗi tiền phân tích đã hiện diện.","remediation":"hb-sampling","case_id":"fcase01","case_title":"Bọt khí trong bơm tiêm khí máu","case_vignette":"Người bệnh đang thở khí phòng, SpO₂ 92%. Mẫu khí máu động mạch có bọt khí nhìn thấy trước khi đưa vào máy; kết quả PaO₂ 148 mmHg, PaCO₂ 31 mmHg.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"air-bubble-preanalytical","error_pattern":"sample_quality_error"},{"id":"f32","topic":"foundation","difficulty":"intermediate","lesson":"hb-sampling","cognitive":"apply","clinicalContext":"case-based","q":"Mẫu hình thay đổi nào phù hợp nhất với việc máu tiếp xúc đáng kể với không khí?","o":["PaO₂ luôn giảm về 0, PaCO₂ tăng và pH giảm","PaO₂ có xu hướng tiến về giá trị của không khí môi trường, PaCO₂ có thể giảm và pH có thể tăng","Chỉ HCO₃⁻ thay đổi, còn PaO₂ và PaCO₂ không đổi","Mọi thông số đều tăng theo cùng một tỷ lệ cố định"],"a":1,"e":"Trao đổi khí giữa bọt khí và mẫu có thể kéo PO₂ về gần áp suất oxy môi trường; mất CO₂ có thể làm PaCO₂ giảm và pH tăng.","distractorRationale":"Các phương án nhiễu mô tả sai chiều trao đổi khí hoặc giả định có hệ số hiệu chỉnh cố định.","remediation":"hb-sampling","case_id":"fcase01","case_title":"Bọt khí trong bơm tiêm khí máu","case_vignette":"Cùng mẫu trên được để vài phút khi vẫn còn bọt khí. PaO₂ cao bất thường, PaCO₂ thấp hơn dự kiến và pH hơi tăng.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"air-bubble-effect","error_pattern":"sample_quality_error"},{"id":"f33","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","clinicalContext":"case-based","q":"Cách xử lý suy luận an toàn nhất đối với kết quả khí máu này là gì?","o":["Tự trừ 20 mmHg khỏi PaO₂ để “sửa” kết quả","Dùng riêng pH của mẫu và bỏ qua toàn bộ bối cảnh","Đánh dấu độ tin cậy thấp và ưu tiên lấy lại mẫu đúng kỹ thuật nếu kết quả ảnh hưởng quyết định lâm sàng","Coi kết quả là chính xác vì máy phân tích không báo lỗi"],"a":2,"e":"Không có công thức sửa đơn giản đáng tin cậy cho mẫu có bọt khí đáng kể; khi kết quả không phù hợp lâm sàng nên xử lý vấn đề tiền phân tích và lấy lại mẫu theo quy trình.","distractorRationale":"Các phương án nhiễu đề xuất hiệu chỉnh tùy ý hoặc tin tuyệt đối vào máy dù tính toàn vẹn mẫu đã bị ảnh hưởng.","remediation":"hb-sampling","case_id":"fcase01","case_title":"Bọt khí trong bơm tiêm khí máu","case_vignette":"Lâm sàng và SpO₂ không phù hợp với kết quả khí máu; bọt khí đã được xác nhận trong mẫu.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"sample-recollection-decision","error_pattern":"sample_quality_error"},{"id":"f34","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"understand","clinicalContext":"case-based","q":"Nguyên nhân tiền phân tích nào cần được nghĩ đến trước tiên?","o":["Máy phân tích chắc chắn bị hỏng","Mọi mẫu lấy từ đường động mạch đều thấp hơn mẫu chọc trực tiếp","Pha loãng chỉ ảnh hưởng glucose, không ảnh hưởng khí máu","Mẫu có thể bị pha loãng bởi dịch còn trong đường lấy mẫu"],"a":3,"e":"Dịch tồn lưu trong catheter/đường lấy mẫu có thể pha loãng mẫu và làm sai nhiều chất phân tích; phải tuân thủ quy trình lấy mẫu từ đường động mạch của cơ sở.","distractorRationale":"Các phương án nhiễu quy kết lỗi thiết bị hoặc phủ nhận ảnh hưởng pha loãng của dịch tồn lưu.","remediation":"hb-sampling","case_id":"fcase02","case_title":"Nhiễm dịch từ đường động mạch","case_vignette":"Khí máu được lấy từ đường động mạch ngay sau khi đường truyền vừa được bơm rửa. Mẫu đầu cho nhiều thông số thấp bất ngờ so với lâm sàng.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"line-contamination","error_pattern":"sample_quality_error"},{"id":"f35","topic":"foundation","difficulty":"intermediate","lesson":"hb-sampling","cognitive":"apply","clinicalContext":"case-based","q":"Đặc điểm nào làm tăng nghi ngờ mẫu bị pha loãng hơn là một rối loạn sinh lý đơn thuần?","o":["Nhiều chất phân tích cùng thay đổi theo hướng pha loãng và không phù hợp với bối cảnh lâm sàng","Chỉ một thông số duy nhất thay đổi theo đúng bệnh cảnh","PaCO₂ tăng trong khi mọi điện giải ổn định","Kết quả lặp lại từ mẫu chọc động mạch giống hệt mẫu đầu"],"a":0,"e":"Sai lệch đồng thời của nhiều chất phân tích, đặc biệt khi không phù hợp lâm sàng và có nguy cơ dịch tồn lưu, là dấu hiệu quan trọng của nhiễm/pha loãng mẫu.","distractorRationale":"Các phương án nhiễu mô tả dữ kiện làm giảm chứ không tăng khả năng nhiễm dịch.","remediation":"hb-sampling","case_id":"fcase02","case_title":"Nhiễm dịch từ đường động mạch","case_vignette":"Ở mẫu nghi pha loãng, PaCO₂, HCO₃⁻ và một số điện giải cùng thấp bất thường so với các xét nghiệm gần thời điểm đó.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"dilution-pattern","error_pattern":"sample_quality_error"},{"id":"f36","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","clinicalContext":"case-based","q":"Nguyên tắc nào phù hợp nhất khi so sánh hai kết quả?","o":["Lấy trung bình hai mẫu để có giá trị “thật”","Ưu tiên mẫu có tính toàn vẹn tốt hơn và không cố hiệu chỉnh số học mẫu đã nghi nhiễm dịch","Luôn chọn mẫu đầu vì lấy trước","Chỉ so sánh pH, còn các thông số khác không cần xem"],"a":1,"e":"Khi có bằng chứng lỗi tiền phân tích, kết quả của mẫu lỗi không nên được “sửa” bằng phép tính tùy ý; mẫu lấy đúng kỹ thuật có giá trị diễn giải cao hơn.","distractorRationale":"Các phương án nhiễu tạo ra quy tắc số học không được thẩm định hoặc ưu tiên mẫu kém tin cậy.","remediation":"hb-sampling","case_id":"fcase02","case_title":"Nhiễm dịch từ đường động mạch","case_vignette":"Mẫu đầu nghi nhiễm dịch; một mẫu mới được lấy lại theo đúng quy trình đường động mạch và phù hợp rõ hơn với lâm sàng.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"handbook:preanalytical","concept":"preanalytical-priority","error_pattern":"sample_quality_error"},{"id":"f37","topic":"foundation","difficulty":"basic","lesson":"hb-core","cognitive":"understand","clinicalContext":"case-based","q":"Bước kiểm tra nào quan trọng nhất trước khi kết luận người bệnh giảm oxy máu nặng?","o":["Bỏ qua SpO₂ vì khí máu luôn đúng tuyệt đối","Chẩn đoán ngay luồng thông trong phổi","Xác minh lại vị trí lấy và loại mẫu thực sự là động mạch hay tĩnh mạch","Giả định PO₂ tĩnh mạch có thể thay trực tiếp PaO₂"],"a":2,"e":"Khi PO₂ không phù hợp với SpO₂ và bệnh cảnh, cần xác minh loại mẫu; PO₂ tĩnh mạch không thể dùng thay PaO₂ để định lượng oxy hóa động mạch.","distractorRationale":"Các phương án nhiễu bỏ qua tính nhất quán dữ liệu hoặc đồng nhất PO₂ tĩnh mạch với PaO₂.","remediation":"hb-core","case_id":"fcase03","case_title":"Nhầm loại mẫu động mạch – tĩnh mạch","case_vignette":"Phiếu ghi “khí máu động mạch”, nhưng người bệnh có SpO₂ 96% trong khi PO₂ của mẫu chỉ 38 mmHg; pH và PCO₂ tương đối phù hợp với mẫu tĩnh mạch.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"sample-type-verification","error_pattern":"sample_quality_error"},{"id":"f38","topic":"foundation","difficulty":"intermediate","lesson":"hb-core","cognitive":"apply","clinicalContext":"case-based","q":"Thông số nào của mẫu tĩnh mạch đặc biệt không nên được dùng thay trực tiếp giá trị động mạch khi đánh giá oxy hóa?","o":["pH trong mọi hoàn cảnh","Bicarbonat trong mọi hoàn cảnh","Natri trong mọi hoàn cảnh","PO₂"],"a":3,"e":"PO₂ tĩnh mạch chịu ảnh hưởng chiết xuất oxy ở mô và không đại diện cho PaO₂; vì vậy không dùng trực tiếp để định lượng oxy hóa động mạch.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa hạn chế của các thông số khác hoặc bỏ qua khác biệt sinh lý chính của PO₂.","remediation":"hb-core","case_id":"fcase03","case_title":"Nhầm loại mẫu động mạch – tĩnh mạch","case_vignette":"Sau khi kiểm tra, mẫu đầu được xác nhận là tĩnh mạch ngoại vi.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"venous-po2-limitation","error_pattern":"knowledge_gap"},{"id":"f39","topic":"foundation","difficulty":"advanced","lesson":"hb-core","cognitive":"analyze","clinicalContext":"case-based","q":"Cách tiếp cận nào phù hợp nhất trong tình huống này?","o":["Sử dụng mẫu động mạch đáng tin cậy hoặc phương pháp đánh giá oxy hóa đã được thẩm định cho bối cảnh cụ thể","Dùng PO₂ tĩnh mạch và cộng cố định 40 mmHg","Chỉ dùng PCO₂ tĩnh mạch để suy ra PaO₂","Không cần đánh giá thêm vì đã có một mẫu tĩnh mạch"],"a":0,"e":"Khi cần định lượng oxy hóa động mạch, phải dựa vào dữ liệu phù hợp và có độ tin cậy; không có phép cộng cố định biến PO₂ tĩnh mạch thành PaO₂.","distractorRationale":"Các phương án nhiễu dùng quy đổi không được thẩm định hoặc bỏ qua nhu cầu đánh giá oxy hóa đáng tin cậy.","remediation":"hb-core","case_id":"fcase03","case_title":"Nhầm loại mẫu động mạch – tĩnh mạch","case_vignette":"Người bệnh vẫn cần đánh giá chính xác mức oxy hóa vì SpO₂ không ổn định và quyết định hỗ trợ hô hấp phụ thuộc kết quả.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"arterial-oxygenation-validation","error_pattern":"context_omission"},{"id":"f40","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"understand","clinicalContext":"case-based","q":"Hiện tượng nào giải thích hợp lý nhất chênh lệch PaO₂ giữa T0 và T1?","o":["SpO₂ luôn tăng giả khi bạch cầu cao","Tế bào trong mẫu tiếp tục tiêu thụ oxy khi phân tích chậm, gây giảm PaO₂ giả","Máy phân tích tự tăng PaO₂ ở mẫu thứ hai","PaO₂ động mạch thật luôn tăng hơn 30 mmHg sau một lần lấy máu"],"a":1,"e":"Ở số lượng tế bào rất cao, tiêu thụ oxy sau lấy mẫu có thể làm PO₂ giảm đáng kể nếu xử lý chậm; phân tích nhanh làm giảm sai số này.","distractorRationale":"Các phương án nhiễu quy sai cơ chế hoặc coi khác biệt là thay đổi sinh lý bắt buộc.","remediation":"hb-sampling","case_id":"fcase04","case_title":"Giảm oxy giả do tăng bạch cầu và chậm phân tích","case_vignette":"Người bệnh bạch cầu tăng rất cao, SpO₂ 96%. Mẫu T0 được phân tích sau 25 phút cho PaO₂ 45 mmHg; mẫu T1 lấy lại và phân tích ngay cho PaO₂ 82 mmHg.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"handbook:preanalytical","concept":"leukocyte-larceny","error_pattern":"sample_quality_error"},{"id":"f41","topic":"foundation","difficulty":"intermediate","lesson":"hb-sampling","cognitive":"apply","clinicalContext":"case-based","q":"Dữ kiện nào củng cố mạnh nhất giả thuyết giảm oxy giả ngoài cơ thể?","o":["PaCO₂ ở cả hai mẫu đều đo được","Người bệnh có cùng tuổi ở hai thời điểm","PaO₂ cải thiện rõ khi rút ngắn thời gian xử lý trong khi SpO₂ lâm sàng gần như không đổi","Máy phân tích dùng cùng đơn vị mmHg"],"a":2,"e":"Mối liên hệ giữa độ trễ xử lý và PaO₂, cùng sự bất tương hợp với SpO₂ ổn định, là manh mối quan trọng của tiêu thụ oxy trong mẫu.","distractorRationale":"Các phương án nhiễu nêu dữ kiện không phân biệt được cơ chế tiền phân tích.","remediation":"hb-sampling","case_id":"fcase04","case_title":"Giảm oxy giả do tăng bạch cầu và chậm phân tích","case_vignette":"T0: PaO₂ 45 mmHg sau 25 phút. T1: PaO₂ 82 mmHg khi phân tích ngay; SpO₂ lâm sàng duy trì 95–96% trong cả hai thời điểm.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"handbook:preanalytical","concept":"serial-preanalytical-comparison","error_pattern":"sample_quality_error"},{"id":"f42","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","clinicalContext":"case-based","q":"Nguyên tắc nào quan trọng nhất khi dùng chuỗi PaO₂ để theo dõi người bệnh này?","o":["Có thể trộn lẫn mẫu xử lý chậm và mẫu xử lý ngay trong cùng một xu hướng","Không cần ghi thời điểm phân tích nếu PaO₂ được máy trả số","Chỉ cần so sánh pH, không cần quan tâm PaO₂","Chỉ so sánh xu hướng khi điều kiện lấy và thời gian xử lý mẫu đủ tương đồng"],"a":3,"e":"Xu hướng nối tiếp chỉ có ý nghĩa khi các điều kiện tiền phân tích đủ tương đương; nếu không, thay đổi có thể phản ánh quy trình hơn là sinh lý.","distractorRationale":"Các phương án nhiễu bỏ qua tính so sánh được của các phép đo nối tiếp.","remediation":"hb-sampling","case_id":"fcase04","case_title":"Giảm oxy giả do tăng bạch cầu và chậm phân tích","case_vignette":"Sau khi chuẩn hóa quy trình, các mẫu sau đều được phân tích ngay và PaO₂ trở nên nhất quán với SpO₂.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"handbook:preanalytical","concept":"serial-comparability","error_pattern":"sample_quality_error"},{"id":"f43","topic":"foundation","difficulty":"basic","lesson":"hb-reading","cognitive":"understand","clinicalContext":"case-based","q":"Thông tin nào bắt buộc phải đi cùng PaO₂ khi so sánh T0 và T1?","o":["FiO₂, thiết bị hỗ trợ oxy và thời điểm lấy mẫu so với thay đổi hỗ trợ","Chỉ chiều cao người bệnh","Chỉ nồng độ natri","Chỉ nhóm máu ABO"],"a":0,"e":"PaO₂ phải được diễn giải trong điều kiện oxy cụ thể; thay đổi FiO₂ và thời điểm lấy mẫu quyết định khả năng so sánh giữa các lần đo.","distractorRationale":"Các phương án nhiễu nêu dữ kiện không quyết định điều kiện oxy hóa tại thời điểm lấy mẫu.","remediation":"hb-reading","case_id":"fcase05","case_title":"Thay đổi hỗ trợ oxy ngay trước khi lấy mẫu","case_vignette":"Mẫu T0 được lấy khi FiO₂ 0,28. Trước mẫu T1 khoảng 2 phút, FiO₂ được tăng lên 0,50; T1 cho PaO₂ cao hơn.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"oxygen-context-documentation","error_pattern":"context_omission"},{"id":"f44","topic":"foundation","difficulty":"intermediate","lesson":"hb-reading","cognitive":"apply","clinicalContext":"case-based","q":"Vì sao không nên kết luận chỉ từ việc PaO₂ tăng 68 lên 92 mmHg rằng trao đổi khí đã cải thiện?","o":["PaO₂ không bao giờ thay đổi theo FiO₂","Điều kiện FiO₂ khác nhau và T1 được lấy rất sớm sau thay đổi nên hai giá trị không đại diện cùng điều kiện đo","PaO₂ chỉ có ý nghĩa khi bằng đúng 100 mmHg","Mọi thay đổi PaO₂ dưới 30 mmHg đều là sai số máy"],"a":1,"e":"So sánh PaO₂ tuyệt đối giữa hai FiO₂ khác nhau có thể gây hiểu sai; thời điểm sau thay đổi hỗ trợ cũng cần đủ để phản ánh trạng thái mới.","distractorRationale":"Các phương án nhiễu phủ nhận sinh lý oxy hoặc dùng ngưỡng tùy ý.","remediation":"hb-reading","case_id":"fcase05","case_title":"Thay đổi hỗ trợ oxy ngay trước khi lấy mẫu","case_vignette":"T0: PaO₂ 68 mmHg ở FiO₂ 0,28. T1: PaO₂ 92 mmHg ở FiO₂ 0,50, lấy chỉ 2 phút sau thay đổi.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"serial-oxygen-context","error_pattern":"context_omission"},{"id":"f45","topic":"foundation","difficulty":"advanced","lesson":"hb-reading","cognitive":"analyze","clinicalContext":"case-based","q":"Điều gì làm T2 phù hợp hơn T1 để đánh giá đáp ứng oxy hóa?","o":["T2 luôn chính xác hơn chỉ vì lấy muộn hơn","FiO₂ không cần biết nếu PaO₂ trên 60 mmHg","Điều kiện hỗ trợ được ghi nhận rõ và mẫu được lấy sau khi trạng thái mới đã ổn định hơn","Chỉ cần PaCO₂ giống T0 là đủ"],"a":2,"e":"Đánh giá nối tiếp tốt cần điều kiện đo được xác định và đủ ổn định; không chỉ dựa vào thứ tự thời gian của mẫu.","distractorRationale":"Các phương án nhiễu biến thời gian thành tiêu chí tuyệt đối hoặc bỏ qua điều kiện hỗ trợ oxy.","remediation":"hb-reading","case_id":"fcase05","case_title":"Thay đổi hỗ trợ oxy ngay trước khi lấy mẫu","case_vignette":"Một mẫu T2 được lấy sau khi hỗ trợ oxy ổn định lâu hơn ở FiO₂ 0,50; các thông số lâm sàng cũng được ghi đầy đủ.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"serial-oxygen-stability","error_pattern":"context_omission"},{"id":"a31","topic":"acidbase","difficulty":"basic","lesson":"hb-case-dka","cognitive":"understand","clinicalContext":"case-based","q":"Rối loạn toan–kiềm chính ở T0 là gì?","o":["Kiềm chuyển hóa đơn thuần","Toan hô hấp đơn thuần","Kiềm hô hấp đơn thuần","Toan chuyển hóa tăng khoảng trống anion"],"a":3,"e":"Khoảng trống anion = 138 − (100 + 8) = 30 mmol/L, tăng rõ trong bối cảnh pH và HCO₃⁻ thấp.","distractorRationale":"Các phương án nhiễu chọn sai hướng pH hoặc bỏ qua khoảng trống anion.","remediation":"hb-case-dka","case_id":"acase01","case_title":"Nhiễm toan ceton: chuyển từ tăng khoảng trống anion sang tăng clo","case_vignette":"T0: pH 7,22; HCO₃⁻ 8 mmol/L; PaCO₂ 20 mmHg; Na⁺ 138 mmol/L; Cl⁻ 100 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"dka-high-anion-gap","error_pattern":"calculation_error"},{"id":"a32","topic":"acidbase","difficulty":"intermediate","lesson":"hb-case-dka","cognitive":"apply","clinicalContext":"case-based","q":"So với công thức Winter, PaCO₂ 20 mmHg ở T0 phù hợp nhất với nhận định nào?","o":["Đáp ứng hô hấp nằm trong khoảng bù dự kiến cho toan chuyển hóa","Có toan hô hấp phối hợp rõ","Có kiềm hô hấp phối hợp rõ","Không thể dùng công thức Winter khi HCO₃⁻ dưới 10 mmol/L"],"a":0,"e":"Winter: PaCO₂ dự kiến ≈ 1,5 × 8 + 8 = 20 ± 2 mmHg; giá trị đo được nằm trong khoảng dự kiến.","distractorRationale":"Các phương án nhiễu đảo hướng sai lệch hoặc phủ nhận ứng dụng của công thức bù.","remediation":"hb-case-dka","case_id":"acase01","case_title":"Nhiễm toan ceton: chuyển từ tăng khoảng trống anion sang tăng clo","case_vignette":"T0 vẫn có HCO₃⁻ 8 mmol/L và PaCO₂ 20 mmHg.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"winter-compensation","error_pattern":"calculation_error"},{"id":"a33","topic":"acidbase","difficulty":"advanced","lesson":"hb-case-dka","cognitive":"analyze","clinicalContext":"case-based","q":"HCO₃⁻ vẫn thấp ở T1 dù khoảng trống anion đã gần bình thường gợi ý điều gì?","o":["Nhiễm toan ceton chắc chắn vẫn nặng như T0","Có thể đã xuất hiện hoặc còn lại thành phần toan chuyển hóa khoảng trống anion bình thường, thường liên quan tăng clo trong quá trình hồi phục","Đã chuyển thành kiềm chuyển hóa đơn thuần","Khoảng trống anion bình thường loại trừ mọi toan chuyển hóa"],"a":1,"e":"Trong quá trình hồi phục nhiễm toan ceton, khoảng trống anion có thể đóng lại trước khi HCO₃⁻ phục hồi hoàn toàn; tăng clo có thể tạo toan chuyển hóa khoảng trống anion bình thường.","distractorRationale":"Các phương án nhiễu đồng nhất HCO₃⁻ thấp với ketoacidosis đang hoạt động hoặc hiểu sai ý nghĩa khoảng trống anion.","remediation":"hb-case-dka","case_id":"acase01","case_title":"Nhiễm toan ceton: chuyển từ tăng khoảng trống anion sang tăng clo","case_vignette":"T1 sau điều trị: pH 7,28; HCO₃⁻ 14 mmol/L; Na⁺ 138 mmol/L; Cl⁻ 112 mmol/L; khoảng trống anion còn khoảng 12 mmol/L.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"dka-hyperchloremic-transition","error_pattern":"context_omission"},{"id":"a34","topic":"acidbase","difficulty":"basic","lesson":"hb-mixed","cognitive":"understand","clinicalContext":"case-based","q":"Khoảng trống anion xấp xỉ bao nhiêu?","o":["12 mmol/L","16 mmol/L","28 mmol/L","52 mmol/L"],"a":2,"e":"Khoảng trống anion = 140 − (88 + 24) = 28 mmol/L.","distractorRationale":"Các phương án nhiễu xuất phát từ bỏ HCO₃⁻, dùng sai dấu hoặc dùng ngưỡng thay vì tính trực tiếp.","remediation":"hb-mixed","case_id":"acase02","case_title":"Nôn kéo dài kèm toan chuyển hóa tăng khoảng trống anion","case_vignette":"Người bệnh nôn nhiều, ăn kém. Khí máu: pH 7,45; PaCO₂ 35 mmHg; HCO₃⁻ 24 mmol/L. Điện giải: Na⁺ 140, Cl⁻ 88 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"anion-gap-calculation","error_pattern":"calculation_error"},{"id":"a35","topic":"acidbase","difficulty":"intermediate","lesson":"hb-mixed","cognitive":"apply","clinicalContext":"case-based","q":"Tổ hợp dữ liệu này gợi ý mạnh nhất kiểu rối loạn nào?","o":["Chỉ có kiềm hô hấp đơn thuần","Chỉ có toan hô hấp đơn thuần","Khí máu hoàn toàn bình thường vì pH gần bình thường","Toan chuyển hóa tăng khoảng trống anion phối hợp với một quá trình làm HCO₃⁻ cao hơn dự kiến, thường là kiềm chuyển hóa do nôn"],"a":3,"e":"Khoảng trống anion tăng đáng kể nhưng HCO₃⁻ không giảm tương ứng; nôn kéo dài là bối cảnh điển hình của kiềm chuyển hóa đi kèm.","distractorRationale":"Các phương án nhiễu bỏ qua khoảng trống anion hoặc dùng pH để loại trừ rối loạn phối hợp.","remediation":"hb-mixed","case_id":"acase02","case_title":"Nôn kéo dài kèm toan chuyển hóa tăng khoảng trống anion","case_vignette":"Cùng dữ liệu: pH 7,45, HCO₃⁻ 24 mmol/L và khoảng trống anion khoảng 28 mmol/L.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"delta-gap-mixed-disorder","error_pattern":"mechanism_confusion"},{"id":"a36","topic":"acidbase","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","clinicalContext":"case-based","q":"Bài học suy luận quan trọng nhất từ ca này là gì?","o":["pH kiềm hoặc gần bình thường không loại trừ một quá trình toan chuyển hóa đáng kể khi có rối loạn phối hợp","pH trên 7,40 luôn loại trừ toan chuyển hóa","Khoảng trống anion chỉ có ý nghĩa khi pH dưới 7,20","HCO₃⁻ bình thường luôn chứng minh không có rối loạn chuyển hóa"],"a":0,"e":"Các rối loạn phối hợp có thể kéo pH về vùng gần bình thường hoặc kiềm; phải đọc PaCO₂, HCO₃⁻ và khoảng trống anion cùng bối cảnh.","distractorRationale":"Các phương án nhiễu dựa vào một thông số đơn lẻ để loại trừ rối loạn phối hợp.","remediation":"hb-mixed","case_id":"acase02","case_title":"Nôn kéo dài kèm toan chuyển hóa tăng khoảng trống anion","case_vignette":"Người bệnh vẫn có pH kiềm nhẹ 7,45 dù tồn tại khoảng trống anion tăng rõ.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"mixed-disorder-pitfall","error_pattern":"context_omission"},{"id":"a37","topic":"acidbase","difficulty":"basic","lesson":"hb-case-salicylate","cognitive":"understand","clinicalContext":"case-based","q":"Mẫu hình nào phù hợp nhất với PaCO₂ và HCO₃⁻ cùng giảm?","o":["Toan hô hấp đơn thuần","Cần nghĩ đến kiềm hô hấp phối hợp toan chuyển hóa","Kiềm chuyển hóa đơn thuần","Khí máu bình thường"],"a":1,"e":"PaCO₂ rất thấp tạo thành phần kiềm hô hấp, trong khi HCO₃⁻ giảm sâu hơn mức dự kiến của một rối loạn hô hấp đơn độc, gợi ý thêm toan chuyển hóa.","distractorRationale":"Các phương án nhiễu không giải thích đồng thời được PaCO₂ và HCO₃⁻ giảm.","remediation":"hb-case-salicylate","case_id":"acase03","case_title":"Ngộ độc salicylat với rối loạn phối hợp","case_vignette":"Người bệnh ù tai, thở nhanh sau dùng salicylat liều cao. pH 7,48; PaCO₂ 21 mmHg; HCO₃⁻ 15 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"salicylate-mixed-pattern","error_pattern":"mechanism_confusion"},{"id":"a38","topic":"acidbase","difficulty":"intermediate","lesson":"hb-case-salicylate","cognitive":"apply","clinicalContext":"case-based","q":"PaCO₂ thấp hơn nhiều mức Winter dự kiến cho thấy điều gì?","o":["Có thêm toan hô hấp","Đáp ứng bù hoàn toàn bình thường","Có thêm kiềm hô hấp ngoài đáp ứng bù của toan chuyển hóa","PaCO₂ không dùng được trong phân tích rối loạn phối hợp"],"a":2,"e":"PaCO₂ thấp hơn mức bù dự kiến cho toan chuyển hóa cho thấy một quá trình thông khí làm giảm CO₂ độc lập, tức kiềm hô hấp phối hợp.","distractorRationale":"Các phương án nhiễu đảo hướng sai lệch Winter hoặc phủ nhận vai trò của PaCO₂.","remediation":"hb-case-salicylate","case_id":"acase03","case_title":"Ngộ độc salicylat với rối loạn phối hợp","case_vignette":"HCO₃⁻ 15 mmol/L. Nếu đây là toan chuyển hóa đơn thuần, Winter dự kiến PaCO₂ khoảng 30,5 ± 2 mmHg; thực tế PaCO₂ 21 mmHg.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"winter-low-paco2","error_pattern":"calculation_error"},{"id":"a39","topic":"acidbase","difficulty":"advanced","lesson":"hb-case-salicylate","cognitive":"analyze","clinicalContext":"case-based","q":"Cách diễn giải nào tránh sai lầm thường gặp nhất trong ngộ độc salicylat?","o":["Chỉ theo pH và bỏ qua HCO₃⁻","Gọi đây là kiềm hô hấp đơn thuần vì pH cao","Loại trừ ngộ độc nếu khoảng trống anion không tăng rất cao","Không dùng pH kiềm để loại trừ toan chuyển hóa; phải nhận diện đồng thời hai quá trình đối nghịch"],"a":3,"e":"Ngộ độc salicylat thường tạo rối loạn phối hợp; pH có thể kiềm trong khi thiếu hụt bicarbonat và toan chuyển hóa vẫn hiện diện.","distractorRationale":"Các phương án nhiễu đơn giản hóa ca bệnh thành một rối loạn duy nhất hoặc dùng tiêu chí loại trừ không phù hợp.","remediation":"hb-case-salicylate","case_id":"acase03","case_title":"Ngộ độc salicylat với rối loạn phối hợp","case_vignette":"pH vẫn kiềm 7,48 dù có bằng chứng toan chuyển hóa phối hợp.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"salicylate-integration","error_pattern":"context_omission"},{"id":"a40","topic":"acidbase","difficulty":"basic","lesson":"hb-case-copd","cognitive":"understand","clinicalContext":"case-based","q":"Mẫu T0 phù hợp nhất với trạng thái nào?","o":["Tăng CO₂ mạn có thích nghi thận","Kiềm hô hấp cấp","Toan chuyển hóa đơn thuần","Khí máu hoàn toàn bình thường"],"a":0,"e":"PaCO₂ tăng kéo dài kèm HCO₃⁻ tăng và pH gần bình thường gợi ý thích nghi mạn của thận với toan hô hấp.","distractorRationale":"Các phương án nhiễu bỏ qua quan hệ PaCO₂–HCO₃⁻ và thời gian thích nghi.","remediation":"hb-case-copd","case_id":"acase04","case_title":"Tăng CO₂ cấp trên nền mạn","case_vignette":"Khí máu nền T0 của người bệnh bệnh phổi tắc nghẽn mạn tính: pH 7,37; PaCO₂ 60 mmHg; HCO₃⁻ 34 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"chronic-respiratory-acidosis","error_pattern":"mechanism_confusion"},{"id":"a41","topic":"acidbase","difficulty":"intermediate","lesson":"hb-case-copd","cognitive":"apply","clinicalContext":"case-based","q":"So với nền, T1 gợi ý mạnh nhất điều gì?","o":["Chỉ là kiềm chuyển hóa mới xuất hiện","Có thành phần tăng CO₂ cấp chồng lên tình trạng tăng CO₂ mạn","PaCO₂ tăng không quan trọng vì HCO₃⁻ cũng tăng","T1 cho thấy tăng thông khí cấp"],"a":1,"e":"PaCO₂ tăng thêm 20 mmHg cùng pH giảm rõ so với nền là dấu hiệu của một thành phần toan hô hấp cấp trên nền mạn.","distractorRationale":"Các phương án nhiễu bỏ dữ liệu nền hoặc đảo hướng thay đổi thông khí.","remediation":"hb-case-copd","case_id":"acase04","case_title":"Tăng CO₂ cấp trên nền mạn","case_vignette":"T1 khi khó thở tăng: pH 7,28; PaCO₂ 80 mmHg; HCO₃⁻ 36 mmol/L. T0 gần đây: PaCO₂ 60, HCO₃⁻ 34 mmol/L.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"acute-on-chronic-hypercapnia","error_pattern":"context_omission"},{"id":"a42","topic":"acidbase","difficulty":"advanced","lesson":"hb-case-copd","cognitive":"analyze","clinicalContext":"case-based","q":"Vì sao dữ liệu nền có giá trị đặc biệt hơn việc chỉ áp dụng một quy tắc bù “cấp hay mạn” chung?","o":["Vì quy tắc bù không bao giờ có giá trị","Vì PaCO₂ nền luôn bằng 40 mmHg","Nó cho biết trực tiếp trạng thái PaCO₂ và HCO₃⁻ quen thuộc của chính người bệnh để nhận diện phần thay đổi mới","Vì HCO₃⁻ không thay đổi theo thời gian"],"a":2,"e":"Quy tắc bù là ước tính quần thể; khi có dữ liệu nền tin cậy của chính người bệnh, so sánh dọc giúp nhận diện phần thay đổi cấp chính xác hơn.","distractorRationale":"Các phương án nhiễu phủ nhận sinh lý bù hoặc đưa ra hằng số không đúng.","remediation":"hb-case-copd","case_id":"acase04","case_title":"Tăng CO₂ cấp trên nền mạn","case_vignette":"Có khí máu nền đáng tin cậy T0 ngay trước đợt mất bù.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"prior-abg-comparison","error_pattern":"context_omission"},{"id":"a43","topic":"acidbase","difficulty":"basic","lesson":"hb-mixed","cognitive":"understand","clinicalContext":"case-based","q":"Với Na⁺ 138, Cl⁻ 104 và HCO₃⁻ 12 mmol/L, khoảng trống anion xấp xỉ bao nhiêu?","o":["10 mmol/L","34 mmol/L","46 mmol/L","22 mmol/L"],"a":3,"e":"Khoảng trống anion = 138 − (104 + 12) = 22 mmol/L.","distractorRationale":"Các phương án nhiễu dùng sai phép tính hoặc bỏ một thành phần.","remediation":"hb-mixed","case_id":"acase05","case_title":"Suy thận và nhiễm trùng với toan chuyển hóa tăng khoảng trống anion","case_vignette":"Người bệnh suy thận kèm nhiễm trùng: pH 7,32; PaCO₂ 24 mmHg; HCO₃⁻ 12 mmol/L; Na⁺ 138; Cl⁻ 104 mmol/L; lactat 5,0 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"anion-gap-calculation","error_pattern":"calculation_error"},{"id":"a44","topic":"acidbase","difficulty":"intermediate","lesson":"hb-mixed","cognitive":"apply","clinicalContext":"case-based","q":"PaCO₂ này so với Winter phù hợp nhất với nhận định nào?","o":["Nằm ở khoảng thấp nhưng vẫn phù hợp với bù hô hấp dự kiến","Cao hơn rõ, chứng minh toan hô hấp phối hợp","Thấp hơn rất nhiều, chứng minh kiềm hô hấp nặng","Không thể đánh giá bù khi có suy thận"],"a":0,"e":"Winter dự kiến khoảng 1,5 × 12 + 8 = 26 ± 2 mmHg; PaCO₂ 24 mmHg nằm trong khoảng dự kiến.","distractorRationale":"Các phương án nhiễu tính sai khoảng Winter hoặc cho rằng bệnh nền làm công thức mất hoàn toàn giá trị.","remediation":"hb-mixed","case_id":"acase05","case_title":"Suy thận và nhiễm trùng với toan chuyển hóa tăng khoảng trống anion","case_vignette":"HCO₃⁻ 12 mmol/L và PaCO₂ 24 mmHg.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"winter-compensation","error_pattern":"calculation_error"},{"id":"a45","topic":"acidbase","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","clinicalContext":"case-based","q":"Kết luận nào phù hợp nhất về nguyên nhân toan chuyển hóa?","o":["Lactat 5,0 chứng minh toàn bộ khoảng trống anion chỉ do lactat","Có thể có nhiều acid không đo được cùng đóng góp; khoảng trống anion không tự xác định duy nhất lactat hay urê là nguyên nhân","Suy thận loại trừ vai trò của lactat","Khoảng trống anion tăng chỉ gặp trong nhiễm toan ceton"],"a":1,"e":"Khoảng trống anion là dấu hiệu của anion không đo được, không phải xét nghiệm đặc hiệu nguyên nhân; trong ca phức tạp có thể có nhiều nguồn acid đồng thời.","distractorRationale":"Các phương án nhiễu biến chỉ dấu không đặc hiệu thành chẩn đoán nguyên nhân duy nhất.","remediation":"hb-mixed","case_id":"acase05","case_title":"Suy thận và nhiễm trùng với toan chuyển hóa tăng khoảng trống anion","case_vignette":"Khoảng trống anion tăng; lactat 5,0 mmol/L và người bệnh có suy thận nặng.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"calculation-core+handbook","concept":"anion-gap-etiology","error_pattern":"context_omission"},{"id":"o31","topic":"oxygen","difficulty":"basic","lesson":"hb-hypoxemia","cognitive":"understand","clinicalContext":"case-based","q":"Rối loạn thông khí chính là gì?","o":["Tăng thông khí gây kiềm hô hấp","Toan chuyển hóa đơn thuần","Giảm thông khí phế nang gây tăng PaCO₂ và toan hô hấp","Kiềm chuyển hóa đơn thuần"],"a":2,"e":"PaCO₂ tăng rõ kèm pH giảm cho thấy toan hô hấp do giảm thông khí phế nang.","distractorRationale":"Các phương án nhiễu đảo chiều thông khí hoặc chọn rối loạn chuyển hóa không giải thích PaCO₂.","remediation":"hb-hypoxemia","case_id":"ocase01","case_title":"Giảm thông khí do thuốc an thần/opioid","case_vignette":"Người bệnh giảm ý thức sau dùng opioid: pH 7,22; PaCO₂ 68 mmHg; PaO₂ 56 mmHg khi thở khí phòng.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"alveolar-hypoventilation","error_pattern":"mechanism_confusion"},{"id":"o32","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"apply","clinicalContext":"case-based","q":"Chênh áp oxy phế nang–động mạch nhỏ trong bối cảnh này gợi ý gì?","o":["Chắc chắn có luồng thông trong phổi rất lớn","Chắc chắn có phù phổi lan tỏa","PaCO₂ không liên quan đến PAO₂","Giảm oxy máu có thể được giải thích chủ yếu bởi giảm thông khí hơn là một khiếm khuyết trao đổi khí lớn trong phổi"],"a":3,"e":"Giảm thông khí làm PAO₂ giảm theo PaCO₂; nếu A–a không tăng nhiều, cơ chế giảm thông khí là lời giải thích quan trọng cho giảm oxy máu.","distractorRationale":"Các phương án nhiễu gán cơ chế làm tăng A–a rõ hoặc phủ nhận phương trình khí phế nang.","remediation":"hb-hypoxemia","case_id":"ocase01","case_title":"Giảm thông khí do thuốc an thần/opioid","case_vignette":"Ở khí phòng và mực nước biển, với PaCO₂ 68 mmHg, PAO₂ ước tính theo phương trình khí phế nang vào khoảng giữa 60 mmHg; PaO₂ đo 56 mmHg.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"aa-gradient-hypoventilation","error_pattern":"calculation_error"},{"id":"o33","topic":"oxygen","difficulty":"advanced","lesson":"hb-hypoxemia","cognitive":"analyze","clinicalContext":"case-based","q":"Bài học tích hợp quan trọng nhất là gì?","o":["PaO₂ thấp không đồng nghĩa với bệnh nhu mô phổi; phải đọc cùng PaCO₂ và cơ chế giảm thông khí","Mọi PaO₂ thấp đều do luồng thông trong phổi","PaCO₂ chỉ dùng trong toan–kiềm, không liên quan oxy hóa","Chênh áp A–a bình thường loại trừ mọi nguy cơ hô hấp"],"a":0,"e":"Oxy hóa và thông khí liên quan chặt chẽ; giảm thông khí đơn thuần có thể gây giảm oxy máu với A–a gần bình thường nhưng vẫn là tình trạng nghiêm trọng.","distractorRationale":"Các phương án nhiễu đồng nhất giảm oxy với một cơ chế duy nhất hoặc đánh giá thấp tăng CO₂.","remediation":"hb-hypoxemia","case_id":"ocase01","case_title":"Giảm thông khí do thuốc an thần/opioid","case_vignette":"Người bệnh vẫn giảm ý thức và PaCO₂ tăng, trong khi chênh áp A–a không tăng nhiều.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"hypoxemia-mechanism-integration","error_pattern":"context_omission"},{"id":"o34","topic":"oxygen","difficulty":"basic","lesson":"hb-hypoxemia","cognitive":"understand","clinicalContext":"case-based","q":"Cơ chế nào phù hợp hơn giảm thông khí đơn thuần?","o":["Giảm thông khí đơn thuần với A–a bình thường","Bất tương xứng thông khí–tưới máu hoặc cơ chế làm tăng chênh áp A–a","Tăng hemoglobin đơn thuần","Sai số do công thức Winter"],"a":1,"e":"PaO₂ thấp với A–a tăng cho thấy vấn đề trao đổi khí trong phổi như bất tương xứng thông khí–tưới máu, hạn chế khuếch tán hoặc luồng thông hơn là giảm thông khí đơn thuần.","distractorRationale":"Các phương án nhiễu không giải thích chênh áp A–a tăng.","remediation":"hb-hypoxemia","case_id":"ocase02","case_title":"Viêm phổi với bất tương xứng thông khí–tưới máu","case_vignette":"Người bệnh viêm phổi: PaO₂ 55 mmHg khi thở khí phòng, PaCO₂ 32 mmHg. Chênh áp A–a tăng rõ.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"widened-aa-gradient","error_pattern":"mechanism_confusion"},{"id":"o35","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"apply","clinicalContext":"case-based","q":"Đáp ứng oxy rõ như vậy phù hợp hơn với nhận định nào?","o":["Chứng minh chắc chắn không có bệnh phổi","Chứng minh có luồng thông hoàn toàn","Một phần giảm oxy máu có khả năng đáp ứng với tăng FiO₂, thường gặp trong bất tương xứng thông khí–tưới máu hơn là luồng thông lớn tuyệt đối","PaO₂ không bao giờ thay đổi theo FiO₂"],"a":2,"e":"Bất tương xứng thông khí–tưới máu thường cải thiện đáng kể với oxy bổ sung; luồng thông lớn có xu hướng đáp ứng kém hơn. Tuy nhiên đáp ứng oxy không phải xét nghiệm đặc hiệu duy nhất.","distractorRationale":"Các phương án nhiễu biến đáp ứng oxy thành bằng chứng tuyệt đối hoặc phủ nhận sinh lý.","remediation":"hb-hypoxemia","case_id":"ocase02","case_title":"Viêm phổi với bất tương xứng thông khí–tưới máu","case_vignette":"Khi FiO₂ được tăng lên 0,40 trong điều kiện ổn định, PaO₂ tăng lên 120 mmHg.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"oxygen-response-vq","error_pattern":"mechanism_confusion"},{"id":"o36","topic":"oxygen","difficulty":"advanced","lesson":"hb-hypoxemia","cognitive":"analyze","clinicalContext":"case-based","q":"Kết luận nào giữ đúng mức độ chắc chắn của dữ liệu?","o":["Đáp ứng oxy tự nó xác định chính xác vùng tổn thương","PaO₂ cải thiện loại trừ viêm phổi","Không cần xem lại FiO₂ khi theo dõi","Đáp ứng oxy hỗ trợ cơ chế bất tương xứng thông khí–tưới máu nhưng vẫn phải tích hợp hình ảnh, PaCO₂ và bệnh cảnh"],"a":3,"e":"Cơ chế giảm oxy thường cần tích hợp nhiều dữ liệu; đáp ứng với oxy là một mảnh ghép, không phải chẩn đoán nguyên nhân độc lập.","distractorRationale":"Các phương án nhiễu kết luận quá mức từ một quan sát sinh lý.","remediation":"hb-hypoxemia","case_id":"ocase02","case_title":"Viêm phổi với bất tương xứng thông khí–tưới máu","case_vignette":"Hình ảnh phổi và lâm sàng vẫn cho thấy tổn thương khu trú; PaO₂ cải thiện rõ với oxy bổ sung.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"vq-context-integration","error_pattern":"context_omission"},{"id":"o37","topic":"oxygen","difficulty":"basic","lesson":"hb-pf","cognitive":"understand","clinicalContext":"case-based","q":"Tỷ số PaO₂/FiO₂ ở T0 xấp xỉ bao nhiêu?","o":["80 mmHg","125 mmHg","180 mmHg","512 mmHg"],"a":0,"e":"P/F = 64 / 0,80 = 80 mmHg.","distractorRationale":"Các phương án nhiễu chia sai chiều hoặc không đổi FiO₂ về dạng thập phân.","remediation":"hb-pf","case_id":"ocase03","case_title":"Suy hô hấp giảm oxy trên thở máy: xu hướng P/F","case_vignette":"T0 khi thở máy: PaO₂ 64 mmHg, FiO₂ 0,80, PEEP 10 cmH₂O.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"pf-ratio-calculation","error_pattern":"calculation_error"},{"id":"o38","topic":"oxygen","difficulty":"intermediate","lesson":"hb-pf","cognitive":"apply","clinicalContext":"case-based","q":"Tỷ số P/F ở T1 và xu hướng so với T0 phù hợp nhất là gì?","o":["Khoảng 47 mmHg, xấu hơn rõ","Khoảng 130 mmHg, cải thiện so với T0 nhưng oxy hóa vẫn suy giảm đáng kể","Khoảng 260 mmHg, đã bình thường hoàn toàn","Không thể tính P/F khi người bệnh thở máy"],"a":1,"e":"78 / 0,60 = 130 mmHg; tăng từ 80 lên 130 cho thấy cải thiện tương đối trong điều kiện PEEP được giữ như nhau.","distractorRationale":"Các phương án nhiễu tính sai hoặc diễn giải quá mức mức cải thiện.","remediation":"hb-pf","case_id":"ocase03","case_title":"Suy hô hấp giảm oxy trên thở máy: xu hướng P/F","case_vignette":"T1 sau đó với PEEP vẫn 10 cmH₂O: PaO₂ 78 mmHg, FiO₂ 0,60.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"serial-pf-ratio","error_pattern":"calculation_error"},{"id":"o39","topic":"oxygen","difficulty":"advanced","lesson":"hb-pf","cognitive":"analyze","clinicalContext":"case-based","q":"Khi dùng P/F để theo dõi nối tiếp, nguyên tắc nào quan trọng nhất?","o":["P/F hoàn toàn không phụ thuộc bất kỳ cài đặt nào","Chỉ cần PaO₂, FiO₂ không cần ghi","So sánh trong bối cảnh hỗ trợ hô hấp và huyết động tương đồng, không coi P/F là đại lượng độc lập với điều kiện đo","Một lần P/F cải thiện chứng minh tổn thương phổi đã hồi phục"],"a":2,"e":"P/F hữu ích nhưng chịu ảnh hưởng của FiO₂, PEEP, huyết động và thời điểm; xu hướng cần được đặt trong bối cảnh hỗ trợ tương đồng.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa P/F hoặc bỏ điều kiện đo.","remediation":"hb-pf","case_id":"ocase03","case_title":"Suy hô hấp giảm oxy trên thở máy: xu hướng P/F","case_vignette":"T0 và T1 có cùng PEEP nhưng FiO₂ khác nhau; huyết động và chiến lược máy thở vẫn có thể ảnh hưởng oxy hóa.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"calculation-core+handbook","concept":"pf-context","error_pattern":"context_omission"},{"id":"o40","topic":"oxygen","difficulty":"basic","lesson":"hb-case-co","cognitive":"understand","clinicalContext":"case-based","q":"Vì sao PaO₂ 95 mmHg không loại trừ ngộ độc carbon monoxit?","o":["Carbon monoxit luôn làm PaO₂ bằng 0","PaO₂ là phép đo trực tiếp carboxyhemoglobin","SpO₂ 99% chứng minh không có rối loạn vận chuyển oxy","PaO₂ phản ánh oxy hòa tan trong huyết tương, không đo phần hemoglobin bị carbon monoxit chiếm chỗ"],"a":3,"e":"PaO₂ có thể bình thường trong ngộ độc CO vì nó không phản ánh khả năng gắn oxy của hemoglobin; cần đo COHb khi bệnh cảnh gợi ý.","distractorRationale":"Các phương án nhiễu đồng nhất PaO₂ với COHb hoặc tin tuyệt đối vào SpO₂.","remediation":"hb-case-co","case_id":"ocase04","case_title":"Ngộ độc carbon monoxit với PaO₂ bảo tồn","case_vignette":"Người bệnh đau đầu, chóng mặt sau dùng máy phát điện trong không gian kín. SpO₂ 99%, PaO₂ 95 mmHg, nhưng carboxyhemoglobin đo bằng đồng oxy kế là 18%.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"co-po2-limitation","error_pattern":"knowledge_gap"},{"id":"o41","topic":"oxygen","difficulty":"intermediate","lesson":"hb-case-co","cognitive":"apply","clinicalContext":"case-based","q":"Điểm hạn chế quan trọng của máy đo SpO₂ thông thường trong bối cảnh COHb là gì?","o":["Máy hai bước sóng không phân biệt chính xác oxyhemoglobin với carboxyhemoglobin nên có thể cho độ bão hòa gây hiểu nhầm","Máy luôn đọc thấp hơn thực tế đúng 18%","Máy đo trực tiếp PaO₂ động mạch","COHb không ảnh hưởng bất kỳ phép đo độ bão hòa nào"],"a":0,"e":"Máy đo độ bão hòa oxy ngoại vi hai bước sóng thông thường không chính xác khi có COHb; xác nhận cần đồng oxy kế hoặc quang phổ nhiều bước sóng.","distractorRationale":"Các phương án nhiễu gán sai chức năng hoặc một sai số cố định không có cơ sở.","remediation":"hb-case-co","case_id":"ocase04","case_title":"Ngộ độc carbon monoxit với PaO₂ bảo tồn","case_vignette":"SpO₂ bằng máy đo hai bước sóng vẫn 99% dù COHb 18%.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"co-pulse-oximetry","error_pattern":"mechanism_confusion"},{"id":"o42","topic":"oxygen","difficulty":"advanced","lesson":"hb-case-co","cognitive":"analyze","clinicalContext":"case-based","q":"Cách diễn giải COHb phù hợp nhất là gì?","o":["COHb luôn tỷ lệ hoàn hảo với mức độ tổn thương thần kinh","Đọc COHb cùng lịch sử phơi nhiễm, thời gian rời nguồn và biểu hiện lâm sàng; không dùng mức COHb đơn độc để phản ánh toàn bộ mức độ nặng","COHb bình thường sau vài giờ loại trừ chắc chắn phơi nhiễm trước đó","Chỉ PaCO₂ quyết định chẩn đoán CO"],"a":1,"e":"COHb giảm theo thời gian sau khi rời nguồn/được thở oxy và tương quan không hoàn hảo với mức độ nặng; bệnh sử và triệu chứng vẫn rất quan trọng.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa một nồng độ hoặc dùng thông số không liên quan để xác định chẩn đoán.","remediation":"hb-case-co","case_id":"ocase04","case_title":"Ngộ độc carbon monoxit với PaO₂ bảo tồn","case_vignette":"Người bệnh đã rời nguồn phơi nhiễm một thời gian trước khi lấy mẫu; triệu chứng thần kinh vẫn còn.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"cohb-context","error_pattern":"context_omission"},{"id":"o43","topic":"oxygen","difficulty":"basic","lesson":"hb-saturation","cognitive":"understand","clinicalContext":"case-based","q":"Sự kết hợp SpO₂ thấp dai dẳng với PaO₂ rất cao gợi ý điều gì?","o":["PaO₂ cao luôn chứng minh không có thiếu oxy chức năng","SpO₂ 85% chắc chắn do giảm thông khí đơn thuần","Có thể có rối loạn hemoglobin như tăng methemoglobin làm độ bão hòa không phản ánh PaO₂ theo cách thông thường","PaO₂ 210 mmHg chứng minh máy đo SpO₂ hỏng"],"a":2,"e":"Rối loạn dạng hemoglobin có thể tạo “khoảng cách độ bão hòa”: PaO₂ phản ánh oxy hòa tan trong khi chức năng hemoglobin bị thay đổi.","distractorRationale":"Các phương án nhiễu đồng nhất PaO₂ cao với vận chuyển oxy bình thường hoặc quy toàn bộ cho thiết bị.","remediation":"hb-saturation","case_id":"ocase05","case_title":"Methemoglobin và khoảng cách độ bão hòa","case_vignette":"Sau dùng thuốc oxy hóa, người bệnh tím, SpO₂ khoảng 85% dù đang thở oxy; PaO₂ động mạch 210 mmHg. Đồng oxy kế cho methemoglobin 14%.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"saturation-gap","error_pattern":"mechanism_confusion"},{"id":"o44","topic":"oxygen","difficulty":"intermediate","lesson":"hb-saturation","cognitive":"apply","clinicalContext":"case-based","q":"Vì sao PaO₂ có thể cao trong khi chức năng vận chuyển oxy vẫn bất thường?","o":["PaO₂ chính là nồng độ methemoglobin","Methemoglobin chỉ làm PaCO₂ tăng","Hemoglobin không đóng vai trò đáng kể trong vận chuyển oxy","PaO₂ đo áp suất oxy hòa tan, không trực tiếp đo khả năng hemoglobin mang và nhả oxy"],"a":3,"e":"Phần lớn oxy được vận chuyển gắn hemoglobin; PaO₂ chỉ phản ánh phần oxy hòa tan nên có thể không biểu hiện rối loạn dạng hemoglobin.","distractorRationale":"Các phương án nhiễu nhầm bản chất PaO₂ hoặc đánh giá sai vai trò hemoglobin.","remediation":"hb-saturation","case_id":"ocase05","case_title":"Methemoglobin và khoảng cách độ bão hòa","case_vignette":"PaO₂ vẫn 210 mmHg nhưng đồng oxy kế cho methemoglobin 14%.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"po2-vs-oxygen-content","error_pattern":"knowledge_gap"},{"id":"o45","topic":"oxygen","difficulty":"advanced","lesson":"hb-saturation","cognitive":"analyze","clinicalContext":"case-based","q":"Xét nghiệm nào trực tiếp hữu ích nhất để phân biệt các dạng hemoglobin bất thường?","o":["Đồng oxy kế nhiều bước sóng","Chỉ PaO₂ trên khí máu thông thường","Chỉ công thức Winter","Chỉ khoảng trống anion"],"a":0,"e":"Đồng oxy kế hoặc quang phổ nhiều bước sóng có thể định lượng các dạng hemoglobin như oxyhemoglobin, carboxyhemoglobin và methemoglobin.","distractorRationale":"Các phương án nhiễu là phép đo không phân biệt được các dạng hemoglobin.","remediation":"hb-saturation","case_id":"ocase05","case_title":"Methemoglobin và khoảng cách độ bão hòa","case_vignette":"Bệnh cảnh và khoảng cách độ bão hòa làm tăng nghi ngờ rối loạn dạng hemoglobin.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"cooximetry","error_pattern":"knowledge_gap"},{"id":"c31","topic":"clinical","difficulty":"basic","lesson":"hb-case-sepsis","cognitive":"understand","clinicalContext":"case-based","q":"Với pH 7,28, HCO₃⁻ 13 mmol/L và lactat 6,2 mmol/L ở T0, rối loạn chính nào nổi bật?","o":["Kiềm chuyển hóa đơn thuần","Toan chuyển hóa với tăng lactat là một thành phần quan trọng cần tích hợp","Toan hô hấp đơn thuần","Khí máu bình thường"],"a":1,"e":"pH và HCO₃⁻ thấp cho thấy toan chuyển hóa; lactat tăng cao là dữ kiện quan trọng về chuyển hóa/tưới máu nhưng không phải nguyên nhân duy nhất có thể có.","distractorRationale":"Các phương án nhiễu chọn sai rối loạn chính hoặc bỏ qua HCO₃⁻ thấp.","remediation":"hb-case-sepsis","case_id":"ccase01","case_title":"Sốc nhiễm trùng: khí máu và lactat nối tiếp","case_vignette":"T0 ở người bệnh sốc nhiễm trùng: pH 7,28; PaCO₂ 28 mmHg; HCO₃⁻ 13 mmol/L; lactat 6,2 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"sepsis-lactate-acidosis","error_pattern":"context_omission"},{"id":"c32","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-sepsis","cognitive":"apply","clinicalContext":"case-based","q":"Diễn giải xu hướng T0 → T1 phù hợp nhất là gì?","o":["Lactat giảm chứng minh sốc đã hết hoàn toàn","Chỉ cần lactat, không cần xem pH hay huyết động","Có tín hiệu cải thiện chuyển hóa nhưng lactat vẫn tăng và xu hướng phải được đọc cùng huyết động, tưới máu và bệnh cảnh","HCO₃⁻ tăng chứng minh đã xuất hiện kiềm chuyển hóa"],"a":2,"e":"Giảm lactat và cải thiện pH/HCO₃⁻ là tín hiệu thuận lợi, nhưng không thay thế đánh giá lâm sàng và huyết động hiện tại.","distractorRationale":"Các phương án nhiễu biến xu hướng cải thiện thành kết luận tuyệt đối hoặc bỏ dữ liệu tích hợp.","remediation":"hb-case-sepsis","case_id":"ccase01","case_title":"Sốc nhiễm trùng: khí máu và lactat nối tiếp","case_vignette":"T1 sau can thiệp ban đầu: lactat giảm từ 6,2 xuống 3,8 mmol/L; pH tăng lên 7,34 và HCO₃⁻ lên 18 mmol/L.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"serial-lactate","error_pattern":"context_omission"},{"id":"c33","topic":"clinical","difficulty":"advanced","lesson":"hb-case-sepsis","cognitive":"analyze","clinicalContext":"case-based","q":"Bài học quan trọng nhất khi dùng lactat nối tiếp là gì?","o":["Lactat giảm bất kỳ mức nào đều cho phép ngừng đánh giá huyết động","Lactat chỉ có giá trị ở mẫu đầu tiên","Lactat thấp hơn 4 mmol/L luôn loại trừ sốc","Xu hướng lactat là một chỉ dấu theo dõi, không phải chứng nhận độc lập rằng tưới máu và sốc đã hồi phục"],"a":3,"e":"Lactat chịu ảnh hưởng nhiều cơ chế; xu hướng có giá trị nhưng phải đặt trong toàn cảnh huyết động, tưới máu, chức năng cơ quan và nguyên nhân nền.","distractorRationale":"Các phương án nhiễu dùng ngưỡng tuyệt đối hoặc phủ nhận giá trị của theo dõi nối tiếp.","remediation":"hb-case-sepsis","case_id":"ccase01","case_title":"Sốc nhiễm trùng: khí máu và lactat nối tiếp","case_vignette":"T1 lactat đã giảm nhưng huyết áp vẫn cần hỗ trợ và tưới máu ngoại vi còn kém.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"lactate-context","error_pattern":"context_omission"},{"id":"c34","topic":"clinical","difficulty":"basic","lesson":"hb-case-sglt2","cognitive":"understand","clinicalContext":"case-based","q":"Glucose 9,8 mmol/L có loại trừ nhiễm toan ceton do đái tháo đường không?","o":["Không; ở người đã có đái tháo đường, ketosis và toan chuyển hóa có thể xuất hiện dù glucose dưới 11,1 mmol/L","Có; phải glucose trên 20 mmol/L mới có thể là nhiễm toan ceton","Có; pH chỉ có ý nghĩa khi glucose trên 30 mmol/L","Không cần xem keton nếu glucose không cao"],"a":0,"e":"Tiêu chuẩn hiện hành nhận diện nhiễm toan ceton do đái tháo đường với tiền sử đái tháo đường hoặc tăng glucose kèm tăng ceton và toan chuyển hóa; khoảng 10% trường hợp có thể có glucose dưới 11,1 mmol/L.","distractorRationale":"Các phương án nhiễu dùng ngưỡng glucose cũ/không đúng để loại trừ ketosis và acidosis.","remediation":"hb-case-sglt2","case_id":"ccase02","case_title":"Nhiễm toan ceton liên quan thuốc ức chế SGLT2 với glucose không cao","case_vignette":"Người bệnh đái tháo đường típ 2 dùng thuốc ức chế SGLT2, ăn kém và nôn. Glucose 9,8 mmol/L; β-hydroxybutyrate 4,5 mmol/L; pH 7,25; HCO₃⁻ 13 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"euglycemic-dka","error_pattern":"knowledge_gap"},{"id":"c35","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-sglt2","cognitive":"apply","clinicalContext":"case-based","q":"Yếu tố nào trong bệnh sử làm tăng tính phù hợp của chẩn đoán nhiễm toan ceton với glucose không cao?","o":["Dùng paracetamol liều thông thường","Sử dụng thuốc ức chế SGLT2 trong bối cảnh giảm ăn/nhịn ăn hoặc bệnh cấp","Nhóm máu O","Cận thị"],"a":1,"e":"Thuốc ức chế SGLT2, giảm ăn/nhịn ăn, mất nước và bệnh cấp là các bối cảnh đã biết liên quan nhiễm toan ceton có glucose không cao.","distractorRationale":"Các phương án nhiễu là yếu tố không liên quan đến cơ chế DKA do SGLT2.","remediation":"hb-case-sglt2","case_id":"ccase02","case_title":"Nhiễm toan ceton liên quan thuốc ức chế SGLT2 với glucose không cao","case_vignette":"Người bệnh đang dùng thuốc ức chế SGLT2 và có giảm ăn kéo dài trước khi xuất hiện ketosis/toan chuyển hóa.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"sglt2-dka-risk","error_pattern":"context_omission"},{"id":"c36","topic":"clinical","difficulty":"advanced","lesson":"hb-case-sglt2","cognitive":"analyze","clinicalContext":"case-based","q":"Cách suy luận nào đúng nhất để tránh bỏ sót ca này?","o":["Chỉ theo glucose và bỏ qua keton","Chỉ theo pH và bỏ qua tiền sử dùng thuốc","Ưu tiên bộ ba bối cảnh đái tháo đường + ketosis + toan chuyển hóa thay vì đòi hỏi tăng glucose rất cao","Loại trừ nhiễm toan ceton nếu glucose dưới 11,1 mmol/L dù người bệnh đã có đái tháo đường"],"a":2,"e":"Các tiêu chí hiện hành cho phép tiền sử đái tháo đường thay cho ngưỡng glucose ở thành phần đầu, miễn có tăng ceton và toan chuyển hóa.","distractorRationale":"Các phương án nhiễu dùng một biến đơn lẻ hoặc ngưỡng glucose để loại trừ sai.","remediation":"hb-case-sglt2","case_id":"ccase02","case_title":"Nhiễm toan ceton liên quan thuốc ức chế SGLT2 với glucose không cao","case_vignette":"Glucose không cao nhưng β-hydroxybutyrate tăng rõ, pH <7,30 và HCO₃⁻ <18 mmol/L.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"dka-diagnostic-framework","error_pattern":"context_omission"},{"id":"c37","topic":"clinical","difficulty":"basic","lesson":"hb-case-ventilator","cognitive":"understand","clinicalContext":"case-based","q":"Rối loạn hô hấp nổi bật ở T0 là gì?","o":["Kiềm hô hấp","Toan chuyển hóa đơn thuần","Kiềm chuyển hóa đơn thuần","Toan hô hấp do tăng PaCO₂"],"a":3,"e":"PaCO₂ tăng rõ kèm pH giảm cho thấy toan hô hấp; HCO₃⁻ chưa đủ để giải thích pH như một rối loạn chuyển hóa nguyên phát.","distractorRationale":"Các phương án nhiễu chọn sai hướng PaCO₂ hoặc cơ chế nguyên phát.","remediation":"hb-case-ventilator","case_id":"ccase03","case_title":"Tăng CO₂ trên thở máy và đáp ứng nối tiếp","case_vignette":"T0 trên thở máy: pH 7,21; PaCO₂ 72 mmHg; HCO₃⁻ 28 mmol/L.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"ventilator-hypercapnia","error_pattern":"mechanism_confusion"},{"id":"c38","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-ventilator","cognitive":"apply","clinicalContext":"case-based","q":"Thay đổi T0 → T1 cho thấy điều gì về thông khí phế nang?","o":["Thông khí phế nang đã tăng tương đối, thể hiện bằng PaCO₂ giảm và pH cải thiện","Thông khí phế nang giảm vì PaCO₂ thấp hơn","Oxy hóa chắc chắn xấu đi vì PaCO₂ giảm","Không thể dùng PaCO₂ để đánh giá xu hướng thông khí"],"a":0,"e":"Khi sản xuất CO₂ không thay đổi lớn, PaCO₂ giảm sau tăng thông khí phút phù hợp với cải thiện thông khí phế nang.","distractorRationale":"Các phương án nhiễu đảo quan hệ thông khí–PaCO₂ hoặc suy diễn oxy hóa không có dữ liệu.","remediation":"hb-case-ventilator","case_id":"ccase03","case_title":"Tăng CO₂ trên thở máy và đáp ứng nối tiếp","case_vignette":"Sau điều chỉnh thông khí phút theo đánh giá lâm sàng, T1 sau 30 phút: pH 7,31; PaCO₂ 55 mmHg; HCO₃⁻ 27 mmol/L.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"serial-ventilation","error_pattern":"mechanism_confusion"},{"id":"c39","topic":"clinical","difficulty":"advanced","lesson":"hb-case-ventilator","cognitive":"analyze","clinicalContext":"case-based","q":"Nguyên tắc nào phù hợp nhất khi dùng khí máu nối tiếp để đánh giá đáp ứng thở máy?","o":["Một PaCO₂ giảm luôn có nghĩa là chiến lược thở máy tối ưu","Luôn gắn thay đổi PaCO₂/pH với thay đổi cài đặt và bối cảnh cơ học hô hấp thay vì nhìn con số tách rời","Không cần ghi lại cài đặt máy nếu pH cải thiện","PaCO₂ mục tiêu giống nhau cho mọi người bệnh và mọi bệnh cảnh"],"a":1,"e":"Khí máu nối tiếp có giá trị nhất khi liên kết với thông số máy và mục tiêu lâm sàng; không có một mục tiêu PaCO₂ duy nhất phù hợp mọi tình huống.","distractorRationale":"Các phương án nhiễu tuyệt đối hóa một con số và bỏ bối cảnh máy thở.","remediation":"hb-case-ventilator","case_id":"ccase03","case_title":"Tăng CO₂ trên thở máy và đáp ứng nối tiếp","case_vignette":"T1 cải thiện PaCO₂ nhưng việc diễn giải vẫn cần biết cài đặt máy, thể tích phút, tình trạng phổi và thời điểm lấy mẫu.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"ventilator-context","error_pattern":"context_omission"},{"id":"c40","topic":"clinical","difficulty":"basic","lesson":"hb-respiratory-failure","cognitive":"understand","clinicalContext":"case-based","q":"Ở T0 của cơn hen nặng, pH 7,48 và PaCO₂ 29 mmHg phù hợp nhất với rối loạn nào?","o":["Toan hô hấp","Toan chuyển hóa","Kiềm hô hấp do tăng thông khí","Kiềm chuyển hóa đơn thuần"],"a":2,"e":"PaCO₂ thấp kèm pH tăng phù hợp kiềm hô hấp, thường gặp khi người bệnh còn tăng thông khí mạnh.","distractorRationale":"Các phương án nhiễu đảo hướng PaCO₂ hoặc chọn rối loạn chuyển hóa.","remediation":"hb-respiratory-failure","case_id":"ccase04","case_title":"Hen nặng: PaCO₂ tăng dần khi người bệnh mệt","case_vignette":"T0 trong cơn hen nặng: pH 7,48; PaCO₂ 29 mmHg; người bệnh thở nhanh.","case_sequence":1,"case_stage":"initial","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"asthma-respiratory-alkalosis","error_pattern":"mechanism_confusion"},{"id":"c41","topic":"clinical","difficulty":"intermediate","lesson":"hb-respiratory-failure","cognitive":"apply","clinicalContext":"case-based","q":"Trong bối cảnh hen nặng đang xấu đi, PaCO₂ từ 29 tăng lên 45 mmHg nên được nhìn nhận thế nào?","o":["Luôn là dấu hiệu khỏi bệnh vì PaCO₂ về gần 40","Không có ý nghĩa vì PaCO₂ vẫn dưới 50","Chứng minh có kiềm chuyển hóa","Là dấu hiệu đáng lo về giảm khả năng duy trì tăng thông khí, không nên coi “PaCO₂ bình thường” là sự cải thiện tự động"],"a":3,"e":"Trong hen nặng, PaCO₂ đang thấp mà tăng về bình thường/cao cùng mệt lâm sàng có thể phản ánh suy giảm thông khí và mỏi cơ hô hấp.","distractorRationale":"Các phương án nhiễu xem giá trị “bình thường” tách khỏi xu hướng và mức độ nặng lâm sàng.","remediation":"hb-respiratory-failure","case_id":"ccase04","case_title":"Hen nặng: PaCO₂ tăng dần khi người bệnh mệt","case_vignette":"T1 sau đó người bệnh mệt hơn: pH 7,32; PaCO₂ tăng lên 45 mmHg dù mức tắc nghẽn và khó thở lâm sàng nặng hơn.","case_sequence":2,"case_stage":"analysis","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"asthma-rising-paco2","error_pattern":"context_omission"},{"id":"c42","topic":"clinical","difficulty":"advanced","lesson":"hb-respiratory-failure","cognitive":"analyze","clinicalContext":"case-based","q":"Bài học nào quan trọng nhất từ chuỗi khí máu này?","o":["Xu hướng PaCO₂ và trạng thái lâm sàng có thể quan trọng hơn việc một giá trị đơn lẻ nằm trong khoảng tham chiếu","Chỉ cần xem PaCO₂ cuối cùng có nằm 35–45 mmHg hay không","pH không cần xem nếu PaCO₂ ở khoảng tham chiếu","Mọi thay đổi PaCO₂ ở hen đều do sai số lấy mẫu"],"a":0,"e":"Một giá trị trong “khoảng bình thường” có thể bất thường về mặt sinh lý nếu nó đại diện sự thất bại của đáp ứng tăng thông khí trước đó.","distractorRationale":"Các phương án nhiễu bỏ thông tin dọc và bối cảnh sinh lý.","remediation":"hb-respiratory-failure","case_id":"ccase04","case_title":"Hen nặng: PaCO₂ tăng dần khi người bệnh mệt","case_vignette":"T0 PaCO₂ 29 mmHg; T1 PaCO₂ 45 mmHg kèm pH giảm và mệt tăng.","case_sequence":3,"case_stage":"integration","serial_abg":true,"serial_group":"T0–T1","source_scope":"clinical-library+handbook","concept":"serial-trend-interpretation","error_pattern":"context_omission"},{"id":"c43","topic":"clinical","difficulty":"basic","lesson":"hb-saturation","cognitive":"understand","clinicalContext":"case-based","q":"PaO₂ 92 mmHg cho biết chủ yếu điều gì?","o":["Tổng hàm lượng oxy động mạch chắc chắn bình thường","Áp suất oxy hòa tan trong huyết tương, không phải tổng lượng oxy mà máu có thể vận chuyển","Nồng độ hemoglobin chắc chắn bình thường","Cung cấp oxy mô chắc chắn đầy đủ"],"a":1,"e":"PaO₂ phản ánh phần oxy hòa tan; phần lớn oxy trong máu được vận chuyển gắn hemoglobin nên thiếu máu nặng có thể làm hàm lượng oxy giảm dù PaO₂ bình thường.","distractorRationale":"Các phương án nhiễu đồng nhất PaO₂ với hàm lượng hoặc cung cấp oxy.","remediation":"hb-saturation","case_id":"ccase05","case_title":"Thiếu máu nặng với PaO₂ và SaO₂ bảo tồn","case_vignette":"Người bệnh thiếu máu nặng, Hb 5,5 g/dL, PaO₂ 92 mmHg và SaO₂ 97% nhưng có nhịp tim nhanh và dấu hiệu giảm tưới máu mô.","case_sequence":1,"case_stage":"initial","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"po2-vs-content","error_pattern":"knowledge_gap"},{"id":"c44","topic":"clinical","difficulty":"intermediate","lesson":"hb-saturation","cognitive":"apply","clinicalContext":"case-based","q":"Yếu tố nào làm hàm lượng oxy động mạch có thể thấp đáng kể trong ca này?","o":["PaO₂ trên 90 tự làm hàm lượng oxy bằng 0","SaO₂ cao làm giảm khả năng mang oxy","Nồng độ hemoglobin rất thấp làm giảm lượng oxy gắn hemoglobin dù độ bão hòa cao","PaCO₂ là thành phần chính quyết định hàm lượng oxy"],"a":2,"e":"CaO₂ phụ thuộc chủ yếu vào Hb × SaO₂, còn phần oxy hòa tan do PaO₂ đóng góp nhỏ hơn nhiều.","distractorRationale":"Các phương án nhiễu hiểu sai các thành phần của hàm lượng oxy.","remediation":"hb-saturation","case_id":"ccase05","case_title":"Thiếu máu nặng với PaO₂ và SaO₂ bảo tồn","case_vignette":"Hb chỉ 5,5 g/dL nhưng SaO₂ 97%.","case_sequence":2,"case_stage":"analysis","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"oxygen-content-hemoglobin","error_pattern":"mechanism_confusion"},{"id":"c45","topic":"clinical","difficulty":"advanced","lesson":"hb-saturation","cognitive":"analyze","clinicalContext":"case-based","q":"Cách tích hợp nào đúng nhất?","o":["PaO₂ bình thường loại trừ mọi dạng thiếu oxy mô","Chỉ cần SaO₂ để đánh giá toàn bộ cung cấp oxy","Hemoglobin không liên quan nếu PaO₂ trên 80 mmHg","Đánh giá vận chuyển oxy phải xem cả hemoglobin, độ bão hòa, cung lượng tim và nhu cầu mô; PaO₂ bình thường không đủ để kết luận cung cấp oxy đầy đủ"],"a":3,"e":"Cung cấp oxy cho mô phụ thuộc hàm lượng oxy động mạch và cung lượng tim; PaO₂ bình thường chỉ phản ánh một phần nhỏ của hệ thống vận chuyển oxy.","distractorRationale":"Các phương án nhiễu dùng một chỉ số đơn lẻ để thay cho toàn bộ sinh lý cung cấp oxy.","remediation":"hb-saturation","case_id":"ccase05","case_title":"Thiếu máu nặng với PaO₂ và SaO₂ bảo tồn","case_vignette":"PaO₂ và SaO₂ bảo tồn nhưng người bệnh vẫn có dấu hiệu giảm cung cấp oxy mô trong bối cảnh Hb 5,5 g/dL.","case_sequence":3,"case_stage":"integration","serial_abg":false,"serial_group":"","source_scope":"clinical-library+handbook","concept":"oxygen-delivery-integration","error_pattern":"context_omission"}];
	var ASSESSMENT_V53_MIXED_QUESTIONS = [{"id":"mf001","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"understand","q":"Những yếu tố nào có thể làm giảm độ tin cậy của mẫu khí máu trước khi diễn giải?","item_format":"multiple_response","e":"Bọt khí, chậm xử lý không phù hợp và nhiễm dịch từ đường lấy mẫu đều có thể làm thay đổi kết quả; máy không báo lỗi không loại trừ sai số tiền phân tích.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-sampling","source_scope":"handbook:hb-sampling","concept":"preanalytical-integrity","error_pattern":"sample_quality_error","adaptive":false,"schema_version":3,"o":["Có bọt khí nhìn thấy trong bơm tiêm","Mẫu bị trì hoãn xử lý không phù hợp với quy trình","Mẫu lấy qua đường động mạch còn dịch bơm rửa","Máy phân tích không báo lỗi nên mẫu chắc chắn hợp lệ","Chỉ riêng tuổi người bệnh làm mẫu khí máu mất giá trị"],"correct_answers":[0,1,2],"domain":"foundation","lesson_id":"hb-sampling","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-sampling"},{"id":"mf002","topic":"foundation","difficulty":"intermediate","lesson":"hb-saturation","cognitive":"understand","q":"Chọn tất cả nhận định đúng về PaO₂, SaO₂ và hàm lượng oxy động mạch.","item_format":"multiple_response","e":"PaO₂ phản ánh áp suất oxy hòa tan, SaO₂ phản ánh tỷ lệ hemoglobin gắn oxy, còn nồng độ hemoglobin là thành phần lớn quyết định hàm lượng oxy. PaO₂ bình thường không bảo đảm hàm lượng oxy bình thường khi thiếu máu nặng.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-saturation","source_scope":"handbook:hb-saturation","concept":"oxygen-variables","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"o":["PaO₂ phản ánh áp suất riêng phần oxy hòa tan trong huyết tương","SaO₂ phản ánh tỷ lệ vị trí gắn oxy của hemoglobin đang được bão hòa","Nồng độ hemoglobin ảnh hưởng lớn đến hàm lượng oxy động mạch","PaO₂ bình thường luôn bảo đảm hàm lượng oxy động mạch bình thường","Đo độ bão hòa ngoại vi trực tiếp đo PaCO₂"],"correct_answers":[0,1,2],"domain":"foundation","lesson_id":"hb-saturation","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-saturation"},{"id":"mf003","topic":"acidbase","difficulty":"intermediate","lesson":"hb-compensation","cognitive":"apply","q":"Khí máu: pH 7,25; HCO₃⁻ 12 mmol/L; PaCO₂ 40 mmHg. Chọn tất cả nhận định phù hợp.","item_format":"multiple_response","e":"HCO₃⁻ thấp với acidemia xác định toan chuyển hóa. Theo Winter, PaCO₂ dự kiến khoảng 26 ± 2 mmHg; PaCO₂ thực tế 40 mmHg cao hơn rõ, gợi ý thêm toan hô hấp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-compensation","source_scope":"handbook:hb-compensation","concept":"winter-mixed-acidosis","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"o":["Có toan chuyển hóa","Có thêm toan hô hấp vì PaCO₂ cao hơn mức bù dự kiến","Bù hô hấp là phù hợp hoàn toàn","Có kiềm hô hấp phối hợp","Chỉ từ ba số này không thể xác định khoảng trống anion nếu thiếu điện giải"],"correct_answers":[0,1,4],"domain":"acidbase","lesson_id":"hb-compensation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-compensation"},{"id":"mf004","topic":"acidbase","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","q":"Khí máu: pH 7,52; HCO₃⁻ 32 mmol/L; PaCO₂ 30 mmHg. Chọn tất cả thành phần rối loạn có bằng chứng từ dữ kiện.","item_format":"multiple_response","e":"HCO₃⁻ tăng phù hợp kiềm chuyển hóa, trong khi PaCO₂ lại giảm thay vì tăng theo bù dự kiến, cho thấy kiềm hô hấp phối hợp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-mixed","source_scope":"handbook:hb-mixed","concept":"dual-alkalosis","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"o":["Kiềm chuyển hóa","Kiềm hô hấp","Toan hô hấp","Toan chuyển hóa","Đây là kiềm chuyển hóa đơn thuần với bù hô hấp thích hợp"],"correct_answers":[0,1],"domain":"acidbase","lesson_id":"hb-mixed","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-mixed"},{"id":"mf005","topic":"oxygen","difficulty":"intermediate","lesson":"hb-hypoxemia","cognitive":"understand","q":"Những cơ chế nào thường làm tăng chênh áp oxy phế nang–động mạch (A–a)?","item_format":"multiple_response","e":"Bất tương xứng thông khí/tưới máu, shunt và hạn chế khuếch tán có thể làm tăng A–a; giảm thông khí đơn thuần và giảm oxy khí hít vào thường không làm tăng A–a nếu phổi còn nguyên vẹn.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-hypoxemia","source_scope":"handbook:hb-hypoxemia","concept":"aa-gradient-mechanisms","error_pattern":"knowledge_gap","adaptive":false,"schema_version":3,"o":["Bất tương xứng thông khí/tưới máu","Luồng thông phải–trái hoặc shunt trong phổi","Hạn chế khuếch tán","Giảm thông khí phế nang đơn thuần","Giảm oxy khí hít vào ở độ cao đơn thuần"],"correct_answers":[0,1,2],"domain":"oxygen","lesson_id":"hb-hypoxemia","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-hypoxemia"},{"id":"mf006","topic":"oxygen","difficulty":"advanced","lesson":"hb-saturation","cognitive":"analyze","q":"Trong những tình huống nào cần nghĩ đến đồng oxy kế vì PaO₂/SpO₂ thông thường có thể không phản ánh đúng dyshemoglobin?","item_format":"multiple_response","e":"Phơi nhiễm carbon monoxit, nghi methemoglobin và khoảng cách độ bão hòa không giải thích được là các bối cảnh điển hình cần đồng oxy kế.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-saturation","source_scope":"handbook:hb-saturation","concept":"coox-indications","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Phơi nhiễm khói hoặc carbon monoxit","Nghi methemoglobin sau thuốc/chất oxy hóa","Có “khoảng cách độ bão hòa” không giải thích được","Thiếu máu thiếu sắt đơn thuần nhưng SpO₂ ổn định","Giảm thông khí do opioid với SpO₂ và PaO₂ phù hợp nhau"],"correct_answers":[0,1,2],"domain":"oxygen","lesson_id":"hb-saturation","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-saturation"},{"id":"mf007","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-sglt2","cognitive":"apply","q":"Chọn tất cả dữ kiện phù hợp với nhiễm toan ceton liên quan thuốc ức chế SGLT2 dù glucose không tăng rất cao.","item_format":"multiple_response","e":"Nhiễm toan ceton liên quan SGLT2 có thể biểu hiện bằng toan chuyển hóa tăng khoảng trống anion và ketonemia/ketonuria trong khi glucose chỉ tăng vừa hoặc thậm chí không tăng nhiều.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-sglt2","source_scope":"clinical-library+handbook:hb-case-sglt2","concept":"sglt2-euglycemic-dka","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Đang dùng thuốc ức chế SGLT2","Toan chuyển hóa tăng khoảng trống anion","Có tăng ceton máu hoặc niệu","Glucose có thể thấp hơn mức thường gặp ở DKA cổ điển","Khoảng trống anion bình thường và không có ceton là bằng chứng ủng hộ mạnh"],"correct_answers":[0,1,2,3],"domain":"clinical","lesson_id":"hb-case-sglt2","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-sglt2"},{"id":"mf008","topic":"clinical","difficulty":"advanced","lesson":"hb-case-salicylate","cognitive":"analyze","q":"Những đặc điểm nào có thể cùng xuất hiện trong ngộ độc salicylat với rối loạn toan–kiềm phối hợp?","item_format":"multiple_response","e":"Salicylat điển hình có thể gây kiềm hô hấp sớm phối hợp toan chuyển hóa tăng khoảng trống anion; pH cuối cùng có thể kiềm, gần bình thường hoặc toan tùy mức độ và thời điểm.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-salicylate","source_scope":"clinical-library+handbook:hb-case-salicylate","concept":"salicylate-mixed-pattern","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"o":["PaCO₂ giảm","HCO₃⁻ giảm","Khoảng trống anion tăng","pH có thể gần bình thường hoặc kiềm dù có toan chuyển hóa","Tăng PaCO₂ đơn thuần là mẫu hình kinh điển duy nhất"],"correct_answers":[0,1,2,3],"domain":"clinical","lesson_id":"hb-case-salicylate","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-salicylate"},{"id":"mf009","topic":"foundation","difficulty":"basic","lesson":"hb-reading","cognitive":"apply","q":"Sắp xếp trình tự đọc khí máu từ bước đầu đến tích hợp cuối.","item_format":"ordering","e":"Trình tự an toàn là xác minh mẫu/bối cảnh → xác định pH → nhận diện thành phần hô hấp/chuyển hóa → đánh giá bù và rối loạn phối hợp → tích hợp oxy hóa.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-reading","source_scope":"handbook:hb-reading","concept":"abg-reading-sequence","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Đánh giá bù trừ và rối loạn phối hợp","Xác minh loại mẫu, chất lượng mẫu và bối cảnh lấy","Đánh giá oxy hóa trong bối cảnh FiO₂/hỗ trợ oxy","Xác định acidemia hay alkalemia từ pH","Đối chiếu PaCO₂ và HCO₃⁻ để nhận diện rối loạn nguyên phát"],"correct_order":[1,3,4,0,2],"domain":"foundation","lesson_id":"hb-reading","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-reading"},{"id":"mf010","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","q":"Sắp xếp cách xử lý suy luận khi PaO₂ trên khí máu không phù hợp với SpO₂ và bệnh cảnh.","item_format":"ordering","e":"Cần ưu tiên kiểm tra tính toàn vẹn mẫu và bối cảnh oxy trước, sau đó xác minh/lấy lại mẫu khi cần; chỉ sau đó mới mở rộng sang dyshemoglobin và tích hợp toàn bộ dữ kiện.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-sampling","source_scope":"handbook:hb-sampling","concept":"discordant-oxygen-data","error_pattern":"sample_quality_error","adaptive":false,"schema_version":3,"o":["Xem xét đồng oxy kế nếu bệnh cảnh gợi ý dyshemoglobin","Xác minh loại mẫu và lỗi tiền phân tích như bọt khí/nhiễm dịch","Tích hợp kết quả đã xác minh với lâm sàng","Xác nhận FiO₂, phương thức hỗ trợ oxy và thời điểm lấy mẫu","Lấy lại hoặc xác minh mẫu đúng kỹ thuật nếu độ tin cậy còn thấp"],"correct_order":[1,3,4,0,2],"domain":"foundation","lesson_id":"hb-sampling","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-sampling"},{"id":"mf011","topic":"acidbase","difficulty":"basic","lesson":"hb-metabolic-acidosis","cognitive":"apply","q":"Sắp xếp các bước đánh giá một trường hợp nghi toan chuyển hóa.","item_format":"ordering","e":"Sau khi xác định acidemia và HCO₃⁻ thấp, cần tính khoảng trống anion, kiểm tra bù hô hấp bằng Winter, rồi đánh giá rối loạn phối hợp khi thích hợp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-metabolic-acidosis","source_scope":"handbook:hb-metabolic-acidosis","concept":"metabolic-acidosis-workflow","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"o":["Tính khoảng trống anion","Đánh giá bù hô hấp bằng công thức Winter","Xác định acidemia từ pH","Đánh giá rối loạn chuyển hóa phối hợp bằng delta khi có chỉ định","Xác nhận HCO₃⁻ giảm phù hợp rối loạn chuyển hóa"],"correct_order":[2,4,0,1,3],"domain":"acidbase","lesson_id":"hb-metabolic-acidosis","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-metabolic-acidosis"},{"id":"mf012","topic":"acidbase","difficulty":"advanced","lesson":"hb-respiratory-acidosis","cognitive":"analyze","q":"Sắp xếp cách phân tích tăng PaCO₂ kèm acidemia.","item_format":"ordering","e":"Cần nhận diện toan hô hấp, đặt trong bối cảnh cấp/mạn, so HCO₃⁻ với mức bù dự kiến, tìm rối loạn phối hợp và cuối cùng tích hợp với lâm sàng.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-respiratory-acidosis","source_scope":"handbook:hb-respiratory-acidosis","concept":"respiratory-acidosis-workflow","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"o":["So HCO₃⁻ với mức bù dự kiến theo cấp/mạn","Tích hợp với nguyên nhân giảm thông khí và diễn tiến","Xác định pH thấp và PaCO₂ tăng","Tìm bằng chứng rối loạn chuyển hóa phối hợp","Xác định bối cảnh cấp, mạn hoặc cấp trên nền mạn"],"correct_order":[2,4,0,3,1],"domain":"acidbase","lesson_id":"hb-respiratory-acidosis","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-respiratory-acidosis"},{"id":"mf013","topic":"oxygen","difficulty":"basic","lesson":"hb-oxygen-summary","cognitive":"apply","q":"Sắp xếp trình tự đánh giá giảm oxy máu trên khí máu.","item_format":"ordering","e":"FiO₂ và chất lượng mẫu phải được xác minh trước khi định lượng mức giảm oxy, sử dụng P/F hoặc A–a phù hợp, suy luận cơ chế và theo dõi xu hướng.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-oxygen-summary","source_scope":"handbook:hb-oxygen-summary","concept":"hypoxemia-workflow","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Tính/đánh giá chỉ số oxy hóa phù hợp như P/F hoặc A–a","Xác minh FiO₂, hỗ trợ oxy và độ tin cậy mẫu","Suy luận cơ chế giảm oxy máu","Đọc PaO₂ cùng SpO₂/SaO₂","So sánh xu hướng với các lần đo trước nếu có"],"correct_order":[1,3,0,2,4],"domain":"oxygen","lesson_id":"hb-oxygen-summary","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-oxygen-summary"},{"id":"mf014","topic":"oxygen","difficulty":"advanced","lesson":"hb-case-co","cognitive":"analyze","q":"Sắp xếp trình tự diễn giải khi nghi phơi nhiễm carbon monoxit nhưng PaO₂ không thấp.","item_format":"ordering","e":"PaO₂ bình thường không loại trừ CO; cần bắt đầu từ bối cảnh phơi nhiễm, nhận ra giới hạn của PaO₂/SpO₂, dùng đồng oxy kế và tích hợp COHb theo thời điểm lấy mẫu/hỗ trợ oxy.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-co","source_scope":"clinical-library+handbook:hb-case-co","concept":"co-interpretation-sequence","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Đọc COHb bằng đồng oxy kế","Nhận diện PaO₂ bình thường không loại trừ carbon monoxit","Tích hợp COHb với thời điểm lấy mẫu và việc đã thở oxy hay chưa","Xác định bối cảnh phơi nhiễm khói/CO và triệu chứng phù hợp","Theo dõi lại dữ liệu phù hợp với diễn tiến lâm sàng"],"correct_order":[3,1,0,2,4],"domain":"oxygen","lesson_id":"hb-case-co","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-co"},{"id":"mf015","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-dka","cognitive":"apply","q":"Sắp xếp trình tự diễn giải khí máu và xét nghiệm liên quan trong nhiễm toan ceton.","item_format":"ordering","e":"Cần xác định toan chuyển hóa, khoảng trống anion, bù hô hấp, đối chiếu keton/glucose và sau đó theo dõi sự cải thiện của toan–khoảng trống anion theo thời gian.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-dka","source_scope":"clinical-library+handbook:hb-case-dka","concept":"dka-interpretation-sequence","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Đánh giá bù hô hấp","Theo dõi xu hướng pH/HCO₃⁻ và khoảng trống anion","Xác định toan chuyển hóa từ pH và HCO₃⁻","Đối chiếu ceton và glucose với bối cảnh","Tính khoảng trống anion"],"correct_order":[2,4,0,3,1],"domain":"clinical","lesson_id":"hb-case-dka","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-dka"},{"id":"mf016","topic":"clinical","difficulty":"advanced","lesson":"hb-case-ventilator","cognitive":"analyze","q":"Sắp xếp cách đọc khí máu nối tiếp ở người bệnh đang thở máy.","item_format":"ordering","e":"Cần biết thời điểm và cài đặt máy tại mỗi mẫu, đọc thông khí qua pH/PaCO₂, đánh giá oxy hóa theo FiO₂/PEEP, so xu hướng và tích hợp với tình trạng lâm sàng.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-ventilator","source_scope":"clinical-library+handbook:hb-case-ventilator","concept":"ventilator-serial-sequence","error_pattern":"context_omission","adaptive":false,"schema_version":3,"o":["Đánh giá oxy hóa trong bối cảnh FiO₂/PEEP","So sánh với khí máu trước để xác định chiều thay đổi","Ghi nhận thời điểm lấy mẫu và cài đặt máy thở tương ứng","Đọc pH và PaCO₂ để đánh giá thông khí","Tích hợp với diễn tiến lâm sàng thay vì chỉ nhìn một con số"],"correct_order":[2,3,0,1,4],"domain":"clinical","lesson_id":"hb-case-ventilator","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-ventilator"},{"id":"mf017","topic":"foundation","difficulty":"basic","lesson":"hb-core","cognitive":"understand","q":"Ghép mỗi thông số với ý nghĩa sinh lý chính.","item_format":"matching","e":"pH phản ánh trạng thái acid–base; PaCO₂ là thành phần hô hấp; PaO₂ là áp suất oxy hòa tan; HCO₃⁻ là thành phần chuyển hóa/chất đệm.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-core","source_scope":"handbook:hb-core","concept":"core-abg-variables","error_pattern":"knowledge_gap","adaptive":false,"schema_version":3,"match_left":["pH","PaCO₂","PaO₂","HCO₃⁻"],"match_options":["Thành phần chuyển hóa/chất đệm bicarbonat","Áp suất riêng phần oxy hòa tan","Mức acid–base tổng thể","Thành phần hô hấp/thông khí"],"correct_matches":[2,3,1,0],"domain":"foundation","lesson_id":"hb-core","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-core"},{"id":"mf018","topic":"foundation","difficulty":"advanced","lesson":"hb-sampling","cognitive":"analyze","q":"Ghép lỗi tiền phân tích với hậu quả diễn giải điển hình.","item_format":"matching","e":"Mỗi lỗi tiền phân tích có cơ chế khác nhau; không nên dùng quy tắc hiệu chỉnh số học tùy ý để “sửa” mẫu lỗi.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-sampling","source_scope":"handbook:hb-sampling","concept":"preanalytical-effects","error_pattern":"sample_quality_error","adaptive":false,"schema_version":3,"match_left":["Bọt khí trong bơm tiêm","Trì hoãn xử lý mẫu","Nhiễm dịch bơm rửa từ đường lấy mẫu","Mẫu tĩnh mạch bị ghi nhầm là động mạch"],"match_options":["PO₂ không đại diện PaO₂ và có thể thấp đáng kể","Các chất phân tích có thể bị pha loãng đồng thời","Trao đổi khí với không khí làm PO₂/PCO₂ dịch chuyển","Chuyển hóa tế bào tiếp tục làm kết quả thay đổi theo thời gian"],"correct_matches":[2,3,1,0],"domain":"foundation","lesson_id":"hb-sampling","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-sampling"},{"id":"mf019","topic":"acidbase","difficulty":"basic","lesson":"hb-four","cognitive":"understand","q":"Ghép rối loạn nguyên phát với mẫu hình định hướng.","item_format":"matching","e":"Bốn rối loạn nguyên phát được nhận diện bằng hướng thay đổi pH cùng PaCO₂ hoặc HCO₃⁻.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-four","source_scope":"handbook:hb-four","concept":"four-primary-disorders","error_pattern":"knowledge_gap","adaptive":false,"schema_version":3,"match_left":["Toan chuyển hóa","Kiềm chuyển hóa","Toan hô hấp","Kiềm hô hấp"],"match_options":["pH tăng với HCO₃⁻ tăng","pH giảm với PaCO₂ tăng","pH tăng với PaCO₂ giảm","pH giảm với HCO₃⁻ giảm"],"correct_matches":[3,0,1,2],"domain":"acidbase","lesson_id":"hb-four","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-four"},{"id":"mf020","topic":"acidbase","difficulty":"intermediate","lesson":"hb-reference","cognitive":"apply","q":"Ghép công cụ tính với mục đích chính trong diễn giải toan–kiềm.","item_format":"matching","e":"Winter đánh giá bù trong toan chuyển hóa; khoảng trống anion giúp nhận diện anion không đo; delta ratio hỗ trợ tìm rối loạn chuyển hóa phối hợp; Henderson–Hasselbalch liên hệ pH, HCO₃⁻ và PaCO₂.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-reference","source_scope":"handbook:hb-reference","concept":"acidbase-formulas","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"match_left":["Công thức Winter","Khoảng trống anion","Delta ratio","Henderson–Hasselbalch"],"match_options":["Liên hệ pH với HCO₃⁻ và PaCO₂","Ước tính PaCO₂ bù dự kiến trong toan chuyển hóa","Đánh giá rối loạn chuyển hóa phối hợp khi khoảng trống anion tăng","Ước lượng phần anion không đo trong huyết tương"],"correct_matches":[1,3,2,0],"domain":"acidbase","lesson_id":"hb-reference","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-reference"},{"id":"mf021","topic":"oxygen","difficulty":"basic","lesson":"hb-reference","cognitive":"understand","q":"Ghép chỉ số oxy hóa với khái niệm nó phản ánh.","item_format":"matching","e":"Các chỉ số oxy hóa trả lời các câu hỏi khác nhau và không thể thay thế hoàn toàn cho nhau.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-reference","source_scope":"handbook:hb-reference","concept":"oxygenation-indices","error_pattern":"knowledge_gap","adaptive":false,"schema_version":3,"match_left":["Tỷ số PaO₂/FiO₂","Chênh áp A–a","SaO₂","CaO₂"],"match_options":["Tỷ lệ hemoglobin gắn oxy","Mức oxy trong máu phụ thuộc chủ yếu Hb và độ bão hòa","Mức suy giảm oxy hóa tương đối theo FiO₂","Chênh lệch oxy từ phế nang đến động mạch"],"correct_matches":[2,3,0,1],"domain":"oxygen","lesson_id":"hb-reference","cognitive_level":"understand","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-reference"},{"id":"mf022","topic":"oxygen","difficulty":"advanced","lesson":"hb-hypoxemia","cognitive":"analyze","q":"Ghép tình huống với cơ chế giảm oxy máu nổi bật nhất.","item_format":"matching","e":"Giảm thông khí, bất tương xứng V/Q, shunt và giảm oxy khí hít vào là các cơ chế khác nhau cần phân biệt bằng bối cảnh và chỉ số oxy hóa.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-hypoxemia","source_scope":"handbook:hb-hypoxemia","concept":"hypoxemia-mechanisms","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"match_left":["Quá liều opioid gây giảm thông khí","Thuyên tắc phổi","ARDS với phế nang ngập dịch/xẹp","Ở độ cao lớn"],"match_options":["Giảm oxy khí hít vào","Shunt/VQ rất thấp nổi bật","Giảm thông khí phế nang","Bất tương xứng thông khí/tưới máu"],"correct_matches":[2,3,1,0],"domain":"oxygen","lesson_id":"hb-hypoxemia","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-hypoxemia"},{"id":"mf023","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-copd","cognitive":"apply","q":"Ghép dữ kiện ca bệnh với trọng tâm diễn giải phù hợp.","item_format":"matching","e":"Những bối cảnh khác nhau yêu cầu ưu tiên các lớp diễn giải khác nhau thay vì áp dụng một mẫu duy nhất.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-copd","source_scope":"clinical-library+handbook:hb-case-copd","concept":"clinical-clue-priority","error_pattern":"context_omission","adaptive":false,"schema_version":3,"match_left":["COPD, PaCO₂ cao và HCO₃⁻ tăng","Phơi nhiễm khói, PaO₂ bình thường nhưng triệu chứng gợi CO","Shock với lactat tăng","Đang dùng SGLT2, toan tăng khoảng trống anion và keton dương tính"],"match_options":["Nghi toan ceton với glucose có thể không tăng rất cao","Đánh giá tăng CO₂ mạn/cấp trên nền mạn","Đánh giá giảm tưới máu và xu hướng lactat","Không loại trừ CO chỉ vì PaO₂ bình thường; cần đồng oxy kế"],"correct_matches":[1,3,2,0],"domain":"clinical","lesson_id":"hb-case-copd","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-copd"},{"id":"mf024","topic":"clinical","difficulty":"advanced","lesson":"hb-mixed","cognitive":"analyze","q":"Ghép mẫu khí máu với diễn giải toan–kiềm phù hợp nhất.","item_format":"matching","e":"So hướng pH, HCO₃⁻ và PaCO₂ với bù dự kiến giúp phân biệt rối loạn đơn thuần và phối hợp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-mixed","source_scope":"clinical-library+handbook:hb-mixed","concept":"mixed-pattern-recognition","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"match_left":["pH 7,25; HCO₃⁻ 12; PaCO₂ 25","pH 7,25; HCO₃⁻ 12; PaCO₂ 40","pH 7,52; HCO₃⁻ 32; PaCO₂ 48","pH 7,52; HCO₃⁻ 32; PaCO₂ 30"],"match_options":["Kiềm chuyển hóa với bù hô hấp phù hợp","Toan chuyển hóa với bù hô hấp phù hợp","Toan chuyển hóa phối hợp toan hô hấp","Kiềm chuyển hóa phối hợp kiềm hô hấp"],"correct_matches":[1,2,0,3],"domain":"clinical","lesson_id":"hb-mixed","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-mixed"},{"id":"mf025","topic":"foundation","difficulty":"basic","lesson":"hb-equation","cognitive":"apply","q":"Dùng Henderson–Hasselbalch: pH = 6,1 + log₁₀[HCO₃⁻/(0,03 × PaCO₂)]. Với HCO₃⁻ = 24 mmol/L và PaCO₂ = 40 mmHg, pH xấp xỉ bao nhiêu?","item_format":"numeric_calculation","e":"Kết quả là 6,1 + log₁₀(24/1,2) = 6,1 + log₁₀(20) ≈ 7,40.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-equation","source_scope":"handbook:hb-equation","concept":"henderson-hasselbalch","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":7.4,"tolerance":0.02,"unit":"pH","decimals":2,"domain":"foundation","lesson_id":"hb-equation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-equation"},{"id":"mf026","topic":"foundation","difficulty":"intermediate","lesson":"hb-saturation","cognitive":"apply","q":"Ước tính CaO₂ theo công thức 1,34 × Hb × SaO₂ + 0,003 × PaO₂. Với Hb 10 g/dL, SaO₂ 98% và PaO₂ 100 mmHg, CaO₂ xấp xỉ bao nhiêu mL O₂/dL?","item_format":"numeric_calculation","e":"CaO₂ ≈ 1,34 × 10 × 0,98 + 0,003 × 100 = 13,43 mL O₂/dL.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-saturation","source_scope":"handbook:hb-saturation","concept":"arterial-oxygen-content","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":13.43,"tolerance":0.15,"unit":"mL O₂/dL","decimals":1,"domain":"foundation","lesson_id":"hb-saturation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-saturation"},{"id":"mf027","topic":"acidbase","difficulty":"basic","lesson":"hb-anion-gap","cognitive":"apply","q":"Tính khoảng trống anion không hiệu chỉnh kali: Na⁺ 140, Cl⁻ 104, HCO₃⁻ 12 mmol/L. Kết quả bằng bao nhiêu mmol/L?","item_format":"numeric_calculation","e":"AG = Na⁺ − (Cl⁻ + HCO₃⁻) = 140 − (104 + 12) = 24 mmol/L.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-anion-gap","source_scope":"handbook:hb-anion-gap","concept":"anion-gap","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":24,"tolerance":0.5,"unit":"mmol/L","decimals":0,"domain":"acidbase","lesson_id":"hb-anion-gap","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-anion-gap"},{"id":"mf028","topic":"acidbase","difficulty":"intermediate","lesson":"hb-compensation","cognitive":"apply","q":"Theo công thức Winter, PaCO₂ dự kiến trung tâm = 1,5 × HCO₃⁻ + 8. Nếu HCO₃⁻ = 12 mmol/L, giá trị trung tâm dự kiến là bao nhiêu mmHg?","item_format":"numeric_calculation","e":"1,5 × 12 + 8 = 26 mmHg; khoảng thường dùng là xấp xỉ 26 ± 2 mmHg.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-compensation","source_scope":"handbook:hb-compensation","concept":"winter-formula","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":26,"tolerance":0.5,"unit":"mmHg","decimals":0,"domain":"acidbase","lesson_id":"hb-compensation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-compensation"},{"id":"mf029","topic":"oxygen","difficulty":"basic","lesson":"hb-pf","cognitive":"apply","q":"PaO₂ = 80 mmHg khi FiO₂ = 0,40. Tỷ số PaO₂/FiO₂ bằng bao nhiêu?","item_format":"numeric_calculation","e":"P/F = 80 / 0,40 = 200.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-pf","source_scope":"handbook:hb-pf","concept":"pf-ratio","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":200,"tolerance":2,"unit":"mmHg","decimals":0,"domain":"oxygen","lesson_id":"hb-pf","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-pf"},{"id":"mf030","topic":"oxygen","difficulty":"advanced","lesson":"hb-alveolar-equation","cognitive":"apply","q":"Ở mực nước biển, dùng PAO₂ = FiO₂ × (760 − 47) − PaCO₂/0,8. Với FiO₂ 0,21 và PaCO₂ 40 mmHg, PAO₂ xấp xỉ bao nhiêu mmHg?","item_format":"numeric_calculation","e":"PAO₂ ≈ 0,21 × 713 − 40/0,8 ≈ 99,7 mmHg, thường làm tròn khoảng 100 mmHg.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-alveolar-equation","source_scope":"handbook:hb-alveolar-equation","concept":"alveolar-gas-equation","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":99.7,"tolerance":2,"unit":"mmHg","decimals":0,"domain":"oxygen","lesson_id":"hb-alveolar-equation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-alveolar-equation"},{"id":"mf031","topic":"clinical","difficulty":"intermediate","lesson":"hb-mixed","cognitive":"apply","q":"Với AG đo được 24 mmol/L, AG bình thường giả định 12; HCO₃⁻ đo được 14 mmol/L, HCO₃⁻ bình thường 24. Delta ratio = (AG−12)/(24−HCO₃⁻) bằng bao nhiêu?","item_format":"numeric_calculation","e":"Delta ratio = (24−12)/(24−14) = 12/10 = 1,2.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-mixed","source_scope":"clinical-library+handbook:hb-mixed","concept":"delta-ratio","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":1.2,"tolerance":0.1,"unit":"","decimals":1,"domain":"clinical","lesson_id":"hb-mixed","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-mixed"},{"id":"mf032","topic":"clinical","difficulty":"intermediate","lesson":"hb-saturation","cognitive":"apply","q":"Một người bệnh thiếu máu có Hb 8 g/dL, SaO₂ 95% và PaO₂ 90 mmHg. Dùng công thức CaO₂ đã học để ước tính hàm lượng oxy động mạch, làm tròn một chữ số thập phân.","item_format":"numeric_calculation","e":"CaO₂ ≈ 1,34 × 8 × 0,95 + 0,003 × 90 ≈ 10,45 mL O₂/dL.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-saturation","source_scope":"clinical-library+handbook:hb-saturation","concept":"anemia-oxygen-content","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"answer_value":10.45,"tolerance":0.2,"unit":"mL O₂/dL","decimals":1,"domain":"clinical","lesson_id":"hb-saturation","cognitive_level":"apply","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-saturation"},{"id":"mf033","topic":"foundation","difficulty":"basic","lesson":"hb-sampling","cognitive":"analyze","q":"Mẫu khí máu có bọt khí nhìn thấy; PaO₂ cao bất thường so với SpO₂ và bệnh cảnh. Hoàn tất ba trường diễn giải.","item_format":"structured_case_interpretation","e":"Bọt khí làm độ tin cậy mẫu thấp; PaO₂ không nên được dùng như giá trị tuyệt đối và ưu tiên là xử lý lỗi tiền phân tích/lấy lại mẫu đúng kỹ thuật nếu kết quả ảnh hưởng quyết định.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-sampling","source_scope":"clinical-library+handbook:hb-sampling","concept":"air-bubble-structured","error_pattern":"sample_quality_error","adaptive":false,"schema_version":3,"case_vignette":"Người bệnh thở khí phòng, SpO₂ 92%, nhưng mẫu có bọt khí và PaO₂ 148 mmHg.","structured_fields":[{"id":"reliability","label":"Độ tin cậy mẫu","options":["Cao","Thấp do lỗi tiền phân tích","Không liên quan đến bọt khí"],"correct":1},{"id":"po2","label":"Cách dùng PaO₂","options":["Dùng tuyệt đối để kết luận oxy hóa bình thường","Diễn giải thận trọng, không coi là giá trị tuyệt đối","Tự trừ cố định 20 mmHg"],"correct":1},{"id":"priority","label":"Ưu tiên suy luận","options":["Xử lý chất lượng mẫu trước khi kết luận sinh lý","Chẩn đoán shunt ngay","Bỏ qua SpO₂"],"correct":0}],"domain":"foundation","lesson_id":"hb-sampling","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-sampling"},{"id":"mf034","topic":"foundation","difficulty":"intermediate","lesson":"hb-core","cognitive":"analyze","q":"Mẫu ghi là động mạch nhưng PO₂ 38 mmHg trong khi SpO₂ 96%; pH/PCO₂ tương tự mẫu tĩnh mạch. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"Dữ kiện không nhất quán làm tăng nghi ngờ nhầm loại mẫu; PO₂ tĩnh mạch không thay cho PaO₂ khi cần định lượng oxy hóa động mạch.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-core","source_scope":"clinical-library+handbook:hb-core","concept":"venous-mislabel-structured","error_pattern":"sample_quality_error","adaptive":false,"schema_version":3,"case_vignette":"SpO₂ 96%, phiếu ghi ABG nhưng PO₂ chỉ 38 mmHg; kiểm tra quy trình lấy mẫu chưa chắc chắn.","structured_fields":[{"id":"sample","label":"Khả năng cần nghĩ trước","options":["Mẫu tĩnh mạch bị ghi nhầm","Giảm oxy máu động mạch chắc chắn nặng","PaO₂ và PvO₂ luôn tương đương"],"correct":0},{"id":"oxygen","label":"Giá trị PO₂ của mẫu tĩnh mạch","options":["Có thể thay trực tiếp PaO₂","Không dùng trực tiếp để định lượng oxy hóa động mạch","Chỉ cần cộng 40 mmHg"],"correct":1},{"id":"next","label":"Bước xác minh","options":["Xác minh loại mẫu/lấy mẫu động mạch đáng tin cậy khi cần","Bỏ qua vì đã có PO₂","Chỉ dùng PCO₂ để suy ra PaO₂"],"correct":0}],"domain":"foundation","lesson_id":"hb-core","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-core"},{"id":"mf035","topic":"acidbase","difficulty":"intermediate","lesson":"hb-metabolic-acidosis","cognitive":"analyze","q":"Khí máu: pH 7,25; PaCO₂ 25; HCO₃⁻ 11 mmol/L. Na⁺ 140, Cl⁻ 100. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"Có toan chuyển hóa tăng khoảng trống anion: AG = 29. Winter cho PaCO₂ dự kiến 24,5 ± 2 mmHg, nên PaCO₂ 25 phù hợp bù hô hấp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-metabolic-acidosis","source_scope":"clinical-library+handbook:hb-metabolic-acidosis","concept":"hagma-winter-structured","error_pattern":"calculation_error","adaptive":false,"schema_version":3,"case_vignette":"Người bệnh có acidemia; điện giải và khí máu được lấy cùng thời điểm.","structured_fields":[{"id":"primary","label":"Rối loạn nguyên phát","options":["Toan chuyển hóa","Toan hô hấp","Kiềm chuyển hóa"],"correct":0},{"id":"ag","label":"Khoảng trống anion","options":["Bình thường","Tăng","Không thể tính vì đã có đủ Na/Cl/HCO₃"],"correct":1},{"id":"comp","label":"Bù hô hấp theo Winter","options":["Phù hợp","Có thêm toan hô hấp","Có thêm kiềm hô hấp"],"correct":0}],"domain":"acidbase","lesson_id":"hb-metabolic-acidosis","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-metabolic-acidosis"},{"id":"mf036","topic":"acidbase","difficulty":"advanced","lesson":"hb-metabolic-alkalosis","cognitive":"analyze","q":"Khí máu: pH 7,48; HCO₃⁻ 35 mmol/L; PaCO₂ 48 mmHg. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"Kiềm chuyển hóa là rối loạn nguyên phát. Với HCO₃⁻ tăng 11 mmol/L, PaCO₂ bù ước tính khoảng 48 mmHg, phù hợp dữ kiện; không cần gán thêm rối loạn hô hấp chỉ từ ba số này.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-metabolic-alkalosis","source_scope":"clinical-library+handbook:hb-metabolic-alkalosis","concept":"metabolic-alkalosis-compensation","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"case_vignette":"Không có thêm dữ kiện hô hấp ngoài khí máu tại thời điểm này.","structured_fields":[{"id":"primary","label":"Rối loạn nguyên phát","options":["Kiềm chuyển hóa","Kiềm hô hấp","Toan hô hấp"],"correct":0},{"id":"comp","label":"PaCO₂ 48 mmHg","options":["Phù hợp mức bù dự kiến","Thấp rõ gợi kiềm hô hấp phối hợp","Cao đến mức bắt buộc có toan hô hấp phối hợp"],"correct":0},{"id":"mixed","label":"Kết luận rối loạn phối hợp","options":["Không có bằng chứng bắt buộc từ ba số này","Chắc chắn có kiềm hô hấp","Chắc chắn có toan chuyển hóa"],"correct":0}],"domain":"acidbase","lesson_id":"hb-metabolic-alkalosis","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-metabolic-alkalosis"},{"id":"mf037","topic":"oxygen","difficulty":"intermediate","lesson":"hb-pf","cognitive":"analyze","q":"PaO₂ 60 mmHg khi FiO₂ 0,50. Hoàn tất diễn giải cấu trúc về oxy hóa.","item_format":"structured_case_interpretation","e":"P/F = 120 cho thấy suy giảm oxy hóa rõ. Tỷ số này mô tả mức oxy hóa nhưng chẩn đoán hội chứng cụ thể vẫn cần bối cảnh lâm sàng và thông tin hỗ trợ hô hấp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-pf","source_scope":"clinical-library+handbook:hb-pf","concept":"pf-structured","error_pattern":"context_omission","adaptive":false,"schema_version":3,"case_vignette":"Người bệnh đang nhận FiO₂ 0,50; PaO₂ đo cùng thời điểm là 60 mmHg.","structured_fields":[{"id":"pf","label":"Tỷ số P/F gần nhất","options":["120","200","300"],"correct":0},{"id":"degree","label":"Mức oxy hóa","options":["Suy giảm rõ","Hoàn toàn bình thường","Không thể nói gì dù biết PaO₂ và FiO₂"],"correct":0},{"id":"scope","label":"Phạm vi kết luận","options":["P/F một mình đủ chẩn đoán mọi nguyên nhân","Cần tích hợp bối cảnh và hỗ trợ hô hấp để phân loại hội chứng/nguyên nhân","FiO₂ không cần khi đọc PaO₂"],"correct":1}],"domain":"oxygen","lesson_id":"hb-pf","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-pf"},{"id":"mf038","topic":"oxygen","difficulty":"advanced","lesson":"hb-case-co","cognitive":"analyze","q":"Người bệnh phơi nhiễm khói, đau đầu/chóng mặt; PaO₂ 95 mmHg và SpO₂ 99%. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"PaO₂ có thể bình thường trong ngộ độc CO vì phản ánh oxy hòa tan; cần đồng oxy kế đo COHb và không dùng PaO₂ bình thường để loại trừ CO.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-co","source_scope":"clinical-library+handbook:hb-case-co","concept":"co-normal-pao2-structured","error_pattern":"context_omission","adaptive":false,"schema_version":3,"case_vignette":"Bệnh cảnh gợi phơi nhiễm carbon monoxit nhưng chỉ số oxy hóa thông thường không thấp.","structured_fields":[{"id":"pao2","label":"Ý nghĩa PaO₂ 95","options":["Loại trừ CO","Có thể vẫn bình thường trong CO","Chứng minh CaO₂ bình thường"],"correct":1},{"id":"test","label":"Xét nghiệm ưu tiên để xác định dyshemoglobin","options":["Đồng oxy kế/COHb","Chỉ lặp SpO₂","Chỉ tính anion gap"],"correct":0},{"id":"integration","label":"Kết luận","options":["Không loại trừ CO chỉ dựa vào PaO₂/SpO₂","CO chỉ tồn tại khi PaO₂ < 60","SpO₂ luôn đo chính xác COHb"],"correct":0}],"domain":"oxygen","lesson_id":"hb-case-co","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-co"},{"id":"mf039","topic":"clinical","difficulty":"intermediate","lesson":"hb-case-salicylate","cognitive":"analyze","q":"Khí máu: pH 7,46; PaCO₂ 20; HCO₃⁻ 14. Na⁺ 140, Cl⁻ 104. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"PaCO₂ thấp và HCO₃⁻ thấp với AG 22 phù hợp rối loạn phối hợp kiềm hô hấp + toan chuyển hóa tăng khoảng trống anion, mẫu hình tương thích ngộ độc salicylat trong bối cảnh phù hợp.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-salicylate","source_scope":"clinical-library+handbook:hb-case-salicylate","concept":"salicylate-structured","error_pattern":"mechanism_confusion","adaptive":false,"schema_version":3,"case_vignette":"Người bệnh có ù tai, buồn nôn và nghi dùng salicylat quá mức.","structured_fields":[{"id":"acidbase","label":"Mẫu hình toan–kiềm","options":["Kiềm hô hấp phối hợp toan chuyển hóa","Kiềm hô hấp đơn thuần","Toan hô hấp đơn thuần"],"correct":0},{"id":"ag","label":"Khoảng trống anion","options":["22 mmol/L, tăng","10 mmol/L, bình thường","Không thể tính"],"correct":0},{"id":"context","label":"Tích hợp bệnh cảnh","options":["Tương thích mẫu hình salicylat","Loại trừ salicylat","Chứng minh chỉ có bệnh phổi tắc nghẽn"],"correct":0}],"domain":"clinical","lesson_id":"hb-case-salicylate","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-salicylate"},{"id":"mf040","topic":"clinical","difficulty":"advanced","lesson":"hb-case-copd","cognitive":"analyze","q":"Khí máu: pH 7,28; PaCO₂ 70; HCO₃⁻ 32 mmol/L ở người bệnh COPD có tăng CO₂ mạn trước đó. Hoàn tất diễn giải.","item_format":"structured_case_interpretation","e":"PaCO₂ tăng xác định toan hô hấp; HCO₃⁻ tăng cho thấy có bù thận/chronicity, trong khi pH vẫn acid cho thấy thành phần cấp nặng thêm trên nền tăng CO₂ mạn là khả năng cần ưu tiên.","distractorRationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation":"hb-case-copd","source_scope":"clinical-library+handbook:hb-case-copd","concept":"acute-on-chronic-hypercapnia","error_pattern":"context_omission","adaptive":false,"schema_version":3,"case_vignette":"Hồ sơ trước đây cho thấy người bệnh từng có PaCO₂ tăng và HCO₃⁻ cao.","structured_fields":[{"id":"primary","label":"Rối loạn chính","options":["Toan hô hấp","Toan chuyển hóa","Kiềm hô hấp"],"correct":0},{"id":"hco3","label":"Ý nghĩa HCO₃⁻ 32","options":["Gợi có bù thận/chronicity","Loại trừ tăng CO₂ mạn","Chỉ do lỗi máy"],"correct":0},{"id":"integration","label":"Diễn giải tích hợp","options":["Cấp trên nền tăng CO₂ mạn cần được cân nhắc","Chắc chắn là toan hô hấp cấp đơn thuần không có nền mạn","pH 7,28 là bình thường"],"correct":0}],"domain":"clinical","lesson_id":"hb-case-copd","cognitive_level":"analyze","distractor_rationale":"Các lựa chọn hoặc cấu hình sai phản ánh nhầm cơ chế, bỏ sót bước diễn giải hoặc áp dụng công thức không phù hợp với dữ kiện.","remediation_link":"hb-case-copd"}];
	function assessmentCognitiveForDifficulty(difficulty){return difficulty==='basic'?'remember':difficulty==='advanced'?'analyze':'apply';}
	function assessmentConceptFromLesson(lesson){return String(lesson||'hb-reading').replace(/^hb-case-/,'case:').replace(/^hb-/,'');}
	function assessmentErrorPattern(x){
		var lesson=String(x.lesson||''),ctx=String(x.clinicalContext||''),stem=String(x.q||'').toLowerCase();
		if(ctx==='preanalytical'||/sampling|airbubble/.test(lesson)) return 'sample_quality_error';
		if(/equation|anion-gap|alveolar|aa-gradient|pf/.test(lesson)||/bao nhiêu|xấp xỉ|tính /.test(stem)) return 'calculation_error';
		if(x.topic==='clinical'||/serial|critical-care|ventilation|toxicology|diabetes|pulmonary/.test(ctx)) return 'context_omission';
		if((x.cognitive||'')==='remember') return 'knowledge_gap';
		return 'mechanism_confusion';
	}
	function assessmentSourceScope(x){
		if(x.error_pattern==='calculation_error') return 'calculation-core+handbook';
		if(x.error_pattern==='sample_quality_error') return 'handbook:preanalytical';
		if(x.topic==='clinical') return 'clinical-library+handbook';
		return 'handbook';
	}
	function normalizeAssessmentItem(q){
		var x=Object.assign({},q);x.o=(q.o||[]).slice();
		x.lesson=x.lesson||LEGACY_ITEM_LESSON[x.id]||'hb-reading';
		x.cognitive=x.cognitive||assessmentCognitiveForDifficulty(x.difficulty||'intermediate');
		x.clinicalContext=x.clinicalContext||({foundation:'general',acidbase:'general',oxygen:'respiratory',clinical:'clinical-case'}[x.topic]||'general');
		x.distractorRationale=x.distractorRationale||'Các phương án nhiễu phản ánh lỗi đọc tách rời thông số, đảo hướng sinh lý hoặc kết luận vượt quá dữ kiện hiện có.';
		x.remediation=x.remediation||x.lesson;
		/* v5.1 assessment taxonomy. Compatibility aliases stay available to avoid engine/storage migration. */
		x.domain=x.topic;
		x.lesson_id=x.lesson;
		x.concept=x.concept||assessmentConceptFromLesson(x.lesson);
		x.cognitive_level=x.cognitive;
		x.error_pattern=x.error_pattern||assessmentErrorPattern(x);
		x.source_scope=x.source_scope||assessmentSourceScope(x);
		x.distractor_rationale=x.distractorRationale;
		x.remediation_link=x.remediation;
		x.item_format=x.item_format||'single_best_answer';
		x.case_linked=!!x.case_id;
		if(x.case_linked){x.case_sequence=Number(x.case_sequence||1);x.case_stage=x.case_stage||'initial';x.serial_abg=!!x.serial_abg;}
		x.schema_version=x.case_linked?2:1;
		if(x.item_format!=='single_best_answer')x.schema_version=3;
		return x;
	}
	var ASSESSMENT_BANK = LEARNING_QUESTIONS.map(function(q){
		return normalizeAssessmentItem({id:q.id,topic:q.topic,difficulty:ASSESSMENT_DIFFICULTY[q.id]||'intermediate',q:q.q,o:q.o,a:q.a,e:q.e,adaptive:true});
	}).concat(ASSESSMENT_EXTRA_QUESTIONS.map(function(q){var x=Object.assign({},q);x.adaptive=false;return normalizeAssessmentItem(x);})).concat(ASSESSMENT_V51_QUESTIONS.map(function(q){var x=Object.assign({},q);x.adaptive=false;return normalizeAssessmentItem(x);})).concat(ASSESSMENT_V52_CASE_QUESTIONS.map(function(q){var x=Object.assign({},q);x.adaptive=false;return normalizeAssessmentItem(x);})).concat(ASSESSMENT_V53_MIXED_QUESTIONS.map(function(q){var x=Object.assign({},q);x.adaptive=false;return normalizeAssessmentItem(x);}));
	var ASSESSMENT_MIXED_FORMATS=['multiple_response','ordering','matching','numeric_calculation','structured_case_interpretation'];
	var CONTENT_GOVERNANCE_V59={release:'5.9',assessmentItems:220,lessons:50,cases:50,itemFormats:6,mockPacks:8,corpusFrozenForV60:true,localFirst:true};
	var ASSESSMENT_BLUEPRINTS = {
		generator:{label:'Tạo đề luyện tập',description:'Chọn miền kiến thức, độ khó, dạng câu hỏi và mã đề phù hợp với mục tiêu ôn tập.',generator:true,total:30,minutes:45},
		quick:{label:'Nhanh · 12 câu',description:'Mỗi miền kiến thức 3 câu: 1 cơ bản, 1 trung bình và 1 nâng cao.',perTopic:{basic:1,intermediate:1,advanced:1},itemFormat:'single_best_answer'},
		standard:{label:'Cân bằng · 16 câu',description:'Mỗi miền kiến thức 4 câu: 1 cơ bản, 2 trung bình và 1 nâng cao.',perTopic:{basic:1,intermediate:2,advanced:1},itemFormat:'single_best_answer'},
		advanced:{label:'Nâng cao · 20 câu',description:'Mỗi miền kiến thức 5 câu, tăng tỷ trọng câu nâng cao.',perTopic:{basic:1,intermediate:1,advanced:3},itemFormat:'single_best_answer'},
		case:{label:'Theo ca · 20 câu',description:'Chỉ lấy câu SBA gắn ca lâm sàng; cân bằng bốn miền và ưu tiên mức vận dụng–phân tích.',perTopic:{basic:1,intermediate:2,advanced:2},caseOnly:true,itemFormat:'single_best_answer'},
		mixed:{label:'Hỗn hợp · 20 câu',description:'Mỗi miền có đủ 5 dạng mới: nhiều đáp án, sắp xếp, ghép cặp, tính số và diễn giải cấu trúc.',mixedOnly:true,formats:ASSESSMENT_MIXED_FORMATS.slice()},
		mock_foundation:{label:'Thi thử Nền tảng · 30 câu',description:'Sinh lý, lấy mẫu, kiểm tra tính hợp lý và nền tảng diễn giải khí máu.',mockPack:true,total:30,minutes:35,seed:54011,topic:'foundation',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
		mock_acidbase:{label:'Thi thử Toan–kiềm · 30 câu',description:'Rối loạn nguyên phát, bù trừ, khoảng trống anion, delta và rối loạn phối hợp.',mockPack:true,total:30,minutes:40,seed:54021,topic:'acidbase',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
		mock_oxygen:{label:'Thi thử Oxy hóa/Thông khí · 30 câu',description:'PaO₂/FiO₂, A–a, thông khí phế nang, luồng thông, thông khí–tưới máu và bối cảnh hỗ trợ hô hấp.',mockPack:true,total:30,minutes:40,seed:54031,topic:'oxygen',difficultyPlan:{basic:10,intermediate:10,advanced:10}},
		mock_clinical:{label:'Thi thử Ca lâm sàng · 30 câu',description:'Ca gắn dữ kiện lâm sàng và khí máu nối tiếp; ưu tiên tích hợp hơn ghi nhớ đơn thuần.',mockPack:true,total:30,minutes:45,seed:54041,caseOnly:true,difficultyPlan:{basic:8,intermediate:11,advanced:11}},
		mock_advanced:{label:'Thi thử Suy luận nâng cao · 30 câu',description:'Tập trung câu nâng cao và nhiều định dạng trên cả bốn miền kiến thức.',mockPack:true,total:30,minutes:45,seed:54051,difficulty:'advanced',topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7}},
		mock_comprehensive:{label:'Thi thử Tổng hợp A · 30 câu',description:'Đề mô phỏng tổng hợp, cân bằng miền kiến thức, độ khó, ca lâm sàng và định dạng.',mockPack:true,total:30,minutes:45,seed:54061,comprehensive:true,topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7},difficultyPlan:{basic:8,intermediate:12,advanced:10}},
		mock_comprehensive_b:{label:'Thi thử Tổng hợp B · 30 câu',description:'Bộ đề tương đương thứ hai với mã đề độc lập, giữ phân bố 7/8/8/7 theo bốn miền kiến thức.',mockPack:true,total:30,minutes:45,seed:54071,comprehensive:true,topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7},difficultyPlan:{basic:8,intermediate:12,advanced:10}},
		mock_multiformat:{label:'Thi thử Đa định dạng · 30 câu',description:'Mỗi miền có 5 câu đa định dạng và thêm 10 câu SBA để đánh giá khả năng chuyển đổi giữa nhiều kiểu nhiệm vụ.',mockPack:true,total:30,minutes:45,seed:54081,mixedComprehensive:true,topicPlan:{foundation:7,acidbase:8,oxygen:8,clinical:7}}
	};


	function assessmentFormatName(format){
		return {single_best_answer:'Một đáp án',multiple_response:'Nhiều đáp án',ordering:'Sắp xếp',matching:'Ghép cặp',numeric_calculation:'Tính số',structured_case_interpretation:'Diễn giải cấu trúc'}[format]||'Câu hỏi';
	}
	function assessmentNumericValue(value){
		if(value===null||value===undefined||value==='')return NaN;
		return Number(String(value).trim().replace(',','.'));
	}
	function assessmentOrderingSequence(answer){
		if(!Array.isArray(answer))return [];
		return answer.map(function(rank,index){return {rank:Number(rank),index:index};}).filter(function(x){return Number.isFinite(x.rank);}).sort(function(a,b){return a.rank-b.rank;}).map(function(x){return x.index;});
	}
	function assessmentAnswerComplete(item,answer){
		var f=item.item_format||'single_best_answer';
		if(f==='single_best_answer')return Number.isInteger(answer);
		if(f==='multiple_response')return Array.isArray(answer)&&answer.length>0;
		if(f==='ordering'){
			if(!Array.isArray(answer)||answer.length!==(item.o||[]).length)return false;
			if(answer.some(function(v){return v===null||v===undefined||v==='';}))return false;var ranks=answer.map(Number);return ranks.every(Number.isFinite)&&new Set(ranks).size===ranks.length&&Math.min.apply(null,ranks)===0&&Math.max.apply(null,ranks)===ranks.length-1;
		}
		if(f==='matching')return Array.isArray(answer)&&answer.length===(item.match_left||[]).length&&answer.every(function(v){return v!==null&&v!==undefined&&v!==''&&Number.isInteger(Number(v))&&Number(v)>=0;});
		if(f==='numeric_calculation')return Number.isFinite(assessmentNumericValue(answer));
		if(f==='structured_case_interpretation')return !!answer&&typeof answer==='object'&&(item.structured_fields||[]).every(function(field){return Number.isInteger(Number(answer[field.id]));});
		return false;
	}
	function assessmentItemCorrect(item,answer){
		if(!assessmentAnswerComplete(item,answer))return false;
		var f=item.item_format||'single_best_answer';
		if(f==='single_best_answer')return Number(answer)===Number(item.a);
		if(f==='multiple_response'){
			var a=answer.map(Number).sort(function(x,y){return x-y;}),b=(item.correct_answers||[]).map(Number).sort(function(x,y){return x-y;});
			return a.length===b.length&&a.every(function(v,i){return v===b[i];});
		}
		if(f==='ordering'){
			var seq=assessmentOrderingSequence(answer),correct=(item.correct_order||[]).map(Number);return seq.length===correct.length&&seq.every(function(v,i){return v===correct[i];});
		}
		if(f==='matching')return (item.correct_matches||[]).every(function(v,i){return Number(answer[i])===Number(v);});
		if(f==='numeric_calculation')return Math.abs(assessmentNumericValue(answer)-Number(item.answer_value))<=Number(item.tolerance||0);
		if(f==='structured_case_interpretation')return (item.structured_fields||[]).every(function(field){return Number(answer[field.id])===Number(field.correct);});
		return false;
	}


	function setupLearningSystem(root) {
		var host = root.querySelector('[data-learning-system]');
		if (!host || host.dataset.learningReady === '1') return;
		host.dataset.learningReady = '1';
		var storageKey = 'medipharm_abg_learning_v30';
		var state = {questions:{},cards:{},cardSchedule:{},exam:{count:0,best:0,last:0,total:12},assessment:{version:38,count:0,best:0,last:0,total:0,history:[]},adaptive:{version:37,started:0,completed:0,lastSession:0,lastCompleted:0},remediation:{version:57,totalErrors:0,lastUpdated:0,patterns:{},concepts:{},items:{}},platform:{version:40,analyses:0,lastAnalysis:0,lastContext:'',theoryViewed:{},lastTheory:0,lastActivity:0}};
		var hadSavedAssessment = false;
		try {
			var saved = JSON.parse(window.localStorage.getItem(storageKey) || 'null');
			if (saved && typeof saved === 'object') { hadSavedAssessment=!!(saved.assessment&&typeof saved.assessment==='object'); state = Object.assign(state, saved); }
		} catch (error) {}
		if (!state.questions || typeof state.questions !== 'object') state.questions = {};
		if (!state.cards || typeof state.cards !== 'object') state.cards = {};
		if (!state.cardSchedule || typeof state.cardSchedule !== 'object') state.cardSchedule = {};
		if (!state.exam || typeof state.exam !== 'object') state.exam = {count:0,best:0,last:0,total:12};
		if (!state.assessment || typeof state.assessment !== 'object') state.assessment = {version:38,count:0,best:0,last:0,total:0,history:[]};
		if (!hadSavedAssessment && Number(state.exam.count||0)>0) state.assessment = {version:38,count:Number(state.exam.count||0),best:Number(state.exam.best||0),last:Number(state.exam.last||0),total:Number(state.exam.total||0),history:[]};
		if (!Array.isArray(state.assessment.history)) state.assessment.history = [];
		state.assessment.version=38;
		if (!state.adaptive || typeof state.adaptive !== 'object') state.adaptive = {version:37,started:0,completed:0,lastSession:0,lastCompleted:0};
		state.adaptive.version=37;
		if (!state.remediation || typeof state.remediation !== 'object') state.remediation={version:57,totalErrors:0,lastUpdated:0,patterns:{},concepts:{},items:{}};
		if (!state.remediation.patterns || typeof state.remediation.patterns !== 'object') state.remediation.patterns={};
		if (!state.remediation.concepts || typeof state.remediation.concepts !== 'object') state.remediation.concepts={};
		if (!state.remediation.items || typeof state.remediation.items !== 'object') state.remediation.items={};
		state.remediation.version=57;state.remediation.totalErrors=Number(state.remediation.totalErrors||0);state.remediation.lastUpdated=Number(state.remediation.lastUpdated||0);
		if (!state.platform || typeof state.platform !== 'object') state.platform = {version:40,analyses:0,lastAnalysis:0,lastContext:'',theoryViewed:{},lastTheory:0,lastActivity:0};
		if (!state.platform.theoryViewed || typeof state.platform.theoryViewed !== 'object') state.platform.theoryViewed = {};
		state.platform.version=40;
		state.platform.analyses=Number(state.platform.analyses||0);

		var DAY_MS=24*60*60*1000, HOUR_MS=60*60*1000;
		var REVIEW_INTERVAL_DAYS=[1,3,7,14,30,60];
		function normalizeQuestionRecord(item){
			item=(item&&typeof item==='object')?item:{};
			item.attempts=Number(item.attempts||0);item.correct=Number(item.correct||0);item.everCorrect=!!item.everCorrect;
			item.streak=Number(item.streak||0);item.lastAnswered=Number(item.lastAnswered||0);item.nextReview=Number(item.nextReview||0);
			return item;
		}
		var ERROR_PATTERN_META={knowledge_gap:{label:'Thiếu kiến thức nền',short:'Kiến thức nền',note:'Củng cố khái niệm hoặc khoảng tham chiếu trước khi áp dụng.'},reasoning_sequence_error:{label:'Sai trình tự suy luận',short:'Trình tự suy luận',note:'Ôn lại thứ tự đọc mẫu → pH → cơ chế → bù → oxy hóa → tích hợp.'},calculation_error:{label:'Sai tính toán',short:'Tính toán',note:'Làm lại công thức, đơn vị và điều kiện áp dụng trước khi diễn giải.'},context_omission:{label:'Bỏ sót bối cảnh lâm sàng',short:'Bối cảnh',note:'Đọc lại FiO₂, hỗ trợ hô hấp, bệnh nền, độc chất và thời điểm lấy mẫu.'},oxygenation_error:{label:'Sai đánh giá oxy hóa/thông khí',short:'Oxy hóa & thông khí',note:'Phân biệt PaO₂, SpO₂, FiO₂, PaCO₂ và các chỉ số trao đổi khí.'},sample_quality_error:{label:'Bỏ sót chất lượng mẫu',short:'Chất lượng mẫu',note:'Kiểm tra loại mẫu, bọt khí, heparin, nhiễm dịch và chậm phân tích.'},serial_interpretation_error:{label:'Sai diễn giải khí máu nối tiếp',short:'Khí máu nối tiếp',note:'So sánh xu hướng trong cùng bối cảnh FiO₂, máy thở và thời điểm can thiệp.'}};
		function remediationPatternForQuestion(q){var x=(q&&q.domain)?q:normalizeAssessmentItem(Object.assign({difficulty:'intermediate'},q||{}));if(x.error_pattern==='sample_quality_error')return 'sample_quality_error';if(x.error_pattern==='calculation_error')return 'calculation_error';if(x.serial_abg||String(x.clinicalContext||'').toLowerCase()==='serial'||/serial|trend/.test(String(x.concept||'')))return 'serial_interpretation_error';if(x.topic==='oxygen')return 'oxygenation_error';if(x.error_pattern==='context_omission')return 'context_omission';if(x.error_pattern==='knowledge_gap')return 'knowledge_gap';return 'reasoning_sequence_error';}
		function remediationBankItem(id){return ASSESSMENT_BANK.find(function(q){return q.id===id;})||null;}
		function remediationRelatedCase(topic){return {foundation:'normal',acidbase:'dka',oxygen:'hagma',clinical:'mixed'}[topic]||'normal';}
		function recordRemediationResult(q,ok,source){if(!q||!q.id)return;var now=Date.now(),x=(q.domain?q:normalizeAssessmentItem(Object.assign({difficulty:'intermediate'},q))),pattern=remediationPatternForQuestion(x),concept=x.concept||assessmentConceptFromLesson(x.lesson),item=state.remediation.items[x.id]||{id:x.id,wrongCount:0,correctAfterError:0};if(ok){if(item.wrongCount){item.correctAfterError=Number(item.correctAfterError||0)+1;item.lastCorrect=now;item.status=item.correctAfterError>=2?'improving':'reviewing';var pr=state.remediation.patterns[pattern];if(pr)pr.recoveries=Number(pr.recoveries||0)+1;}else{return;}}else{item.wrongCount=Number(item.wrongCount||0)+1;item.correctAfterError=0;item.lastWrong=now;item.status='needs_review';state.remediation.totalErrors++;var p=state.remediation.patterns[pattern]||(state.remediation.patterns[pattern]={errors:0,recoveries:0,lastAt:0});p.errors++;p.lastAt=now;var c=state.remediation.concepts[concept]||(state.remediation.concepts[concept]={errors:0,lastAt:0,topic:x.topic,lesson:x.remediation_link||x.lesson});c.errors++;c.lastAt=now;}item.pattern=pattern;item.topic=x.topic;item.lesson=x.remediation_link||x.lesson;item.concept=concept;item.case_id=x.case_id||'';item.lastSource=source||'practice';state.remediation.items[x.id]=item;state.remediation.lastUpdated=now;}
		function remediationPriorityItems(limit){var now=Date.now();return Object.keys(state.remediation.items||{}).map(function(id){var item=state.remediation.items[id],q=remediationBankItem(id),age=item.lastWrong?Math.max(0,(now-item.lastWrong)/DAY_MS):90,active=Math.max(0,Number(item.wrongCount||0)-Math.floor(Number(item.correctAfterError||0)/2));return {item:item,q:q,active:active,score:active*30+Math.max(0,20-age)-Number(item.correctAfterError||0)*5};}).filter(function(x){return x.q&&x.active>0;}).sort(function(a,b){return b.score-a.score||Number(b.item.lastWrong||0)-Number(a.item.lastWrong||0);}).slice(0,limit||6);}
		function remediationPatternRows(){return Object.keys(state.remediation.patterns||{}).map(function(key){var r=state.remediation.patterns[key]||{},meta=ERROR_PATTERN_META[key]||{label:key,short:key,note:''};return {key:key,label:meta.label,short:meta.short,note:meta.note,errors:Number(r.errors||0),recoveries:Number(r.recoveries||0),lastAt:Number(r.lastAt||0)};}).filter(function(r){return r.errors>0;}).sort(function(a,b){return b.errors-a.errors||b.lastAt-a.lastAt;});}
		function remediationInlineHtml(){var rows=remediationPriorityItems(3);if(!rows.length)return '';return '<section class="nah-abg__targeted-remediation"><div><span>ÔN TẬP CÓ MỤC TIÊU</span><strong>Ưu tiên sau lượt làm bài này</strong></div><div>'+rows.map(function(x){var meta=ERROR_PATTERN_META[x.item.pattern]||{};return '<article><b>'+escapeHtml(meta.short||x.item.pattern)+'</b><span>'+escapeHtml(learningTopicName(x.q.topic))+'</span><small>'+escapeHtml((x.q.q||'').slice(0,92))+'</small></article>';}).join('')+'</div><button type="button" class="nah-abg__button nah-abg__button--ghost" data-exam-remediation>Mở lộ trình cải thiện</button></section>';}

		function recordQuestionResult(q,ok,source){
			var now=Date.now(), item=normalizeQuestionRecord(state.questions[q.id]);
			item.attempts++; if(ok){item.correct++;item.everCorrect=true;item.streak=Math.max(0,item.streak)+1;}else{item.streak=0;}
			item.lastCorrect=!!ok;item.lastAnswered=now;item.lastSource=source||'topic';
			if(ok){var idx=Math.min(item.streak-1,REVIEW_INTERVAL_DAYS.length-1);item.intervalDays=REVIEW_INTERVAL_DAYS[Math.max(0,idx)];item.nextReview=now+item.intervalDays*DAY_MS;}
			else{item.intervalDays=0;item.nextReview=now+6*HOUR_MS;}
			state.questions[q.id]=item;recordRemediationResult(q,ok,source);return item;
		}
		function isQuestionDue(item,now){item=normalizeQuestionRecord(item);return !!item.nextReview&&item.nextReview<=(now||Date.now());}
		function topicMetrics(topic){
			var pool=LEARNING_QUESTIONS.filter(function(q){return q.topic===topic;}), attempts=0,correct=0,mastered=0,due=0,needsReview=0,seen=0,now=Date.now();
			pool.forEach(function(q){var item=state.questions[q.id];if(!item)return;item=normalizeQuestionRecord(item);if(item.attempts){seen++;attempts+=item.attempts;correct+=item.correct;}if(item.everCorrect)mastered++;if(isQuestionDue(item,now))due++;if(item.attempts&&item.lastCorrect===false)needsReview++;});
			var accuracy=attempts?Math.round(correct/attempts*100):null, mastery=pool.length?Math.round(mastered/pool.length*100):0;
			var strength=accuracy===null?mastery:Math.round(accuracy*.65+mastery*.35);
			return {topic:topic,total:pool.length,seen:seen,attempts:attempts,correct:correct,accuracy:accuracy,mastered:mastered,mastery:mastery,due:due,needsReview:needsReview,strength:strength};
		}
		function allTopicMetrics(){return ['foundation','acidbase','oxygen','clinical'].map(topicMetrics);}
		function recommendedTopic(){
			var rows=allTopicMetrics(), dueRows=rows.filter(function(r){return r.due>0;});
			if(dueRows.length)return dueRows.sort(function(a,b){return b.due-a.due||a.strength-b.strength;})[0];
			var weak=rows.filter(function(r){return r.attempts>=2&&r.strength<80;});
			if(weak.length)return weak.sort(function(a,b){return a.strength-b.strength||b.attempts-a.attempts;})[0];
			return rows.sort(function(a,b){return a.mastery-b.mastery||a.seen-b.seen;})[0];
		}
		function adaptiveQuestionScore(q){
			var item=state.questions[q.id], metric=topicMetrics(q.topic), score=(100-metric.strength)*.7;
			if(!item)return score+45; item=normalizeQuestionRecord(item);
			if(isQuestionDue(item))score+=110;if(item.lastCorrect===false)score+=55;if(item.everCorrect===false)score+=20;score-=Math.min(25,item.streak*5);return score;
		}
		function buildAdaptiveQueue(limit,avoid){
			return LEARNING_QUESTIONS.filter(function(q){return q.id!==avoid;}).map(function(q){return {q:q,score:adaptiveQuestionScore(q)};}).sort(function(a,b){return b.score-a.score||a.q.id.localeCompare(b.q.id);}).slice(0,limit||8).map(function(x){return x.q;});
		}
		function dueQuestionCount(){return LEARNING_QUESTIONS.filter(function(q){return isQuestionDue(state.questions[q.id]);}).length;}
		function dueCardCount(){var now=Date.now();return LEARNING_CARDS.filter(function(c){var x=state.cardSchedule[c.id];return x&&Number(x.nextReview||0)&&Number(x.nextReview)<=now;}).length;}


		/* v4.2 — Interactive Home & Dynamic Learning Feed. Nội dung hoàn toàn cục bộ. */
		var HOME_PEARLS=[
			{topic:'acidbase',text:'Đừng gọi tên rối loạn chỉ từ pH. pH gần bình thường vẫn có thể che giấu hai rối loạn toan–kiềm đối nghịch cùng tồn tại.'},
			{topic:'acidbase',text:'Khi HCO₃⁻ giảm, PaCO₂ phải được đối chiếu với mức bù dự kiến. Một PaCO₂ “thấp” chưa chắc là bù phù hợp.'},
			{topic:'acidbase',text:'Khoảng trống anion tăng không tự nói lên nguyên nhân. Luôn đặt nó cạnh lactate, ketone, chức năng thận, độc chất và bối cảnh lâm sàng.'},
			{topic:'acidbase',text:'Albumin thấp có thể làm khoảng trống anion đo được trông bình thường hơn thực tế; hiệu chỉnh albumin hữu ích khi nghi toan chuyển hóa tăng khoảng trống anion.'},
			{topic:'acidbase',text:'Delta ratio hữu ích nhất khi đã xác định có toan chuyển hóa tăng khoảng trống anion và muốn tìm thêm rối loạn chuyển hóa phối hợp.'},
			{topic:'oxygen',text:'PaO₂ phản ánh oxy hòa tan trong huyết tương; khả năng vận chuyển oxy của máu còn phụ thuộc mạnh vào hemoglobin và độ bão hòa oxy.'},
			{topic:'oxygen',text:'Giảm PaO₂ không đồng nghĩa với giảm thông khí đơn thuần. A–a gradient giúp phân biệt giảm thông khí với bất tương xứng thông khí–tưới máu, luồng thông hoặc hạn chế khuếch tán.'},
			{topic:'oxygen',text:'PaCO₂ là một tín hiệu của thông khí phế nang. Tăng PaCO₂ thường gợi ý thông khí phế nang không đủ so với lượng CO₂ tạo ra.'},
			{topic:'oxygen',text:'Một PaO₂ “đẹp” khi đang thở FiO₂ cao có thể vẫn biểu hiện suy giảm trao đổi khí đáng kể; luôn đọc PaO₂ trong bối cảnh FiO₂.'},
			{topic:'oxygen',text:'SpO₂ và PaO₂ không thể thay thế hoàn toàn cho nhau. Đường cong phân ly oxy–hemoglobin khiến cùng một thay đổi PaO₂ có ý nghĩa khác nhau ở các vùng khác nhau.'},
			{topic:'foundation',text:'Trước khi diễn giải sâu, hãy xác nhận loại mẫu, FiO₂, thời điểm lấy mẫu và chất lượng mẫu. Sai tiền phân tích có thể làm toàn bộ suy luận phía sau trở nên vô nghĩa.'},
			{topic:'foundation',text:'Bọt khí trong bơm tiêm có thể kéo PaO₂ về phía áp suất oxy của khí trời và làm thay đổi PaCO₂; mức ảnh hưởng phụ thuộc lượng khí và thời gian tiếp xúc.'},
			{topic:'foundation',text:'Heparin lỏng dư có thể pha loãng mẫu và làm sai điện giải hoặc khí máu. Kỹ thuật lấy mẫu là một phần của diễn giải, không phải bước hành chính.'},
			{topic:'foundation',text:'Khí máu tĩnh mạch thường hữu ích cho đánh giá pH/CO₂ trong nhiều bối cảnh, nhưng không dùng để thay PaO₂ động mạch khi cần đánh giá oxy hóa.'},
			{topic:'clinical',text:'Khí máu không phải chẩn đoán. Kết quả có giá trị nhất khi được ghép với nhịp thở, huyết động, điện giải, lactate, bệnh nền và diễn biến theo thời gian.'},
			{topic:'clinical',text:'Một khí máu đơn lẻ là ảnh chụp tại một thời điểm. Trong bệnh nhân thay đổi nhanh, xu hướng nối tiếp thường có giá trị hơn một con số đơn độc.'},
			{topic:'clinical',text:'Khi dữ liệu khí máu và bệnh cảnh không khớp, ưu tiên kiểm tra chất lượng mẫu và thời điểm lấy mẫu trước khi tạo thêm giả thuyết bệnh lý.'},
			{topic:'clinical',text:'Trong nhiễm trùng huyết hoặc sốc, lactate bổ sung thông tin về tưới máu/chuyển hóa nhưng không nên được giải thích tách rời khỏi huyết động và bối cảnh.'},
			{topic:'clinical',text:'Ở người dùng SGLT2, nhiễm toan ceton có thể xuất hiện với glucose không quá cao; khí máu, khoảng trống anion và ketone cần được đọc cùng nhau.'},
			{topic:'clinical',text:'Ở COPD mạn, HCO₃⁻ tăng có thể phản ánh thích nghi thận với tăng CO₂ kéo dài. Đừng áp quy tắc bù cấp tính cho mọi trường hợp tăng PaCO₂.'},
			{topic:'oxygen',text:'Tỷ số PaO₂/FiO₂ là thước đo thực dụng nhưng chịu ảnh hưởng bởi FiO₂, PEEP và bối cảnh thông khí; không nên đọc như một con số cô lập.'},
			{topic:'acidbase',text:'Bù sinh lý không “sửa” hoàn toàn pH về bình thường. Khi pH bình thường hóa quá đẹp, hãy nghĩ đến khả năng có rối loạn phối hợp.'},
			{topic:'foundation',text:'Luôn kiểm tra xem HCO₃⁻ là giá trị tính từ khí máu hay bicarbonate/total CO₂ từ hóa sinh; hai phép đo liên quan nhưng không hoàn toàn đồng nhất.'},
			{topic:'clinical',text:'Khi quyết định lấy lại khí máu, hãy hỏi câu hỏi lâm sàng nào đang cần trả lời. Lặp xét nghiệm chỉ có ý nghĩa nếu kết quả có thể thay đổi đánh giá hoặc theo dõi.'}
		];
		var HOME_FACTS=[
			{topic:'foundation',text:'pH là thang logarit.',note:'Một thay đổi pH nhỏ có thể tương ứng với thay đổi đáng kể nồng độ ion H⁺.'},
			{topic:'foundation',text:'PaCO₂ chịu ảnh hưởng trực tiếp bởi thông khí phế nang.',note:'Khi sản xuất CO₂ tương đối ổn định, PaCO₂ tăng khi thông khí phế nang giảm.'},
			{topic:'acidbase',text:'HCO₃⁻ trên máy khí máu thường là giá trị tính toán.',note:'Nó được suy ra từ pH và PaCO₂ theo phương trình Henderson–Hasselbalch.'},
			{topic:'acidbase',text:'Khoảng trống anion là một đại lượng suy ra.',note:'Giá trị phụ thuộc công thức, phương pháp xét nghiệm và albumin.'},
			{topic:'acidbase',text:'Albumin là anion không đo được quan trọng trong huyết tương.',note:'Giảm albumin có thể làm giảm khoảng trống anion nền.'},
			{topic:'oxygen',text:'FiO₂ khí phòng xấp xỉ 0,21.',note:'Khi bệnh nhân nhận oxy bổ sung, FiO₂ thực tế phụ thuộc thiết bị và kiểu thở.'},
			{topic:'oxygen',text:'PaO₂ giảm theo tuổi và điều kiện sinh lý.',note:'Không có một ngưỡng “bình thường” tuyệt đối phù hợp mọi bệnh nhân và mọi độ cao.'},
			{topic:'oxygen',text:'Chênh áp oxy phế nang–động mạch phụ thuộc FiO₂ và tuổi.',note:'Nó hữu ích nhất khi được tính trong đúng bối cảnh hô hấp.'},
			{topic:'oxygen',text:'Luồng thông phải–trái thực sự thường đáp ứng oxy bổ sung kém hơn mất tương hợp thông khí/tưới máu.',note:'Đây là nguyên lý sinh lý học quan trọng khi đánh giá giảm oxy máu.'},
			{topic:'foundation',text:'Mẫu khí máu cần được trộn phù hợp sau lấy.',note:'Cục máu đông hoặc phân bố tế bào không đồng đều có thể làm sai kết quả.'},
			{topic:'foundation',text:'Chậm phân tích làm tăng nguy cơ biến đổi mẫu.',note:'Tế bào tiếp tục tiêu thụ O₂ và tạo CO₂/lactate sau khi lấy mẫu.'},
			{topic:'foundation',text:'Bạch cầu hoặc tiểu cầu tăng rất cao có thể gây giảm oxy máu giả do biến đổi mẫu.',note:'Tiêu thụ O₂ trong ống nghiệm có thể làm PaO₂ đo được thấp giả nếu phân tích chậm.'},
			{topic:'clinical',text:'Lactate không đồng nghĩa tuyệt đối với thiếu oxy mô.',note:'Nhiều cơ chế khác nhau có thể làm lactate tăng.'},
			{topic:'clinical',text:'Toan ceton có thể đi kèm rối loạn toan–kiềm phối hợp.',note:'Nôn, hồi sức dịch hoặc bệnh hô hấp có thể làm pH/HCO₃⁻ không điển hình.'},
			{topic:'clinical',text:'COPD mạn có thể có tăng PaCO₂ nền.',note:'Mức HCO₃⁻ và pH giúp phân biệt thích nghi mạn với thành phần cấp trên nền mạn.'},
			{topic:'oxygen',text:'SpO₂ có thể bị ảnh hưởng bởi tưới máu ngoại vi và chuyển động.',note:'Khi số đo không phù hợp bệnh cảnh, cần đánh giá chất lượng tín hiệu.'},
			{topic:'clinical',text:'Carboxyhemoglobin có thể làm phép đo độ bão hòa oxy ngoại vi thông thường đánh giá sai tình trạng oxy hóa.',note:'Khi nghi ngộ độc carbon monoxit, đồng oxy kế có vai trò quan trọng.'},
			{topic:'clinical',text:'Methemoglobin làm thay đổi mối liên hệ giữa PaO₂ và độ bão hòa oxy chức năng.',note:'PaO₂ có thể không phản ánh đầy đủ khả năng vận chuyển oxy khi có rối loạn hemoglobin.'},
			{topic:'acidbase',text:'Bù hô hấp có giới hạn sinh lý.',note:'Nếu PaCO₂ lệch đáng kể khỏi mức dự kiến, nghĩ đến rối loạn hô hấp phối hợp.'},
			{topic:'acidbase',text:'Bù chuyển hóa trong rối loạn hô hấp cần thời gian.',note:'Mức thay đổi HCO₃⁻ khác nhau giữa rối loạn hô hấp cấp và mạn.'},
			{topic:'foundation',text:'Loại mẫu quyết định câu hỏi mà khí máu có thể trả lời tốt.',note:'Khí máu tĩnh mạch và khí máu động mạch không thể hoán đổi cho mọi mục tiêu lâm sàng.'},
			{topic:'oxygen',text:'PaO₂/FiO₂ không đánh giá trực tiếp thông khí.',note:'PaCO₂ mới liên quan trực tiếp hơn đến thông khí phế nang.'},
			{topic:'clinical',text:'Một giá trị “bất thường” cần được so với giá trị nền của bệnh nhân.',note:'Bệnh mạn có thể làm giá trị nền khác đáng kể so với người khỏe mạnh.'},
			{topic:'foundation',text:'Chất lượng dữ liệu đứng trước độ phức tạp của thuật toán.',note:'Nếu mẫu sai, diễn giải tinh vi hơn không tạo ra kết quả đáng tin cậy hơn.'}
		];
		var HOME_QUIZZES=[
			{topic:'acidbase',q:'pH 7,28; HCO₃⁻ 14 mmol/L. Bước nào quan trọng tiếp theo để đánh giá rối loạn phối hợp?',o:['Chỉ nhìn PaO₂','So PaCO₂ thực tế với mức bù dự kiến','Bỏ qua điện giải','Chỉ đọc SpO₂'],a:1,e:'Trong toan chuyển hóa, cần đối chiếu PaCO₂ thực tế với mức bù dự kiến để phát hiện thành phần hô hấp phối hợp.'},
			{topic:'oxygen',q:'PaO₂ 60 mmHg ở bệnh nhân đang thở FiO₂ 0,80 nên được hiểu thế nào?',o:['Bình thường vì PaO₂ > 50','Phải đọc trong bối cảnh FiO₂ cao','Chỉ cần xem pH','Không liên quan trao đổi khí'],a:1,e:'Một PaO₂ 60 mmHg khi FiO₂ rất cao gợi ý suy giảm trao đổi khí đáng kể; PaO₂ phải được đặt cạnh FiO₂.'},
			{topic:'foundation',q:'Khi nghi mẫu có nhiều bọt khí, hành động diễn giải phù hợp nhất là gì?',o:['Tin hoàn toàn PaO₂','Xác nhận chất lượng mẫu trước khi suy luận sâu','Chỉ dùng HCO₃⁻','Bỏ qua loại mẫu'],a:1,e:'Bọt khí có thể làm thay đổi PaO₂ và PaCO₂. Chất lượng mẫu phải được xác nhận trước khi diễn giải sâu.'},
			{topic:'acidbase',q:'Khoảng trống anion đo được bình thường ở bệnh nhân albumin rất thấp có loại trừ toan chuyển hóa tăng khoảng trống anion không?',o:['Có','Không','Chỉ khi PaO₂ thấp','Chỉ khi FiO₂ cao'],a:1,e:'Albumin thấp làm giảm khoảng trống anion nền; cần cân nhắc hiệu chỉnh albumin khi bệnh cảnh phù hợp.'},
			{topic:'oxygen',q:'Thông số nào phản ánh thông khí phế nang trực tiếp hơn?',o:['PaCO₂','PaO₂','Na⁺','Albumin'],a:0,e:'PaCO₂ liên quan nghịch với thông khí phế nang khi sản xuất CO₂ tương đối ổn định.'},
			{topic:'clinical',q:'Ở bệnh nhân dùng SGLT2 có buồn nôn, thở nhanh và tăng khoảng trống anion, glucose không quá cao. Nên nhớ điều gì?',o:['Loại trừ DKA vì glucose không cao','Cân nhắc ketone và DKA euglycemic','Chỉ đánh giá PaO₂','Không cần HCO₃⁻'],a:1,e:'SGLT2 có thể liên quan DKA với glucose không quá cao; cần đọc ketone, khoảng trống anion và khí máu cùng bệnh cảnh.'},
			{topic:'clinical',q:'Một khí máu không phù hợp bệnh cảnh. Việc nào nên làm sớm?',o:['Tạo chẩn đoán hiếm ngay','Kiểm tra loại mẫu, thời điểm và chất lượng mẫu','Bỏ qua kết quả','Chỉ lặp SpO₂'],a:1,e:'Sự không phù hợp giữa kết quả khí máu và bệnh cảnh lâm sàng là dấu hiệu quan trọng để kiểm tra lại các yếu tố tiền phân tích và thời điểm lấy mẫu.'},
			{topic:'acidbase',q:'pH gần 7,40 có loại trừ rối loạn toan–kiềm không?',o:['Có','Không','Chỉ ở trẻ em','Chỉ khi PaO₂ bình thường'],a:1,e:'Hai rối loạn đối nghịch có thể làm pH gần bình thường. Cần xem PaCO₂, HCO₃⁻ và mức bù.'},
			{topic:'oxygen',q:'A–a gradient bình thường trong giảm oxy máu gợi ý nhiều hơn đến cơ chế nào?',o:['Giảm thông khí hoặc FiO₂ thấp','Luồng thông lớn','Bất tương xứng thông khí–tưới máu nặng','Rối loạn hemoglobin luôn luôn'],a:0,e:'Giảm oxy với A–a gradient không tăng gợi ý giảm thông khí toàn thể hoặc FiO₂ hít vào thấp hơn là bất thường trao đổi khí nội phổi.'},
			{topic:'foundation',q:'Khí máu tĩnh mạch có thể thay khí máu động mạch để đánh giá PaO₂ động mạch chính xác không?',o:['Có trong mọi trường hợp','Không','Chỉ cần đổi đơn vị','Chỉ khi pH > 7,4'],a:1,e:'Khí máu tĩnh mạch hữu ích cho pH/CO₂ trong nhiều bối cảnh nhưng không thay thế PaO₂ động mạch khi mục tiêu là đánh giá oxy hóa.'},
			{topic:'clinical',q:'Trong COPD mạn tăng CO₂, điều gì giúp nhận diện thành phần cấp trên nền mạn?',o:['Chỉ PaO₂','pH và mức HCO₃⁻ so với tăng PaCO₂','Chỉ Na⁺','Chỉ SpO₂'],a:1,e:'Mức pH và đáp ứng HCO₃⁻ giúp đánh giá tăng CO₂ là cấp, mạn hay cấp trên nền mạn.'},
			{topic:'acidbase',q:'Khi đã xác định toan chuyển hóa tăng khoảng trống anion, delta ratio chủ yếu giúp tìm gì?',o:['Rối loạn chuyển hóa phối hợp','Loại mẫu','FiO₂','Rối loạn hemoglobin'],a:0,e:'Delta ratio được dùng để gợi ý thêm toan chuyển hóa không tăng khoảng trống anion hoặc kiềm chuyển hóa phối hợp.'},
			{topic:'oxygen',q:'PaO₂ bình thường có đảm bảo hàm lượng oxy máu bình thường không?',o:['Có','Không, còn phụ thuộc Hb và độ bão hòa','Chỉ phụ thuộc Na⁺','Chỉ phụ thuộc lactate'],a:1,e:'Oxy hòa tan chỉ là phần nhỏ của tổng lượng oxy; hemoglobin và saturation quyết định phần lớn hàm lượng oxy.'},
			{topic:'foundation',q:'Chậm phân tích mẫu khí máu có thể làm thay đổi kết quả do đâu?',o:['Tế bào tiếp tục chuyển hóa trong mẫu','Na⁺ bay hơi','Albumin tăng nhanh','FiO₂ của bệnh nhân tăng'],a:0,e:'Tế bào tiếp tục tiêu thụ O₂ và tạo CO₂/lactate sau lấy mẫu, đặc biệt khi phân tích bị trì hoãn.'},
			{topic:'clinical',q:'Lactate tăng có luôn đồng nghĩa với thiếu oxy mô không?',o:['Luôn luôn','Không','Chỉ khi pH >7,45','Chỉ khi PaCO₂ thấp'],a:1,e:'Lactate tăng có nhiều cơ chế; cần diễn giải cùng huyết động, bệnh cảnh và xu hướng.'},
			{topic:'acidbase',q:'Trong toan chuyển hóa, PaCO₂ thực tế cao hơn đáng kể so với mức bù dự kiến gợi ý gì?',o:['Kiềm hô hấp phối hợp','Toan hô hấp phối hợp','Không có rối loạn phối hợp','Chỉ sai FiO₂'],a:1,e:'PaCO₂ cao hơn mức bù dự kiến cho thấy thành phần toan hô hấp phối hợp.'},
			{topic:'acidbase',q:'Trong toan chuyển hóa, PaCO₂ thực tế thấp hơn đáng kể mức bù dự kiến gợi ý gì?',o:['Kiềm hô hấp phối hợp','Toan hô hấp phối hợp','Không thể kết luận gì','Chỉ sai albumin'],a:0,e:'PaCO₂ thấp hơn mức bù dự kiến gợi ý kiềm hô hấp phối hợp.'},
			{topic:'oxygen',q:'Đo độ bão hòa oxy ngoại vi có thể gây hiểu nhầm trong ngộ độc carbon monoxit vì lý do nào?',o:['Không đo nhịp tim','Không phân biệt tốt oxyhemoglobin với carboxyhemoglobin trên máy thông thường','Luôn thấp giả','PaCO₂ luôn tăng'],a:1,e:'Đo độ bão hòa oxy ngoại vi thông thường có thể không phản ánh đúng rối loạn hemoglobin; cần cân nhắc đồng oxy kế khi nghi ngờ.'},
			{topic:'clinical',q:'Khi theo dõi bệnh nhân biến đổi nhanh, điều gì thường có giá trị hơn?',o:['Một khí máu duy nhất','Xu hướng khí máu nối tiếp gắn với can thiệp và thời điểm','Chỉ giá trị pH','Chỉ PaO₂'],a:1,e:'Xu hướng theo thời gian giúp đánh giá hướng diễn biến và đáp ứng tốt hơn một ảnh chụp đơn lẻ.'},
			{topic:'foundation',q:'Thông tin nào nên đi cùng kết quả khí máu khi đánh giá oxy hóa?',o:['FiO₂/thiết bị oxy','Màu mắt','Nhóm máu ABO','Chiều dài tay'],a:0,e:'PaO₂ phải được đọc cùng FiO₂ hoặc thiết bị hỗ trợ oxy để đánh giá trao đổi khí có ý nghĩa.'},
			{topic:'oxygen',q:'PaCO₂ tăng chủ yếu gợi ý vấn đề ở quá trình nào?',o:['Thông khí phế nang','Lọc cầu thận','Tổng hợp albumin','Dẫn truyền tim'],a:0,e:'PaCO₂ là chỉ dấu trọng tâm của thông khí phế nang.'},
			{topic:'acidbase',q:'Bù sinh lý đơn thuần có thường đưa pH hoàn toàn về 7,40 không?',o:['Thường xuyên','Không','Luôn luôn trong 5 phút','Chỉ ở bệnh thận'],a:1,e:'Bù sinh lý thường làm giảm độ lệch pH nhưng không hoàn toàn bình thường hóa; pH quá “đẹp” có thể gợi ý rối loạn phối hợp.'},
			{topic:'foundation',q:'Nếu nghi mẫu tĩnh mạch bị ghi nhầm là động mạch, phần nào bị ảnh hưởng nhiều nhất khi diễn giải?',o:['Đánh giá oxy hóa từ PaO₂','Tên bệnh nhân','Tuổi','Giới'],a:0,e:'PaO₂ tĩnh mạch không dùng để đánh giá oxy hóa động mạch; loại mẫu phải được xác nhận.'},
			{topic:'clinical',q:'Kết quả khí máu nên được dùng như thế nào?',o:['Thay thế hoàn toàn thăm khám','Kết hợp với bệnh cảnh và dữ liệu khác','Tự động quyết định điều trị','Không cần thời điểm lấy mẫu'],a:1,e:'Khí máu là dữ liệu hỗ trợ suy luận, cần tích hợp với bệnh cảnh, thăm khám, xét nghiệm và diễn biến.'}
		];
		var HOME_CASES=[
			{topic:'acidbase',demo:'hagma',title:'Sốc nhiễm trùng, thở nhanh',data:'pH 7,21 · PaCO₂ 25 · HCO₃⁻ 10 · Lactate 5,1',q:'Nhận định chính phù hợp nhất?',o:['Toan chuyển hóa nặng, cần đánh giá bù và khoảng trống anion','Kiềm chuyển hóa đơn thuần','Toan hô hấp đơn thuần'],a:0,e:'pH thấp và HCO₃⁻ giảm xác định thành phần toan chuyển hóa; PaCO₂ cần được đối chiếu mức bù, đồng thời đánh giá khoảng trống anion/lactate.'},
			{topic:'acidbase',demo:'dka',title:'Đái tháo đường, thở Kussmaul',data:'pH 7,12 · PaCO₂ 22 · HCO₃⁻ 7 · glucose 16 mmol/L',q:'Bước suy luận phù hợp nhất?',o:['Toan chuyển hóa; đánh giá AG/ketone và bù hô hấp','Toan hô hấp cấp','Khí máu bình thường'],a:0,e:'HCO₃⁻ giảm sâu với pH thấp gợi ý toan chuyển hóa; bệnh cảnh cần AG, ketone và đánh giá bù.'},
			{topic:'acidbase',demo:'mixed',title:'pH gần bình thường nhưng số liệu lệch',data:'pH 7,39 · PaCO₂ 24 · HCO₃⁻ 14',q:'Điều gì đáng chú ý nhất?',o:['pH bình thường nên không có rối loạn','Khả năng rối loạn phối hợp vì PaCO₂ và HCO₃⁻ cùng thấp','Chỉ giảm oxy máu'],a:1,e:'pH gần bình thường không loại trừ rối loạn phối hợp. HCO₃⁻ thấp và PaCO₂ thấp cần đối chiếu quy tắc bù.'},
			{topic:'foundation',demo:'normal',title:'Người khỏe, khí phòng',data:'pH 7,40 · PaCO₂ 40 · HCO₃⁻ 24 · PaO₂ 95',q:'Mẫu này minh họa điều gì?',o:['Bộ giá trị tham chiếu sinh lý điển hình','Toan chuyển hóa','Suy hô hấp tăng CO₂'],a:0,e:'Đây là bộ dữ liệu gần giá trị sinh lý điển hình ở người trưởng thành khỏe mạnh thở khí phòng.'},
			{topic:'oxygen',demo:'normal',title:'PaO₂ 95 mmHg khi khí phòng',data:'FiO₂ 0,21 · PaO₂ 95 · PaCO₂ 40',q:'Kết luận phù hợp nhất?',o:['Oxy hóa nhìn chung phù hợp trong bối cảnh này','Suy giảm trao đổi khí nặng','Không thể dùng PaO₂ trong ABG'],a:0,e:'PaO₂ phải đọc theo FiO₂ và bệnh cảnh; ở khí phòng, bộ số này không gợi ý giảm oxy máu.'},
			{topic:'clinical',demo:'hagma',title:'Lactate giảm sau hồi sức',data:'Lactate 7,8 → 5,1 mmol/L trong 2 giờ',q:'Diễn giải tốt nhất?',o:['Xu hướng cải thiện nhưng vẫn tăng, cần đặt cùng huyết động và bệnh cảnh','Đã bình thường hoàn toàn','Không có giá trị theo dõi'],a:0,e:'Xu hướng giảm có thể là dấu hiệu thuận lợi nhưng lactate còn cao và không được diễn giải tách rời huyết động.'},
			{topic:'acidbase',demo:'dka',title:'HCO₃⁻ rất thấp, PaCO₂ cũng thấp',data:'pH 7,12 · PaCO₂ 22 · HCO₃⁻ 7',q:'PaCO₂ thấp trong ca này trước hết gợi ý gì?',o:['Có thể là bù hô hấp cho toan chuyển hóa','Toan hô hấp','Không liên quan'],a:0,e:'Trong toan chuyển hóa, giảm PaCO₂ là đáp ứng bù dự kiến; cần tính mức bù để xem có rối loạn hô hấp phối hợp hay không.'},
			{topic:'foundation',demo:'normal',title:'Mẫu bị trì hoãn phân tích',data:'Mẫu để lâu trước khi chạy máy',q:'Kết quả nào có thể bị tác động bởi chuyển hóa tế bào trong mẫu?',o:['PaO₂/PaCO₂ và lactate','Chỉ tuổi bệnh nhân','Chỉ chiều cao'],a:0,e:'Tế bào tiếp tục tiêu thụ O₂ và tạo CO₂/lactate, nên trì hoãn phân tích có thể làm sai các thông số này.'},
			{topic:'oxygen',demo:'hagma',title:'Thở nhanh nhưng PaO₂ chưa giảm',data:'PaCO₂ 25 · PaO₂ 92 · FiO₂ 0,21',q:'PaCO₂ thấp phản ánh chủ yếu điều gì?',o:['Tăng thông khí phế nang','Suy thận','Giảm albumin'],a:0,e:'PaCO₂ thấp thường phản ánh thông khí phế nang tăng so với sản xuất CO₂.'},
			{topic:'clinical',demo:'mixed',title:'Rối loạn phối hợp',data:'pH 7,39 · PaCO₂ 24 · HCO₃⁻ 14',q:'Tại sao không nên dừng ở pH?',o:['Vì pH gần bình thường có thể che hai rối loạn đối nghịch','Vì pH không bao giờ hữu ích','Vì chỉ PaO₂ quan trọng'],a:0,e:'Khi các thành phần khác lệch mạnh, pH gần bình thường là tín hiệu cần tìm rối loạn phối hợp.'},
			{topic:'acidbase',demo:'hagma',title:'Khoảng trống anion cần bối cảnh',data:'Na 138 · Cl 100 · HCO₃⁻ 10 · albumin 32 g/L',q:'Thông tin nào giúp đọc AG tốt hơn?',o:['Albumin và nguyên nhân lâm sàng','Màu da','Chiều cao'],a:0,e:'Albumin ảnh hưởng AG nền và nguyên nhân lâm sàng quyết định ý nghĩa của AG tăng.'},
			{topic:'clinical',demo:'dka',title:'Theo dõi nhiễm toan ceton do đái tháo đường',data:'Một khí máu sau can thiệp',q:'Điều gì giúp đánh giá diễn biến tốt hơn?',o:['So với kết quả trước và thời điểm can thiệp','Chỉ nhìn một pH mới','Bỏ qua điện giải'],a:0,e:'Xu hướng nối tiếp cùng thời điểm can thiệp giúp đánh giá hướng thay đổi tốt hơn một số đo đơn độc.'},
			{topic:'foundation',demo:'normal',title:'VBG bị ghi nhầm ABG',data:'Loại mẫu không chắc chắn',q:'Trước khi dùng PaO₂ để đánh giá oxy hóa nên làm gì?',o:['Xác nhận loại mẫu','Tự đổi PaO₂ sang giá trị động mạch','Bỏ qua FiO₂'],a:0,e:'PaO₂ tĩnh mạch không thể dùng thay PaO₂ động mạch cho đánh giá oxy hóa; loại mẫu cần được xác nhận.'},
			{topic:'oxygen',demo:'normal',title:'Đọc PaO₂ theo FiO₂',data:'PaO₂ 95 mmHg',q:'Thông tin còn thiếu quan trọng nhất nếu chỉ có PaO₂?',o:['FiO₂/thiết bị oxy','Nhóm máu','BMI'],a:0,e:'Không thể đánh giá đầy đủ oxy hóa từ PaO₂ mà không biết FiO₂ hoặc hỗ trợ oxy.'},
			{topic:'acidbase',demo:'mixed',title:'Bù “quá mức”',data:'Toan chuyển hóa nhưng PaCO₂ thấp hơn mức dự kiến',q:'Nên nghĩ thêm đến gì?',o:['Kiềm hô hấp phối hợp','Toan hô hấp phối hợp','Không có gì'],a:0,e:'PaCO₂ thấp hơn mức bù dự kiến gợi ý kiềm hô hấp phối hợp.'},
			{topic:'clinical',demo:'hagma',title:'Khí máu trong sốc',data:'pH 7,21 · lactate 5,1 · huyết áp thấp',q:'Cách đọc phù hợp nhất?',o:['Tích hợp khí máu, lactate và huyết động','Chỉ dùng pH để phân loại sốc','Chỉ nhìn PaO₂'],a:0,e:'Khí máu và lactate cung cấp dữ liệu chuyển hóa nhưng phải tích hợp với huyết động và bệnh cảnh.'}
		];
		function homeRandomIndex(length){if(length<2)return 0;try{if(window.crypto&&window.crypto.getRandomValues){var x=new Uint32Array(1);window.crypto.getRandomValues(x);return x[0]%length;}}catch(error){}return Math.floor(Math.random()*length);}
		function homePick(list,avoid){if(!list.length)return null;var index=homeRandomIndex(list.length);if(list.length>1&&index===avoid)index=(index+1+homeRandomIndex(list.length-1))%list.length;return {item:list[index],index:index};}
		var homeFeedState={pearl:-1,fact:-1,quiz:-1,case:-1};
		function openHomeTopic(topic){var button=root.querySelector('[data-open-theory-topic="'+String(topic||'foundation')+'"]');if(button){button.click();return;}setWorkspaceTab('theory',true);}
		function renderHomeOptions(shell,item,feedback,onCorrect){if(!shell||!item)return;shell.innerHTML=item.o.map(function(option,index){return '<button type="button" data-feed-answer="'+index+'"><span>'+String.fromCharCode(65+index)+'</span>'+escapeHtml(publicCopy(option))+'</button>';}).join('');shell.querySelectorAll('[data-feed-answer]').forEach(function(button){button.addEventListener('click',function(){var answer=Number(button.getAttribute('data-feed-answer')),ok=answer===item.a;shell.querySelectorAll('button').forEach(function(b){b.disabled=true;b.classList.toggle('is-correct',Number(b.getAttribute('data-feed-answer'))===item.a);if(Number(b.getAttribute('data-feed-answer'))===answer&&!ok)b.classList.add('is-wrong');});if(feedback){feedback.hidden=false;feedback.className='nah-abg__feed-feedback '+(ok?'is-correct':'is-wrong');feedback.innerHTML='<strong>'+(ok?'Chính xác':'Chưa chính xác')+'</strong><p>'+escapeHtml(publicCopy(item.e))+'</p>';}if(ok&&onCorrect)onCorrect();});});}
		function renderHomeFeed(){
			var pearlPick=homePick(HOME_PEARLS,homeFeedState.pearl),factPick=homePick(HOME_FACTS,homeFeedState.fact),quizPick=homePick(HOME_QUIZZES,homeFeedState.quiz),casePick=homePick(HOME_CASES,homeFeedState.case);if(!pearlPick||!factPick||!quizPick||!casePick)return;
			homeFeedState.pearl=pearlPick.index;homeFeedState.fact=factPick.index;homeFeedState.quiz=quizPick.index;homeFeedState.case=casePick.index;
			var pearl=pearlPick.item,fact=factPick.item,quiz=quizPick.item,mini=casePick.item;
			var pearlText=root.querySelector('[data-home-pearl-text]'),pearlTopic=root.querySelector('[data-home-pearl-topic]');if(pearlText)pearlText.textContent=publicCopy(pearl.text);if(pearlTopic){pearlTopic.dataset.topic=pearl.topic;pearlTopic.onclick=function(){openHomeTopic(pearl.topic);};}
			var factText=root.querySelector('[data-home-fact-text]'),factNote=root.querySelector('[data-home-fact-note]');if(factText)factText.textContent=publicCopy(fact.text);if(factNote)factNote.textContent=publicCopy(fact.note);
			var quizQ=root.querySelector('[data-home-quiz-question]'),quizOpts=root.querySelector('[data-home-quiz-options]'),quizFeedback=root.querySelector('[data-home-quiz-feedback]'),quizTopic=root.querySelector('[data-home-quiz-topic]');if(quizQ)quizQ.textContent=publicCopy(quiz.q);if(quizFeedback){quizFeedback.hidden=true;quizFeedback.innerHTML='';}if(quizTopic){quizTopic.hidden=true;quizTopic.onclick=function(){openHomeTopic(quiz.topic);};}renderHomeOptions(quizOpts,quiz,quizFeedback,function(){if(quizTopic)quizTopic.hidden=false;});
			var caseTitle=root.querySelector('[data-home-case-title]'),caseData=root.querySelector('[data-home-case-data]'),caseQuestion=root.querySelector('[data-home-case-question]'),caseOpts=root.querySelector('[data-home-case-options]'),caseFeedback=root.querySelector('[data-home-case-feedback]'),caseAnalysis=root.querySelector('[data-home-case-analysis]');if(caseTitle)caseTitle.textContent=publicCopy(mini.title);if(caseData)caseData.textContent=publicCopy(mini.data);if(caseQuestion)caseQuestion.textContent=publicCopy(mini.q);if(caseFeedback){caseFeedback.hidden=true;caseFeedback.innerHTML='';}if(caseAnalysis){caseAnalysis.hidden=true;caseAnalysis.dataset.demo=mini.demo||'';caseAnalysis.onclick=function(){setWorkspaceTab('analysis',true);var demoSelect=root.querySelector('[data-demo-select]');if(demoSelect&&mini.demo&&DEMOS[mini.demo]){demoSelect.value=mini.demo;var loader=root.querySelector('[data-load-demo]');if(loader)loader.click();}};}renderHomeOptions(caseOpts,mini,caseFeedback,function(){if(caseAnalysis)caseAnalysis.hidden=false;});
		}
		var homeFeedRefresh=root.querySelector('[data-home-feed-refresh]');if(homeFeedRefresh)homeFeedRefresh.addEventListener('click',function(){renderHomeFeed();homeFeedRefresh.classList.remove('is-spinning');void homeFeedRefresh.offsetWidth;homeFeedRefresh.classList.add('is-spinning');});
		renderHomeFeed();

		function save() {
			try { window.localStorage.setItem(storageKey, JSON.stringify(state)); } catch (error) {}
			renderStats();
			renderProgress();
			renderAdaptiveDashboard();
			renderRemediationDashboard();
			renderV58Longitudinal();
			renderV60Integrated();
			renderPlatformDashboard();
		}
		function questionStats() {
			var ids = Object.keys(state.questions);
			var attempted = ids.length;
			var mastered = ids.filter(function(id){ return state.questions[id] && state.questions[id].everCorrect; }).length;
			var attempts = ids.reduce(function(sum,id){ return sum + Number(state.questions[id].attempts || 0); },0);
			var correct = ids.reduce(function(sum,id){ return sum + Number(state.questions[id].correct || 0); },0);
			return {attempted:attempted,mastered:mastered,attempts:attempts,correct:correct};
		}
		function masteredCards() { return Object.keys(state.cards).filter(function(id){return state.cards[id] === 'mastered';}).length; }
		function overallPercent() {
			var qs=questionStats();
			var qPart = LEARNING_QUESTIONS.length ? qs.mastered / LEARNING_QUESTIONS.length : 0;
			var cPart = LEARNING_CARDS.length ? masteredCards() / LEARNING_CARDS.length : 0;
			var bestAssessment=Number((state.assessment&&state.assessment.best)||state.exam.best||0);
			var ePart = Math.min(1, bestAssessment / 100);
			return Math.round((qPart * .45 + cPart * .25 + ePart * .30) * 100);
		}
		function renderStats() {
			var shell=host.querySelector('[data-learning-stats]'); if(!shell)return;
			var qs=questionStats(), pct=overallPercent();
			shell.innerHTML='<div><strong>'+pct+'%</strong><span>Tiến độ tổng hợp</span></div><div><strong>'+qs.mastered+'/'+LEARNING_QUESTIONS.length+'</strong><span>Câu hỏi đã trả lời đúng</span></div><div><strong>'+masteredCards()+'/'+LEARNING_CARDS.length+'</strong><span>Thẻ đã ghi nhớ</span></div><div><strong>'+Number((state.assessment&&state.assessment.best)||state.exam.best||0)+'%</strong><span>Điểm đánh giá tốt nhất</span></div>';
		}

		/* v5.8 — Longitudinal Assessment Intelligence.
		 * Chỉ suy ra từ tối đa 10 lượt assessment đã có trong state cục bộ. */
		function v58AssessmentHistory(){return ((state.assessment&&state.assessment.history)||[]).filter(function(h){return h&&Number.isFinite(Number(h.score));}).slice(0,10).reverse();}
		function v58Mean(values){if(!values.length)return null;return values.reduce(function(a,b){return a+Number(b||0);},0)/values.length;}
		function v58Std(values){if(values.length<2)return null;var m=v58Mean(values);return Math.sqrt(values.reduce(function(sum,v){return sum+Math.pow(Number(v)-m,2);},0)/values.length);}
		function v58GroupPct(row,key,group){var x=row&&row[group]&&row[group][key];return x&&Number(x.total)>0?Math.round(Number(x.correct||0)/Number(x.total)*100):null;}
		function v58TrendLabel(delta){if(delta===null)return 'Chưa đủ dữ liệu';if(delta>=5)return 'Đang cải thiện';if(delta<=-5)return 'Cần xem lại xu hướng';return 'Tương đối ổn định';}
		function v58StabilityLabel(sd,count){if(count<3||sd===null)return 'Cần thêm lượt đánh giá';if(sd<=5)return 'Ổn định';if(sd<=12)return 'Dao động vừa';return 'Dao động nhiều';}
		function v58DomainTrend(history,topic){var vals=history.map(function(h){return v58GroupPct(h,topic,'topics');}).filter(function(v){return v!==null;});if(!vals.length)return {last:null,delta:null};var split=Math.max(1,Math.floor(vals.length/2)),first=v58Mean(vals.slice(0,split)),recent=v58Mean(vals.slice(-Math.min(3,vals.length)));return {last:vals[vals.length-1],delta:Math.round(recent-first)};}
		function renderV58Longitudinal(){var shell=root.querySelector('[data-home-v58-longitudinal]');if(!shell)return;var history=v58AssessmentHistory(),burden=dueQuestionCount()+dueCardCount()+remediationPriorityItems(20).length;if(!history.length){shell.innerHTML='<div class="nah-abg__v58-empty"><strong>Chưa có chuỗi đánh giá để so sánh</strong><p>Hoàn thành ít nhất hai bài đánh giá để bắt đầu thấy xu hướng; ba lượt trở lên giúp ước lượng độ ổn định tốt hơn.</p></div>';return;}var scores=history.map(function(h){return Number(h.score||0);}),recent=v58Mean(scores.slice(-Math.min(3,scores.length))),early=v58Mean(scores.slice(0,Math.min(3,scores.length))),delta=scores.length>=2?Math.round(recent-early):null,sd=v58Std(scores.slice(-Math.min(5,scores.length))),stability=v58StabilityLabel(sd,scores.length),trend=v58TrendLabel(delta);var bars=history.map(function(h,i){var score=Math.max(0,Math.min(100,Number(h.score||0)));return '<i style="height:'+Math.max(10,score)+'%" title="Lượt '+(i+1)+': '+score+'%"><span>'+score+'</span></i>';}).join('');var domains=['foundation','acidbase','oxygen','clinical'].map(function(topic){var t=v58DomainTrend(history,topic);return '<article><strong>'+escapeHtml(learningTopicName(topic))+'</strong><b>'+(t.last===null?'—':t.last+'%')+'</b><span>'+(t.delta===null?'Chưa đủ lượt':((t.delta>0?'+':'')+t.delta+' điểm'))+'</span></article>';}).join('');shell.innerHTML='<div class="nah-abg__v58-summary"><article><strong>'+scores[scores.length-1]+'%</strong><span>Lượt gần nhất</span></article><article><strong>'+(delta===null?'—':((delta>0?'+':'')+delta))+'</strong><span>Thay đổi gần đây</span></article><article><strong>'+escapeHtml(stability)+'</strong><span>Độ ổn định</span></article><article><strong>'+burden+'</strong><span>Gánh nặng ôn đến hạn</span></article></div><div class="nah-abg__v58-chart" aria-label="Điểm các lượt đánh giá gần đây">'+bars+'</div><div class="nah-abg__v58-domains">'+domains+'</div><p class="nah-abg__v58-note"><b>'+escapeHtml(trend)+'.</b> Chỉ số này mô tả lịch sử tự học trên thiết bị, không suy diễn hoặc chứng nhận năng lực lâm sàng.</p>';}

		function renderProgress() {
			var shell=host.querySelector('[data-learning-progress]'); if(!shell)return;
			var topics=['foundation','acidbase','oxygen','clinical'];
			var rows=topics.map(function(topic){
				var metric=topicMetrics(topic), pct=metric.mastery, detail=metric.mastered+'/'+metric.total+' câu đã trả lời đúng';
				if(metric.accuracy!==null)detail+=' · Độ chính xác '+metric.accuracy+'%';if(metric.due)detail+=' · '+metric.due+' câu đến hạn';
				return '<div class="nah-abg__progress-row"><div><strong>'+escapeHtml(learningTopicName(topic))+'</strong><span>'+escapeHtml(detail)+'</span></div><div class="nah-abg__progress-bar" aria-label="'+pct+' phần trăm"><span style="width:'+pct+'%"></span></div><b>'+pct+'%</b></div>';
			}).join('');
			var assessmentCount=Number((state.assessment&&state.assessment.count)||state.exam.count||0), assessmentLast=Number((state.assessment&&state.assessment.last)||state.exam.last||0), assessmentBest=Number((state.assessment&&state.assessment.best)||state.exam.best||0);
			var examText = assessmentCount ? ('Đã làm '+assessmentCount+' lượt · Lần gần nhất '+assessmentLast+'% · Tốt nhất '+assessmentBest+'%') : 'Chưa làm bài đánh giá có cấu trúc.';
			var adaptiveText=Number(state.adaptive.started||0)?('Đã bắt đầu '+Number(state.adaptive.started||0)+' phiên · Hoàn thành '+Number(state.adaptive.completed||0)+' phiên · Hiện có '+dueQuestionCount()+' câu đến hạn'):'Chưa bắt đầu phiên ôn thích ứng.';
			shell.innerHTML='<div class="nah-abg__progress-overview"><strong>Tiến độ theo chủ đề</strong><p>Tiến độ này nhằm giúp nhận ra phần cần ôn lại, không phải điểm đánh giá năng lực chuyên môn.</p></div>'+rows+'<div class="nah-abg__exam-history"><strong>Ôn tập thích ứng</strong><span>'+escapeHtml(adaptiveText)+'</span></div><div class="nah-abg__exam-history"><strong>Thi và đánh giá</strong><span>'+escapeHtml(examText)+'</span></div>';
		}


		/* v4.0 — Bảng điều khiển hợp nhất hành trình học tập. */
		var platformDashboard=root.querySelector('[data-platform-dashboard]');
		var homeProgress=root.querySelector('[data-home-progress]'), homeRecTitle=root.querySelector('[data-home-recommendation-title]'), homeRecText=root.querySelector('[data-home-recommendation-text]'), homeRecAction=root.querySelector('[data-home-recommendation-action]');
		function platformTheoryCount(){return Object.keys(state.platform.theoryViewed||{}).length;}
		function platformTheoryTotal(){var total=root.querySelectorAll('[data-workspace-panel="theory"] .nah-abg__handbook-accordion').length;return total||50;}
		function platformRecommendation(){
			var qs=questionStats(), recommended=recommendedTopic(), due=dueQuestionCount(), assessment=state.assessment||{}, theorySeen=platformTheoryCount(), analyses=Number(state.platform.analyses||0);
			if(theorySeen<3 && qs.mastered<6)return {kind:'theory',topic:'foundation',title:'Bắt đầu từ nền tảng',text:'Đọc các nguyên lý cốt lõi trước, sau đó chuyển sang câu hỏi ngắn để kiểm tra khả năng vận dụng.'};
			if(due>0 || (recommended&&recommended.attempts>=2&&recommended.strength<75))return {kind:'adaptive',title:'Ôn phần đang cần củng cố',text:due?('Có '+due+' câu đã đến hạn ôn lại. Lộ trình thích ứng sẽ ưu tiên các câu này trước.'):'Lịch sử trả lời cho thấy có một miền kiến thức nên được củng cố trước khi làm bài đánh giá tiếp theo.'};
			if(Number(assessment.count||0)===0 && qs.mastered>=8)return {kind:'exam',title:'Thử một bài đánh giá có cấu trúc',text:'Bạn đã có đủ hoạt động ôn tập để dùng một bài đánh giá làm mốc tự kiểm tra ban đầu.'};
			if(analyses===0)return {kind:'analysis',title:'Áp dụng vào một ca khí máu',text:'Chuyển kiến thức đã học sang quy trình phân tích và đối chiếu kết quả với bối cảnh lâm sàng.'};
			if(Number(assessment.last||0)<80 && Number(assessment.count||0)>0)return {kind:'adaptive',title:'Ôn theo kết quả đánh giá gần nhất',text:'Ưu tiên miền kiến thức còn yếu trước khi lặp lại bài đánh giá.'};
			return {kind:'analysis',title:'Tiếp tục luyện suy luận trên ca bệnh',text:'Dùng phần Phân tích để luyện từ dữ liệu khí máu đến diễn giải và kiểm tra tính phù hợp với bệnh cảnh.'};
		}
		function platformActionButton(rec){
			if(rec.kind==='theory')return '<button type="button" class="nah-abg__button nah-abg__button--primary" data-open-theory-topic="'+escapeHtml(rec.topic||'foundation')+'">Học tiếp</button>';
			if(rec.kind==='adaptive')return '<button type="button" class="nah-abg__button nah-abg__button--primary" data-platform-learning="adaptive">Ôn theo lộ trình</button>';
			if(rec.kind==='exam')return '<button type="button" class="nah-abg__button nah-abg__button--primary" data-platform-learning="exam">Làm bài đánh giá</button>';
			return '<button type="button" class="nah-abg__button nah-abg__button--primary" data-platform-workspace="analysis">Mở phần Phân tích</button>';
		}
		function bindPlatformActions(){
			if(!platformDashboard)return;
			platformDashboard.querySelectorAll('[data-platform-workspace]').forEach(function(btn){btn.addEventListener('click',function(){var name=btn.getAttribute('data-platform-workspace')||'analysis',tab=root.querySelector('[data-workspace-tab="'+name+'"]');if(tab)tab.click();var tabs=root.querySelector('.nah-abg__workspace-tabs');if(tabs)tabs.scrollIntoView({behavior:'smooth',block:'start'});});});
			platformDashboard.querySelectorAll('[data-platform-learning]').forEach(function(btn){btn.addEventListener('click',function(){setTab(btn.getAttribute('data-platform-learning')||'adaptive');host.scrollIntoView({behavior:'smooth',block:'start'});});});
		}
		function v43Status(pct,due,seen){if(due>0)return 'Cần ôn';if(pct>=75)return 'Đã vững';if(seen||pct>0)return 'Đang học';return 'Mới';}
		function v43DomainRows(){
			var f=topicMetrics('foundation'),a=topicMetrics('acidbase'),o=topicMetrics('oxygen'),c=topicMetrics('clinical');
			var acidMixed=Math.max(0,Math.min(100,Math.round(a.mastery*.7+(a.accuracy===null?0:a.accuracy*.3))));
			var samplingSeen=Object.keys(state.platform.theoryViewed||{}).filter(function(k){return /sampl|preanal|quality|specimen/i.test(k);}).length;
			var samplingPct=Math.min(100,samplingSeen*20);
			return [
				{name:'Nền tảng khí máu',pct:f.mastery,due:f.due,seen:f.seen},
				{name:'Toan–kiềm',pct:a.mastery,due:a.due,seen:a.seen},
				{name:'Rối loạn phối hợp',pct:acidMixed,due:a.needsReview,seen:a.seen},
				{name:'Oxy hóa & thông khí',pct:o.mastery,due:o.due,seen:o.seen},
				{name:'Chất lượng mẫu',pct:samplingPct,due:0,seen:samplingSeen},
				{name:'Ứng dụng lâm sàng',pct:c.mastery,due:c.due,seen:c.seen}
			].map(function(x){x.status=v43Status(x.pct,x.due,x.seen);return x;});
		}
		function v43LastActivity(){var t=Number(state.platform.lastActivity||state.adaptive.lastCompleted||state.adaptive.lastSession||0);if(!t)return 'Chưa có hoạt động gần đây';var d=Math.max(0,Math.floor((Date.now()-t)/DAY_MS));return d===0?'Hoạt động hôm nay':d===1?'Hoạt động hôm qua':'Hoạt động '+d+' ngày trước';}
		function renderV43Dashboard(qs,assessment,theorySeen,theoryTotal,analyses,best){
			var snapshot=root.querySelector('[data-home-v43-snapshot]'), mastery=root.querySelector('[data-home-v43-mastery]'), insight=root.querySelector('[data-home-v43-insight]');
			var overall=overallPercent(), due=dueQuestionCount()+dueCardCount(), rows=v43DomainRows();
			if(snapshot)snapshot.innerHTML='<div class="nah-abg__v43-ring" style="--v43-progress:'+overall+'%"><div><strong>'+overall+'%</strong><span>Tiến độ tổng hợp</span></div></div><div class="nah-abg__v43-kpis"><article><b>'+due+'</b><span>Đến hạn ôn</span></article><article><b>'+best+'%</b><span>Điểm tốt nhất</span></article><article><b>'+analyses+'</b><span>Lượt phân tích</span></article><article><b>'+theorySeen+'/'+theoryTotal+'</b><span>Bài đã mở</span></article></div><small class="nah-abg__v43-activity">'+escapeHtml(v43LastActivity())+'</small>';
			if(mastery)mastery.innerHTML=rows.map(function(r){return '<article><div><strong>'+escapeHtml(r.name)+'</strong><span class="nah-abg__v43-status" data-status="'+escapeHtml(r.status)+'">'+escapeHtml(r.status)+'</span></div><div class="nah-abg__v43-bar"><i style="width:'+r.pct+'%"></i></div><b>'+r.pct+'%</b></article>';}).join('');
			if(insight){var active=rows.filter(function(r){return r.seen||r.pct;});var weak=active.slice().sort(function(a,b){return a.pct-b.pct;})[0], strong=active.slice().sort(function(a,b){return b.pct-a.pct;})[0];var title='Bắt đầu xây dựng hồ sơ học tập',text='Hãy mở một bài lý thuyết hoặc trả lời vài câu hỏi để Dashboard nhận diện miền cần ưu tiên.';if(active.length){title=due?'Có nội dung đến hạn ôn':'Tiến độ đang được cập nhật';text=(strong&&strong.pct?('Bạn đang tiến tốt hơn ở '+strong.name+'. '):'')+(weak&&weak!==strong?('Nên ưu tiên '+weak.name+' trong phiên học tiếp theo.'):'Tiếp tục luyện tập để có thêm dữ liệu so sánh giữa các miền.');}insight.innerHTML='<h3>'+escapeHtml(title)+'</h3><p>'+escapeHtml(text)+'</p><small>Phân tích này chỉ dựa trên hoạt động tự học lưu tại thiết bị.</small>';}
		}
		/* v4.8 — Personalized Study Plan & Mastery Intelligence.
		 * Kế hoạch được suy ra hoàn toàn từ learning state cục bộ hiện có; không thêm schema hoặc request mạng. */
		function v48EvidenceLabel(){
			var attempts=questionStats().attempts, theory=platformTheoryCount(), assessments=Number((state.assessment||{}).count||0), analyses=Number(state.platform.analyses||0);
			var score=attempts+theory+assessments*4+analyses*2;
			if(score<6)return 'Dữ liệu gợi ý: mới bắt đầu';
			if(score<20)return 'Dữ liệu gợi ý: đang hình thành';
			return 'Dữ liệu gợi ý: đã đủ phong phú';
		}
		function v48PlanItems(){
			var qs=questionStats(), rec=recommendedTopic()||topicMetrics('foundation'), dueQ=dueQuestionCount(), dueC=dueCardCount(), due=dueQ+dueC, assessment=state.assessment||{}, theorySeen=platformTheoryCount(), analyses=Number(state.platform.analyses||0);
			var topic=rec.topic||'foundation', topicName=learningTopicName(topic);
			var first={kind:'theory',topic:topic,label:'1 · HIỂU',title:(theorySeen<3?'Nắm chắc nền tảng':'Củng cố '+topicName),text:(theorySeen<3?'Mở một bài cốt lõi và theo ví dụ từng bước trước khi luyện câu hỏi.':'Miền này đang có mức ưu tiên cao hơn trong hồ sơ học tập hiện tại.'),cta:'Mở bài học'};
			var second=due>0?{kind:'adaptive',label:'2 · NHỚ',title:'Ôn '+due+' nội dung đến hạn',text:(dueQ?dueQ+' câu hỏi':'')+(dueQ&&dueC?' · ':'')+(dueC?dueC+' thẻ ghi nhớ':'')+'.',cta:'Ôn theo lộ trình'}:{kind:'questions',topic:topic,label:'2 · NHỚ',title:'Luyện vài câu về '+topicName,text:'Chưa có nội dung đến hạn; dùng một cụm câu ngắn để củng cố khả năng nhớ và vận dụng.',cta:'Luyện câu hỏi'};
			var third;
			if(Number(assessment.count||0)===0 && qs.mastered>=8){third={kind:'exam',label:'3 · KIỂM TRA',title:'Tạo một mốc tự đánh giá',text:'Bạn đã có đủ hoạt động nền để làm một đề ngắn và xác định miền cần củng cố tiếp.',cta:'Làm bài đánh giá'};}
			else if(analyses===0){third={kind:'analysis',label:'3 · ÁP DỤNG',title:'Áp dụng vào một ca khí máu',text:'Chuyển từ kiến thức sang quy trình phân tích từng bước trên một bộ số liệu thực hành.',cta:'Mở Phân tích'};}
			else{third={kind:'analysis',label:'3 · ÁP DỤNG',title:'Luyện thêm một ca có bối cảnh',text:'Đối chiếu khí máu với dữ kiện lâm sàng để củng cố khả năng suy luận thay vì chỉ nhớ công thức.',cta:'Luyện ca mới'};}
			return [first,second,third];
		}
		function v48PlanHtml(items,compact){
			return items.map(function(item,index){return '<article class="nah-abg__v48-plan-step" data-v48-kind="'+escapeHtml(item.kind)+'" data-v48-topic="'+escapeHtml(item.topic||'foundation')+'"><span>'+escapeHtml(item.label)+'</span><strong>'+escapeHtml(item.title)+'</strong><p>'+escapeHtml(item.text)+'</p><button type="button" class="nah-abg__feed-link" data-v48-plan-action>'+escapeHtml(item.cta)+' →</button></article>';}).join('');
		}
		function v48OpenPlanItem(item){
			if(!item)return;var kind=item.getAttribute('data-v48-kind')||'analysis',topic=item.getAttribute('data-v48-topic')||'foundation';
			if(kind==='theory'){var theoryBtn=root.querySelector('[data-open-theory-topic="'+topic+'"]');if(theoryBtn){theoryBtn.click();return;}setWorkspaceTab('theory',true);return;}
			if(kind==='adaptive'||kind==='questions'||kind==='exam'||kind==='cards'){setWorkspaceTab('review',true);var toggle=root.querySelector('[data-learning-tab="'+kind+'"]');if(toggle)toggle.click();var system=root.querySelector('[data-learning-system]');if(system)system.scrollIntoView({behavior:'smooth',block:'start'});return;}
			setWorkspaceTab('analysis',true);
		}
		function renderV48Plan(){
			var items=v48PlanItems(), home=root.querySelector('[data-home-v48-plan]'), session=root.querySelector('[data-v48-session-plan]'), evidence=root.querySelector('[data-home-v48-evidence]');
			if(evidence)evidence.textContent=v48EvidenceLabel();
			if(home)home.innerHTML=v48PlanHtml(items,false);
			if(session)session.innerHTML=v48PlanHtml(items,true);
			[home,session].filter(Boolean).forEach(function(box){box.querySelectorAll('[data-v48-plan-action]').forEach(function(btn){btn.addEventListener('click',function(){v48OpenPlanItem(btn.closest('[data-v48-kind]'));});});});
		}

		/* v4.9 — Longitudinal Learning Analytics & Review Readiness.
		 * Chỉ tổng hợp các timestamp đã có trong state cục bộ; không thêm storage schema hoặc request mạng. */
		function v49DayStart(ts){var d=new Date(ts||Date.now());d.setHours(0,0,0,0);return d.getTime();}
		function v49ActivityDays(){
			var today=v49DayStart(Date.now()), days=[];
			for(var i=6;i>=0;i--)days.push({at:today-i*DAY_MS,count:0});
			function add(ts,weight){ts=Number(ts||0);if(!ts)return;var idx=Math.floor((v49DayStart(ts)-days[0].at)/DAY_MS);if(idx>=0&&idx<7)days[idx].count+=Number(weight||1);}
			Object.keys(state.questions||{}).forEach(function(id){var q=normalizeQuestionRecord(state.questions[id]);add(q.lastAnswered,1);});
			Object.keys(state.cardSchedule||{}).forEach(function(id){var c=state.cardSchedule[id]||{};add(c.lastRated,1);});
			Object.keys((state.platform&&state.platform.theoryViewed)||{}).forEach(function(id){add(state.platform.theoryViewed[id],1);});
			((state.assessment&&state.assessment.history)||[]).forEach(function(x){add(x&&x.at,1);});
			add(state.adaptive&&state.adaptive.lastCompleted,1);
			return days;
		}
		function v49Readiness(){
			var rows=allTopicMetrics(), attempts=rows.reduce(function(n,r){return n+r.attempts;},0), mastered=rows.reduce(function(n,r){return n+r.mastered;},0);
			var due=dueQuestionCount()+dueCardCount(), assessed=Number((state.assessment||{}).count||0), best=Number((state.assessment||{}).best||0), theory=platformTheoryCount();
			if(attempts<6||theory<2)return {status:'Đang khởi động',tone:'start',title:'Xây nền trước khi tự kiểm tra',text:'Mở thêm một vài bài cốt lõi và trả lời câu hỏi ngắn để có đủ dữ liệu định hướng.'};
			if(due>=4)return {status:'Nên củng cố',tone:'review',title:'Ưu tiên phần đang đến hạn',text:'Bạn có '+due+' nội dung cần ôn. Hoàn thành chúng trước khi làm một bài đánh giá mới.'};
			if(mastered>=10 && (assessed===0||best>=70))return {status:'Có thể tự kiểm tra',tone:'ready',title:'Sẵn sàng tạo một mốc đánh giá',text:'Tiến độ hiện tại phù hợp để làm một đề ngắn, sau đó dùng kết quả để điều chỉnh lộ trình.'};
			return {status:'Đang tiến bộ',tone:'steady',title:'Tiếp tục một vòng hiểu – nhớ – áp dụng',text:'Hồ sơ học tập đã hình thành; nên củng cố miền yếu nhất rồi quay lại tự đánh giá.'};
		}
		function renderV49Insights(){
			var week=root.querySelector('[data-home-v49-week]'), readiness=root.querySelector('[data-home-v49-readiness]');
			if(week){var days=v49ActivityDays(),max=Math.max.apply(null,days.map(function(d){return d.count;}))||1,total=days.reduce(function(n,d){return n+d.count;},0);var labels=['CN','T2','T3','T4','T5','T6','T7'];week.innerHTML='<div class="nah-abg__v49-week-head"><strong>'+total+' dấu mốc học</strong><span>7 ngày</span></div><div class="nah-abg__v49-bars">'+days.map(function(d){var dt=new Date(d.at),h=Math.max(d.count?12:4,Math.round(d.count/max*100));return '<div><i style="height:'+h+'%" aria-hidden="true"></i><b>'+d.count+'</b><span>'+labels[dt.getDay()]+'</span></div>';}).join('')+'</div>'; }
			if(readiness){var r=v49Readiness();readiness.setAttribute('data-tone',r.tone);readiness.innerHTML='<span>'+escapeHtml(r.status)+'</span><h4>'+escapeHtml(r.title)+'</h4><p>'+escapeHtml(r.text)+'</p><button type="button" class="nah-abg__feed-link" data-v49-readiness-action>'+(r.tone==='ready'?'Mở bài đánh giá →':r.tone==='review'?'Ôn nội dung đến hạn →':'Xem kế hoạch hôm nay →')+'</button>';var btn=readiness.querySelector('[data-v49-readiness-action]');if(btn)btn.addEventListener('click',function(){if(r.tone==='ready'){setWorkspaceTab('review',true);var exam=root.querySelector('[data-learning-tab="exam"]');if(exam)exam.click();}else if(r.tone==='review'){setWorkspaceTab('review',true);var adaptive=root.querySelector('[data-learning-tab="adaptive"]');if(adaptive)adaptive.click();}else{var plan=root.querySelector('[data-home-v48-plan]');if(plan)scrollWorkspacePanelIntoView(plan);}});}
		}

		/* v5.0 — Integrated Learning Portfolio & Mastery Milestones.
		 * Tổng hợp duy nhất từ state cục bộ hiện có; không tạo schema mới và không suy diễn năng lực lâm sàng. */
		function v50Signals(){
			var qs=questionStats(), assessment=state.assessment||{}, days=v49ActivityDays();
			return {theory:platformTheoryCount(),attempts:qs.attempts,mastered:qs.mastered,cards:masteredCards(),assessmentCount:Number(assessment.count||0),best:Number(assessment.best||state.exam.best||0),analyses:Number(state.platform.analyses||0),activeDays:days.filter(function(d){return d.count>0;}).length,due:dueQuestionCount()+dueCardCount()};
		}
		function v50Milestones(){
			var x=v50Signals();
			return [
				{id:'foundation',label:'Xây nền',reached:x.theory>=5&&x.attempts>=8,detail:x.theory+'/50 bài · '+x.attempts+' lượt câu hỏi',kind:'theory',cta:'Mở bài nền tảng'},
				{id:'retain',label:'Củng cố',reached:x.mastered>=12&&x.cards>=5,detail:x.mastered+'/'+LEARNING_QUESTIONS.length+' câu · '+x.cards+'/'+LEARNING_CARDS.length+' thẻ',kind:'adaptive',cta:'Ôn phần cần củng cố'},
				{id:'assess',label:'Tự đánh giá',reached:x.assessmentCount>=1,detail:x.assessmentCount?(x.assessmentCount+' lượt · tốt nhất '+x.best+'%'):'Chưa có mốc đánh giá',kind:'exam',cta:'Làm bài đánh giá'},
				{id:'apply',label:'Vận dụng',reached:x.analyses>=2,detail:x.analyses+' lượt phân tích ca',kind:'analysis',cta:'Luyện một ca khí máu'},
				{id:'maintain',label:'Duy trì',reached:x.activeDays>=3,detail:x.activeDays+'/7 ngày có hoạt động',kind:'adaptive',cta:'Tiếp tục phiên học'}
			];
		}
		function v50JourneySummary(milestones){
			var reached=milestones.filter(function(m){return m.reached;}).length,next=milestones.filter(function(m){return !m.reached;})[0]||null,title='Bắt đầu tạo dấu mốc đầu tiên';
			if(reached===1)title='Nền tảng đang hình thành';
			else if(reached===2)title='Đang chuyển từ hiểu sang ghi nhớ';
			else if(reached===3)title='Đã có một hồ sơ tự học rõ hơn';
			else if(reached===4)title='Đang kết nối kiến thức với thực hành';
			else if(reached===5)title='Duy trì một hành trình học cân bằng';
			return {reached:reached,next:next,title:title};
		}
		function v50OpenAction(kind){
			kind=kind||'theory';
			if(kind==='theory'){var theory=root.querySelector('[data-open-theory-topic="foundation"]');if(theory){theory.click();return;}setWorkspaceTab('theory',true);return;}
			if(kind==='adaptive'||kind==='exam'||kind==='cards'){setWorkspaceTab('review',true);var tab=root.querySelector('[data-learning-tab="'+kind+'"]');if(tab)tab.click();var system=root.querySelector('[data-learning-system]');if(system)scrollWorkspacePanelIntoView(system);return;}
			setWorkspaceTab('analysis',true);
		}
		function renderV50Portfolio(){
			var home=root.querySelector('[data-home-v50-portfolio]'), compact=root.querySelector('[data-learning-v50-milestone]');
			var milestones=v50Milestones(), summary=v50JourneySummary(milestones), x=v50Signals(), next=summary.next;
			if(home){
				home.innerHTML='<div class="nah-abg__v50-overview"><div class="nah-abg__v50-count"><strong>'+summary.reached+'/5</strong><span>mức tiến triển</span></div><div><h4>'+escapeHtml(summary.title)+'</h4><p>'+(next?('Gợi ý tiếp theo: <strong>'+escapeHtml(next.label)+'</strong>.'):'Bạn đã có hoạt động ở đủ các nhóm học tập; hãy duy trì nhịp học và tiếp tục luyện ca.')+'</p></div></div>'+
				'<div class="nah-abg__v50-evidence nah-abg__v50-evidence--v611"><article><b>'+x.theory+'/50</b><span>Bài đã mở</span></article><article><b>'+x.attempts+'</b><span>Câu đã làm</span></article><article><b>'+x.best+'%</b><span>Điểm tốt nhất</span></article><article><b>'+x.due+'</b><span>Nội dung cần ôn</span></article></div>'+
				'<div class="nah-abg__v50-milestones">'+milestones.map(function(m,i){return '<article class="'+(m.reached?'is-reached':'')+(next===m?' is-next':'')+'"><span>'+(m.reached?'✓':(i+1))+'</span><div><strong>'+escapeHtml(m.label)+'</strong></div></article>';}).join('')+'</div>';
			}
			if(compact){compact.innerHTML='<div><span>MỐC HÀNH TRÌNH</span><strong>'+summary.reached+'/5 dấu mốc đã hình thành</strong><small>'+(next?('Tiếp theo: '+escapeHtml(next.label)):'Tiếp tục duy trì và mở rộng ca thực hành')+'</small></div><button type="button" class="nah-abg__feed-link" data-v50-compact-action="'+escapeHtml(next?next.kind:'adaptive')+'">'+escapeHtml(next?next.cta:'Tiếp tục học')+' →</button>';var c=compact.querySelector('[data-v50-compact-action]');if(c)c.addEventListener('click',function(){v50OpenAction(c.getAttribute('data-v50-compact-action'));});}
		}

		function renderPlatformDashboard(){
			var qs=questionStats(), assessment=state.assessment||{}, rec=platformRecommendation(), theorySeen=platformTheoryCount(), theoryTotal=platformTheoryTotal(), analyses=Number(state.platform.analyses||0), best=Number(assessment.best||state.exam.best||0);
			renderV43Dashboard(qs,assessment,theorySeen,theoryTotal,analyses,best);
			renderV48Plan();
			renderV49Insights();
			renderV50Portfolio();
			if(homeProgress)homeProgress.innerHTML='';
			if(homeRecTitle)homeRecTitle.textContent=rec.title;if(homeRecText)homeRecText.textContent=rec.text;if(homeRecAction){homeRecAction.dataset.homeRecKind=rec.kind||'analysis';homeRecAction.dataset.homeRecTopic=rec.topic||'';}
			if(!platformDashboard)return;
			platformDashboard.innerHTML='<section class="nah-abg__platform-recommendation"><div><span>GỢI Ý HỌC TIẾP</span><h4>'+escapeHtml(rec.title)+'</h4><p>'+escapeHtml(rec.text)+'</p></div>'+platformActionButton(rec)+'</section>'+
			'<div class="nah-abg__platform-path">'+
			'<article><span>1</span><div><strong>Lý thuyết</strong><small>'+theorySeen+'/'+theoryTotal+' bài đã mở</small></div><button type="button" data-open-theory-topic="foundation">Mở sổ tay</button></article>'+
			'<article><span>2</span><div><strong>Ôn tập thích ứng</strong><small>'+qs.mastered+'/'+LEARNING_QUESTIONS.length+' câu đã nắm</small></div><button type="button" data-platform-learning="adaptive">Ôn theo lộ trình</button></article>'+
			'<article><span>3</span><div><strong>Thi và đánh giá</strong><small>'+(Number(assessment.count||0)?('Tốt nhất '+best+'%'):'Chưa có lượt đánh giá')+'</small></div><button type="button" data-platform-learning="exam">Mở đánh giá</button></article>'+
			'<article><span>4</span><div><strong>Phân tích ca bệnh</strong><small>'+analyses+' lượt trên thiết bị</small></div><button type="button" data-platform-workspace="analysis">Mở phân tích</button></article>'+
			'<article><span>5</span><div><strong>Đối chiếu lâm sàng</strong><small>Kiểm tra dữ kiện, mâu thuẫn và phần còn thiếu</small></div><button type="button" data-platform-workspace="analysis">Áp dụng vào ca bệnh</button></article>'+
			'</div><p class="nah-abg__platform-note">Các chỉ số chỉ phản ánh hoạt động tự học trên thiết bị này; không phải thang điểm năng lực chuyên môn hoặc công cụ xác lập chẩn đoán.</p>';
			bindPlatformActions();
		}
		root.addEventListener('medipharm-abg-analysis-complete',function(event){
			state.platform.analyses=Number(state.platform.analyses||0)+1;state.platform.lastAnalysis=Date.now();state.platform.lastActivity=state.platform.lastAnalysis;
			var detail=(event&&event.detail)||{};state.platform.lastContext=[detail.setting||'',detail.focus||''].filter(Boolean).join('|');save();
		});
		root.addEventListener('medipharm-abg-theory-open',function(event){
			var detail=(event&&event.detail)||{},id=String(detail.id||'');if(!id)return;state.platform.theoryViewed[id]=Date.now();state.platform.lastTheory=Date.now();state.platform.lastActivity=state.platform.lastTheory;save();
		});

		var adaptiveDashboard=host.querySelector('[data-adaptive-dashboard]');
		function renderAdaptiveDashboard(){
			if(!adaptiveDashboard)return;
			var rows=allTopicMetrics(), recommended=recommendedTopic(), due=dueQuestionCount(), cardDue=dueCardCount();
			var attempts=rows.reduce(function(n,r){return n+r.attempts;},0);
			var weakRows=rows.filter(function(r){return r.attempts>=2&&r.strength<80;}).sort(function(a,b){return a.strength-b.strength;});
			var headline=attempts===0?'Bắt đầu xây dựng lộ trình học cá nhân':(due>0?'Có '+due+' câu đã đến hạn ôn lại':(weakRows.length?'Ưu tiên củng cố '+learningTopicName(weakRows[0].topic):'Tiếp tục mở rộng phần chưa làm'));
			var reason=attempts===0?'Sau một số câu trả lời, ứng dụng sẽ nhận diện phần cần củng cố và điều chỉnh thứ tự ôn.':(due>0?'Các câu đến hạn được ưu tiên trước, sau đó đến câu từng trả lời sai và chủ đề có độ vững thấp hơn.':(weakRows.length?'Gợi ý dựa trên độ chính xác, số câu đã nắm và lịch ôn lại tại thiết bị này.':'Chưa có chủ đề yếu rõ; phiên tiếp theo ưu tiên câu chưa làm và câu sắp đến hạn.'));
			var topicRows=rows.map(function(r){
				var status=r.attempts===0?'Chưa đánh giá':(r.strength<60?'Cần củng cố':r.strength<80?'Đang củng cố':'Đang ổn định');
				var accuracy=r.accuracy===null?'—':r.accuracy+'%';
				return '<article class="nah-abg__adaptive-topic '+(recommended&&recommended.topic===r.topic?'is-recommended':'')+'"><div><strong>'+escapeHtml(learningTopicName(r.topic))+'</strong><span>'+status+'</span></div><dl><div><dt>Độ chính xác</dt><dd>'+accuracy+'</dd></div><div><dt>Đã nắm</dt><dd>'+r.mastered+'/'+r.total+'</dd></div><div><dt>Đến hạn</dt><dd>'+r.due+'</dd></div></dl></article>';
			}).join('');
			adaptiveDashboard.innerHTML='<section class="nah-abg__adaptive-focus"><div><span class="nah-abg__adaptive-kicker">GỢI Ý ÔN TẬP</span><h4>'+escapeHtml(headline)+'</h4><p>'+escapeHtml(reason)+'</p></div><div class="nah-abg__adaptive-summary"><strong>'+due+'</strong><span>câu đến hạn</span><strong>'+cardDue+'</strong><span>thẻ đến hạn</span></div></section><div class="nah-abg__adaptive-topics">'+topicRows+'</div><div class="nah-abg__adaptive-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-adaptive-start>Bắt đầu phiên ôn thích ứng</button>'+(recommended?'<button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="'+escapeHtml(recommended.topic)+'">Xem lý thuyết chủ đề ưu tiên</button>':'')+'</div><p class="nah-abg__adaptive-note">Mỗi phiên tối đa 8 câu. Khoảng ôn được giãn dần khi trả lời đúng liên tiếp; câu trả lời sai được đưa lại vào lịch ôn sớm hơn. Gợi ý này chỉ phục vụ tự học, không phải đánh giá năng lực lâm sàng.</p>';
			var start=adaptiveDashboard.querySelector('[data-adaptive-start]');if(start)start.addEventListener('click',startAdaptiveSession);
		}

		var remediationDashboard=host.querySelector('[data-remediation-dashboard]');
		function renderRemediationDashboard(){if(!remediationDashboard)return;var patterns=remediationPatternRows(),queue=remediationPriorityItems(6),repeated=patterns.filter(function(x){return x.errors>=2;}).length;if(!patterns.length){remediationDashboard.innerHTML='<section class="nah-abg__remediation-empty"><span>CHƯA CÓ MẪU LỖI CẦN XỬ LÝ</span><h4>Lộ trình sẽ hình thành sau các lượt luyện tập</h4><p>Khi có câu trả lời sai, ứng dụng sẽ phân loại kiểu lỗi và liên kết nội dung cần ôn. Không có dữ liệu nào được gửi lên máy chủ.</p><button type="button" class="nah-abg__button nah-abg__button--primary" data-remediation-open-exam>Bắt đầu một bài đánh giá</button></section>';return;}var patternHtml=patterns.slice(0,4).map(function(r){var width=Math.min(100,Math.max(12,r.errors/Math.max(1,patterns[0].errors)*100));return '<article><div><strong>'+escapeHtml(r.label)+'</strong><b>'+r.errors+' lần</b></div><div class="nah-abg__remediation-bar"><span style="width:'+width.toFixed(0)+'%"></span></div><small>'+escapeHtml(r.note)+'</small></article>';}).join('');var queueHtml=queue.length?queue.map(function(x){var q=x.q,meta=ERROR_PATTERN_META[x.item.pattern]||{},demo=remediationRelatedCase(q.topic);return '<article class="nah-abg__remediation-item"><div class="nah-abg__remediation-item-head"><span>'+escapeHtml(meta.short||x.item.pattern)+'</span><b>Sai '+Number(x.item.wrongCount||0)+' lần</b></div><strong>'+escapeHtml(q.q)+'</strong><small>'+escapeHtml(learningTopicName(q.topic))+' · '+escapeHtml(difficultyName(q.difficulty))+'</small><div><button type="button" data-remediation-lesson="'+escapeHtml(x.item.lesson||q.lesson)+'">Mở bài liên quan</button><button type="button" data-remediation-cards="'+escapeHtml(q.topic)+'">Ôn thẻ</button><button type="button" data-remediation-case="'+escapeHtml(demo)+'">Làm ca liên quan</button></div></article>';}).join(''):'<p class="nah-abg__remediation-cleared">Các lỗi đã ghi nhận đang có dấu hiệu cải thiện. Tiếp tục làm một bài ngắn để kiểm tra độ ổn định.</p>';remediationDashboard.innerHTML='<section class="nah-abg__remediation-focus"><div><span>ƯU TIÊN CẢI THIỆN</span><h4>'+queue.length+' nội dung đang cần kiểm tra lại</h4><p>Ứng dụng phân loại lỗi để hướng người học về đúng bài, thẻ và ca thực hành thay vì chỉ hiển thị điểm số.</p></div><div><strong>'+Number(state.remediation.totalErrors||0)+'</strong><span>lỗi đã ghi nhận</span><strong>'+repeated+'</strong><span>mẫu lỗi lặp lại</span></div></section><div class="nah-abg__remediation-patterns">'+patternHtml+'</div><section class="nah-abg__remediation-queue"><header><span>HÀNG ĐỢI ÔN TẬP</span><strong>Câu cần củng cố trước</strong></header>'+queueHtml+'</section><p class="nah-abg__remediation-note">Lộ trình này chỉ hỗ trợ tự học. Các kiểu lỗi không phải thang đo năng lực lâm sàng và không dùng để chứng nhận chuyên môn.</p>';}
		if(remediationDashboard)remediationDashboard.addEventListener('click',function(event){var cards=event.target.closest('[data-remediation-cards]'),exam=event.target.closest('[data-remediation-open-exam]');if(cards){setTab('cards');if(cardTopic){cardTopic.value=cards.getAttribute('data-remediation-cards')||'all';cardTopic.dispatchEvent(new Event('change',{bubbles:true}));}}if(exam)setTab('exam');});

		var integratedDashboard=host.querySelector('[data-v60-integrated]');
		function renderV60Integrated(){
			if(!integratedDashboard)return;
			var rec=recommendedTopic()||topicMetrics('foundation'),topic=rec.topic||'foundation',dueQ=dueQuestionCount(),dueC=dueCardCount(),assessment=state.assessment||{},last=Array.isArray(assessment.history)&&assessment.history.length?assessment.history[assessment.history.length-1]:null;
			var lastScore=last&&Number.isFinite(Number(last.score))?Math.round(Number(last.score)):(Number(assessment.best||0)||0);
			integratedDashboard.innerHTML='<header class="nah-abg__v60-integrated-head"><div><span>PHIÊN HỌC TÍCH HỢP</span><h4>Ưu tiên '+escapeHtml(learningTopicName(topic))+'</h4><p>Một phiên duy nhất nối nội dung cần học với ôn lại, ca lâm sàng và đánh giá. Bạn có thể dừng sau bất kỳ bước nào.</p></div><div class="nah-abg__v60-integrated-signal"><strong>'+(dueQ+dueC)+'</strong><span>mục đến hạn</span></div></header>'+
			'<div class="nah-abg__v60-integrated-stats"><span><b>220</b> câu</span><span><b>50</b> bài</span><span><b>50</b> ca</span><span><b>8</b> bộ thi</span><span><b>6</b> dạng câu</span></div>'+
			'<div class="nah-abg__v60-integrated-path">'+
			'<button type="button" data-v60-step="theory"><i>1</i><span><strong>Học trọng tâm</strong><small>'+escapeHtml(learningTopicName(topic))+'</small></span></button>'+
			'<button type="button" data-v60-step="cards"><i>2</i><span><strong>Ôn thẻ</strong><small>'+dueC+' thẻ đến hạn</small></span></button>'+
			'<button type="button" data-v60-step="adaptive"><i>3</i><span><strong>Luyện thích ứng</strong><small>'+dueQ+' câu đến hạn</small></span></button>'+
			'<button type="button" data-v60-step="case"><i>4</i><span><strong>Áp dụng ca</strong><small>Ca liên quan chủ đề ưu tiên</small></span></button>'+
			'<button type="button" data-v60-step="mock"><i>5</i><span><strong>Đánh giá</strong><small>'+(lastScore?('Lần gần đây '+lastScore+'%'):'Chưa có điểm gần đây')+'</small></span></button>'+
			'</div><div class="nah-abg__v60-integrated-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-v60-step="adaptive">Bắt đầu từ bước nên ưu tiên</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-v60-step="generator">Tạo đề riêng</button></div>'+
			'<p class="nah-abg__v60-integrated-note">Lộ trình này tổng hợp hoạt động tự học trên thiết bị; không phải chứng nhận hoặc suy diễn năng lực lâm sàng.</p>';
			integratedDashboard.querySelectorAll('[data-v60-step]').forEach(function(btn){btn.addEventListener('click',function(){var kind=btn.getAttribute('data-v60-step');if(kind==='theory'){openHomeTopic(topic);return;}if(kind==='cards'){setTab('cards');var ct=host.querySelector('[data-card-topic]');if(ct){ct.value=topic;ct.dispatchEvent(new Event('change',{bubbles:true}));}return;}if(kind==='adaptive'){startAdaptiveSession();return;}if(kind==='case'){var csel=root.querySelector('[data-classroom-demo-select]'),cload=root.querySelector('[data-classroom-load-demo]'),key=remediationRelatedCase(topic);if(csel)csel.value=key;if(cload)cload.click();return;}if(kind==='mock'||kind==='generator'){setTab('exam');var bp=host.querySelector('[data-assessment-blueprint]');if(bp){bp.value=kind==='generator'?'generator':'mock_multiformat';bp.dispatchEvent(new Event('change',{bubbles:true}));}var tm=host.querySelector('[data-assessment-timing]');if(tm&&kind==='mock'){tm.value='timed';tm.dispatchEvent(new Event('change',{bubbles:true}));}return;}});});
		}

		var tabs=Array.prototype.slice.call(host.querySelectorAll('[data-learning-tab]'));
		var panels=Array.prototype.slice.call(host.querySelectorAll('[data-learning-panel]'));
		function setTab(name) {
			tabs.forEach(function(btn){
				var active=btn.getAttribute('data-learning-tab')===name;
				btn.classList.toggle('is-active',active);
				btn.setAttribute('aria-expanded',active?'true':'false');
				var item=btn.closest('.nah-abg__learning-accordion-item');
				if(item)item.classList.toggle('is-open',active);
			});
			panels.forEach(function(panel){panel.hidden=panel.getAttribute('data-learning-panel')!==name;});
			if(name==='progress')renderProgress();if(name==='remediation')renderRemediationDashboard();
		}
		tabs.forEach(function(btn){btn.addEventListener('click',function(){setTab(btn.getAttribute('data-learning-tab'));});});

		var topicSelect=host.querySelector('[data-learning-topic]');
		var questionShell=host.querySelector('[data-learning-question]');
		var adaptiveSessionBadge=host.querySelector('[data-adaptive-session]');
		var currentQuestion=null, adaptiveMode=false, adaptiveQueue=[], adaptiveTotal=0, adaptivePosition=0;
		function pickQuestion(topic, avoid) {
			var pool=LEARNING_QUESTIONS.filter(function(q){return q.topic===topic && q.id!==avoid;});
			if(!pool.length) pool=LEARNING_QUESTIONS.filter(function(q){return q.topic===topic;});
			return pool[Math.floor(Math.random()*pool.length)] || null;
		}
		function updateAdaptiveSessionBadge(q){
			if(!adaptiveSessionBadge)return;
			if(!adaptiveMode){adaptiveSessionBadge.hidden=true;adaptiveSessionBadge.textContent='';return;}
			adaptiveSessionBadge.hidden=false;
			adaptiveSessionBadge.textContent='Phiên thích ứng '+adaptivePosition+'/'+adaptiveTotal+(q?' · '+learningTopicName(q.topic):'');
		}
		function stopAdaptiveSession(){adaptiveMode=false;adaptiveQueue=[];adaptiveTotal=0;adaptivePosition=0;updateAdaptiveSessionBadge(null);}
		function finishAdaptiveSession(){
			adaptiveMode=false;state.adaptive.completed=Number(state.adaptive.completed||0)+1;state.adaptive.lastCompleted=Date.now();save();updateAdaptiveSessionBadge(null);
			if(!questionShell)return;
			var recommended=recommendedTopic();
			questionShell.innerHTML='<div class="nah-abg__adaptive-complete"><strong>Đã hoàn thành phiên ôn thích ứng</strong><p>Ứng dụng đã cập nhật lịch ôn và chủ đề ưu tiên từ các câu vừa trả lời.</p><div><button type="button" class="nah-abg__button nah-abg__button--primary" data-adaptive-restart>Ôn thêm một phiên</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-adaptive-home>Xem lộ trình cập nhật</button>'+(recommended?'<button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="'+escapeHtml(recommended.topic)+'">Xem lý thuyết cần củng cố</button>':'')+'</div></div>';
			var restart=questionShell.querySelector('[data-adaptive-restart]');if(restart)restart.addEventListener('click',startAdaptiveSession);
			var home=questionShell.querySelector('[data-adaptive-home]');if(home)home.addEventListener('click',function(){setTab('adaptive');renderAdaptiveDashboard();});
		}
		function renderAdaptiveNext(){
			if(!adaptiveMode)return;
			var q=adaptiveQueue.shift();if(!q){finishAdaptiveSession();return;}
			adaptivePosition++;if(topicSelect)topicSelect.value=q.topic;updateAdaptiveSessionBadge(q);renderQuestion(q);
		}
		function startAdaptiveSessionUnlocked(){
			adaptiveQueue=buildAdaptiveQueue(8,currentQuestion?currentQuestion.id:'');adaptiveTotal=adaptiveQueue.length;adaptivePosition=0;adaptiveMode=true;
			state.adaptive.started=Number(state.adaptive.started||0)+1;state.adaptive.lastSession=Date.now();state.adaptive.lastRecommendedTopic=(recommendedTopic()||{}).topic||'';save();
			setTab('questions');renderAdaptiveNext();
		}
		function startAdaptiveSession(){ requestTrialUse('adaptive', startAdaptiveSessionUnlocked); }
		function renderQuestion(q) {
			currentQuestion=q; if(!q||!questionShell)return;
			var prior=state.questions[q.id], priorRecord=prior?normalizeQuestionRecord(prior):null, badges=[];
			if(adaptiveMode)badges.push('<b>Ưu tiên theo lộ trình</b>');
			if(priorRecord&&isQuestionDue(priorRecord))badges.push('<b>Đến hạn ôn lại</b>');
			else if(priorRecord&&priorRecord.attempts&&priorRecord.lastCorrect===false)badges.push('<b>Cần củng cố</b>');
			else if(priorRecord&&priorRecord.everCorrect)badges.push('<b>Đã trả lời đúng trước đây</b>');
			var opts=q.o.map(function(o,i){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-learning-'+q.id+'" value="'+i+'"><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('');
			questionShell.innerHTML='<div class="nah-abg__question-card"><div class="nah-abg__question-meta"><span>'+escapeHtml(learningTopicName(q.topic))+'</span>'+badges.join('')+'</div><h4>'+escapeHtml(q.q)+'</h4><div class="nah-abg__answer-list">'+opts+'</div><button type="button" class="nah-abg__button nah-abg__button--primary" data-learning-submit>Kiểm tra đáp án</button><div class="nah-abg__answer-feedback" data-learning-feedback hidden></div></div>';
			var submit=questionShell.querySelector('[data-learning-submit]');
			submit.addEventListener('click',function(){
				var checked=questionShell.querySelector('input[type="radio"]:checked');
				var feedback=questionShell.querySelector('[data-learning-feedback]');
				if(!checked){feedback.hidden=false;feedback.className='nah-abg__answer-feedback is-warning';feedback.innerHTML='<strong>Chưa chọn đáp án</strong><p>Chọn một phương án trước khi kiểm tra.</p>';return;}
				var chosen=Number(checked.value), ok=chosen===q.a;
				var item=recordQuestionResult(q,ok,adaptiveMode?'adaptive':'topic');save();
				questionShell.querySelectorAll('input[type="radio"]').forEach(function(input){input.disabled=true;}); submit.disabled=true;
				var scheduleText=ok?('Lịch ôn tiếp theo: sau '+Number(item.intervalDays||1)+' ngày.'):'Câu này được đưa lại vào lịch ôn sớm, sau khoảng 6 giờ.';
				feedback.hidden=false;feedback.className='nah-abg__answer-feedback '+(ok?'is-correct':'is-wrong');feedback.innerHTML='<strong>'+(ok?'Đúng':'Chưa đúng')+'</strong><p>'+publicHtml(q.e)+'</p><span>Đáp án: '+publicHtml(q.o[q.a])+'</span><small class="nah-abg__review-schedule">'+escapeHtml(scheduleText)+'</small><div class="nah-abg__adaptive-feedback-actions"><button type="button" class="nah-abg__review-theory-link" data-open-theory-topic="'+escapeHtml(q.topic)+'">Xem lại lý thuyết</button>'+(adaptiveMode?'<button type="button" class="nah-abg__button nah-abg__button--primary" data-adaptive-next>Câu thích ứng tiếp theo</button>':'')+'</div>';
				var adaptiveNext=feedback.querySelector('[data-adaptive-next]');if(adaptiveNext)adaptiveNext.addEventListener('click',renderAdaptiveNext);
			});
		}
		if(topicSelect){topicSelect.addEventListener('change',function(){stopAdaptiveSession();renderQuestion(pickQuestion(topicSelect.value,''));});}
		var nextQuestion=host.querySelector('[data-learning-next-question]'); if(nextQuestion)nextQuestion.addEventListener('click',function(){if(adaptiveMode)renderAdaptiveNext();else renderQuestion(pickQuestion(topicSelect?topicSelect.value:'foundation',currentQuestion?currentQuestion.id:''));});
		renderQuestion(pickQuestion(topicSelect?topicSelect.value:'foundation',''));

		var challengeLevel=host.querySelector('[data-challenge-level]');
		var challengeCase=host.querySelector('[data-challenge-case]');
		var challengeShell=host.querySelector('[data-challenge-shell]');
		var challengeIndex=0, challengeAnswers=[];
		var challengeStorageKey='medipharm_abg_challenge_v33', challengeProgress={};
		try { challengeProgress=JSON.parse(window.localStorage.getItem(challengeStorageKey)||'{}')||{}; } catch(error) {}
		function saveChallenge(){try{window.localStorage.setItem(challengeStorageKey,JSON.stringify(challengeProgress));}catch(error){}}
		function challengePool(){var level=challengeLevel?challengeLevel.value:'basic';return CASE_CHALLENGES.filter(function(c){return c.level===level;});}
		function selectedChallenge(){var id=challengeCase?challengeCase.value:'';return CASE_CHALLENGES.find(function(c){return c.id===id;})||challengePool()[0];}
		function fillChallengeCases(){
			if(!challengeCase)return;
			var pool=challengePool(), current=challengeCase.value;
			challengeCase.innerHTML=pool.map(function(c){var done=challengeProgress[c.id]&&challengeProgress[c.id].completed;return '<option value="'+escapeHtml(c.id)+'">'+escapeHtml(c.title)+(done?' · Đã hoàn thành':'')+'</option>';}).join('');
			if(pool.some(function(c){return c.id===current;}))challengeCase.value=current;
			challengeIndex=0;challengeAnswers=[];renderChallenge();
		}
		function renderChallenge(){
			if(!challengeShell)return;
			var c=selectedChallenge(); if(!c){challengeShell.innerHTML='';return;}
			if(challengeIndex>=c.steps.length){finishChallenge(c);return;}
			var step=c.steps[challengeIndex], progress=Math.round(challengeIndex/c.steps.length*100);
			var opts=step.o.map(function(o,i){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-challenge-'+challengeIndex+'" value="'+i+'"><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('');
			challengeShell.innerHTML='<article class="nah-abg__challenge-card"><header><div><span class="nah-abg__challenge-level">'+(c.level==='basic'?'Cơ bản':c.level==='intermediate'?'Trung bình':'Nâng cao')+'</span><h4>'+escapeHtml(c.title)+'</h4></div><b>'+(challengeIndex+1)+' / '+c.steps.length+'</b></header><div class="nah-abg__challenge-progress"><span style="width:'+progress+'%"></span></div><p class="nah-abg__challenge-case">'+escapeHtml(c.intro)+'</p><section class="nah-abg__challenge-step"><h5>'+escapeHtml(step.q)+'</h5><div class="nah-abg__answer-list">'+opts+'</div><button type="button" class="nah-abg__button nah-abg__button--primary" data-challenge-check>Kiểm tra bước này</button><div class="nah-abg__answer-feedback" data-challenge-feedback hidden></div></section></article>';
			challengeShell.querySelector('[data-challenge-check]').addEventListener('click',function(){
				var checked=challengeShell.querySelector('input[type="radio"]:checked'), feedback=challengeShell.querySelector('[data-challenge-feedback]');
				if(!checked){feedback.hidden=false;feedback.className='nah-abg__answer-feedback is-warning';feedback.innerHTML='<strong>Chưa chọn nhận định</strong><p>Hãy tự đưa ra nhận định trước khi mở giải thích.</p>';return;}
				var chosen=Number(checked.value), ok=chosen===step.a; challengeAnswers.push({correct:ok});
				challengeShell.querySelectorAll('input[type="radio"]').forEach(function(input){input.disabled=true;});
				this.disabled=true; feedback.hidden=false; feedback.className='nah-abg__answer-feedback '+(ok?'is-correct':'is-wrong');
				feedback.innerHTML='<strong>'+(ok?'Đúng':'Chưa đúng')+'</strong><p>'+escapeHtml(step.e)+'</p><span>Nhận định phù hợp: '+escapeHtml(step.o[step.a])+'</span><button type="button" class="nah-abg__button nah-abg__button--primary nah-abg__challenge-next" data-challenge-next>'+(challengeIndex===c.steps.length-1?'Xem tổng kết':'Bước tiếp theo')+'</button>';
				feedback.querySelector('[data-challenge-next]').addEventListener('click',function(){challengeIndex++;renderChallenge();});
			});
		}
		function finishChallenge(c){
			var correct=challengeAnswers.filter(function(a){return a.correct;}).length, score=Math.round(correct/c.steps.length*100);
			var old=challengeProgress[c.id]||{}; challengeProgress[c.id]={completed:true,last:score,best:Math.max(score,Number(old.best||0))}; saveChallenge();
			challengeShell.innerHTML='<article class="nah-abg__challenge-result"><div class="nah-abg__exam-score"><strong>'+score+'%</strong><span>'+correct+'/'+c.steps.length+' bước phù hợp</span></div><h4>Hoàn thành '+escapeHtml(c.title)+'</h4><p>'+(score===100?'Bạn đã đi đúng toàn bộ trình tự suy luận của ca này.':'Nên xem lại những bước chưa phù hợp rồi làm lại ca để củng cố trình tự suy luận.')+'</p><div class="nah-abg__challenge-result-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-challenge-restart>Làm lại ca này</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="'+escapeHtml(c.topic)+'">Xem lại lý thuyết liên quan</button></div></article>';
			challengeShell.querySelector('[data-challenge-restart]').addEventListener('click',function(){challengeIndex=0;challengeAnswers=[];renderChallenge();});
			if(challengeCase&&challengeCase.options[challengeCase.selectedIndex]) challengeCase.options[challengeCase.selectedIndex].text= c.title+' · Đã hoàn thành';
		}
		if(challengeLevel)challengeLevel.addEventListener('change',fillChallengeCases);
		if(challengeCase)challengeCase.addEventListener('change',function(){challengeIndex=0;challengeAnswers=[];renderChallenge();});
		fillChallengeCases();


		var mixedCase=host.querySelector('[data-mixed-case]');
		var mixedShell=host.querySelector('[data-mixed-shell]');
		var mixedStatus=host.querySelector('[data-mixed-status]');
		var mixedIndex=0, mixedAnswers=[];
		var mixedStorageKey='medipharm_abg_mixed_v34', mixedProgress={};
		try { mixedProgress=JSON.parse(window.localStorage.getItem(mixedStorageKey)||'{}')||{}; } catch(error) {}
		function saveMixed(){try{window.localStorage.setItem(mixedStorageKey,JSON.stringify(mixedProgress));}catch(error){}}
		function selectedMixed(){var id=mixedCase?mixedCase.value:'';return MIXED_DISORDER_CASES.find(function(c){return c.id===id;})||MIXED_DISORDER_CASES[0];}
		function fillMixedCases(){
			if(!mixedCase)return;
			var current=mixedCase.value;
			mixedCase.innerHTML=MIXED_DISORDER_CASES.map(function(c){var done=mixedProgress[c.id]&&mixedProgress[c.id].completed;return '<option value="'+escapeHtml(c.id)+'">'+escapeHtml(c.title)+(done?' · Đã hoàn thành':'')+'</option>';}).join('');
			if(MIXED_DISORDER_CASES.some(function(c){return c.id===current;}))mixedCase.value=current;
			mixedIndex=0;mixedAnswers=[];renderMixedStatus();renderMixed();
		}
		function renderMixedStatus(){
			if(!mixedStatus)return;
			var completed=MIXED_DISORDER_CASES.filter(function(c){return mixedProgress[c.id]&&mixedProgress[c.id].completed;}).length;
			mixedStatus.innerHTML='<strong>'+completed+'/'+MIXED_DISORDER_CASES.length+'</strong><span>tình huống đã hoàn thành</span>';
		}
		function renderMixed(){
			if(!mixedShell)return;
			var c=selectedMixed(); if(!c){mixedShell.innerHTML='';return;}
			if(mixedIndex>=c.steps.length){finishMixed(c);return;}
			var step=c.steps[mixedIndex], progress=Math.round(mixedIndex/c.steps.length*100);
			var opts=step.o.map(function(o,i){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-mixed-'+mixedIndex+'" value="'+i+'"><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('');
			mixedShell.innerHTML='<article class="nah-abg__mixed-case"><header><div><span>Rối loạn phối hợp</span><h4>'+escapeHtml(c.title)+'</h4></div><b>'+(mixedIndex+1)+' / '+c.steps.length+'</b></header><div class="nah-abg__challenge-progress"><span style="width:'+progress+'%"></span></div><p class="nah-abg__mixed-case-data">'+escapeHtml(c.intro)+'</p><h5>'+escapeHtml(step.q)+'</h5><div class="nah-abg__answer-list">'+opts+'</div><button type="button" class="nah-abg__button nah-abg__button--primary" data-mixed-check>Kiểm tra nhận định</button><div class="nah-abg__answer-feedback" data-mixed-feedback hidden></div></article>';
			mixedShell.querySelector('[data-mixed-check]').addEventListener('click',function(){
				var checked=mixedShell.querySelector('input[type="radio"]:checked'), feedback=mixedShell.querySelector('[data-mixed-feedback]');
				if(!checked){feedback.hidden=false;feedback.className='nah-abg__answer-feedback is-warning';feedback.innerHTML='<strong>Chưa chọn nhận định</strong><p>Hãy tự đưa ra nhận định trước khi xem giải thích.</p>';return;}
				var chosen=Number(checked.value), ok=chosen===step.a;mixedAnswers.push({correct:ok});
				mixedShell.querySelectorAll('input[type="radio"]').forEach(function(input){input.disabled=true;});this.disabled=true;
				feedback.hidden=false;feedback.className='nah-abg__answer-feedback '+(ok?'is-correct':'is-wrong');
				feedback.innerHTML='<strong>'+(ok?'Đúng':'Chưa đúng')+'</strong><p>'+escapeHtml(step.e)+'</p><span>Nhận định phù hợp: '+escapeHtml(step.o[step.a])+'</span><button type="button" class="nah-abg__button nah-abg__button--primary nah-abg__challenge-next" data-mixed-next>'+(mixedIndex===c.steps.length-1?'Xem tổng kết':'Bước tiếp theo')+'</button>';
				feedback.querySelector('[data-mixed-next]').addEventListener('click',function(){mixedIndex++;renderMixed();});
			});
		}
		function finishMixed(c){
			var correct=mixedAnswers.filter(function(a){return a.correct;}).length, score=Math.round(correct/c.steps.length*100);
			var old=mixedProgress[c.id]||{};mixedProgress[c.id]={completed:true,last:score,best:Math.max(score,Number(old.best||0))};saveMixed();renderMixedStatus();
			mixedShell.innerHTML='<article class="nah-abg__challenge-result"><div class="nah-abg__exam-score"><strong>'+score+'%</strong><span>'+correct+'/'+c.steps.length+' nhận định phù hợp</span></div><h4>Hoàn thành '+escapeHtml(c.title)+'</h4><p>'+(score===100?'Bạn đã nhận diện đúng các dấu hiệu của rối loạn phối hợp trong tình huống này.':'Nên xem lại bước đánh giá đáp ứng bù hoặc so sánh khoảng trống anion rồi thử lại.')+'</p><div class="nah-abg__challenge-result-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-mixed-restart>Làm lại tình huống</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="acidbase">Xem lại lý thuyết toan–kiềm</button></div></article>';
			mixedShell.querySelector('[data-mixed-restart]').addEventListener('click',function(){mixedIndex=0;mixedAnswers=[];renderMixed();});
			if(mixedCase&&mixedCase.options[mixedCase.selectedIndex])mixedCase.options[mixedCase.selectedIndex].text=c.title+' · Đã hoàn thành';
		}
		if(mixedCase)mixedCase.addEventListener('change',function(){mixedIndex=0;mixedAnswers=[];renderMixed();});
		fillMixedCases();


		var oxygenCase=host.querySelector('[data-oxygen-case]');
		var oxygenShell=host.querySelector('[data-oxygen-shell]');
		var oxygenStatus=host.querySelector('[data-oxygen-status]');
		var oxygenIndex=0, oxygenAnswers=[];
		var oxygenStorageKey='medipharm_abg_oxygen_v35', oxygenProgress={};
		try { oxygenProgress=JSON.parse(window.localStorage.getItem(oxygenStorageKey)||'{}')||{}; } catch(error) {}
		function saveOxygen(){try{window.localStorage.setItem(oxygenStorageKey,JSON.stringify(oxygenProgress));}catch(error){}}
		function selectedOxygen(){var id=oxygenCase?oxygenCase.value:'';return OXYGEN_VENT_CASES.find(function(c){return c.id===id;})||OXYGEN_VENT_CASES[0];}
		function fillOxygenCases(){
			if(!oxygenCase)return;
			var current=oxygenCase.value;
			oxygenCase.innerHTML=OXYGEN_VENT_CASES.map(function(c){var done=oxygenProgress[c.id]&&oxygenProgress[c.id].completed;return '<option value="'+escapeHtml(c.id)+'">'+escapeHtml(c.title)+(done?' · Đã hoàn thành':'')+'</option>';}).join('');
			if(OXYGEN_VENT_CASES.some(function(c){return c.id===current;}))oxygenCase.value=current;
			oxygenIndex=0;oxygenAnswers=[];renderOxygenStatus();renderOxygenMasterclass();
		}
		function renderOxygenStatus(){
			if(!oxygenStatus)return;
			var completed=OXYGEN_VENT_CASES.filter(function(c){return oxygenProgress[c.id]&&oxygenProgress[c.id].completed;}).length;
			oxygenStatus.innerHTML='<strong>'+completed+'/'+OXYGEN_VENT_CASES.length+'</strong><span>tình huống đã hoàn thành</span>';
		}
		function renderOxygenMasterclass(){
			if(!oxygenShell)return;
			var c=selectedOxygen(); if(!c){oxygenShell.innerHTML='';return;}
			if(oxygenIndex>=c.steps.length){finishOxygen(c);return;}
			var step=c.steps[oxygenIndex], progress=Math.round(oxygenIndex/c.steps.length*100);
			var opts=step.o.map(function(o,i){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-oxygen-'+oxygenIndex+'" value="'+i+'"><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('');
			oxygenShell.innerHTML='<article class="nah-abg__oxygen-training-case"><header><div><span>Oxy hóa máu &amp; thông khí</span><h4>'+escapeHtml(c.title)+'</h4></div><b>'+(oxygenIndex+1)+' / '+c.steps.length+'</b></header><div class="nah-abg__challenge-progress"><span style="width:'+progress+'%"></span></div><p class="nah-abg__oxygen-case-data">'+escapeHtml(c.intro)+'</p><h5>'+escapeHtml(step.q)+'</h5><div class="nah-abg__answer-list">'+opts+'</div><button type="button" class="nah-abg__button nah-abg__button--primary" data-oxygen-check>Kiểm tra nhận định</button><div class="nah-abg__answer-feedback" data-oxygen-feedback hidden></div></article>';
			oxygenShell.querySelector('[data-oxygen-check]').addEventListener('click',function(){
				var checked=oxygenShell.querySelector('input[type="radio"]:checked'), feedback=oxygenShell.querySelector('[data-oxygen-feedback]');
				if(!checked){feedback.hidden=false;feedback.className='nah-abg__answer-feedback is-warning';feedback.innerHTML='<strong>Chưa chọn nhận định</strong><p>Hãy tự phân tích cơ chế trước khi xem giải thích.</p>';return;}
				var chosen=Number(checked.value), ok=chosen===step.a;oxygenAnswers.push({correct:ok});
				oxygenShell.querySelectorAll('input[type="radio"]').forEach(function(input){input.disabled=true;});this.disabled=true;
				feedback.hidden=false;feedback.className='nah-abg__answer-feedback '+(ok?'is-correct':'is-wrong');
				feedback.innerHTML='<strong>'+(ok?'Đúng':'Chưa đúng')+'</strong><p>'+escapeHtml(step.e)+'</p><span>Nhận định phù hợp: '+escapeHtml(step.o[step.a])+'</span><button type="button" class="nah-abg__button nah-abg__button--primary nah-abg__challenge-next" data-oxygen-next>'+(oxygenIndex===c.steps.length-1?'Xem tổng kết':'Bước tiếp theo')+'</button>';
				feedback.querySelector('[data-oxygen-next]').addEventListener('click',function(){oxygenIndex++;renderOxygenMasterclass();});
			});
		}
		function finishOxygen(c){
			var correct=oxygenAnswers.filter(function(a){return a.correct;}).length, score=Math.round(correct/c.steps.length*100);
			var old=oxygenProgress[c.id]||{};oxygenProgress[c.id]={completed:true,last:score,best:Math.max(score,Number(old.best||0))};saveOxygen();renderOxygenStatus();
			oxygenShell.innerHTML='<article class="nah-abg__challenge-result"><div class="nah-abg__exam-score"><strong>'+score+'%</strong><span>'+correct+'/'+c.steps.length+' nhận định phù hợp</span></div><h4>Hoàn thành '+escapeHtml(c.title)+'</h4><p>'+(score===100?'Bạn đã phân biệt đúng các trục oxy hóa máu và thông khí trong tình huống này.':'Nên xem lại FiO₂, PaCO₂, chênh áp A–a và cơ chế trao đổi khí rồi thử lại.')+'</p><div class="nah-abg__challenge-result-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-oxygen-restart>Làm lại tình huống</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="oxygen">Xem lại lý thuyết oxy hóa máu</button></div></article>';
			oxygenShell.querySelector('[data-oxygen-restart]').addEventListener('click',function(){oxygenIndex=0;oxygenAnswers=[];renderOxygenMasterclass();});
			if(oxygenCase&&oxygenCase.options[oxygenCase.selectedIndex])oxygenCase.options[oxygenCase.selectedIndex].text=c.title+' · Đã hoàn thành';
		}
		if(oxygenCase)oxygenCase.addEventListener('change',function(){oxygenIndex=0;oxygenAnswers=[];renderOxygenMasterclass();});
		fillOxygenCases();


		var samplingCase=host.querySelector('[data-sampling-case]');
		var samplingShell=host.querySelector('[data-sampling-shell]');
		var samplingStatus=host.querySelector('[data-sampling-status]');
		var samplingIndex=0, samplingAnswers=[];
		var samplingStorageKey='medipharm_abg_sampling_v36', samplingProgress={};
		try { samplingProgress=JSON.parse(window.localStorage.getItem(samplingStorageKey)||'{}')||{}; } catch(error) {}
		function saveSampling(){try{window.localStorage.setItem(samplingStorageKey,JSON.stringify(samplingProgress));}catch(error){}}
		function selectedSampling(){var id=samplingCase?samplingCase.value:'';return SAMPLING_SAFETY_CASES.find(function(c){return c.id===id;})||SAMPLING_SAFETY_CASES[0];}
		function fillSamplingCases(){
			if(!samplingCase)return;
			samplingCase.innerHTML=SAMPLING_SAFETY_CASES.map(function(c){var done=samplingProgress[c.id]&&samplingProgress[c.id].completed;return '<option value="'+escapeHtml(c.id)+'">'+escapeHtml(c.title)+(done?' · Đã hoàn thành':'')+'</option>';}).join('');
			renderSamplingStatus();renderSampling();
		}
		function renderSamplingStatus(){
			if(!samplingStatus)return;
			var completed=SAMPLING_SAFETY_CASES.filter(function(c){return samplingProgress[c.id]&&samplingProgress[c.id].completed;}).length;
			samplingStatus.innerHTML='<strong>'+completed+'/'+SAMPLING_SAFETY_CASES.length+'</strong><span>tình huống đã hoàn thành</span>';
		}
		function renderSampling(){
			if(!samplingShell)return;var c=selectedSampling();if(!c)return;
			if(samplingIndex>=c.steps.length){finishSampling(c);return;}
			var step=c.steps[samplingIndex], progress=Math.round(samplingIndex/c.steps.length*100);
			var opts=step.o.map(function(o,i){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-sampling-'+c.id+'-'+samplingIndex+'" value="'+i+'"><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('');
			samplingShell.innerHTML='<article class="nah-abg__sampling-training-case"><header><div><span>An toàn tiền phân tích</span><h4>'+escapeHtml(c.title)+'</h4></div><b>'+(samplingIndex+1)+' / '+c.steps.length+'</b></header><div class="nah-abg__challenge-progress"><span style="width:'+progress+'%"></span></div><p class="nah-abg__sampling-case-data">'+escapeHtml(c.intro)+'</p><h5>'+escapeHtml(step.q)+'</h5><div class="nah-abg__answer-list">'+opts+'</div><button type="button" class="nah-abg__button nah-abg__button--primary" data-sampling-check>Kiểm tra nhận định</button><div class="nah-abg__answer-feedback" data-sampling-feedback hidden></div></article>';
			samplingShell.querySelector('[data-sampling-check]').addEventListener('click',function(){
				var checked=samplingShell.querySelector('input[type="radio"]:checked'), feedback=samplingShell.querySelector('[data-sampling-feedback]');
				if(!checked){feedback.hidden=false;feedback.className='nah-abg__answer-feedback is-warning';feedback.innerHTML='<strong>Chưa chọn nhận định</strong><p>Hãy tự nhận diện vấn đề của mẫu trước khi xem giải thích.</p>';return;}
				var chosen=Number(checked.value), ok=chosen===step.a;samplingAnswers.push({correct:ok});
				samplingShell.querySelectorAll('input[type="radio"]').forEach(function(input){input.disabled=true;});this.disabled=true;
				feedback.hidden=false;feedback.className='nah-abg__answer-feedback '+(ok?'is-correct':'is-wrong');
				feedback.innerHTML='<strong>'+(ok?'Đúng':'Chưa đúng')+'</strong><p>'+escapeHtml(step.e)+'</p><span>Nhận định phù hợp: '+escapeHtml(step.o[step.a])+'</span><button type="button" class="nah-abg__button nah-abg__button--primary nah-abg__challenge-next" data-sampling-next>'+(samplingIndex===c.steps.length-1?'Xem tổng kết':'Bước tiếp theo')+'</button>';
				feedback.querySelector('[data-sampling-next]').addEventListener('click',function(){samplingIndex++;renderSampling();});
			});
		}
		function finishSampling(c){
			var correct=samplingAnswers.filter(function(a){return a.correct;}).length, score=Math.round(correct/c.steps.length*100);
			var old=samplingProgress[c.id]||{};samplingProgress[c.id]={completed:true,last:score,best:Math.max(score,Number(old.best||0))};saveSampling();renderSamplingStatus();
			samplingShell.innerHTML='<article class="nah-abg__challenge-result"><div class="nah-abg__exam-score"><strong>'+score+'%</strong><span>'+correct+'/'+c.steps.length+' nhận định phù hợp</span></div><h4>Hoàn thành '+escapeHtml(c.title)+'</h4><p>'+(score===100?'Bạn đã nhận diện đúng các nguy cơ tiền phân tích chính trong tình huống này.':'Nên quay lại bảng kiểm chất lượng mẫu, sau đó làm lại tình huống trước khi chuyển sang diễn giải khí máu.')+'</p><div class="nah-abg__challenge-result-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-sampling-restart>Làm lại tình huống</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-open-theory-topic="foundation">Xem lại lý thuyết lấy mẫu</button></div></article>';
			samplingShell.querySelector('[data-sampling-restart]').addEventListener('click',function(){samplingIndex=0;samplingAnswers=[];renderSampling();});
			if(samplingCase&&samplingCase.options[samplingCase.selectedIndex])samplingCase.options[samplingCase.selectedIndex].text=c.title+' · Đã hoàn thành';
		}
		if(samplingCase)samplingCase.addEventListener('change',function(){samplingIndex=0;samplingAnswers=[];renderSampling();});
		fillSamplingCases();


		var cardTopic=host.querySelector('[data-card-topic]'), cardShell=host.querySelector('[data-learning-card]'), cardCounter=host.querySelector('[data-card-counter]');
		var cardIndex=0, cardFace='front';
		function cardPool(){var t=cardTopic?cardTopic.value:'all',now=Date.now();return LEARNING_CARDS.filter(function(c){return t==='all'||c.topic===t;}).sort(function(a,b){var ad=state.cardSchedule[a.id]&&Number(state.cardSchedule[a.id].nextReview||0)&&Number(state.cardSchedule[a.id].nextReview)<=now?1:0,bd=state.cardSchedule[b.id]&&Number(state.cardSchedule[b.id].nextReview||0)&&Number(state.cardSchedule[b.id].nextReview)<=now?1:0;return bd-ad;});}
		function renderCard(){
			var pool=cardPool(); if(!pool.length||!cardShell)return; if(cardIndex>=pool.length)cardIndex=0; if(cardIndex<0)cardIndex=pool.length-1;
			var c=pool[cardIndex], status=state.cards[c.id]||'', cardSchedule=state.cardSchedule[c.id]||{}, cardDue=Number(cardSchedule.nextReview||0)&&Number(cardSchedule.nextReview)<=Date.now();
			if(cardCounter)cardCounter.textContent=(cardIndex+1)+' / '+pool.length;
			cardShell.innerHTML='<div class="nah-abg__memory-card '+(cardFace==='back'?'is-flipped':'')+'"><div class="nah-abg__memory-meta"><span>'+escapeHtml(learningTopicName(c.topic))+'</span>'+(cardDue?'<b>Đến hạn ôn lại</b>':status==='mastered'?'<b>Đã ghi nhớ</b>':status==='review'?'<b>Cần ôn lại</b>':'')+'</div><div class="nah-abg__memory-face"><small>'+(cardFace==='front'?'Câu hỏi':'Gợi nhớ')+'</small><strong>'+escapeHtml(cardFace==='front'?c.front:c.back)+'</strong></div><div class="nah-abg__memory-actions"><button type="button" class="nah-abg__button nah-abg__button--ghost" data-card-prev>← Trước</button><button type="button" class="nah-abg__button nah-abg__button--primary" data-card-flip>'+(cardFace==='front'?'Lật thẻ':'Xem câu hỏi')+'</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-card-next>Sau →</button></div>'+(cardFace==='back'?'<div class="nah-abg__memory-rating"><button type="button" data-card-rate="review">Cần ôn lại</button><button type="button" data-card-rate="mastered">Đã nhớ</button></div>':'')+'</div>';
			cardShell.querySelector('[data-card-prev]').addEventListener('click',function(){cardIndex--;cardFace='front';renderCard();});
			cardShell.querySelector('[data-card-next]').addEventListener('click',function(){cardIndex++;cardFace='front';renderCard();});
			cardShell.querySelector('[data-card-flip]').addEventListener('click',function(){cardFace=cardFace==='front'?'back':'front';renderCard();});
			cardShell.querySelectorAll('[data-card-rate]').forEach(function(btn){btn.addEventListener('click',function(){var rating=btn.getAttribute('data-card-rate'),now=Date.now(),sch=state.cardSchedule[c.id]||{streak:0};state.cards[c.id]=rating;if(rating==='mastered'){sch.streak=Number(sch.streak||0)+1;sch.intervalDays=REVIEW_INTERVAL_DAYS[Math.min(sch.streak-1,REVIEW_INTERVAL_DAYS.length-1)];sch.nextReview=now+sch.intervalDays*DAY_MS;}else{sch.streak=0;sch.intervalDays=0;sch.nextReview=now+6*HOUR_MS;}sch.lastRated=now;sch.status=rating;state.cardSchedule[c.id]=sch;save();cardIndex++;cardFace='front';renderCard();});});
		}
		if(cardTopic)cardTopic.addEventListener('change',function(){cardIndex=0;cardFace='front';renderCard();});
		renderCard();

		var homeQuickCard=root.querySelector('[data-home-v441-card]'),homeQuickSummary=root.querySelector('[data-home-v441-card-summary]'),homeQuickOpen=root.querySelector('[data-home-v441-open-cards]'),homeQuickFace='front',homeQuickIndex=0;
		function homeQuickPool(){var now=Date.now();return LEARNING_CARDS.slice().sort(function(a,b){var ad=state.cardSchedule[a.id]&&Number(state.cardSchedule[a.id].nextReview||0)&&Number(state.cardSchedule[a.id].nextReview)<=now?1:0,bd=state.cardSchedule[b.id]&&Number(state.cardSchedule[b.id].nextReview||0)&&Number(state.cardSchedule[b.id].nextReview)<=now?1:0;return bd-ad;});}
		function renderHomeQuickCard(){if(!homeQuickCard)return;var pool=homeQuickPool();if(!pool.length)return;homeQuickIndex=((homeQuickIndex%pool.length)+pool.length)%pool.length;var c=pool[homeQuickIndex],status=state.cards[c.id]||'',sch=state.cardSchedule[c.id]||{},due=Number(sch.nextReview||0)&&Number(sch.nextReview)<=Date.now(),mastered=Object.keys(state.cards||{}).filter(function(id){return state.cards[id]==='mastered';}).length,dueCount=LEARNING_CARDS.filter(function(x){var z=state.cardSchedule[x.id]||{};return Number(z.nextReview||0)&&Number(z.nextReview)<=Date.now();}).length;if(homeQuickSummary)homeQuickSummary.textContent=mastered+'/'+LEARNING_CARDS.length+' đã nhớ · '+dueCount+' thẻ đến hạn';homeQuickCard.innerHTML='<article class="nah-abg__v441-card '+(homeQuickFace==='back'?'is-flipped':'')+'"><div class="nah-abg__v441-card-meta"><span>'+escapeHtml(learningTopicName(c.topic))+'</span>'+(due?'<b>Đến hạn ôn</b>':status==='mastered'?'<b>Đã nhớ</b>':status==='review'?'<b>Cần ôn lại</b>':'')+'</div><div class="nah-abg__v441-card-face"><small>'+(homeQuickFace==='front'?'Câu hỏi':'Gợi nhớ')+'</small><strong>'+escapeHtml(homeQuickFace==='front'?c.front:c.back)+'</strong></div><div class="nah-abg__v441-card-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-home-v441-flip>'+(homeQuickFace==='front'?'Lật thẻ':'Xem câu hỏi')+'</button>'+(homeQuickFace==='back'?'<button type="button" class="nah-abg__button nah-abg__button--ghost" data-home-v441-rate="review">Cần ôn lại</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-home-v441-rate="mastered">Đã nhớ</button>':'')+'</div></article>';var flip=homeQuickCard.querySelector('[data-home-v441-flip]');if(flip)flip.addEventListener('click',function(){homeQuickFace=homeQuickFace==='front'?'back':'front';renderHomeQuickCard();});homeQuickCard.querySelectorAll('[data-home-v441-rate]').forEach(function(btn){btn.addEventListener('click',function(){var rating=btn.getAttribute('data-home-v441-rate'),now=Date.now(),z=state.cardSchedule[c.id]||{streak:0};state.cards[c.id]=rating;if(rating==='mastered'){z.streak=Number(z.streak||0)+1;z.intervalDays=REVIEW_INTERVAL_DAYS[Math.min(z.streak-1,REVIEW_INTERVAL_DAYS.length-1)];z.nextReview=now+z.intervalDays*DAY_MS;}else{z.streak=0;z.intervalDays=0;z.nextReview=now+6*HOUR_MS;}z.lastRated=now;z.status=rating;state.cardSchedule[c.id]=z;save();homeQuickIndex++;homeQuickFace='front';renderHomeQuickCard();renderCard();});});}
		if(homeQuickOpen)homeQuickOpen.addEventListener('click',function(){setWorkspaceTab('review');var hub=root.querySelector('[data-learning-hub="cards"]');if(hub)hub.click();});
		renderHomeQuickCard();

		var examStart=host.querySelector('[data-exam-start]'), examIntro=host.querySelector('[data-exam-intro]'), examShell=host.querySelector('[data-exam-shell]');
		var assessmentBlueprintSelect=host.querySelector('[data-assessment-blueprint]'), assessmentBlueprintSummary=host.querySelector('[data-assessment-blueprint-summary]'), assessmentTimingSelect=host.querySelector('[data-assessment-timing]');
		var generatorPanel=host.querySelector('[data-exam-generator-panel]'),generatorTotal=host.querySelector('[data-generator-total]'),generatorDomain=host.querySelector('[data-generator-domain]'),generatorDifficulty=host.querySelector('[data-generator-difficulty]'),generatorFormat=host.querySelector('[data-generator-format]'),generatorSeed=host.querySelector('[data-generator-seed]'),generatorAntiRepeat=host.querySelector('[data-generator-antirepeat]'),generatorNewSeed=host.querySelector('[data-generator-new-seed]'),generatorPreview=host.querySelector('[data-generator-preview]');
		var examQuestions=[], examIndex=0, examAnswers=[], examFlags=[], examStartedAt=0, examDeadline=0, examTimerHandle=0, examTimed=false, examTimeLimitSec=0, examFinishedReason='submitted',examGeneratorConfig=null,examSeed=0;
		function shuffled(arr){var a=arr.slice();for(var i=a.length-1;i>0;i--){var r=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[r];a[r]=t;}return a;}
		function seededShuffled(arr,seed){var a=arr.slice(),x=(Number(seed)||1)>>>0;function rnd(){x=(x*1664525+1013904223)>>>0;return x/4294967296;}for(var i=a.length-1;i>0;i--){var r=Math.floor(rnd()*(i+1)),t=a[i];a[i]=a[r];a[r]=t;}return a;}
		function mockPool(filter,seed){return seededShuffled(ASSESSMENT_BANK.filter(filter),seed);}
		function takeMock(pool,count,used,out){for(var i=0;i<pool.length&&count>0;i++){var q=pool[i];if(used[q.id])continue;used[q.id]=true;out.push(q);count--;}return count;}
		function buildMockExam(key,bp){var used={},out=[],seed=Number(bp.seed||54000),topics=['foundation','acidbase','oxygen','clinical'],levels=['basic','intermediate','advanced'];if(bp.topic){levels.forEach(function(level,li){takeMock(mockPool(function(q){return q.topic===bp.topic&&q.difficulty===level;},seed+li),Number((bp.difficultyPlan||{})[level]||0),used,out);});}else if(bp.caseOnly){levels.forEach(function(level,li){takeMock(mockPool(function(q){return q.case_linked&&q.difficulty===level;},seed+li),Number((bp.difficultyPlan||{})[level]||0),used,out);});}else if(bp.difficulty){topics.forEach(function(topic,ti){takeMock(mockPool(function(q){return q.topic===topic&&q.difficulty===bp.difficulty;},seed+ti),Number((bp.topicPlan||{})[topic]||0),used,out);});}else if(bp.mixedComprehensive){var sbaPlan={foundation:2,acidbase:3,oxygen:3,clinical:2};topics.forEach(function(topic,ti){takeMock(mockPool(function(q){return q.topic===topic&&q.item_format!=='single_best_answer';},seed+ti*31),5,used,out);takeMock(mockPool(function(q){return q.topic===topic&&q.item_format==='single_best_answer';},seed+ti*31+11),Number(sbaPlan[topic]||0),used,out);});}else if(bp.comprehensive){var plan={foundation:{basic:2,intermediate:3,advanced:2},acidbase:{basic:2,intermediate:3,advanced:3},oxygen:{basic:2,intermediate:3,advanced:3},clinical:{basic:2,intermediate:3,advanced:2}};topics.forEach(function(topic,ti){levels.forEach(function(level,li){takeMock(mockPool(function(q){return q.topic===topic&&q.difficulty===level;},seed+ti*10+li),Number(plan[topic][level]||0),used,out);});});}if(out.length<Number(bp.total||30))takeMock(mockPool(function(){return true;},seed+999),Number(bp.total||30)-out.length,used,out);return seededShuffled(out.slice(0,Number(bp.total||30)),seed+5000).map(prepareAssessmentItem);}
		function difficultyName(level){return level==='basic'?'Cơ bản':level==='advanced'?'Nâng cao':'Trung bình';}
		function prepareAssessmentItem(q,seed){
			var item=Object.assign({},q),f=item.item_format||'single_best_answer',seedBase=Number(seed)||0;
			function itemShuffle(arr,offset){return seedBase?seededShuffled(arr,seedBase+Number(offset||0)):shuffled(arr);}
			if(f==='single_best_answer'){
				var pairs=(q.o||[]).map(function(text,index){return {text:text,correct:index===q.a};});pairs=itemShuffle(pairs,11);item.o=pairs.map(function(x){return x.text;});item.a=pairs.findIndex(function(x){return x.correct;});
			}else if(f==='multiple_response'){
				var good={};(q.correct_answers||[]).forEach(function(i){good[Number(i)]=true;});var mp=itemShuffle((q.o||[]).map(function(text,index){return {text:text,correct:!!good[index]};}),23);item.o=mp.map(function(x){return x.text;});item.correct_answers=mp.map(function(x,i){return x.correct?i:null;}).filter(function(x){return x!==null;});
			}else if(f==='matching'){
				var right=itemShuffle((q.match_options||[]).map(function(text,index){return {text:text,original:index};}),37);var remap={};right.forEach(function(x,i){remap[x.original]=i;});item.match_options=right.map(function(x){return x.text;});item.correct_matches=(q.correct_matches||[]).map(function(old){return remap[Number(old)];});item.match_left=(q.match_left||[]).slice();
			}else if(f==='structured_case_interpretation'){
				item.structured_fields=(q.structured_fields||[]).map(function(field,fieldIndex){var opts=itemShuffle((field.options||[]).map(function(text,index){return {text:text,correct:index===field.correct};}),51+fieldIndex*17);return Object.assign({},field,{options:opts.map(function(x){return x.text;}),correct:opts.findIndex(function(x){return x.correct;})});});
			}else if(f==='ordering'){item.o=(q.o||[]).slice();item.correct_order=(q.correct_order||[]).slice();}
			return item;
		}
		function selectAssessmentItems(topic,difficulty,count,used,caseOnly,itemFormat){
			var pool=shuffled(ASSESSMENT_BANK.filter(function(q){return q.topic===topic&&q.difficulty===difficulty&&!used[q.id]&&(!caseOnly||q.case_linked)&&(!itemFormat||q.item_format===itemFormat);})),out=[];
			pool.slice(0,count).forEach(function(q){used[q.id]=true;out.push(q);});return out;
		}
		function selectMixedItem(topic,format,used){
			var pool=shuffled(ASSESSMENT_BANK.filter(function(q){return q.topic===topic&&q.item_format===format&&!used[q.id];}));if(!pool.length)return null;used[pool[0].id]=true;return pool[0];
		}
		function normalizeGeneratorSeed(value){var text=String(value===undefined||value===null?'':value).trim();if(!text)return 0;if(/^\d+$/.test(text))return (Number(text)||1)>>>0;var h=2166136261;for(var i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0)||1;}
		function newGeneratorSeed(){return ((Date.now()^Math.floor(Math.random()*0x7fffffff))>>>0)||55001;}
		function allocatePlan(weights,total,keys){var raw={},out={},used=0;keys.forEach(function(k){raw[k]=Number(weights[k]||0)*total;out[k]=Math.floor(raw[k]);used+=out[k];});keys.slice().sort(function(a,b){return (raw[b]-Math.floor(raw[b]))-(raw[a]-Math.floor(raw[a]));}).forEach(function(k){if(used<total){out[k]++;used++;}});return out;}
		function expandPlan(plan,keys){var out=[];keys.forEach(function(k){for(var i=0;i<Number(plan[k]||0);i++)out.push(k);});return out;}
		function generatorConfig(ensureSeed){var total=Math.max(20,Math.min(40,Number(generatorTotal?generatorTotal.value:30)||30)),domain=(generatorDomain?generatorDomain.value:'balanced'),difficulty=(generatorDifficulty?generatorDifficulty.value:'balanced'),format=(generatorFormat?generatorFormat.value:'mixed'),seed=normalizeGeneratorSeed(generatorSeed?generatorSeed.value:'');if(ensureSeed&&!seed){seed=newGeneratorSeed();if(generatorSeed)generatorSeed.value=String(seed);}return {total:total,domain:domain,difficulty:difficulty,format:format,seed:seed,antiRepeat:!!(generatorAntiRepeat&&generatorAntiRepeat.checked)};}
		function generatorWeights(config){var topics=['foundation','acidbase','oxygen','clinical'],levels=['basic','intermediate','advanced'],formats=['single_best_answer'].concat(ASSESSMENT_MIXED_FORMATS),dw={foundation:.25,acidbase:.25,oxygen:.25,clinical:.25},lw={basic:.25,intermediate:.45,advanced:.30},fw={single_best_answer:1};if(config.domain!=='balanced'){dw={foundation:.15,acidbase:.15,oxygen:.15,clinical:.15};dw[config.domain]=.55;}if(config.difficulty==='foundation')lw={basic:.45,intermediate:.40,advanced:.15};else if(config.difficulty==='advanced')lw={basic:.10,intermediate:.35,advanced:.55};if(config.format==='mixed'){fw={single_best_answer:.55,multiple_response:.09,ordering:.09,matching:.09,numeric_calculation:.09,structured_case_interpretation:.09};}else if(config.format==='mixed_heavy'){fw={single_best_answer:.30,multiple_response:.14,ordering:.14,matching:.14,numeric_calculation:.14,structured_case_interpretation:.14};}return {topics:topics,levels:levels,formats:formats,domains:allocatePlan(dw,config.total,topics),difficulties:allocatePlan(lw,config.total,levels),itemFormats:allocatePlan(fw,config.total,Object.keys(fw))};}
		function recentGeneratorItemIds(){var ids={};((state.assessment&&state.assessment.history)||[]).filter(function(h){return h&&h.blueprint==='generator'&&Array.isArray(h.itemIds);}).slice(0,3).forEach(function(h){h.itemIds.forEach(function(id){ids[id]=true;});});return ids;}
		function buildGeneratedExam(config){var plan=generatorWeights(config),seed=config.seed||newGeneratorSeed(),used={},recent=config.antiRepeat?recentGeneratorItemIds():{},domainSlots=seededShuffled(expandPlan(plan.domains,plan.topics),seed+101),difficultySlots=seededShuffled(expandPlan(plan.difficulties,plan.levels),seed+211),formatKeys=Object.keys(plan.itemFormats),formatSlots=seededShuffled(expandPlan(plan.itemFormats,formatKeys),seed+307),pool=seededShuffled(ASSESSMENT_BANK.slice(),seed+401),out=[];
			function pick(filter,avoidRecent){for(var i=0;i<pool.length;i++){var q=pool[i];if(used[q.id]||(avoidRecent&&recent[q.id]))continue;if(filter(q)){used[q.id]=true;return q;}}return null;}
			for(var n=0;n<config.total;n++){var d=domainSlots[n],lv=difficultySlots[n],fmt=formatSlots[n],q=null,avoid=config.antiRepeat;q=pick(function(x){return x.topic===d&&x.difficulty===lv&&x.item_format===fmt;},avoid)||pick(function(x){return x.topic===d&&x.item_format===fmt;},avoid)||pick(function(x){return x.difficulty===lv&&x.item_format===fmt;},avoid)||pick(function(x){return x.item_format===fmt;},avoid)||pick(function(x){return x.topic===d&&x.difficulty===lv&&formatKeys.indexOf(x.item_format)>=0;},avoid)||pick(function(x){return formatKeys.indexOf(x.item_format)>=0;},avoid);if(!q&&avoid){q=pick(function(x){return x.topic===d&&x.difficulty===lv&&x.item_format===fmt;},false)||pick(function(x){return x.item_format===fmt;},false)||pick(function(x){return formatKeys.indexOf(x.item_format)>=0;},false);}if(q)out.push(q);}
			return seededShuffled(out,seed+509).slice(0,config.total).map(function(q,i){return prepareAssessmentItem(q,seed+1000+i*97);});
		}
		function generatorPlanText(config){var plan=generatorWeights(config),domainText=plan.topics.map(function(k){return learningTopicName(k)+' '+plan.domains[k];}).join(' · '),difficultyText=plan.levels.map(function(k){return difficultyName(k)+' '+plan.difficulties[k];}).join(' · '),formatText=Object.keys(plan.itemFormats).map(function(k){return assessmentFormatName(k)+' '+plan.itemFormats[k];}).join(' · ');return {domain:domainText,difficulty:difficultyText,format:formatText};}
		function renderGeneratorPreview(){if(!generatorPanel)return;var isGenerator=!!(assessmentBlueprintSelect&&assessmentBlueprintSelect.value==='generator');generatorPanel.hidden=!isGenerator;if(!isGenerator)return;var c=generatorConfig(false),txt=generatorPlanText(c);if(generatorPreview)generatorPreview.innerHTML='<span><b>Miền</b> '+escapeHtml(txt.domain)+'</span><span><b>Độ khó</b> '+escapeHtml(txt.difficulty)+'</span><span><b>Dạng câu</b> '+escapeHtml(txt.format)+'</span><span><b>Mã đề</b> '+escapeHtml(c.seed?String(c.seed):'Tự tạo khi bắt đầu')+(c.antiRepeat?' · chống lặp bật':'')+'</span>';}
		function buildExam(blueprintKey){
			var blueprint=ASSESSMENT_BLUEPRINTS[blueprintKey]||ASSESSMENT_BLUEPRINTS.standard, topics=['foundation','acidbase','oxygen','clinical'], levels=['basic','intermediate','advanced'], used={},out=[];
			if(blueprint.generator){examGeneratorConfig=generatorConfig(true);examSeed=examGeneratorConfig.seed;return buildGeneratedExam(examGeneratorConfig);}
			if(blueprint.mockPack)return buildMockExam(blueprintKey,blueprint);
			if(blueprint.mixedOnly){topics.forEach(function(topic){(blueprint.formats||ASSESSMENT_MIXED_FORMATS).forEach(function(format){var q=selectMixedItem(topic,format,used);if(q)out.push(q);});});return shuffled(out).map(prepareAssessmentItem);}
			topics.forEach(function(topic){levels.forEach(function(level){out=out.concat(selectAssessmentItems(topic,level,Number(blueprint.perTopic[level]||0),used,!!blueprint.caseOnly,blueprint.itemFormat||'single_best_answer'));});});
			return shuffled(out).map(prepareAssessmentItem);
		}
		function renderBlueprintSummary(){
			if(!assessmentBlueprintSummary)return;var key=assessmentBlueprintSelect?assessmentBlueprintSelect.value:'standard',bp=ASSESSMENT_BLUEPRINTS[key]||ASSESSMENT_BLUEPRINTS.standard,timed=assessmentTimingSelect?assessmentTimingSelect.value==='timed':true,total;if(bp.generator){var c=generatorConfig(false);total=c.total;renderGeneratorPreview();assessmentBlueprintSummary.innerHTML='<strong>'+escapeHtml(bp.label)+'</strong><span>'+escapeHtml(bp.description)+'</span><small>'+total+' câu · '+(timed?('bấm giờ khoảng '+Math.round(total*1.5)+' phút'):'không bấm giờ')+' · mã đề '+escapeHtml(c.seed?String(c.seed):'tự tạo')+(c.antiRepeat?' · chống lặp gần đây':'')+'</small>';return;}total=bp.mockPack?Number(bp.total||30):(bp.mixedOnly?4*(bp.formats||ASSESSMENT_MIXED_FORMATS).length:4*(bp.perTopic.basic+bp.perTopic.intermediate+bp.perTopic.advanced));renderGeneratorPreview();assessmentBlueprintSummary.innerHTML='<strong>'+escapeHtml(bp.label)+'</strong><span>'+escapeHtml(bp.description)+'</span><small>'+total+' câu'+(bp.mockPack?' · bộ đề cố định theo mã đề · '+(timed?('bấm giờ '+Number(bp.minutes||45)+' phút'):'không bấm giờ'):(bp.mixedOnly?' · chia đều 4 miền · 5 dạng/cụm miền':' · chia đều 4 miền kiến thức'))+'</small>';
		}
		if(assessmentBlueprintSelect)assessmentBlueprintSelect.addEventListener('change',function(){var bp=ASSESSMENT_BLUEPRINTS[assessmentBlueprintSelect.value]||ASSESSMENT_BLUEPRINTS.standard;if(assessmentTimingSelect&&assessmentTimingSelect.dataset.userTiming!=='1')assessmentTimingSelect.value=(bp.mockPack||bp.generator)?'timed':'untimed';renderBlueprintSummary();});if(assessmentTimingSelect)assessmentTimingSelect.addEventListener('change',function(){assessmentTimingSelect.dataset.userTiming='1';renderBlueprintSummary();});[generatorTotal,generatorDomain,generatorDifficulty,generatorFormat,generatorSeed,generatorAntiRepeat].forEach(function(el){if(el)el.addEventListener('change',renderBlueprintSummary);});if(generatorSeed)generatorSeed.addEventListener('input',renderBlueprintSummary);if(generatorNewSeed)generatorNewSeed.addEventListener('click',function(){if(generatorSeed)generatorSeed.value=String(newGeneratorSeed());renderBlueprintSummary();});
		try{var initialParams=(new URL(window.location.href)).searchParams;if(initialParams.get('blueprint')==='generator'&&assessmentBlueprintSelect){assessmentBlueprintSelect.value='generator';if(generatorSeed&&initialParams.get('seed'))generatorSeed.value=initialParams.get('seed');if(assessmentTimingSelect)assessmentTimingSelect.value='timed';}}catch(error){}
		renderBlueprintSummary();
		function stopExamTimer(){if(examTimerHandle){window.clearInterval(examTimerHandle);examTimerHandle=0;}}
		function examElapsedSec(){return examStartedAt?Math.max(0,Math.floor((Date.now()-examStartedAt)/1000)):0;}
		function examRemainingSec(){return examTimed&&examDeadline?Math.max(0,Math.ceil((examDeadline-Date.now())/1000)):0;}
		function formatExamClock(sec){sec=Math.max(0,Number(sec)||0);var m=Math.floor(sec/60),ss=Math.floor(sec%60);return String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0');}
		function updateExamTimer(){var el=examShell?examShell.querySelector('[data-exam-timer]'):null;if(el)el.textContent=examTimed?formatExamClock(examRemainingSec()):('Đã làm '+formatExamClock(examElapsedSec()));if(examTimed&&examDeadline&&Date.now()>=examDeadline){stopExamTimer();examFinishedReason='timeout';finishExam();}}
		function startExamTimer(){stopExamTimer();examStartedAt=Date.now();examDeadline=examTimed?(examStartedAt+examTimeLimitSec*1000):0;examTimerHandle=window.setInterval(updateExamTimer,1000);}
		function answeredExamCount(){return examQuestions.reduce(function(n,q,i){return n+(assessmentAnswerComplete(q,examAnswers[i])?1:0);},0);}
		function renderExamNavigator(){
			return '<div class="nah-abg__assessment-nav" aria-label="Điều hướng câu hỏi">'+examQuestions.map(function(q,i){var cls=(i===examIndex?' is-current':'')+(assessmentAnswerComplete(q,examAnswers[i])?' is-answered':'')+(examFlags[i]?' is-flagged':'');return '<button type="button" class="'+cls.trim()+'" data-exam-jump="'+i+'" aria-label="Câu '+(i+1)+'">'+(i+1)+'</button>';}).join('')+'</div>';
		}
		function formatInstruction(q){var f=q.item_format||'single_best_answer';return {single_best_answer:'Chọn một đáp án tốt nhất.',multiple_response:'Chọn tất cả phương án đúng. Câu chỉ được tính đúng khi chọn đúng toàn bộ tập đáp án.',ordering:'Gán vị trí cho từng bước. Mỗi vị trí chỉ dùng một lần.',matching:'Ghép mỗi mục bên trái với một lựa chọn phù hợp bên phải.',numeric_calculation:'Nhập kết quả số; có chấp nhận sai số làm tròn đã định nghĩa cho câu này.',structured_case_interpretation:'Hoàn tất tất cả trường diễn giải. Câu chỉ được tính đúng khi toàn bộ trường chính xác.'}[f]||'';}
		function renderAssessmentInput(q,answer){
			var f=q.item_format||'single_best_answer';
			if(f==='single_best_answer')return '<div class="nah-abg__answer-list">'+(q.o||[]).map(function(o,i){var checked=Number(answer)===i?' checked':'';return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-exam-'+examIndex+'" value="'+i+'"'+checked+'><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('')+'</div>';
			if(f==='multiple_response'){
				var selected=Array.isArray(answer)?answer.map(Number):[];return '<div class="nah-abg__answer-list nah-abg__mixed-checklist">'+(q.o||[]).map(function(o,i){return '<label class="nah-abg__answer-option"><input type="checkbox" data-exam-multi="'+i+'"'+(selected.indexOf(i)>=0?' checked':'')+'><span class="nah-abg__answer-option-text">'+escapeHtml(o)+'</span></label>';}).join('')+'</div>';
			}
			if(f==='ordering'){
				var ranks=Array.isArray(answer)?answer:[];return '<div class="nah-abg__mixed-ordering">'+(q.o||[]).map(function(o,i){var raw=ranks[i],value=raw!==null&&raw!==undefined&&raw!==''&&Number.isInteger(Number(raw))?Number(raw):'';return '<label><span>'+escapeHtml(o)+'</span><select data-exam-order="'+i+'"><option value="">— Vị trí —</option>'+(q.o||[]).map(function(_,r){return '<option value="'+r+'"'+(value===r?' selected':'')+'>'+(r+1)+'</option>';}).join('')+'</select></label>';}).join('')+'</div>';
			}
			if(f==='matching'){
				var matches=Array.isArray(answer)?answer:[];return '<div class="nah-abg__mixed-matching">'+(q.match_left||[]).map(function(left,i){var raw=matches[i],value=raw!==null&&raw!==undefined&&raw!==''&&Number.isInteger(Number(raw))?Number(raw):'';return '<label><span>'+escapeHtml(left)+'</span><select data-exam-match="'+i+'"><option value="">— Chọn ghép cặp —</option>'+(q.match_options||[]).map(function(right,r){return '<option value="'+r+'"'+(value===r?' selected':'')+'>'+escapeHtml(right)+'</option>';}).join('')+'</select></label>';}).join('')+'</div>';
			}
			if(f==='numeric_calculation'){
				return '<label class="nah-abg__mixed-numeric"><span>Kết quả'+(q.unit?' ('+escapeHtml(q.unit)+')':'')+'</span><input type="text" inputmode="decimal" autocomplete="off" data-exam-numeric value="'+(answer===null||answer===undefined?'':escapeHtml(String(answer)))+'" placeholder="Nhập giá trị số"><small>Sai số chấp nhận: ±'+escapeHtml(String(q.tolerance||0))+(q.unit?' '+escapeHtml(q.unit):'')+'</small></label>';
			}
			if(f==='structured_case_interpretation'){
				var obj=answer&&typeof answer==='object'?answer:{};return '<div class="nah-abg__mixed-structured">'+(q.structured_fields||[]).map(function(field,fi){return '<fieldset><legend>'+escapeHtml(field.label)+'</legend>'+(field.options||[]).map(function(opt,oi){return '<label class="nah-abg__answer-option"><input type="radio" name="'+escapeHtml(root.id)+'-exam-'+examIndex+'-'+fi+'" data-exam-structured="'+escapeHtml(field.id)+'" value="'+oi+'"'+(Number(obj[field.id])===oi?' checked':'')+'><span class="nah-abg__answer-option-text">'+escapeHtml(opt)+'</span></label>';}).join('')+'</fieldset>';}).join('')+'</div>';
			}
			return '';
		}
		function bindAssessmentInputs(q){
			var f=q.item_format||'single_best_answer';
			if(f==='single_best_answer')examShell.querySelectorAll('.nah-abg__assessment-question input[type="radio"]').forEach(function(input){input.addEventListener('change',function(){examAnswers[examIndex]=Number(input.value);renderExamQuestion();});});
			else if(f==='multiple_response')examShell.querySelectorAll('[data-exam-multi]').forEach(function(input){input.addEventListener('change',function(){var selected=[];examShell.querySelectorAll('[data-exam-multi]:checked').forEach(function(x){selected.push(Number(x.getAttribute('data-exam-multi')));});examAnswers[examIndex]=selected.sort(function(a,b){return a-b;});renderExamQuestion();});});
			else if(f==='ordering')examShell.querySelectorAll('[data-exam-order]').forEach(function(select){select.addEventListener('change',function(){var answer=new Array((q.o||[]).length).fill(null);examShell.querySelectorAll('[data-exam-order]').forEach(function(x){var i=Number(x.getAttribute('data-exam-order'));answer[i]=x.value===''?null:Number(x.value);});examAnswers[examIndex]=answer;renderExamQuestion();});});
			else if(f==='matching')examShell.querySelectorAll('[data-exam-match]').forEach(function(select){select.addEventListener('change',function(){var answer=new Array((q.match_left||[]).length).fill(null);examShell.querySelectorAll('[data-exam-match]').forEach(function(x){var i=Number(x.getAttribute('data-exam-match'));answer[i]=x.value===''?null:Number(x.value);});examAnswers[examIndex]=answer;renderExamQuestion();});});
			else if(f==='numeric_calculation'){var input=examShell.querySelector('[data-exam-numeric]');if(input){input.addEventListener('change',function(){examAnswers[examIndex]=input.value.trim();renderExamQuestion();});input.addEventListener('keydown',function(event){if(event.key==='Enter'){event.preventDefault();input.blur();}});}}
			else if(f==='structured_case_interpretation')examShell.querySelectorAll('[data-exam-structured]').forEach(function(input){input.addEventListener('change',function(){var obj=examAnswers[examIndex]&&typeof examAnswers[examIndex]==='object'?Object.assign({},examAnswers[examIndex]):{};obj[input.getAttribute('data-exam-structured')]=Number(input.value);examAnswers[examIndex]=obj;renderExamQuestion();});});
		}
		function renderExamQuestion(){
			if(!examShell)return;var q=examQuestions[examIndex];if(!q){return;}
			var caseText=q.case_vignette||'';var caseBlock=(q.case_linked||((q.item_format==='structured_case_interpretation')&&caseText))?'<aside class="nah-abg__case-context"><div><span>CA LÂM SÀNG</span><b>'+escapeHtml(q.case_title||q.case_id||'Diễn giải có cấu trúc')+'</b>'+(q.case_linked?'<em>Bước '+Number(q.case_sequence||1)+'/3'+(q.serial_abg?' · Khí máu nối tiếp':'')+'</em>':'')+'</div><p>'+escapeHtml(caseText)+'</p></aside>':'';
			examShell.innerHTML='<section class="nah-abg__assessment-shell"><div class="nah-abg__assessment-topline"><div><strong>Câu '+(examIndex+1)+' / '+examQuestions.length+'</strong><span>'+answeredExamCount()+' đã trả lời</span><span class="nah-abg__exam-clock" data-exam-timer>'+escapeHtml(examTimed?formatExamClock(examRemainingSec()):('Đã làm '+formatExamClock(examElapsedSec())))+'</span></div><div><span>'+escapeHtml(learningTopicName(q.topic))+'</span><b>'+escapeHtml(difficultyName(q.difficulty))+'</b><i class="nah-abg__format-chip">'+escapeHtml(assessmentFormatName(q.item_format))+'</i></div></div>'+renderExamNavigator()+'<div class="nah-abg__question-card nah-abg__assessment-question">'+caseBlock+'<h4>'+escapeHtml(q.q)+'</h4><p class="nah-abg__format-instruction">'+escapeHtml(formatInstruction(q))+'</p>'+renderAssessmentInput(q,examAnswers[examIndex])+'<label class="nah-abg__assessment-flag"><input type="checkbox" data-exam-flag'+(examFlags[examIndex]?' checked':'')+'><span>Đánh dấu câu này để xem lại trước khi nộp</span></label><div class="nah-abg__assessment-actions"><button type="button" class="nah-abg__button nah-abg__button--ghost" data-exam-prev'+(examIndex===0?' disabled':'')+'>← Câu trước</button><div><button type="button" class="nah-abg__button nah-abg__button--ghost" data-exam-submit-now>Nộp bài</button><button type="button" class="nah-abg__button nah-abg__button--primary" data-exam-next>'+(examIndex===examQuestions.length-1?'Nộp bài':'Câu tiếp theo →')+'</button></div></div><div class="nah-abg__answer-feedback" data-exam-warning hidden></div></div><p class="nah-abg__assessment-no-feedback">Đáp án và giải thích chỉ xuất hiện sau khi nộp bài.</p></section>';
			bindAssessmentInputs(q);
			var flag=examShell.querySelector('[data-exam-flag]');if(flag)flag.addEventListener('change',function(){examFlags[examIndex]=flag.checked;renderExamQuestion();});
			examShell.querySelectorAll('[data-exam-jump]').forEach(function(btn){btn.addEventListener('click',function(){examIndex=Number(btn.getAttribute('data-exam-jump'));renderExamQuestion();});});
			var prev=examShell.querySelector('[data-exam-prev]');if(prev)prev.addEventListener('click',function(){if(examIndex>0){examIndex--;renderExamQuestion();}});
			examShell.querySelector('[data-exam-next]').addEventListener('click',function(){if(examIndex<examQuestions.length-1){examIndex++;renderExamQuestion();return;}submitExam();});var submitNow=examShell.querySelector('[data-exam-submit-now]');if(submitNow)submitNow.addEventListener('click',submitExam);updateExamTimer();
		}
		function resultByGroup(field){
			var out={};examQuestions.forEach(function(q,i){var key=q[field],row=out[key]||(out[key]={correct:0,total:0});row.total++;if(assessmentItemCorrect(q,examAnswers[i]))row.correct++;});return out;
		}
		function renderResultRows(groups,type){
			return Object.keys(groups).map(function(key){var r=groups[key],pct=Math.round(r.correct/r.total*100),label=type==='topic'?learningTopicName(key):type==='difficulty'?difficultyName(key):assessmentFormatName(key);return '<div class="nah-abg__assessment-result-row"><div><strong>'+escapeHtml(label)+'</strong><span>'+r.correct+'/'+r.total+' câu đúng</span></div><div class="nah-abg__progress-bar"><span style="width:'+pct+'%"></span></div><b>'+pct+'%</b></div>';}).join('');
		}
		function assessmentAnswerText(q,answer,correct){
			var f=q.item_format||'single_best_answer';
			if(f==='single_best_answer'){var idx=correct?Number(q.a):Number(answer);return Number.isInteger(idx)&&q.o[idx]!==undefined?q.o[idx]:'Chưa trả lời';}
			if(f==='multiple_response'){var arr=correct?(q.correct_answers||[]):(Array.isArray(answer)?answer:[]);return arr.map(function(i){return q.o[Number(i)];}).filter(Boolean).join(' · ')||'Chưa trả lời';}
			if(f==='ordering'){var seq=correct?(q.correct_order||[]):assessmentOrderingSequence(answer);return seq.map(function(i,n){return (n+1)+'. '+q.o[Number(i)];}).filter(Boolean).join(' → ')||'Chưa hoàn tất';}
			if(f==='matching'){var arr=correct?(q.correct_matches||[]):answer;if(!Array.isArray(arr))return 'Chưa hoàn tất';return (q.match_left||[]).map(function(left,i){var right=q.match_options[Number(arr[i])];return left+' → '+(right||'—');}).join(' · ');}
			if(f==='numeric_calculation'){return correct?String(q.answer_value)+(q.unit?' '+q.unit:''):(answer===null||answer===undefined||answer===''?'Chưa trả lời':String(answer)+(q.unit?' '+q.unit:''));}
			if(f==='structured_case_interpretation'){var obj=answer&&typeof answer==='object'?answer:{};return (q.structured_fields||[]).map(function(field){var idx=correct?field.correct:obj[field.id];return field.label+': '+((field.options||[])[Number(idx)]||'—');}).join(' · ');}
			return '';
		}
		function submitExam(){
			var unanswered=examQuestions.length-answeredExamCount();if(unanswered&&!window.confirm('Còn '+unanswered+' câu chưa trả lời hoặc chưa hoàn tất. Vẫn nộp bài?'))return;examFinishedReason='submitted';finishExam();
		}
		function finishExam(){
			stopExamTimer();var correct=0,review=[],examErrorPatterns={},topics=resultByGroup('topic'),difficulties=resultByGroup('difficulty'),formats=resultByGroup('item_format'),elapsed=examElapsedSec(),unanswered=examQuestions.length-answeredExamCount();
			examQuestions.forEach(function(q,i){var ok=assessmentItemCorrect(q,examAnswers[i]);if(ok)correct++;if(q.adaptive)recordQuestionResult(q,ok,'exam');else recordRemediationResult(q,ok,'exam');if(!ok){var ep=remediationPatternForQuestion(q);examErrorPatterns[ep]=Number(examErrorPatterns[ep]||0)+1;}if(!ok)review.push('<article><div><span>'+escapeHtml(learningTopicName(q.topic))+' · '+escapeHtml(q.lesson.replace(/^hb-/,''))+'</span><b>'+escapeHtml(difficultyName(q.difficulty))+' · '+escapeHtml(assessmentFormatName(q.item_format))+'</b></div>'+(q.case_linked?'<small class="nah-abg__case-review-label">'+escapeHtml(q.case_title||q.case_id)+' · Bước '+Number(q.case_sequence||1)+'/3</small>':'')+'<strong>'+escapeHtml(q.q)+'</strong><p><em>Đáp án đã chọn:</em> '+escapeHtml(assessmentAnswerText(q,examAnswers[i],false))+'</p><p><em>Đáp án đúng:</em> '+escapeHtml(assessmentAnswerText(q,null,true))+'</p><p>'+escapeHtml(q.e)+'</p></article>');});
			var score=Math.round(correct/examQuestions.length*100),blueprintKey=assessmentBlueprintSelect?assessmentBlueprintSelect.value:'standard',weak=Object.keys(topics).map(function(k){return {topic:k,pct:Math.round(topics[k].correct/topics[k].total*100)};}).sort(function(a,b){return a.pct-b.pct;});
			state.assessment.count=Number(state.assessment.count||0)+1;state.assessment.last=score;state.assessment.best=Math.max(Number(state.assessment.best||0),score);state.assessment.total=examQuestions.length;state.assessment.lastBlueprint=blueprintKey;state.assessment.history.unshift({at:Date.now(),blueprint:blueprintKey,score:score,correct:correct,total:examQuestions.length,topics:topics,difficulties:difficulties,formats:formats,timed:examTimed,timeLimitSec:examTimeLimitSec,elapsedSec:elapsed,finishedReason:examFinishedReason,unanswered:unanswered,errorPatterns:examErrorPatterns,seed:blueprintKey==='generator'?examSeed:undefined,generatorConfig:blueprintKey==='generator'?examGeneratorConfig:undefined,itemIds:examQuestions.map(function(q){return q.id;})});state.assessment.history=state.assessment.history.slice(0,10);
			state.exam.count=Number(state.exam.count||0)+1;state.exam.last=score;state.exam.best=Math.max(Number(state.exam.best||0),score);state.exam.total=examQuestions.length;save();
			var bp=ASSESSMENT_BLUEPRINTS[blueprintKey]||ASSESSMENT_BLUEPRINTS.standard,showFormats=blueprintKey==='mixed'||bp.mockPack||bp.generator,formatSection=showFormats?'<section><h5>Kết quả theo dạng câu hỏi</h5>'+renderResultRows(formats,'format')+'</section>':'',simulationMeta=(bp.mockPack||bp.generator)?'<div class="nah-abg__mock-result-meta"><span>'+escapeHtml(bp.label)+'</span>'+(bp.generator?'<span>Mã đề '+escapeHtml(String(examSeed||''))+'</span>':'')+'<span>'+(examTimed?'Bấm giờ':'Không bấm giờ')+'</span><span>Thời gian '+escapeHtml(formatExamClock(elapsed))+'</span>'+(examFinishedReason==='timeout'?'<span>Hết giờ · tự nộp</span>':'')+(unanswered?'<span>'+unanswered+' câu chưa hoàn tất</span>':'')+'</div>':'';
			examShell.innerHTML='<div class="nah-abg__exam-result nah-abg__assessment-result"><div class="nah-abg__exam-score"><strong>'+score+'%</strong><span>'+correct+'/'+examQuestions.length+' câu đúng</span></div><h4>'+(score>=85?'Kết quả vững':score>=70?'Đạt nền tảng khá, còn điểm cần củng cố':'Nên ôn lại các miền kiến thức còn yếu')+'</h4><p>Đây là kết quả tự đánh giá phục vụ học tập, không phải chứng nhận năng lực chuyên môn.</p>'+simulationMeta+'<div class="nah-abg__assessment-result-grid '+(formatSection?'nah-abg__assessment-result-grid--mixed':'')+'"><section><h5>Kết quả theo miền kiến thức</h5>'+renderResultRows(topics,'topic')+'</section><section><h5>Kết quả theo độ khó</h5>'+renderResultRows(difficulties,'difficulty')+'</section>'+formatSection+'</div><div class="nah-abg__assessment-priority"><strong>Ưu tiên ôn lại</strong><span>'+escapeHtml(learningTopicName(weak[0].topic))+' · '+weak[0].pct+'%</span>'+(weak[1]&&weak[1].pct<80?'<span>'+escapeHtml(learningTopicName(weak[1].topic))+' · '+weak[1].pct+'%</span>':'')+'</div>'+remediationInlineHtml()+(review.length?'<details open class="nah-abg__assessment-errors"><summary>Phân tích '+review.length+' câu trả lời sai</summary><div>'+review.join('')+'</div></details>':'<div class="nah-abg__answer-feedback is-correct"><strong>Hoàn thành toàn bộ câu hỏi chính xác</strong><p>Không có câu trả lời sai trong lượt đánh giá này.</p></div>')+'<div class="nah-abg__assessment-result-actions"><button type="button" class="nah-abg__button nah-abg__button--primary" data-exam-restart>Làm đề khác</button><button type="button" class="nah-abg__button nah-abg__button--ghost" data-exam-adaptive>Ôn theo kết quả vừa làm</button></div></div>';
			var restart=examShell.querySelector('[data-exam-restart]');if(restart)restart.addEventListener('click',function(){examShell.innerHTML='';if(examIntro)examIntro.hidden=false;renderBlueprintSummary();});
			var remediationBtn=examShell.querySelector('[data-exam-remediation]');if(remediationBtn)remediationBtn.addEventListener('click',function(){setTab('remediation');});var adaptiveBtn=examShell.querySelector('[data-exam-adaptive]');if(adaptiveBtn)adaptiveBtn.addEventListener('click',startAdaptiveSession);
		}
		function setExamStartBusy(busy){if(!examStart)return;examStart.disabled=!!busy;examStart.setAttribute('aria-busy',busy?'true':'false');examStart.textContent=busy?'Đang tạo đề…':'Bắt đầu';}
		function startExamUnlocked(){
			try {
				var key=assessmentBlueprintSelect?assessmentBlueprintSelect.value:'standard',bp=ASSESSMENT_BLUEPRINTS[key]||ASSESSMENT_BLUEPRINTS.standard;examGeneratorConfig=null;examSeed=0;examQuestions=buildExam(key);
				if(!examQuestions.length){setExamStartBusy(false);if(assessmentBlueprintSummary)assessmentBlueprintSummary.innerHTML='<strong>Chưa thể tạo đề</strong><span>Vui lòng đổi lựa chọn cấu trúc đề rồi thử lại.</span>';return false;}
				examIndex=0;examAnswers=new Array(examQuestions.length).fill(null);examFlags=new Array(examQuestions.length).fill(false);examTimed=!!(assessmentTimingSelect&&assessmentTimingSelect.value==='timed');var minutes=bp.generator?Math.max(30,Math.round(examQuestions.length*1.5)):Number(bp.minutes||45);examTimeLimitSec=examTimed?Number(minutes*60):0;examFinishedReason='submitted';setExamStartBusy(false);if(examIntro)examIntro.hidden=true;startExamTimer();renderExamQuestion();return true;
			} catch(error) {
				stopExamTimer();examQuestions=[];examIndex=0;
				if(examShell)examShell.innerHTML='';if(examIntro)examIntro.hidden=false;
				setExamStartBusy(false);
				if(assessmentBlueprintSummary)assessmentBlueprintSummary.innerHTML='<strong>Chưa thể tạo đề</strong><span>Đã xảy ra lỗi khi tạo đề. Vui lòng thử lại.</span>';
				return false;
			}
		}
		function reconcileGeneratorTrial(){
			postAccessRequest('medipharm_abg_trial_action',{trial_action_name:'assessment'}).then(function(payload){
				if(!payload||!payload.success||!payload.data)throw new Error('trial');var data=payload.data;if(data.cookie){try{document.cookie=data.cookie;}catch(error){}}Access.member=!!data.member;Access.limit=Number(data.limit||Access.limit||10);Access.remaining=Number(data.remaining||0);Access.exhausted=!!data.exhausted;updateTrialUi();
				if(!data.allowed){stopExamTimer();examQuestions=[];if(examShell)examShell.innerHTML='';if(examIntro)examIntro.hidden=false;openTrialGate(false);}
			}).catch(function(){ /* Giữ đề đã tạo từ trạng thái truy cập hợp lệ lúc tải trang; đối soát lại ở lần thao tác kế tiếp. */ });
		}
		function hasMemberAccess(){
			return !!Access.member || root.getAttribute('data-abg-member-access')==='1';
		}
		function startGeneratorExam(){
			var member=hasMemberAccess();
			if(!member&&(Access.exhausted||Number(Access.remaining||0)<=0)){setExamStartBusy(false);openTrialGate(false);return false;}
			/* Generator is entirely local. Never block creation behind admin-ajax: the page-load
			 * access snapshot is enough to start, while guest quota is reconciled afterward. */
			setExamStartBusy(true);
			var started=startExamUnlocked();
			if(started&&!member){
				Access.remaining=Math.max(0,Number(Access.remaining||0)-1);Access.exhausted=Access.remaining<=0;updateTrialUi();reconcileGeneratorTrial();
			}
			return started;
		}
		function startExam(event){
			if(event&&event.preventDefault)event.preventDefault();if(examStart&&examStart.disabled)return;var key=assessmentBlueprintSelect?assessmentBlueprintSelect.value:'standard';
			if(key==='generator'){startGeneratorExam();return;}
			setExamStartBusy(true);requestTrialUse('assessment',startExamUnlocked,function(){setExamStartBusy(false);});
		}
		if(examStart)examStart.addEventListener('click',startExam);
		root.querySelectorAll('[data-home-generator]').forEach(function(btn){btn.addEventListener('click',function(){if(assessmentBlueprintSelect){assessmentBlueprintSelect.value='generator';assessmentBlueprintSelect.dispatchEvent(new Event('change',{bubbles:true}));}if(generatorSeed&&!generatorSeed.value)generatorSeed.value=String(newGeneratorSeed());renderBlueprintSummary();});});

		var reset=host.querySelector('[data-learning-reset]'); if(reset)reset.addEventListener('click',function(){
			if(!window.confirm('Đặt lại toàn bộ tiến độ ôn tập đã lưu trên thiết bị này?'))return;
			state={questions:{},cards:{},cardSchedule:{},exam:{count:0,best:0,last:0,total:12},assessment:{version:38,count:0,best:0,last:0,total:0,history:[]},adaptive:{version:37,started:0,completed:0,lastSession:0,lastCompleted:0},remediation:{version:57,totalErrors:0,lastUpdated:0,patterns:{},concepts:{},items:{}},platform:{version:40,analyses:0,lastAnalysis:0,lastContext:'',theoryViewed:{},lastTheory:0,lastActivity:0}}; stopAdaptiveSession(); try{window.localStorage.removeItem(storageKey);}catch(error){} renderStats();renderProgress();renderAdaptiveDashboard();renderRemediationDashboard();renderV58Longitudinal();renderV60Integrated();renderPlatformDashboard();renderQuestion(pickQuestion(topicSelect?topicSelect.value:'foundation',''));cardIndex=0;cardFace='front';renderCard();
		});

		renderStats(); renderProgress(); renderAdaptiveDashboard(); renderRemediationDashboard(); renderV58Longitudinal(); renderV60Integrated(); renderPlatformDashboard(); setTab('integrated');
	}

	function serialTrendMetric(records, key, label, unit) {
		var vals=records.map(function(r){return r[key];}).filter(function(v){return v!==null && v!==undefined && isFinite(v);});
		if(!vals.length) return '';
		var min=Math.min.apply(null,vals), max=Math.max.apply(null,vals), span=(max-min)||1;
		var points=[]; records.forEach(function(r,i){var v=r[key]; if(v===null||v===undefined||!isFinite(v)) return; var x=records.length===1?50:(i/(records.length-1))*100; var y=34-((v-min)/span)*28; points.push(x.toFixed(1)+','+y.toFixed(1));});
		return '<div class="nah-abg__trend-card"><div><strong>'+escapeHtml(label)+'</strong><span>'+escapeHtml(unit||'')+'</span></div><svg viewBox="0 0 100 38" role="img" aria-label="Xu hướng '+escapeHtml(label)+'"><polyline points="'+points.join(' ')+'" fill="none" vector-effect="non-scaling-stroke"/></svg><small>'+formatNumber(vals[0],1)+' → '+formatNumber(vals[vals.length-1],1)+'</small></div>';
	}

	function renderSerialTrend(records) {
		if(!records.length) return '<div class="nah-abg__empty"><p>Chưa có mốc khí máu nào trong phiên làm việc này.</p></div>';
		var rows=records.map(function(r,i){return '<tr><td>'+(i+1)+'</td><td>'+escapeHtml(r.label)+'</td><td>'+formatNumber(r.ph,2)+'</td><td>'+formatNumber(r.paco2,1)+'</td><td>'+formatNumber(r.hco3,1)+'</td><td>'+formatNumber(r.lactate,1)+'</td><td>'+formatNumber(r.pf,0)+'</td></tr>';}).join('');
		var charts=serialTrendMetric(records,'ph','pH','')+serialTrendMetric(records,'paco2','PaCO₂','mmHg')+serialTrendMetric(records,'hco3','HCO₃⁻','mmol/L')+serialTrendMetric(records,'lactate','Lactat','mmol/L')+serialTrendMetric(records,'pf','PaO₂/FiO₂','');
		return '<div class="nah-abg__trend-grid">'+charts+'</div><div class="nah-abg__trend-table-wrap"><table class="nah-abg__trend-table"><thead><tr><th>#</th><th>Mốc</th><th>pH</th><th>PaCO₂</th><th>HCO₃⁻</th><th>Lactat</th><th>PaO₂/FiO₂</th></tr></thead><tbody>'+rows+'</tbody></table></div><p class="nah-abg__trend-note">Các mốc chỉ được giữ trong phiên trình duyệt hiện tại và không gửi lên máy chủ.</p>';
	}

	function serialRecordFromResult(result, index) {
		var inp=result.input||{}, ox=result.oxygenation||{}, lac=result.lactateAssessment||{};
		return {label:'Mốc '+index+' · '+new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'}),ph:inp.ph,paco2:inp.paco2,hco3:inp.hco3,lactate:lac.available?lac.value:(inp.lactate||null),pf:ox.available?ox.pfRatio:null};
	}

	function setupQuickReference(root) {
		var panel = root.querySelector('[data-quick-reference]');
		var toggle = root.querySelector('[data-quick-reference-toggle]');
		var close = root.querySelector('[data-quick-reference-close]');
		if (!panel || !toggle || panel.dataset.quickReferenceReady === '1') return;
		panel.dataset.quickReferenceReady = '1';
		function setOpen(open, shouldScroll) {
			panel.hidden = !open;
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			toggle.textContent = open ? 'Đóng bảng tra nhanh' : 'Mở bảng tra nhanh';
			if (open && shouldScroll) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}
		toggle.addEventListener('click', function () { setOpen(panel.hidden, true); });
		if (close) close.addEventListener('click', function () { setOpen(false, false); toggle.focus(); });
	}

	function init(root) {
		if (!root || root.dataset.nahAbgReady === '1') {
			return;
		}

		var form = root.querySelector('[data-abg-form]');
		if (!form) {
			return;
		}
		root.dataset.nahAbgReady = '1';
		var workspaceTabs = Array.prototype.slice.call(root.querySelectorAll('[data-workspace-tab]'));
		var workspacePanels = Array.prototype.slice.call(root.querySelectorAll('[data-workspace-panel]'));
		var learnTabs = Array.prototype.slice.call(root.querySelectorAll('[data-learn-section-tab]'));
		var learnSections = Array.prototype.slice.call(root.querySelectorAll('[data-learn-section]'));
		var activeLearnSection = 'practice';
		var workspaceMenuToggle = root.querySelector('[data-workspace-menu-toggle]');
		var workspaceTabList = root.querySelector('[data-workspace-tab-list]');
		var workspaceCurrentLabel = root.querySelector('[data-workspace-current-label]');
		var panels = Array.prototype.slice.call(root.querySelectorAll('[data-form-step]'));
		var progressItems = Array.prototype.slice.call(root.querySelectorAll('[data-progress-step]'));
		var prevButton = root.querySelector('[data-prev-step]');
		var nextButton = root.querySelector('[data-next-step]');
		var analyzeButton = root.querySelector('[data-analyze]');
		var errorBox = root.querySelector('[data-form-errors]');
		var resultShell = root.querySelector('[data-result-shell]');
		var resultActions = root.querySelector('[data-result-actions]');
		var trialGate = root.querySelector('[data-abg-trial-gate]');
		var trialCopy = root.querySelector('.nah-abg__trial-copy');
		var trialLogin = root.querySelector('[data-abg-trial-login]');
		var trialClose = root.querySelector('[data-abg-trial-close]');
		var demoSelect = root.querySelector('[data-demo-select]');
		var learningMode = root.querySelector('[data-learning-mode]');
		var learningAnswer = root.querySelector('[data-learning-answer]');
		var learningPreview = root.querySelector('[data-learning-preview]');
		var currentLearningCase = '';
		var serialTrendShell = root.querySelector('[data-serial-trend]');
		var saveTrendButton = root.querySelector('[data-save-trend]');
		var clearTrendButton = root.querySelector('[data-clear-trend]');
		var serialRecords = [];
		try { serialRecords = JSON.parse(sessionStorage.getItem('medipharm_abg_serial_v24') || '[]'); if(!Array.isArray(serialRecords)) serialRecords=[]; } catch(e) { serialRecords=[]; }
		function refreshSerialTrend(){ if(serialTrendShell) serialTrendShell.innerHTML=renderSerialTrend(serialRecords); }
		refreshSerialTrend();

		var trialLoginLoaded = !!(trialLogin && trialLogin.querySelector('[data-abg-web-login]'));
		var trialLoginLoading = false;
		function updateTrialUi() {
			root.querySelectorAll('[data-abg-trial-remaining]').forEach(function (el) { el.textContent = String(Math.max(0, Number(Access.remaining || 0))); });
		}
		function postAccessRequest(actionName, fields) {
			if (!Access.ajaxUrl || !Access.nonce || typeof window.fetch !== 'function') return Promise.reject(new Error('access'));
			var body = new URLSearchParams();
			body.set('action', actionName);
			body.set('nonce', Access.nonce);
			Object.keys(fields || {}).forEach(function (key) { body.set(key, fields[key]); });
			var controller = typeof window.AbortController === 'function' ? new window.AbortController() : null;
			var timeout = window.setTimeout(function(){ if(controller) controller.abort(); }, 8000);
			return window.fetch(Access.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString(), signal: controller ? controller.signal : undefined })
				.then(function (response) { return response.json(); })
				.finally(function(){ window.clearTimeout(timeout); });
		}
		function loadLoginForm() {
			if (!trialLogin || trialLoginLoaded || trialLoginLoading) return;
			trialLoginLoading = true;
			postAccessRequest('medipharm_abg_login_form', {}).then(function (payload) {
				if (!payload || !payload.success || !payload.data || !payload.data.html) throw new Error('login');
				trialLogin.innerHTML = payload.data.html;
				trialLoginLoaded = true;
				trialLoginLoading = false;
				var focusTarget = trialLogin.querySelector('input,button,a,select,textarea');
				if (focusTarget) window.requestAnimationFrame(function () { focusTarget.focus(); });
			}).catch(function () {
				trialLoginLoading = false;
				trialLogin.innerHTML = '<div class="nah-abg-access-gate__fallback"><h2>Chưa tải được form đăng nhập</h2><p>Vui lòng thử lại hoặc đăng ký tài khoản mới.</p></div>';
			});
		}

		function setWebLoginStatus(formEl, message, error) {
			if (!formEl) return;
			var status = formEl.querySelector('[data-abg-web-login-status]');
			if (!status) return;
			status.hidden = !message;
			status.textContent = message || '';
			status.classList.toggle('is-error', !!error);
		}
		function submitWebLogin(formEl) {
			if (!formEl) return;
			var loginInput = formEl.querySelector('[name="login"]');
			var passwordInput = formEl.querySelector('[name="password"]');
			var submit = formEl.querySelector('[type="submit"]');
			var loginValue = loginInput ? String(loginInput.value || '').trim() : '';
			var passwordValue = passwordInput ? String(passwordInput.value || '') : '';
			if (!loginValue || !passwordValue) {
				setWebLoginStatus(formEl, 'Vui lòng nhập đầy đủ tài khoản và mật khẩu.', true);
				(loginValue ? passwordInput : loginInput).focus();
				return;
			}
			if (submit) submit.disabled = true;
			setWebLoginStatus(formEl, 'Đang xác thực…', false);
			postAccessRequest('medipharm_abg_web_login', { login: loginValue, password: passwordValue })
				.then(function (payload) {
					if (!payload || !payload.success || !payload.data || !payload.data.member) {
						var msg = payload && payload.data && payload.data.message ? payload.data.message : 'Đăng nhập chưa thành công.';
						throw new Error(msg);
					}
					setWebLoginStatus(formEl, 'Đăng nhập thành công. Đang mở ứng dụng…', false);
					window.setTimeout(function () { window.location.reload(); }, 220);
				})
				.catch(function (error) {
					if (submit) submit.disabled = false;
					setWebLoginStatus(formEl, error && error.message ? error.message : 'Chưa đăng nhập được. Vui lòng thử lại.', true);
					if (passwordInput) { passwordInput.value = ''; passwordInput.focus(); }
				});
		}
		if (trialLogin) {
			trialLogin.addEventListener('submit', function (event) {
				var loginForm = event.target.closest('[data-abg-web-login]');
				if (!loginForm) return;
				event.preventDefault();
				submitWebLogin(loginForm);
			});
			trialLogin.addEventListener('click', function (event) {
				var toggle = event.target.closest('[data-abg-password-toggle]');
				if (!toggle) return;
				var formEl = toggle.closest('[data-abg-web-login]');
				var input = formEl ? formEl.querySelector('[name="password"]') : null;
				if (!input) return;
				var reveal = input.type === 'password';
				input.type = reveal ? 'text' : 'password';
				toggle.textContent = reveal ? 'Ẩn' : 'Hiện';
				toggle.setAttribute('aria-label', reveal ? 'Ẩn mật khẩu' : 'Hiện mật khẩu');
			});
		}
		function openTrialGate(showLogin) {
			if (!trialGate) return;
			trialGate.hidden = false;
			document.documentElement.classList.add('nah-abg-trial-open');
			if (trialCopy) trialCopy.hidden = !!showLogin;
			if (trialLogin) trialLogin.hidden = !showLogin;
			if (showLogin) loadLoginForm();
			var focusTarget = !showLogin ? trialGate.querySelector('[data-abg-login-open]') : null;
			if (focusTarget) window.requestAnimationFrame(function () { focusTarget.focus(); });
		}
		function closeTrialGate() {
			if (!trialGate) return;
			trialGate.hidden = true;
			if (trialCopy) trialCopy.hidden = false;
			if (trialLogin) trialLogin.hidden = true;
			document.documentElement.classList.remove('nah-abg-trial-open');
		}
		window.MEDIPHARMABGOpenLogin = function () {
			openTrialGate(true);
			return true;
		};
		function requestTrialUse(actionName, onAllowed) {
			var onDenied = arguments[2];
			if (Access.member) { onAllowed(); return; }
			if (Access.exhausted || Number(Access.remaining || 0) <= 0) { if(onDenied)onDenied(); openTrialGate(false); return; }
			postAccessRequest('medipharm_abg_trial_action', { trial_action_name: actionName })
				.then(function (payload) {
					if (!payload || !payload.success || !payload.data) throw new Error('trial');
					var data = payload.data;
					if (data.cookie) { try { document.cookie = data.cookie; } catch (error) {} }
					Access.member = !!data.member; Access.limit = Number(data.limit || Access.limit || 10); Access.remaining = Number(data.remaining || 0); Access.exhausted = !!data.exhausted;
					updateTrialUi();
					if (data.allowed) onAllowed(); else { if(onDenied)onDenied(); openTrialGate(false); }
				})
				.catch(function () { if(onDenied)onDenied(); openTrialGate(false); });
		}
		root.querySelectorAll('[data-abg-login-open]').forEach(function (button) { button.addEventListener('click', function () { openTrialGate(true); }); });
		if (trialClose) trialClose.addEventListener('click', closeTrialGate);
		if (trialGate) trialGate.addEventListener('click', function (event) { if (event.target === trialGate) closeTrialGate(); });
		document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && trialGate && !trialGate.hidden) closeTrialGate(); });
		updateTrialUi();
		if (Access.openLogin) window.requestAnimationFrame(function () { openTrialGate(true); });
		if (resultShell) {
			resultShell.addEventListener('click', function (event) {
				var reviewButton = event.target.closest('[data-learning-review]');
				if (reviewButton) {
					var reviewKey = reviewButton.getAttribute('data-learning-review');
					setWorkspaceTab('theory', false);
					var theoryTarget = root.querySelector('[data-case-review="' + reviewKey + '"]');
					if (theoryTarget && handbookAccordion) handbookAccordion.open(theoryTarget, true);
					else if (theoryTarget) theoryTarget.scrollIntoView({ behavior: 'smooth', block: 'start' });
					return;
				}
				var reviewTopicButton = event.target.closest('[data-integration-open-review]');
				if (reviewTopicButton) {
					var reviewTopic = reviewTopicButton.getAttribute('data-integration-open-review') || 'clinical';
					setWorkspaceTab('review', true);
					var questionToggle = root.querySelector('[data-learning-tab="questions"]');
					if (questionToggle) questionToggle.click();
					var topicField = root.querySelector('[data-learning-topic]');
					if (topicField) { topicField.value = reviewTopic; topicField.dispatchEvent(new Event('change', { bubbles: true })); }
					return;
				}
				var modeButton = event.target.closest('[data-summary-mode]');
				if (modeButton) {
					var mode = modeButton.getAttribute('data-summary-mode');
					resultShell.querySelectorAll('[data-summary-mode]').forEach(function (button) {
						var active = button.getAttribute('data-summary-mode') === mode;
						button.classList.toggle('is-active', active);
						button.setAttribute('aria-selected', active ? 'true' : 'false');
					});
					resultShell.querySelectorAll('[data-summary-pane]').forEach(function (pane) { pane.hidden = pane.getAttribute('data-summary-pane') !== mode; });
					return;
				}
				var copySummary = event.target.closest('[data-copy-clinical-summary]');
				if (copySummary && lastResult) {
					var text = buildClinicalSummaryText(lastResult, serialRecords);
					var old = copySummary.textContent;
					function done(){ copySummary.textContent='Đã sao chép'; window.setTimeout(function(){copySummary.textContent=old;},1200); }
					if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done).catch(function(){});
				}
			});
		}
		var venousWarning = root.querySelector('[data-venous-warning]');
		var pressureSelect = form.elements.gasPressureUnit;
		var currentStep = 1;
		var lastResult = null;

		setupTheme(root);
		setupPwa(root);
		setupAppMenu(root);
		var handbookAccordion = setupHandbookAccordion(root, scrollWorkspacePanelIntoView);
		setupQuickReference(root);
		setupLearningSystem(root);
		root.querySelectorAll('[data-learning-tab]').forEach(function(toggle){var item=toggle.closest('.nah-abg__learning-accordion-item');if(item)item.dataset.learningItem=toggle.getAttribute('data-learning-tab')||'';});

		function getFixedAdminBarHeight() {
			var adminBar = document.getElementById('wpadminbar');
			if (!adminBar || !window.getComputedStyle) return 0;
			var style = window.getComputedStyle(adminBar);
			if (!style || (style.position !== 'fixed' && style.position !== 'sticky')) return 0;
			var rect = adminBar.getBoundingClientRect();
			/* Count only the portion that is actually visible at the top of the viewport.
			   This also handles host/admin-bar hide-on-scroll implementations. */
			if (rect.bottom <= 0 || rect.top >= window.innerHeight) return 0;
			return Math.max(0, Math.round(Math.min(rect.height, rect.bottom, window.innerHeight)));
		}

		function syncWorkspaceStickyOffsets() {
			var hero = root.querySelector('.nah-abg__hero');
			var nav = root.querySelector('.nah-abg__workspace-tabs.nah-abg__app-nav');
			var adminHeight = getFixedAdminBarHeight();
			var heroHeight = hero ? Math.max(0, Math.round(hero.getBoundingClientRect().height)) : 0;
			var verticalNav = false;
			var navHeight = nav && !verticalNav ? Math.max(0, Math.round(nav.getBoundingClientRect().height)) : 0;
			root.style.setProperty('--nah-abg-app-header-top', adminHeight + 'px');
			root.style.setProperty('--nah-abg-app-header-height', heroHeight + 'px');
			root.style.setProperty('--nah-abg-app-nav-top', (adminHeight + heroHeight) + 'px');
			root.style.setProperty('--nah-abg-app-nav-height', navHeight + 'px');
		}

		function scrollWorkspacePanelIntoView(panel) {
			if (!panel) return;
			syncWorkspaceStickyOffsets();
			var hero = root.querySelector('.nah-abg__hero');
			var nav = root.querySelector('.nah-abg__workspace-tabs.nah-abg__app-nav');
			var verticalNav = !!(window.matchMedia && window.matchMedia('(min-width:1180px)').matches);
			var offset = getFixedAdminBarHeight() +
				(hero ? hero.getBoundingClientRect().height : 0) +
				(nav && !verticalNav ? nav.getBoundingClientRect().height : 0) + 12;
			var scrollTop = window.pageYOffset || document.documentElement.scrollTop || 0;
			var rect = panel.getBoundingClientRect();
			var y = rect.top + scrollTop - offset;
			window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
		}

		function openLessonTargetInViewport(target) {
			if (!target) return;
			setWorkspaceTab('theory', false);
			setLearnSection('lessons', false);
			if (handbookAccordion) handbookAccordion.open(target, false);
			window.requestAnimationFrame(function () {
				syncWorkspaceStickyOffsets();
				window.requestAnimationFrame(function () { scrollWorkspacePanelIntoView(target); });
			});
		}

		syncWorkspaceStickyOffsets();
		window.addEventListener('resize', syncWorkspaceStickyOffsets, { passive: true });
		window.addEventListener('orientationchange', syncWorkspaceStickyOffsets, { passive: true });
		var stickyOffsetRaf = 0;
		window.addEventListener('scroll', function () {
			if (stickyOffsetRaf) return;
			stickyOffsetRaf = window.requestAnimationFrame(function () {
				stickyOffsetRaf = 0;
				syncWorkspaceStickyOffsets();
			});
		}, { passive: true });

		function setLearnSection(section, shouldScroll) {
			var targetSection = section === 'lessons' ? 'lessons' : 'practice';
			activeLearnSection = targetSection;
			learnTabs.forEach(function(button){
				var active=button.getAttribute('data-learn-section-tab')===targetSection;
				button.classList.toggle('is-active',active);
				button.setAttribute('aria-pressed',active?'true':'false');
			});
			learnSections.forEach(function(sectionEl){sectionEl.hidden=sectionEl.getAttribute('data-learn-section')!==targetSection;});
			root.classList.toggle('nah-abg--learn-practice',targetSection==='practice');
			root.classList.toggle('nah-abg--learn-lessons',targetSection==='lessons');
			if(shouldScroll){var sectionEl=root.querySelector('[data-learn-section="'+targetSection+'"]');if(sectionEl)scrollWorkspacePanelIntoView(sectionEl);}
		}

		function learningTabForWorkspace(view) {
			return {qa:'review',review:'review',exam:'review'}[view] || '';
		}

		function workspaceMeta(view) {
			var map={
				home:{label:'Trang chủ'},
				analysis:{label:'Phân tích'},
				theory:{label:'Học tập',title:'Học tập',description:'Từ điển, 6 chuyên đề chuyên sâu và ôn luyện theo câu hỏi.'},
				cases:{label:'Ca lâm sàng',title:'Ca lâm sàng',description:'Thực hành suy luận khí máu theo bệnh cảnh.'},
				profile:{label:'Tiến độ',title:'Tiến độ học tập',description:'Theo dõi nội dung đã đọc trên thiết bị.'}
			};return map[view]||map.analysis;
		}

		function setWorkspaceTab(name, shouldScroll) {
			var requested = name || 'home';
			var canonicalTab = '';
			if(requested==='learn') requested='theory';
			if(requested==='qa'){canonicalTab='review';requested='theory';}
			if(requested==='review'||requested==='exam'){canonicalTab='review';requested='theory';}
			var target=(requested==='home'||requested==='analysis')?requested:'learn';
			var meta=workspaceMeta(requested);
			workspaceTabs.forEach(function(button){
				var active=button.getAttribute('data-workspace-tab')===requested;
				button.classList.toggle('is-active',active);
				button.setAttribute('aria-selected',active?'true':'false');
				button.tabIndex=active?0:-1;
			});
			workspacePanels.forEach(function(panel){panel.hidden=panel.getAttribute('data-workspace-panel')!==target;});
			root.classList.remove('nah-abg--workspace-home','nah-abg--workspace-analysis','nah-abg--workspace-learn');
			root.classList.add('nah-abg--workspace-'+target);
			root.dataset.learningWorkspaceView=(target==='learn'?requested:'');
			root.querySelectorAll('[data-canonical-workspace]').forEach(function(panel){
				if(target!=='learn'){panel.hidden=true;return;}
				var mode=requested==='cases'?'cases':requested==='profile'?'profile':'learning';
				panel.hidden=panel.getAttribute('data-canonical-workspace')!==mode;
			});
			root.querySelectorAll('.nah-abg__mobile-dock [data-home-workspace]').forEach(function(dockButton){
				var dockName=dockButton.getAttribute('data-home-workspace')||'home';
				var active=dockName===requested;
				dockButton.classList.toggle('is-active',active);
				dockButton.setAttribute('aria-current',active?'page':'false');
			});
			if(workspaceCurrentLabel)workspaceCurrentLabel.textContent=meta.label;
			if(workspaceTabList)workspaceTabList.classList.remove('is-open');
			if(workspaceMenuToggle)workspaceMenuToggle.setAttribute('aria-expanded','false');
			try{root.dispatchEvent(new CustomEvent('medipharmabg:workspace',{detail:{view:requested,canonicalTab:canonicalTab}}));}catch(error){}
			requestAnimationFrame(function(){
				syncWorkspaceStickyOffsets();
				if(shouldScroll){var activePanel=target==='learn'?root.querySelector('[data-canonical-workspace="'+(requested==='cases'?'cases':requested==='profile'?'profile':'learning')+'"]'):root.querySelector('[data-workspace-panel="'+target+'"]');scrollWorkspacePanelIntoView(activePanel);}
			});
		}

		workspaceTabs.forEach(function (button) {
			button.addEventListener('click', function () {setWorkspaceTab(button.getAttribute('data-workspace-tab'), true);});
		});
		root.querySelectorAll('[data-clinical-workspace]').forEach(function(button){
			button.addEventListener('click',function(){
				var target=button.getAttribute('data-clinical-workspace')||'theory';
				setWorkspaceTab(target,true);
			});
		});
		if(workspaceMenuToggle)workspaceMenuToggle.addEventListener('click',function(){var open=!(workspaceTabList&&workspaceTabList.classList.contains('is-open'));if(workspaceTabList)workspaceTabList.classList.toggle('is-open',open);workspaceMenuToggle.setAttribute('aria-expanded',open?'true':'false');});
		document.addEventListener('click',function(e){if(!workspaceTabList||!workspaceMenuToggle)return;if(!e.target.closest('.nah-abg__app-nav')){workspaceTabList.classList.remove('is-open');workspaceMenuToggle.setAttribute('aria-expanded','false');}});
		learnTabs.forEach(function(button){button.addEventListener('click',function(){var sec=button.getAttribute('data-learn-section-tab');setWorkspaceTab(sec==='lessons'?'theory':'review',false);setLearnSection(sec,true);});});
		root.querySelectorAll('[data-learning-tab]').forEach(function(toggle){toggle.addEventListener('click',function(){var tab=toggle.getAttribute('data-learning-tab')||'';var view=tab==='qa'?'qa':tab==='exam'?'exam':tab==='progress'?'profile':tab==='challenge'?'cases':'review';var current=root.dataset.learningWorkspaceView||'';if(current!==view&&current!=='cases')setWorkspaceTab(view,false);});});
		root.querySelectorAll('[data-handbook-open-analysis]').forEach(function (button) {
			button.addEventListener('click', function () {
				setWorkspaceTab('analysis', true);
			});
		});
		root.querySelectorAll('[data-open-review]').forEach(function (button) {
			button.addEventListener('click', function () {
				setWorkspaceTab('review', true);
			});
		});
		root.addEventListener('click', function (event) {
			var theoryButton = event.target.closest('[data-open-theory-topic]');
			if (!theoryButton) return;
			var topic = theoryButton.getAttribute('data-open-theory-topic');
			var theoryMap = {foundation:'-hb-balance',acidbase:'-hb-four',oxygen:'-hb-oxygen-ventilation',clinical:'-hb-case-dka'};
			var suffix = theoryMap[topic] || '-hb-balance';
			var target = root.querySelector('#' + root.id.replace(/-root$/, '') + suffix);
			if (!target) target = root.querySelector('[id$="' + suffix + '"]');
			if (target) openLessonTargetInViewport(target);
			else setWorkspaceTab('theory', true);
		});
		root.addEventListener('click',function(event){var lessonButton=event.target.closest('[data-remediation-lesson]');if(lessonButton){var lesson=lessonButton.getAttribute('data-remediation-lesson')||'';var target=root.querySelector('[id$="-'+lesson.replace(/^-/,'')+'"]');if(target)openLessonTargetInViewport(target);else setWorkspaceTab('theory',true);return;}var caseButton=event.target.closest('[data-remediation-case]');if(caseButton){var key=caseButton.getAttribute('data-remediation-case')||'';if(key&&DEMOS[key]&&demoSelect){demoSelect.value=key;setWorkspaceTab('analysis',true);var loader=root.querySelector('[data-load-demo]');if(loader)loader.click();}}});
		root.querySelectorAll('[data-handbook-case]').forEach(function (button) {
			button.addEventListener('click', function () {
				var caseKey = button.getAttribute('data-handbook-case');
				if (!caseKey || !DEMOS[caseKey] || !demoSelect) return;
				demoSelect.value = caseKey;
				setWorkspaceTab('analysis', true);
				var loader = root.querySelector('[data-load-demo]');
				if (loader) loader.click();
			});
		});

		var brandHome=root.querySelector('[data-abg-brand-home]');
		if(brandHome)brandHome.addEventListener('click',function(event){
			if(root.getAttribute('data-abg-standalone')!=='1')return;
			if(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||event.button===1)return;
			event.preventDefault();
			setWorkspaceTab('home',false);
			if(history&&history.replaceState){try{history.replaceState(null,'',brandHome.getAttribute('href')||window.location.href);}catch(error){}}
			window.requestAnimationFrame(function(){window.scrollTo({top:0,behavior:'smooth'});});
		});
		root.querySelectorAll('[data-home-workspace]').forEach(function(button){button.addEventListener('click',function(){var target=button.getAttribute('data-home-workspace')||'home';setWorkspaceTab(target,true);var learn=button.getAttribute('data-home-learning');if(learn){var mapped=learn==='classroom'?'cases':learn==='exam'?'exam':learn==='progress'?'profile':learn==='qa'?'qa':'review';if(mapped!==target)setWorkspaceTab(mapped,false);var toggle=root.querySelector('[data-learning-tab="'+learn+'"]');if(toggle)toggle.click();}});});

		root.querySelectorAll('[data-learning-hub]').forEach(function(button){button.addEventListener('click',function(){var name=button.getAttribute('data-learning-hub')||'adaptive';var toggle=root.querySelector('[data-learning-tab="'+name+'"]');if(toggle)toggle.click();var system=root.querySelector('[data-learning-system]');if(system)system.scrollIntoView({behavior:'smooth',block:'start'});});});
		root.querySelectorAll('[data-theory-map-target]').forEach(function(button){button.addEventListener('click',function(){var suffix=button.getAttribute('data-theory-map-target')||'-hb-balance';var target=root.querySelector('[id$="'+suffix+'"]');if(target)openLessonTargetInViewport(target);});});
		var classroomDemo=root.querySelector('[data-classroom-demo-select]'),classroomLoad=root.querySelector('[data-classroom-load-demo]');
		if(classroomLoad)classroomLoad.addEventListener('click',function(){var key=classroomDemo?classroomDemo.value:'';if(!key||!DEMOS[key]||!demoSelect)return;demoSelect.value=key;setWorkspaceTab('analysis',true);var loader=root.querySelector('[data-load-demo]');if(loader)loader.click();});
		var homeRecAction=root.querySelector('[data-home-recommendation-action]');if(homeRecAction)homeRecAction.addEventListener('click',function(){var kind=homeRecAction.dataset.homeRecKind||'analysis',topic=homeRecAction.dataset.homeRecTopic||'foundation';if(kind==='theory'){var btn=root.querySelector('[data-open-theory-topic="'+topic+'"]');if(btn)btn.click();return;}if(kind==='adaptive'||kind==='exam'){setWorkspaceTab(kind==='exam'?'exam':'review',true);var t=root.querySelector('[data-learning-tab="'+kind+'"]');if(t)t.click();return;}setWorkspaceTab('analysis',true);});


		/* v4.3.1 — Internal ABG search and dark-mode classroom pickers. */
		(function setupInternalSearch(){
			var input=root.querySelector('[data-abg-search-input]'),box=root.querySelector('[data-abg-search-results]');
			if(!input||!box)return;
			var candidates=[];
			workspacePanels.forEach(function(panel){
				var workspace=panel.getAttribute('data-workspace-panel')||'home';
				panel.querySelectorAll('h1,h2,h3,[data-learning-tab],[data-open-theory-topic]').forEach(function(el){
					var text=(el.textContent||'').replace(/\s+/g,' ').trim();if(text.length<3||text.length>110)return;
					var section=el.closest('[data-learn-section]');var learnSection=section?section.getAttribute('data-learn-section'):'';
					if(candidates.some(function(x){return x.text===text&&x.workspace===workspace&&x.learnSection===learnSection;}))return;
					candidates.push({text:text,workspace:workspace,learnSection:learnSection,el:el});
				});
			});
			function close(){box.hidden=true;box.innerHTML='';}
			input.addEventListener('input',function(){var q=input.value.trim().toLocaleLowerCase('vi');if(q.length<2){close();return;}var rows=candidates.filter(function(x){return x.text.toLocaleLowerCase('vi').indexOf(q)>=0;}).slice(0,7);if(!rows.length){box.innerHTML='<p>Chưa tìm thấy nội dung phù hợp.</p>';box.hidden=false;return;}box.innerHTML=rows.map(function(x,i){return '<button type="button" data-abg-search-hit="'+i+'"><strong>'+escapeHtml(x.text)+'</strong><small>'+(x.workspace==='home'?'Trang chủ':x.workspace==='analysis'?'Phân tích':(x.learnSection==='lessons'?'Lý thuyết':'Học tập'))+'</small></button>';}).join('');box.hidden=false;box.querySelectorAll('[data-abg-search-hit]').forEach(function(btn){btn.addEventListener('click',function(){var hit=rows[Number(btn.getAttribute('data-abg-search-hit'))];if(!hit)return;setWorkspaceTab(hit.workspace,false);if(hit.workspace==='learn'&&hit.learnSection){if(hit.learnSection==='lessons')setWorkspaceTab('theory',false);else{var lt=hit.el.closest('[data-learning-tab]')||hit.el.querySelector&&hit.el.querySelector('[data-learning-tab]');var n=lt?lt.getAttribute('data-learning-tab'):'';setWorkspaceTab(n==='qa'?'qa':n==='exam'?'exam':n==='progress'?'profile':'review',false);}}close();input.value='';window.requestAnimationFrame(function(){if(hit.el.matches('[data-learning-tab],[data-open-theory-topic]'))hit.el.click();else{var verticalSearchNav=false;var offset=getFixedAdminBarHeight()+(root.querySelector('.nah-abg__hero')?.getBoundingClientRect().height||0)+(verticalSearchNav?0:(root.querySelector('.nah-abg__app-nav')?.getBoundingClientRect().height||0))+12;var y=hit.el.getBoundingClientRect().top+window.pageYOffset-offset;window.scrollTo({top:Math.max(0,y),behavior:'smooth'});}});});});});
			input.addEventListener('keydown',function(e){if(e.key==='Escape')close();});
			document.addEventListener('click',function(e){if(!e.target.closest('[data-abg-search]'))close();});
		})();

		/* v4.4.2 — use the same accessible, theme-aware picker for all ABG selects.
		   Android/browser native option popups can ignore dark-mode CSS, so the visible
		   control is rendered by the WebApp while the original select remains the
		   underlying form/state source. */
		(function setupThemeAwarePickers(){
			function enhance(select){if(!select||select.dataset.pickerReady==='1'||select.multiple)return;select.dataset.pickerReady='1';select.classList.add('nah-abg__native-select-source');var wrap=document.createElement('div');wrap.className='nah-abg__picker';var btn=document.createElement('button');btn.type='button';btn.className='nah-abg__picker-button';btn.setAttribute('aria-haspopup','listbox');btn.setAttribute('aria-expanded','false');var list=document.createElement('div');list.className='nah-abg__picker-list';list.setAttribute('role','listbox');list.hidden=true;select.parentNode.insertBefore(wrap,select);wrap.appendChild(select);wrap.appendChild(btn);wrap.appendChild(list);
				function label(){var o=select.options[select.selectedIndex];btn.textContent=o?o.text:'Chọn';btn.disabled=!!select.disabled;}
				function close(){list.hidden=true;btn.setAttribute('aria-expanded','false');}
				function render(){list.innerHTML='';Array.prototype.forEach.call(select.options,function(o,i){var x=document.createElement('button');x.type='button';x.setAttribute('role','option');x.className='nah-abg__picker-option'+(i===select.selectedIndex?' is-selected':'');x.setAttribute('aria-selected',i===select.selectedIndex?'true':'false');x.disabled=!!o.disabled;x.textContent=o.text;x.addEventListener('click',function(){if(o.disabled)return;select.selectedIndex=i;select.dispatchEvent(new Event('change',{bubbles:true}));label();close();});list.appendChild(x);});}
				btn.addEventListener('click',function(){var open=list.hidden;root.querySelectorAll('.nah-abg__picker-list:not([hidden])').forEach(function(x){x.hidden=true;});list.hidden=!open;btn.setAttribute('aria-expanded',open?'true':'false');if(open)render();});select.addEventListener('change',label);label();
				document.addEventListener('click',function(e){if(!wrap.contains(e.target))close();});btn.addEventListener('keydown',function(e){if(e.key==='Escape'){close();btn.focus();}});
			}
			function scan(scope){(scope||root).querySelectorAll('select').forEach(enhance);}
			scan(root);
			if(window.MutationObserver){new MutationObserver(function(records){records.forEach(function(r){r.addedNodes.forEach(function(n){if(!n||n.nodeType!==1)return;if(n.matches&&n.matches('select'))enhance(n);else if(n.querySelectorAll)scan(n);});});}).observe(root,{childList:true,subtree:true});}
		})();

		var requestedView='';try{requestedView=(new URL(window.location.href)).searchParams.get('view')||'';}catch(error){}
		if(['home','analysis','theory','qa','cases','review','exam','profile'].indexOf(requestedView)>=0)setWorkspaceTab(requestedView,false);else if(requestedView==='learn')setWorkspaceTab('theory',false);else if(requestedView==='classroom')setWorkspaceTab('cases',false);else setWorkspaceTab('home',false);

		pressureSelect.dataset.previousUnit = pressureSelect.value;

		function showErrors(messages) {
			if (!messages || !messages.length) {
				errorBox.hidden = true;
				errorBox.innerHTML = '';
				return;
			}
			errorBox.innerHTML = '<strong>Chưa thể tiếp tục:</strong><ul>' + messages.map(function (message) {
				return '<li>' + escapeHtml(message) + '</li>';
			}).join('') + '</ul>';
			errorBox.hidden = false;
			errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
		}

		function validateStep(step) {
			var panel = root.querySelector('[data-form-step="' + step + '"]');
			var messages = [];
			if (!panel) {
				return true;
			}

			panel.querySelectorAll('[data-numeric]').forEach(function (field) {
				if (!field.value.trim() && field.required) {
					var label = field.closest('.nah-abg__field').querySelector('span').textContent.replace('*', '').trim();
					var message = 'Vui lòng nhập ' + label + '.';
					setFieldFeedback(field, { state: 'invalid', message: message });
					messages.push(message);
					return;
				}
				if (field.value.trim()) {
					var feedback = validateNumericField(form, field);
					if (feedback.state === 'invalid') {
						messages.push(feedback.message);
					}
				}
			});

			showErrors(Array.from(new Set(messages)));
			return messages.length === 0;
		}

		function goToStep(step, shouldScroll) {
			currentStep = Math.max(1, Math.min(5, step));
			panels.forEach(function (panel) {
				var isActive = Number(panel.getAttribute('data-form-step')) === currentStep;
				panel.hidden = !isActive;
				panel.classList.toggle('is-active', isActive);
			});
			progressItems.forEach(function (item) {
				var itemStep = Number(item.getAttribute('data-progress-step'));
				item.classList.toggle('is-active', itemStep === currentStep);
				item.classList.toggle('is-complete', itemStep < currentStep);
			});
			prevButton.hidden = currentStep === 1;
			nextButton.hidden = currentStep >= 4;
			analyzeButton.hidden = currentStep !== 4;
			if (currentStep === 5) {
				nextButton.hidden = true;
				analyzeButton.hidden = true;
			}
			showErrors([]);
			if (shouldScroll !== false) {
				root.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}
		}

		nextButton.addEventListener('click', function () {
			if (validateStep(currentStep)) {
				goToStep(currentStep + 1);
			}
		});

		prevButton.addEventListener('click', function () {
			goToStep(currentStep - 1);
		});

		form.querySelectorAll('[data-numeric]').forEach(function (field) {
			field.addEventListener('input', function () {
				if (!field.value.trim()) {
					setFieldFeedback(field, { state: 'empty', message: '' });
				} else {
					field.classList.remove('is-invalid', 'is-warning', 'is-valid');
				}
			});
			field.addEventListener('blur', function () {
				if (field.value.trim()) {
					validateNumericField(form, field);
				}
			});
		});

		form.addEventListener('change', function (event) {
			if (event.target.name === 'sampleType') {
				venousWarning.hidden = event.target.value !== 'venous';
			}
			if (event.target.name === 'unitSystem') {
				applyUnitSystem(form, event.target.value, true);
			}
			if (event.target.name === 'gasPressureUnit') {
				var previous = pressureSelect.dataset.previousUnit || 'mmhg';
				updatePressureUnit(form, previous, event.target.value);
				pressureSelect.dataset.previousUnit = event.target.value;
			}
		});

		root.querySelector('[data-load-demo]').addEventListener('click', function () {
			var selected = demoSelect.value;
			if (!selected || !DEMOS[selected]) {
				showErrors(['Vui lòng chọn một ca minh họa.']);
				return;
			}
			form.reset();
			form.querySelectorAll('[data-field-feedback]').forEach(function (feedback) { feedback.remove(); });
			form.querySelectorAll('[data-numeric]').forEach(function (field) {
				field.classList.remove('is-invalid', 'is-warning', 'is-valid');
			});
			setFormValues(form, DEMOS[selected]);
			currentLearningCase = selected;
			if (learningPreview) learningPreview.innerHTML = learningCardHtml(selected, learningMode ? learningMode.value : 'guided', learningAnswer ? learningAnswer.value : '', false);
			applyUnitSystem(form, 'si', false);
			pressureSelect.dataset.previousUnit = form.elements.gasPressureUnit.value;
			updatePressureUnit(form, null, form.elements.gasPressureUnit.value);
			showErrors([]);
			goToStep(2);
		});


		if (learningMode) {
			learningMode.addEventListener('change', function () {
				if (learningPreview && currentLearningCase) learningPreview.innerHTML = learningCardHtml(currentLearningCase, learningMode.value, learningAnswer ? learningAnswer.value : '', false);
				if (learningAnswer) learningAnswer.closest('.nah-abg__learning-answer').hidden = learningMode.value === 'guided';
			});
			if (learningAnswer) learningAnswer.closest('.nah-abg__learning-answer').hidden = learningMode.value === 'guided';
		}

		form.addEventListener('submit', function (event) {
			event.preventDefault();
			if (currentStep < 4) {
				if (validateStep(currentStep)) {
					goToStep(currentStep + 1);
				}
				return;
			}
			if (!validateStep(4)) {
				return;
			}

			var rawInput = readForm(form);
			var result = Core.analyze(rawInput);
			if (result.ok) {
				result.integrationContext = { setting: rawInput.clinicalSetting || 'unspecified', focus: rawInput.clinicalFocus || 'general' };
			}
			if (!result.ok) {
				showErrors(result.errors);
				Object.keys(result.fieldErrors || {}).forEach(function (name) {
					var field = form.elements[name];
					if (field) {
						setFieldFeedback(field, { state: 'invalid', message: result.fieldErrors[name][0] });
					}
				});
				return;
			}

			requestTrialUse('analysis', function () {
				lastResult = result;
				resultShell.innerHTML = renderResult(result, serialRecords) + learningCardHtml(currentLearningCase, learningMode ? learningMode.value : 'guided', learningAnswer ? learningAnswer.options[learningAnswer.selectedIndex].text : '', true);
				resultActions.hidden = false;
				goToStep(5);
				if (typeof window.CustomEvent === 'function') {
					root.dispatchEvent(new CustomEvent('medipharm-abg-analysis-complete',{detail:{setting:rawInput.clinicalSetting||'unspecified',focus:rawInput.clinicalFocus||'general'}}));
				}
			});
		});


		if (saveTrendButton) saveTrendButton.addEventListener('click', function () {
			if (!lastResult) { showErrors(['Hãy phân tích khí máu trước khi lưu mốc theo dõi.']); return; }
			serialRecords.push(serialRecordFromResult(lastResult, serialRecords.length + 1));
			if(serialRecords.length>12) serialRecords=serialRecords.slice(serialRecords.length-12);
			try { sessionStorage.setItem('medipharm_abg_serial_v24', JSON.stringify(serialRecords)); } catch(e) {}
			refreshSerialTrend();
			if(serialTrendShell) serialTrendShell.scrollIntoView({behavior:'smooth',block:'start'});
		});
		if (clearTrendButton) clearTrendButton.addEventListener('click', function () {
			serialRecords=[]; try { sessionStorage.removeItem('medipharm_abg_serial_v24'); } catch(e) {} refreshSerialTrend();
		});

		root.querySelector('[data-copy-result]').addEventListener('click', function (event) {
			if (!lastResult) {
				return;
			}
			var button = event.currentTarget;
			var original = button.textContent;
			function markCopied() {
				button.textContent = 'Đã sao chép';
				window.setTimeout(function () { button.textContent = original; }, 1800);
			}
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(buildClinicalSummaryText(lastResult, serialRecords)).then(markCopied).catch(function () {
					showErrors(['Trình duyệt không cho phép sao chép tự động.']);
				});
			} else {
				var area = document.createElement('textarea');
				area.value = buildClinicalSummaryText(lastResult, serialRecords);
				document.body.appendChild(area);
				area.select();
				try {
					document.execCommand('copy');
					markCopied();
				} catch (error) {
					showErrors(['Trình duyệt không cho phép sao chép tự động.']);
				}
				area.remove();
			}
		});

		root.querySelector('[data-print-result]').addEventListener('click', function () {
			window.print();
		});

		root.querySelector('[data-reset-form]').addEventListener('click', function () {
			form.reset();
			demoSelect.value = '';
			currentLearningCase = '';
			if (learningPreview) learningPreview.innerHTML = '';
			if (learningAnswer) learningAnswer.value = '';
			lastResult = null;
			resultShell.innerHTML = '<div class="nah-abg__empty"><p>Chọn <strong>Phân tích khí máu</strong> để tạo kết quả.</p></div>';
			resultActions.hidden = true;
			venousWarning.hidden = true;
			form.querySelectorAll('[data-field-feedback]').forEach(function (feedback) { feedback.remove(); });
			form.querySelectorAll('[data-numeric]').forEach(function (field) {
				field.classList.remove('is-invalid', 'is-warning', 'is-valid');
			});
			applyUnitSystem(form, 'si', false);
			pressureSelect.dataset.previousUnit = 'mmhg';
			updatePressureUnit(form, null, 'mmhg');
			goToStep(1);
		});

		applyUnitSystem(form, 'si', false);
		updatePressureUnit(form, null, pressureSelect.value);
		goToStep(1, false);
	}

	function initAll(scope) {
		(scope || document).querySelectorAll('[data-nah-abg-root]').forEach(init);
	}

	document.addEventListener('DOMContentLoaded', function () {
		initAll(document);
	});

	if (document.readyState !== 'loading') {
		initAll(document);
	}

	window.NAHABGInit = initAll;
}());

/* v4.6 — Interactive handbook lesson checks. */
document.addEventListener('click',function(event){
  var option=event.target.closest&&event.target.closest('.nah-abg .nah-abg__lesson-option');
  if(!option)return;
  var quiz=option.closest('[data-lesson-quiz]'); if(!quiz)return;
  var chosen=Number(option.getAttribute('data-lesson-answer')); var correct=Number(quiz.getAttribute('data-answer'));
  quiz.querySelectorAll('.nah-abg__lesson-option').forEach(function(el){el.classList.remove('is-correct','is-wrong'); el.disabled=true;});
  option.classList.add(chosen===correct?'is-correct':'is-wrong');
  var right=quiz.querySelector('[data-lesson-answer="'+correct+'"]'); if(right)right.classList.add('is-correct');
  var feedback=quiz.querySelector('.nah-abg__lesson-feedback'); if(feedback){feedback.hidden=false; var strong=feedback.querySelector('strong'); if(strong)strong.textContent=chosen===correct?'Chính xác':'Chưa đúng';}
});

/* v6.3.7 — Mockup-aligned Home quick start + recent activity. */
(function(){
  'use strict';
  function num(v){ return String(v == null ? '' : v).trim(); }
  function fmtTime(ts){
    ts=Number(ts||0); if(!ts) return 'Trên thiết bị';
    try{return new Intl.DateTimeFormat('vi-VN',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(ts));}catch(e){return 'Gần đây';}
  }
  function setup(root){
    if(!root || root.dataset.v637Ready==='1') return;
    root.dataset.v637Ready='1';
    var quick=root.querySelector('[data-home-quick-abg]');
    if(quick){
      quick.addEventListener('submit',function(e){
        e.preventDefault();
        var targetForm=root.querySelector('[data-abg-form]');
        if(!targetForm) return;
        ['ph','paco2','pao2','hco3','sao2','fio2'].forEach(function(name){
          var src=quick.elements[name], dst=targetForm.elements[name];
          if(src&&dst&&num(src.value)){ dst.value=num(src.value); dst.dispatchEvent(new Event('input',{bubbles:true})); dst.dispatchEvent(new Event('change',{bubbles:true})); }
        });
        var tab=root.querySelector('[data-workspace-tab="analysis"]');
        if(tab) tab.click();
        window.requestAnimationFrame(function(){
          var step1=root.querySelector('[data-form-step="1"]');
          var next=root.querySelector('[data-next-step]');
          if(step1 && !step1.hidden && next) next.click();
          var ph=targetForm.elements.ph; if(ph) ph.focus();
        });
        var status=quick.querySelector('[data-home-quick-status]');
        if(status){status.hidden=false;status.textContent='Đã chuyển các thông số sang biểu mẫu Phân tích khí máu.';}
      });
      quick.addEventListener('reset',function(){var s=quick.querySelector('[data-home-quick-status]');if(s)s.hidden=true;});
    }
    var recent=root.querySelector('[data-home-recent-activity]');
    if(recent){
      var state=null;try{state=JSON.parse(window.localStorage.getItem('medipharm_abg_learning_v30')||'null');}catch(e){}
      var rows=[];
      if(state&&state.platform){
        var analyses=Number(state.platform.analyses||0);
        if(analyses>0) rows.push({icon:'ABG',title:analyses+' lần phân tích khí máu',meta:fmtTime(state.platform.lastAnalysis),value:'Phân tích'});
        var viewed=state.platform.theoryViewed&&typeof state.platform.theoryViewed==='object'?Object.keys(state.platform.theoryViewed).length:0;
        if(viewed>0) rows.push({icon:'▣',title:viewed+' chủ đề đã học',meta:fmtTime(state.platform.lastTheory),value:'Học tập'});
      }
      if(state&&state.assessment&&Number(state.assessment.count||0)>0) rows.push({icon:'✓',title:Number(state.assessment.count)+' lượt đánh giá',meta:'Điểm tốt nhất '+Number(state.assessment.best||0)+'%',value:'Ôn luyện'});
      if(state&&state.exam&&Number(state.exam.count||0)>0) rows.push({icon:'◎',title:Number(state.exam.count)+' bộ ôn luyện',meta:'Điểm tốt nhất '+Number(state.exam.best||0)+'%',value:'Ôn luyện'});
      rows=rows.slice(0,3);
      if(rows.length){recent.innerHTML='<div class="nah-abg__home-recent-list">'+rows.map(function(r){return '<div class="nah-abg__home-recent-row"><i>'+r.icon+'</i><span><strong>'+r.title+'</strong><small>'+r.meta+'</small></span><b>'+r.value+'</b></div>';}).join('')+'</div>';}
    }
  }
  function init(){document.querySelectorAll('[data-nah-abg-root]').forEach(setup);}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else window.setTimeout(init,0);
})();

/* v6.5.0 — Dictionary-first home controls. */
(function(){
  'use strict';
  function norm(v){
    try{return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();}
    catch(e){return String(v||'').toLowerCase().trim();}
  }
  function setup(root){
    if(!root || root.dataset.v650Ready==='1') return;
    root.dataset.v650Ready='1';
    var shell=root.querySelector('[data-home-dictionary]');
    if(!shell) return;
    var input=shell.querySelector('[data-abg-dictionary-search]');
    var alpha=shell.querySelector('[data-abg-dictionary-alpha]');
    var rows=Array.prototype.slice.call(shell.querySelectorAll('.nah-abg__v650-term'));
    var empty=shell.querySelector('[data-abg-dictionary-empty]');
    var activeLetter='all';
    function apply(){
      var q=norm(input&&input.value);
      var count=0;
      rows.forEach(function(row){
        var key=norm(row.getAttribute('data-dictionary-key')||row.textContent);
        var letter=String(row.getAttribute('data-dictionary-letter')||'').toUpperCase();
        var show=(!q || key.indexOf(q)>=0) && (activeLetter==='all' || letter===activeLetter);
        row.hidden=!show;if(show)count++;
      });
      if(empty) empty.hidden=count!==0;
    }
    if(input) input.addEventListener('input',apply);
    if(alpha) alpha.addEventListener('click',function(e){
      var btn=e.target.closest('[data-letter]');if(!btn)return;
      activeLetter=btn.getAttribute('data-letter')||'all';
      alpha.querySelectorAll('[data-letter]').forEach(function(x){x.classList.toggle('is-active',x===btn);});
      apply();
    });
  }
  function init(){document.querySelectorAll('[data-nah-abg-root]').forEach(setup);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else window.setTimeout(init,0);
})();

/* v6.6.0 — Home sample-case launcher. */
(function(){
  'use strict';
  function setup(root){
    if(!root || root.dataset.v660Ready==='1') return;
    root.dataset.v660Ready='1';
    root.querySelectorAll('[data-home-demo]').forEach(function(button){
      button.addEventListener('click',function(){
        var key=button.getAttribute('data-home-demo')||'';
        var select=root.querySelector('[data-classroom-demo-select]');
        var load=root.querySelector('[data-classroom-load-demo]');
        if(select && load && key){ select.value=key; load.click(); return; }
        var cases=root.querySelector('[data-workspace-tab="cases"]'); if(cases) cases.click();
      });
    });
  }
  function init(){document.querySelectorAll('[data-nah-abg-root]').forEach(setup);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else window.setTimeout(init,0);
})();


/* v6.7.4 — Mobile Dock Navigation Reliability Hotfix. */
(function(){
  'use strict';
  if (window.__nahAbgDockRouter674) return;
  window.__nahAbgDockRouter674 = true;
  document.addEventListener('click', function(event){
    var button = event.target && event.target.closest ? event.target.closest('.nah-abg__mobile-dock [data-home-workspace]') : null;
    if (!button) return;
    var root = button.closest('[data-nah-abg-root]');
    if (!root) return;
    var workspace = button.getAttribute('data-home-workspace') || 'home';
    var tab = root.querySelector('[data-workspace-tab="' + workspace + '"]');
    if (!tab) return;
    event.preventDefault();
    event.stopPropagation();
    tab.click();
  }, true);
})();


/* v6.9.1 — Analysis Workspace Simplification. Presentation-only DOM grouping. */
(function(){
  'use strict';
  function fieldByName(panel,name){
    var input=panel && panel.querySelector('[name="'+name+'"]');
    return input ? input.closest('.nah-abg__field,fieldset') : null;
  }
  function makeDisclosure(panel,title,names){
    if(!panel || panel.querySelector('[data-abg691-disclosure="'+title+'"]')) return;
    var nodes=[];
    names.forEach(function(name){var node=fieldByName(panel,name);if(node && nodes.indexOf(node)<0)nodes.push(node);});
    if(!nodes.length)return;
    var details=document.createElement('details');details.className='nah-abg__analysis-disclosure';details.setAttribute('data-abg691-disclosure',title);
    var summary=document.createElement('summary');summary.textContent=title;details.appendChild(summary);
    var body=document.createElement('div');body.className='nah-abg__analysis-disclosure-body';details.appendChild(body);
    nodes.forEach(function(node){body.appendChild(node);});
    var grid=panel.querySelector(':scope > .nah-abg__grid');
    if(grid)grid.appendChild(details);else panel.appendChild(details);
  }
  function setup(root){
    if(!root || root.dataset.abg691Ready==='1')return;root.dataset.abg691Ready='1';
    var analysis=root.querySelector('[data-workspace-panel="analysis"]');if(!analysis)return;
    makeDisclosure(analysis.querySelector('[data-form-step="1"]'),'Cài đặt phân tích nâng cao',['unitSystem','gasPressureUnit','chronicity']);
    makeDisclosure(analysis.querySelector('[data-form-step="2"]'),'Thông số khí máu bổ sung',['priorLactate','lactateIntervalHours','cohb','methb']);
    makeDisclosure(analysis.querySelector('[data-form-step="3"]'),'Xét nghiệm tìm nguyên nhân',['urea','creatinine','ketones','measuredOsm','urineChloride','urinePh']);
    makeDisclosure(analysis.querySelector('[data-form-step="4"]'),'Thông tin hỗ trợ hô hấp nâng cao',['peep','atmosphericPressure','hemoglobin']);
    var demo=analysis.querySelector('.nah-abg__demo');if(demo)demo.setAttribute('aria-hidden','true');
    var prev=analysis.querySelector('[data-prev-step]');
    if(prev){
      var observer=new MutationObserver(function(){
        var result=analysis.querySelector('[data-form-step="5"]');
        prev.textContent=result && !result.hidden?'← Quay lại chỉnh dữ liệu':'← Quay lại';
      });
      observer.observe(analysis,{subtree:true,attributes:true,attributeFilter:['hidden']});
    }
  }
  function init(){document.querySelectorAll('[data-nah-abg-root]').forEach(setup);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else window.setTimeout(init,0);
})();

(function(){
'use strict';
var challenges=[
 {v:'pH 7,28 · PaCO₂ 30 · HCO₃⁻ 14',o:['Toan chuyển hóa','Toan hô hấp','Kiềm hô hấp'],a:0,f:'pH giảm và HCO₃⁻ giảm phù hợp toan chuyển hóa; PaCO₂ giảm gợi ý đáp ứng hô hấp.'},
 {v:'pH 7,52 · PaCO₂ 28 · HCO₃⁻ 22',o:['Kiềm hô hấp','Kiềm chuyển hóa','Toan chuyển hóa'],a:0,f:'pH tăng kèm PaCO₂ giảm định hướng kiềm hô hấp.'},
 {v:'pH 7,30 · PaCO₂ 60 · HCO₃⁻ 29',o:['Toan hô hấp','Toan chuyển hóa','Kiềm chuyển hóa'],a:0,f:'pH giảm kèm PaCO₂ tăng định hướng toan hô hấp; HCO₃⁻ tăng phản ánh đáp ứng chuyển hóa.'},
 {v:'pH 7,48 · PaCO₂ 47 · HCO₃⁻ 34',o:['Kiềm chuyển hóa','Kiềm hô hấp','Toan hô hấp'],a:0,f:'pH tăng kèm HCO₃⁻ tăng định hướng kiềm chuyển hóa; PaCO₂ tăng theo hướng bù.'}
];
function init(root,index){
 var values=root.querySelector('[data-abg-launcher-values]'),opts=root.querySelector('[data-abg-launcher-options]'),feedback=root.querySelector('[data-abg-launcher-feedback]'),seedOut=root.querySelector('[data-abg-launcher-seed]'),seedBtn=root.querySelector('[data-abg-launcher-generate]'),seedLink=root.querySelector('[data-abg-launcher-generator-link]'),app=root.getAttribute('data-app-url')||'/phan-tich-khi-mau-app/',pos=index%challenges.length;
 function renderChallenge(){var c=challenges[pos];if(!values||!opts||!feedback)return;values.textContent=c.v;feedback.textContent='Chọn diễn giải phù hợp nhất.';feedback.className='';opts.innerHTML='';c.o.forEach(function(label,i){var b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',function(){opts.querySelectorAll('button').forEach(function(x){x.disabled=true;});b.classList.add(i===c.a?'is-correct':'is-wrong');feedback.textContent=(i===c.a?'Chính xác. ':'Chưa đúng. ')+c.f;feedback.className=i===c.a?'is-correct':'is-wrong';window.setTimeout(function(){pos=(pos+1)%challenges.length;renderChallenge();},4200);});opts.appendChild(b);});}
 function makeSeed(){var seed=((Date.now()^Math.floor(Math.random()*2147483647))>>>0)||55001;if(seedOut)seedOut.textContent=String(seed);if(seedLink){try{var u=new URL(app,window.location.origin);u.searchParams.set('view','exam');u.searchParams.set('blueprint','generator');u.searchParams.set('seed',String(seed));seedLink.href=u.toString();}catch(e){seedLink.href=app+'?view=exam&blueprint=generator&seed='+encodeURIComponent(seed);}}}
 if(seedBtn)seedBtn.addEventListener('click',makeSeed);renderChallenge();
}
document.querySelectorAll('[data-abg-launcher]').forEach(init);
})();

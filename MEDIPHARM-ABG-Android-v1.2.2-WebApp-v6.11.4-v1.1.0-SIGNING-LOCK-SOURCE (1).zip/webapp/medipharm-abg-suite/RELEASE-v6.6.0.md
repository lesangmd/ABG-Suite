# MEDIPHARM ABG Suite v6.6.0 — Action-First Clinical Home

## Scope
- Bỏ hoàn toàn khối Tài nguyên nổi bật khỏi Trang chủ.
- Đổi nhóm card Trang chủ sang 5 hành động có ý nghĩa trực tiếp: Phân tích mới, Ca lâm sàng mẫu, Hỏi đáp lâm sàng, Từ điển học tập, Ôn luyện.
- Đưa ba ca mẫu DKA, COPD/toan hô hấp cấp và thuyên tắc phổi/giảm oxy lên Trang chủ; bấm card sẽ nạp trực tiếp ca mẫu vào luồng thực hành.
- Thêm khối Hỏi đáp nhanh trên Trang chủ, dẫn tới phần Hỏi đáp trong Ôn luyện.
- Giữ Từ điển học tập làm khối nội dung chính; Hoạt động gần đây chuyển thành khối phụ phía dưới.
- Tinh gọn workspace Phân tích khí máu: header thấp hơn, progress bar gọn/sticky và chiều rộng biểu mẫu thống nhất.

## Preserved
- Calculation core không thay đổi.
- Dữ liệu, ca lâm sàng, ngân hàng câu hỏi và luồng xác thực giữ nguyên.

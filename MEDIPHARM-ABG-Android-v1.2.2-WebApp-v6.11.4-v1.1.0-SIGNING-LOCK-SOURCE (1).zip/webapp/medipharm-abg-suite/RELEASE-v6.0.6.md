# MEDIPHARM ABG Suite v6.0.6 — Mobile/Tablet Header Compaction Hotfix

**Parent:** v6.0.5 — Menu Layering & Trial Footer Cleanup Hotfix

## Thay đổi
- Tablet/mobile `<=1024px`: ẩn tên ứng dụng, chỉ giữ logo ABG.
- Nhường toàn bộ chiều ngang còn lại cho hộp tìm kiếm và nút Menu.
- Desktop `>1024px`: giữ nguyên logo + tên ứng dụng.
- Không thay đổi calculation core, trial gate, footer, menu layering, Search Dock ownership, assessment corpus, Sổ tay, ca lâm sàng, route hoặc localStorage.

## Acceptance
- Không có tên ứng dụng ở 1024/820/768/430/390/360px.
- Search và Menu cùng hàng, không overflow ngang.
- Desktop 1025px trở lên vẫn hiển thị tên ứng dụng.

# MEDIPHARM ABG Suite v6.0.4 — Trial Footer Copy Deduplication Hotfix

**Parent:** v6.0.3 — Trial Gate Navigation & Action-Level Access Hotfix  
**Parent SHA-256:** `1b2e5928971a127eeabe07b350c64cd929b2825c1a041e8a6094abf96c39f9d1`

## Thay đổi
- Bỏ cụm CTA lặp `Đăng ký/Đăng nhập` ở cuối footer dùng thử.
- Footer khách chỉ còn một câu duy nhất:
  **Còn x/10 lượt dùng thử. Vui lòng Đăng nhập hoặc Đăng ký tài khoản để truy cập đầy đủ mọi nội dung.**
- `Đăng nhập` mở form Membership/Clinical Access hiện có.
- `Đăng ký tài khoản` dẫn trực tiếp tới `/dangky`.

## Không thay đổi
- Trial action-level gate và quota 10 lượt.
- Route `/phan-tich-khi-mau-app/`.
- Calculation core.
- 220 câu, 50 bài, 50 ca, 8 bộ thi.
- LocalStorage, remediation, longitudinal analytics, Search Dock layering.

## QA
- PHP: **2/2 PASS**
- JavaScript syntax: **75/75 PASS**
- Regression/static: **69 PASS / 1 UI smoke SKIP / 0 FAIL**
- ZIP CRC: **PASS**
- Clean extraction: **PASS**
- Calculation core SHA-256 unchanged: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`

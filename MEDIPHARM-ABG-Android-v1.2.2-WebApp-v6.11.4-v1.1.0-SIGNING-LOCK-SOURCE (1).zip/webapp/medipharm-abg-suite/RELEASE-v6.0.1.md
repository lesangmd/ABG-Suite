# MEDIPHARM ABG Suite v6.0.1 — Landing Page Visual Refresh & Trial Footer Hotfix

**Parent:** v6.0 – Integrated ABG Learning & Assessment Platform  
**Parent SHA-256:** `016f2b28fbe4512ac0d41faeb211476b42f456013e10a4c651e25ab76e375280`

## Phạm vi

Bản v6.0.1 là hotfix UI/UX cho landing page. Không thay đổi calculation core, corpus lâm sàng, assessment scoring, localStorage, remediation, longitudinal analytics, integrated session hoặc access policy.

## Landing page

- Bỏ eyebrow “HỌC KHÍ MÁU THEO CÁCH THỰC HÀNH” để tránh lặp tiêu đề.
- Hero chỉ còn một H1: **Khám phá khí máu lâm sàng**.
- Mô tả chính: **Khám phá khí máu theo cách trực quan, dễ nhớ và sát lâm sàng: học nhanh, luyện ngắn, phân tích ngay và tiến bộ sau mỗi lần quay lại.**
- CTA phụ đổi từ “Vào Học tập” thành **Khám phá bài học**.
- Chip hero đổi thành: Điểm cần nhớ · Thử một câu nhanh · Giải ca 60 giây · Luyện theo tình huống.
- Thêm strip 220 câu · 50 bài · 50 ca · 8 bộ thi thử.
- Đồ họa hero mới gồm vòng ABG trung tâm, thẻ PaCO₂/HCO₃⁻/PaO₂ và đường sóng sinh lý; responsive trên desktop/tablet/mobile và có dark-mode surface.
- Microcopy của các module landing được chỉnh theo giọng mời gọi, trực quan và sát lâm sàng.

## Trial footer

- Xóa thanh trạng thái “DÙNG THỬ / Còn x/10 lượt” phía trên điều hướng ứng dụng.
- Guest footer bên trái dùng đúng wording:
  **Còn x/10 lượt dùng thử. Vui lòng đăng nhập hoặc đăng ký để truy cập đầy đủ. Đăng ký/Đăng nhập**
- `đăng nhập`, `đăng ký` và `Đăng ký/Đăng nhập` dẫn tới chính form do Membership / Clinical Access hiện có sở hữu.
- Mở form thành viên bằng `?access=member` không tiêu hao thêm lượt dùng thử.
- Thành viên chỉ thấy trạng thái ngắn gọn “Thành viên · Toàn quyền truy cập”.

## Invariants

- Assessment: 220 câu canonical / 6 dạng câu hỏi.
- Sổ tay: 50 bài.
- Ca lâm sàng: 50 ca.
- Mock tests: 8 bộ.
- Trial limit: 10 lượt.
- localStorage: `medipharm_abg_learning_v30`.
- Route: `/phan-tich-khi-mau-app/`.
- Calculation core SHA-256: `92118288f114f88238f79d332136492ba1faa9fee2151f2c1ae178b28bb87b02`.

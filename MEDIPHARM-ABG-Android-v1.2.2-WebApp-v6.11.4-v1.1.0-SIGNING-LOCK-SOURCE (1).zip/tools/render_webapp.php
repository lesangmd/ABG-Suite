<?php
error_reporting(E_ALL & ~E_DEPRECATED);
define('ABSPATH', '/fake/');
define('MEDIPHARM_ABG_SUITE_VERSION', '6.11.4');
define('MEDIPHARM_ABG_SUITE_URL', 'https://app.medipharm.local/');
function shortcode_atts($defaults,$atts,$shortcode=''){return array_merge($defaults,(array)$atts);}
function home_url($path='/'){return 'https://app.medipharm.local'.($path[0]=='/'?$path:'/'.$path);}
function admin_url($path=''){return home_url('/wp-admin/'.$path);}
function apply_filters($name,$value,...$args){return $value;}
function get_current_user_id(){return 0;}
function is_user_logged_in(){return false;}
function wp_localize_script(...$args){}
function wp_register_style(...$args){}
function wp_register_script(...$args){}
function wp_enqueue_style(...$args){}
function wp_enqueue_script(...$args){}
function wp_unique_id($prefix=''){static $id=0;return $prefix.(++$id);}
function esc_url($x){return htmlspecialchars($x,ENT_QUOTES,'UTF-8');}
function esc_attr($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function esc_html($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function sanitize_text_field($x){return (string)$x;}
function wp_create_nonce($a){return '';}
function wp_unslash($x){return $x;}
function is_ssl(){return false;}
function medipharm_abg_suite_is_android_shell(){return true;}
function medipharm_abg_suite_android_apk_url(){return '';}
function wp_json_encode($x,...$args){return json_encode($x,...$args);}
function wp_salt($a){return 'local';}
function wp_lostpassword_url(){return home_url("/quen-mat-khau/");}
function wp_parse_url($s,$c=-1){return parse_url($s,$c);}
function sanitize_key($v){return preg_replace('/[^a-z0-9_-]/','',strtolower($v));}
require dirname(__DIR__).'/webapp/medipharm-abg-suite/class-medipharm-abg-suite-module.php';
ob_start();
echo MEDIPHARM_ABG_Suite_Module::instance()->render_analyzer(['context'=>'standalone','title'=>'ABG','app_url'=>'https://app.medipharm.local/','enqueue'=>'0']);
file_put_contents(dirname(__DIR__).'/rendered_main.html',ob_get_clean());
echo strlen(file_get_contents(dirname(__DIR__).'/rendered_main.html'))." bytes\n";

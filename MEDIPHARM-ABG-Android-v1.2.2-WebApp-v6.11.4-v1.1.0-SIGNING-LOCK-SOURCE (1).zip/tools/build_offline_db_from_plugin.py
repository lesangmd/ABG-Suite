#!/usr/bin/env python3
"""Build v1.2.2 offline content from the user supplied MEDIPHARM ABG Suite v6.11.4 zip.
Requires PHP to run render.php first; never reads network resources.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sqlite3, re, base64, mimetypes

ROOT=Path(__file__).resolve().parents[1]
PLUGIN=ROOT/'webapp/medipharm-abg-suite'
ASSETS=PLUGIN/'assets'
MAIN=(ROOT/'rendered_main.html').read_text(encoding='utf8')
css=(ASSETS/'css/nah-abg.css').read_text(encoding='utf8')
core=(ASSETS/'js/nah-abg-core.js').read_text(encoding='utf8')
ui=(ASSETS/'js/nah-abg-ui.js').read_text(encoding='utf8')
canonical=(ASSETS/'js/nah-abg-canonical-learning.js').read_text(encoding='utf8')
for name in ('abg-hero-backdrop.svg', 'abg-login-backdrop.svg'):
    raw=(ASSETS/'graphics'/name).read_bytes()
    uri='data:image/svg+xml;base64,'+base64.b64encode(raw).decode()
    css=css.replace("../graphics/"+name,uri)
# Inline referenced icon graphics so the database has no dependency on external requests.
for path in (ASSETS/'icons').iterdir():
    if path.suffix.lower() in ('.png','.svg'):
        src='https://app.medipharm.local/assets/icons/'+path.name
        mime='image/svg+xml' if path.suffix=='.svg' else 'image/png'
        uri='data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()
        MAIN=MAIN.replace(src,uri)
        css=css.replace('../icons/'+path.name,uri)
assert 'https://app.medipharm.local/assets/icons/' not in MAIN
# SQLite runtime HTML may not request external learning resources: ship all of them with the HTML.
learning={str(p.relative_to(ASSETS/'data/learning')).replace('\\','/'):p.read_text('utf8') for p in (ASSETS/'data/learning').rglob('*') if p.is_file()}
learning_js='''(function(){\n"use strict";\nvar resources=__RESOURCES__;\nvar original=window.fetch.bind(window);\nwindow.fetch=function(input,init){\n  var uri=(typeof input==="string"?input:(input&&input.url)||"");\n  var prefix="https://app.medipharm.local/assets/data/learning/";\n  if(uri.indexOf(prefix)===0){\n    var key=decodeURIComponent(uri.slice(prefix.length).split("?")[0]);\n    if(Object.prototype.hasOwnProperty.call(resources,key)){\n      return Promise.resolve(new Response(resources[key],{status:200,headers:{"Content-Type":/\\.json$/i.test(key)?"application/json; charset=utf-8":"text/plain; charset=utf-8"}}));\n    }\n    return Promise.resolve(new Response("Not found",{status:404}));\n  }\n  return original(input,init);\n};\n})();'''.replace('__RESOURCES__',json.dumps(learning,ensure_ascii=False,separators=(',',':')))
config={'version':'6.11.4','manifestUrl':'','swUrl':'','appUrl':'https://app.medipharm.local/','isHttps':False,'learningBaseUrl':'https://app.medipharm.local/assets/data/learning/','learningVersion':'1.0.1'}
access={'member':True,'limit':999,'remaining':999,'exhausted':False,'ajaxUrl':'','nonce':'','registerUrl':'','openLogin':False}
# Old no-op access UI: authentication is enforced by native Android before rendering.
MAIN=re.sub(r'data-abg-member-access="[01]"','data-abg-member-access="1"',MAIN)
MAIN=re.sub(r'data-abg-trial-remaining="\d+"','data-abg-trial-remaining="999"',MAIN)
# Keep Android native actions; no duplicate install buttons and no home-web shortcut.
MAIN=re.sub(r'<a\s+class="nah-abg__menu-item"\s+href="medipharmabg://login".*?</a>','<a class="nah-abg__menu-item" href="medipharmabg://account">Tài khoản</a>',MAIN,flags=re.S,count=1)
MAIN=re.sub(r'<a\s+class="nah-abg__menu-item"\s+href="medipharmabg://register".*?</a>','<a class="nah-abg__menu-item" href="medipharmabg://logout">Đăng xuất</a>',MAIN,flags=re.S,count=1)
MAIN=re.sub(r'<div class="nah-abg__trial-overlay"[\s\S]*?<div class="nah-abg__workspace-frame">','<div class="nah-abg__workspace-frame">',MAIN,count=1)
bridge='''(function(){document.documentElement.classList.add('medipharm-abg-offline');window.MEDIPHARMABG_OFFLINE={appVersion:'1.2.2',dataVersion:'ABG-WEB-6.11.4'};document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href^="http://"],a[href^="https://"]');if(a){e.preventDefault();}},true);})();'''
html='<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0867d8"><title>Khí Máu</title><style>'+css+'</style></head><body class="nah-sdp-abg-app-body"><main>'+MAIN+'</main><script>window.NAHABGConfig='+json.dumps(config,ensure_ascii=False)+';window.NAHABGAccess='+json.dumps(access,ensure_ascii=False)+';</script><script>'+learning_js+'</script><script>'+core+'</script><script>'+ui+'</script><script>'+canonical+'</script><script>'+bridge+'</script></body></html>'
assert 'data-workspace-tab="more"' not in html
assert 'data-canonical-tab="qa"' not in html
assert 'medipharmabg://check-update' in html
assert 'data-abg-info="about"' in html
assert 'data-abg-viewport-overlay' in html
assert '6.11.4' in html
out=ROOT/'abg_offline_v122.db'
if out.exists():out.unlink()
db=sqlite3.connect(out)
db.execute('CREATE TABLE app_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
db.execute('CREATE TABLE runtime_assets (key TEXT PRIMARY KEY,mime_type TEXT NOT NULL,content BLOB NOT NULL,sha256 TEXT NOT NULL)')
db.execute('CREATE TABLE content_files (path TEXT PRIMARY KEY,mime_type TEXT NOT NULL,content BLOB NOT NULL,sha256 TEXT NOT NULL)')
db.execute('CREATE TABLE schema_info (schema_version INTEGER NOT NULL,generated_at TEXT NOT NULL)')
generated=datetime.now(timezone.utc).isoformat();db.execute('INSERT INTO schema_info VALUES (?,?)',(1,generated))
meta={'app_version':'1.2.2','data_version':'ABG-WEB-6.11.4','web_source_version':'6.11.4','web_source_url':'local-MEDIPHARM-ABG-Suite-v6.11.4','generated_at':generated,'runtime_mode':'sqlite-self-contained-html','network_policy':'online-auth-and-update-only'}
db.executemany('INSERT INTO app_meta(key,value) VALUES (?,?)',meta.items())
for k,mime,b in [('runtime_html','text/html; charset=utf-8',html.encode()),('nah-abg.css','text/css; charset=utf-8',css.encode()),('nah-abg-core.js','application/javascript; charset=utf-8',core.encode()),('nah-abg-ui.js','application/javascript; charset=utf-8',ui.encode()),('nah-abg-canonical-learning.js','application/javascript; charset=utf-8',canonical.encode())]:
    db.execute('INSERT INTO runtime_assets VALUES (?,?,?,?)',(k,mime,b,hashlib.sha256(b).hexdigest()))
for path,value in learning.items():
    content=value.encode(); mime='application/json' if path.endswith('.json') else 'text/plain'
    db.execute('INSERT INTO content_files VALUES (?,?,?,?)',('learning/'+path,mime,content,hashlib.sha256(content).hexdigest()))
for path in PLUGIN.glob('*.json'):
    content=path.read_bytes();db.execute('INSERT OR REPLACE INTO content_files VALUES (?,?,?,?)',(path.name,'application/json',content,hashlib.sha256(content).hexdigest()))
db.commit();db.execute('VACUUM');db.close()
print(json.dumps({'db':str(out),'db_bytes':out.stat().st_size,'runtime_bytes':len(html.encode()),'source_version':'6.11.4','sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))
